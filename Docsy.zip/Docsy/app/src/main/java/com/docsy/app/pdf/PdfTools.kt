package com.docsy.app.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import androidx.exifinterface.media.ExifInterface
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.cos.COSBase
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDDocumentInformation
import com.tom_roush.pdfbox.pdmodel.PDResources
import com.tom_roush.pdfbox.pdmodel.encryption.AccessPermission
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import com.tom_roush.pdfbox.pdmodel.encryption.StandardProtectionPolicy
import com.tom_roush.pdfbox.pdmodel.graphics.form.PDFormXObject
import com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import com.docsy.app.util.FileUtils
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.io.OutputStream
import kotlin.math.max
import kotlin.math.min

object PdfEngine {
    @Volatile private var ready = false

    fun init(context: Context) {
        if (ready) return
        synchronized(this) {
            if (!ready) {
                PDFBoxResourceLoader.init(context.applicationContext)
                ready = true
            }
        }
    }
}

sealed interface ToolResult {
    data class Done(val message: String) : ToolResult
    data class Failed(val message: String) : ToolResult
}

enum class CompressLevel(val label: String, val quality: Float, val maxDim: Int) {
    LIGHT("Light", 0.80f, 2400),
    BALANCED("Balanced", 0.65f, 1600),
    STRONG("Strong", 0.45f, 1100),
}

/**
 * Page and file tools. Every tool reads the input(s), then writes a NEW file to a location the
 * user picked, so originals are never modified.
 */
object PdfTools {
    const val PAGES_ENCRYPTED = -1
    const val PAGES_INVALID = -2

    private const val TEMP_PREFIX = "docsy_tmp_"

    /** Page count of a PDF, or [PAGES_ENCRYPTED] / [PAGES_INVALID]. */
    suspend fun inspect(ctx: Context, uri: Uri): Int = withContext(Dispatchers.IO) {
        val pfd = try {
            ctx.contentResolver.openFileDescriptor(uri, "r")
        } catch (e: Exception) {
            null
        } ?: return@withContext PAGES_INVALID
        pfd.use {
            try {
                val r = PdfRenderer(it)
                try {
                    r.pageCount
                } finally {
                    r.close()
                }
            } catch (e: SecurityException) {
                PAGES_ENCRYPTED
            } catch (e: Exception) {
                PAGES_INVALID
            }
        }
    }

    /** Parses "1-3, 5, 8-" into 0-based page indexes (in the order typed), or null if invalid. */
    fun parsePages(spec: String, total: Int): List<Int>? {
        val out = LinkedHashSet<Int>()
        val parts = spec.split(',', ';').map { it.trim() }.filter { it.isNotEmpty() }
        if (parts.isEmpty()) return null
        for (p in parts) {
            val a: Int
            val b: Int
            if ('-' in p) {
                val (l, r) = p.split('-', limit = 2).map { it.trim() }
                a = if (l.isEmpty()) 1 else l.toIntOrNull() ?: return null
                b = if (r.isEmpty()) total else r.toIntOrNull() ?: return null
            } else {
                a = p.toIntOrNull() ?: return null
                b = a
            }
            if (a < 1 || b > total || a > b) return null
            for (x in a..b) out.add(x - 1)
        }
        return out.toList()
    }

    fun querySize(ctx: Context, uri: Uri): Long = runCatching {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else -1L
        }
    }.getOrNull() ?: -1L

    // ---- Tools ----

    suspend fun merge(ctx: Context, inputs: List<Uri>, out: Uri): ToolResult =
        exec(ctx, out, { "Merged ${inputs.size} files into one PDF (${FileUtils.formatSize(it)})." }) { os ->
            val temps = ArrayList<File>()
            val docs = ArrayList<PDDocument>()
            try {
                val dest = PDDocument()
                docs += dest
                val merger = PDFMergerUtility()
                for (u in inputs) {
                    val f = copyToTemp(ctx, u)
                    temps += f
                    val d = PDDocument.load(f)
                    docs += d
                    merger.appendDocument(dest, d)
                }
                dest.save(os)
            } finally {
                docs.forEach { runCatching { it.close() } }
                temps.forEach { it.delete() }
            }
        }

    suspend fun extractPages(ctx: Context, input: Uri, pages: List<Int>, out: Uri): ToolResult =
        exec(ctx, out, { "Extracted ${pages.size} page(s) (${FileUtils.formatSize(it)})." }) { os ->
            withDoc(ctx, input, "") { src ->
                val dest = PDDocument()
                try {
                    pages.forEach { dest.importPage(src.getPage(it)) }
                    dest.save(os)
                } finally {
                    dest.close()
                }
            }
        }

    suspend fun deletePages(ctx: Context, input: Uri, pages: List<Int>, out: Uri): ToolResult =
        exec(ctx, out, { "Deleted ${pages.size} page(s) (${FileUtils.formatSize(it)})." }) { os ->
            withDoc(ctx, input, "") { doc ->
                if (pages.size >= doc.numberOfPages) throw IOException("A PDF must keep at least one page.")
                pages.sortedDescending().forEach { doc.removePage(it) }
                doc.save(os)
            }
        }

    suspend fun rotatePages(ctx: Context, input: Uri, pages: List<Int>?, angle: Int, out: Uri): ToolResult =
        exec(ctx, out, { "Rotated pages by $angle° (${FileUtils.formatSize(it)})." }) { os ->
            withDoc(ctx, input, "") { doc ->
                val targets = pages ?: (0 until doc.numberOfPages).toList()
                targets.forEach { i ->
                    val p = doc.getPage(i)
                    p.rotation = (((p.rotation + angle) % 360) + 360) % 360
                }
                doc.save(os)
            }
        }

    suspend fun compress(
        ctx: Context,
        input: Uri,
        level: CompressLevel,
        stripMetadata: Boolean,
        out: Uri,
    ): ToolResult {
        val before = querySize(ctx, input)
        return exec(ctx, out, { after ->
            if (before > 0 && after in 1 until before) {
                val pct = ((before - after) * 100 / before).toInt()
                "Reduced from ${FileUtils.formatSize(before)} to ${FileUtils.formatSize(after)} (−$pct%)."
            } else {
                "Saved (${FileUtils.formatSize(after)}), but this file could not be made smaller. " +
                    "Compression only recompresses embedded photos; text and vector PDFs are already compact."
            }
        }) { os ->
            withDoc(ctx, input, "") { doc ->
                recompressImages(doc, level.quality, level.maxDim)
                if (stripMetadata) {
                    doc.documentInformation = PDDocumentInformation()
                    doc.documentCatalog.metadata = null
                }
                doc.save(os)
            }
        }
    }

    suspend fun protect(ctx: Context, input: Uri, password: String, out: Uri): ToolResult =
        exec(ctx, out, { "Password-protected copy saved (${FileUtils.formatSize(it)})." }) { os ->
            withDoc(ctx, input, "") { doc ->
                if (doc.isEncrypted) throw IOException("This PDF is already protected.")
                val policy = StandardProtectionPolicy(password, password, AccessPermission())
                policy.encryptionKeyLength = 128
                policy.setPreferAES(true)
                doc.protect(policy)
                doc.save(os)
            }
        }

    suspend fun unlock(ctx: Context, input: Uri, password: String, out: Uri): ToolResult =
        exec(ctx, out, { "Unlocked copy saved (${FileUtils.formatSize(it)})." }) { os ->
            withDoc(ctx, input, password) { doc ->
                if (!doc.isEncrypted) throw IOException("This PDF is not password-protected.")
                doc.isAllSecurityToBeRemoved = true
                doc.save(os)
            }
        }

    suspend fun imagesToPdf(ctx: Context, images: List<Uri>, out: Uri): ToolResult =
        exec(ctx, out, { "Created a ${images.size}-page PDF (${FileUtils.formatSize(it)})." }) { os ->
            val pdf = PdfDocument()
            try {
                val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
                images.forEachIndexed { i, u ->
                    val bmp = decodeImage(ctx, u) ?: throw IOException("Could not read image ${i + 1}.")
                    try {
                        val landscape = bmp.width > bmp.height
                        val pw = if (landscape) 842 else 595
                        val ph = if (landscape) 595 else 842
                        val page = pdf.startPage(PdfDocument.PageInfo.Builder(pw, ph, i + 1).create())
                        val c = page.canvas
                        c.drawColor(Color.WHITE)
                        val s = min(pw / bmp.width.toFloat(), ph / bmp.height.toFloat())
                        val dw = bmp.width * s
                        val dh = bmp.height * s
                        c.drawBitmap(
                            bmp,
                            null,
                            RectF((pw - dw) / 2f, (ph - dh) / 2f, (pw + dw) / 2f, (ph + dh) / 2f),
                            paint,
                        )
                        pdf.finishPage(page)
                    } finally {
                        bmp.recycle()
                    }
                }
                pdf.writeTo(os)
            } finally {
                pdf.close()
            }
        }

    // ---- Internals ----

    private suspend fun exec(
        ctx: Context,
        out: Uri,
        success: (Long) -> String,
        work: (OutputStream) -> Unit,
    ): ToolResult = withContext(Dispatchers.IO) {
        PdfEngine.init(ctx)
        val cr = ctx.contentResolver
        try {
            val stream = cr.openOutputStream(out, "wt")
                ?: return@withContext ToolResult.Failed("Could not write the output file.")
            stream.use { work(it) }
            ToolResult.Done(success(querySize(ctx, out)))
        } catch (e: CancellationException) {
            runCatching { DocumentsContract.deleteDocument(cr, out) }
            throw e
        } catch (e: Throwable) {
            runCatching { DocumentsContract.deleteDocument(cr, out) }
            ToolResult.Failed(describe(e))
        }
    }

    private fun describe(e: Throwable): String = when (e) {
        is InvalidPasswordException ->
            "The password is wrong, or this PDF is protected. Use the Unlock tool with the correct password first."
        is OutOfMemoryError -> "Not enough memory for this file. Try a smaller document."
        is IOException -> e.message?.takeIf { it.isNotBlank() }?.let { "Could not process this PDF: $it" }
            ?: "Could not read or write this file."
        is SecurityException -> "Permission to this file was lost. Pick it again."
        else -> "Something went wrong: ${e.message ?: e.javaClass.simpleName}"
    }

    private fun copyToTemp(ctx: Context, uri: Uri): File {
        val f = File(ctx.cacheDir, TEMP_PREFIX + System.nanoTime() + ".pdf")
        try {
            ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                ?: throw IOException("Could not open the selected file.")
        } catch (e: Throwable) {
            f.delete()
            throw e
        }
        return f
    }

    private fun <T> withDoc(ctx: Context, uri: Uri, password: String, block: (PDDocument) -> T): T {
        val f = copyToTemp(ctx, uri)
        try {
            PDDocument.load(f, password).use { return block(it) }
        } finally {
            f.delete()
        }
    }

    private fun recompressImages(doc: PDDocument, quality: Float, maxDim: Int) {
        val cache = HashMap<COSBase, PDImageXObject?>()

        fun processResources(res: PDResources?, depth: Int) {
            if (res == null || depth > 4) return
            for (name in res.xObjectNames.toList()) {
                val xo = runCatching { res.getXObject(name) }.getOrNull() ?: continue
                when (xo) {
                    is PDImageXObject -> {
                        val key: COSBase = xo.cosObject
                        val repl = if (cache.containsKey(key)) cache[key] else {
                            val r = runCatching { recompress(doc, xo, quality, maxDim) }.getOrNull()
                            cache[key] = r
                            r
                        }
                        if (repl != null) res.put(name, repl)
                    }
                    is PDFormXObject -> processResources(xo.resources, depth + 1)
                    else -> Unit
                }
            }
        }
        for (page in doc.pages) processResources(page.resources, 0)
    }

    private fun recompress(doc: PDDocument, xo: PDImageXObject, quality: Float, maxDim: Int): PDImageXObject? {
        if (xo.isStencil || xo.softMask != null || xo.mask != null) return null
        if (xo.width < 64 || xo.height < 64) return null
        val oldLen = xo.cosObject.length
        val bmp = try {
            xo.image
        } catch (e: OutOfMemoryError) {
            return null
        } ?: return null
        var scaled: Bitmap = bmp
        try {
            val scale = min(1f, maxDim / max(bmp.width, bmp.height).toFloat())
            if (scale < 1f) {
                scaled = Bitmap.createScaledBitmap(
                    bmp,
                    max(1, (bmp.width * scale).toInt()),
                    max(1, (bmp.height * scale).toInt()),
                    true,
                )
            }
            val jpg = JPEGFactory.createFromImage(doc, scaled, quality)
            return if (jpg.cosObject.length < oldLen * 0.95) jpg else null
        } catch (e: OutOfMemoryError) {
            return null
        } finally {
            if (scaled !== bmp) scaled.recycle()
            bmp.recycle()
        }
    }

    private fun decodeImage(ctx: Context, uri: Uri): Bitmap? {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > 2200) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null

        val orientation = runCatching {
            cr.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            }
        }.getOrNull() ?: ExifInterface.ORIENTATION_NORMAL

        val m = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
            else -> return bmp
        }
        val fixed = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        if (fixed !== bmp) bmp.recycle()
        return fixed
    }
}
