package com.docsy.app.pdf

import android.content.Context
import android.graphics.RectF
import android.net.Uri
import android.os.SystemClock
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.outline.PDOutlineItem
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.Closeable
import java.io.File
import java.io.IOException
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** One search match. [rects] are normalised (0..1, origin top-left) in the page's unrotated view. */
data class SearchHit(val page: Int, val rects: List<RectF>)

data class OutlineEntry(val title: String, val page: Int, val level: Int)

/**
 * Text layer access (search + table of contents) backed by PDFBox. The document is parsed lazily
 * on first use and all access is serialised, because PDFBox documents are not thread-safe.
 */
class PdfTextIndex(
    private val app: Context,
    private val uri: Uri,
    private val session: PdfSession,
) : Closeable {

    private val mutex = Mutex()
    private var doc: PDDocument? = null
    private var ownedFile: File? = null
    @Volatile private var closed = false

    private fun docLocked(): PDDocument {
        if (closed) throw IOException("closed")
        doc?.let { return it }
        PdfEngine.init(app)
        val file = session.backingFile ?: File(app.cacheDir, "docsy_tmp_idx_${System.nanoTime()}.pdf").also { target ->
            ownedFile = target
            app.contentResolver.openInputStream(uri)?.use { i -> target.outputStream().use { o -> i.copyTo(o) } }
                ?: throw IOException("unreadable")
        }
        return PDDocument.load(file).also { doc = it }
    }

    suspend fun search(query: String, onProgress: (List<SearchHit>) -> Unit): List<SearchHit> =
        mutex.withLock {
            withContext(Dispatchers.IO) {
                val d = docLocked()
                val hits = ArrayList<SearchHit>()
                val total = d.numberOfPages
                var lastReport = 0L
                for (p in 0 until total) {
                    ensureActive()
                    if (closed) break
                    hits += pageHits(d, p, query, MAX_HITS - hits.size)
                    if (hits.size >= MAX_HITS) break
                    val now = SystemClock.uptimeMillis()
                    if (now - lastReport > 250) {
                        lastReport = now
                        onProgress(hits.toList())
                    }
                }
                hits
            }
        }

    suspend fun outline(): List<OutlineEntry> = mutex.withLock {
        withContext(Dispatchers.IO) {
            val d = docLocked()
            val root = d.documentCatalog.documentOutline ?: return@withContext emptyList()
            val out = ArrayList<OutlineEntry>()

            fun walk(first: PDOutlineItem?, level: Int) {
                var cur = first
                while (cur != null && out.size < 2000) {
                    val page = runCatching { cur!!.findDestinationPage(d) }.getOrNull()
                    val idx = if (page != null) d.pages.indexOf(page) else -1
                    out += OutlineEntry(cur.title?.trim().orEmpty().ifBlank { "Untitled" }, idx, level)
                    if (level < 6) walk(cur.firstChild, level + 1)
                    cur = cur.nextSibling
                }
            }
            walk(root.firstChild, 0)
            out
        }
    }

    private fun pageHits(d: PDDocument, page: Int, query: String, room: Int): List<SearchHit> {
        if (room <= 0) return emptyList()
        val chars = StringBuilder()
        val pos = ArrayList<TextPosition?>()

        val stripper = object : PDFTextStripper() {
            override fun writeString(text: String, textPositions: MutableList<TextPosition>) {
                for (i in text.indices) {
                    chars.append(text[i])
                    pos.add(textPositions.getOrNull(min(i, textPositions.size - 1)))
                }
                chars.append(' ')
                pos.add(null)
            }
        }
        stripper.sortByPosition = true
        stripper.startPage = page + 1
        stripper.endPage = page + 1
        try {
            stripper.getText(d)
        } catch (e: Exception) {
            return emptyList()
        }

        val pg = d.getPage(page)
        val box = pg.cropBox ?: pg.mediaBox
        val rot = ((pg.rotation % 360) + 360) % 360
        val pw = if (rot == 90 || rot == 270) box.height else box.width
        val ph = if (rot == 90 || rot == 270) box.width else box.height
        if (pw <= 0f || ph <= 0f) return emptyList()

        val text = chars.toString()
        val out = ArrayList<SearchHit>()
        var from = 0
        while (out.size < room) {
            val at = text.indexOf(query, from, ignoreCase = true)
            if (at < 0) break
            out += SearchHit(page, rectsFor(pos, at, at + query.length, pw, ph))
            from = at + query.length
        }
        return out
    }

    private fun rectsFor(pos: List<TextPosition?>, start: Int, end: Int, pw: Float, ph: Float): List<RectF> {
        val rects = ArrayList<RectF>()
        var cur: RectF? = null
        var lastY = 0f
        var lastH = 1f
        for (i in start until min(end, pos.size)) {
            val t = pos[i] ?: continue
            val h = max(t.heightDir, 1f)
            val x = t.xDirAdj
            val w = t.widthDirAdj
            val yb = t.yDirAdj
            val l = x / pw
            val r = (x + w) / pw
            val top = (yb - h) / ph
            val bot = yb / ph
            val c = cur
            if (c != null && abs(yb - lastY) <= lastH * 0.5f) {
                c.left = min(c.left, l)
                c.right = max(c.right, r)
                c.top = min(c.top, top)
                c.bottom = max(c.bottom, bot)
            } else {
                if (c != null) rects += c
                cur = RectF(l, top, r, bot)
            }
            lastY = yb
            lastH = h
        }
        cur?.let { rects += it }
        rects.forEach {
            it.left = it.left.coerceIn(0f, 1f)
            it.right = it.right.coerceIn(0f, 1f)
            it.top = it.top.coerceIn(0f, 1f)
            it.bottom = it.bottom.coerceIn(0f, 1f)
        }
        return rects
    }

    override fun close() {
        closed = true
        runCatching { doc?.close() }
        doc = null
        ownedFile?.delete()
    }

    companion object {
        const val MAX_HITS = 300
    }
}
