package com.docsy.app.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.docsy.app.data.DocEntry
import com.docsy.app.data.Prefs
import com.docsy.app.ui.DocRow
import com.docsy.app.ui.EmptyState
import com.docsy.app.ui.MenuAction
import com.docsy.app.ui.theme.DocsyBlue
import com.docsy.app.ui.theme.DocsyNavy
import com.docsy.app.ui.theme.DocsyPurple
import com.docsy.app.util.FileUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    prefs: Prefs,
    onPickPdf: () -> Unit,
    onOpen: (DocEntry) -> Unit,
) {
    val recents by prefs.recents.state.collectAsState()
    val favourites by prefs.favourites.state.collectAsState()
    val positions by prefs.positions.state.collectAsState()
    var query by remember { mutableStateOf("") }

    val searching = query.isNotBlank()
    val results = remember(query, recents, favourites) {
        (recents + favourites).distinctBy { it.uri }.filter { it.name.contains(query.trim(), ignoreCase = true) }
    }
    val continueEntry = recents.firstOrNull { (positions[it.uri] ?: 0) > 0 } ?: recents.firstOrNull()

    fun subtitle(e: DocEntry): String {
        val page = positions[e.uri]
        val parts = buildList {
            if (e.pageCount > 0) add("${e.pageCount} pages")
            if (page != null && page > 0 && e.pageCount > 0) add("page ${page + 1}")
            if (e.lastOpened > 0) add(FileUtils.formatDate(e.lastOpened))
        }
        return parts.joinToString(" · ").ifBlank { "PDF" }
    }

    @Composable
    fun DocItem(e: DocEntry) {
        val isFav = favourites.any { it.uri == e.uri }
        DocRow(
            name = e.name,
            subtitle = subtitle(e),
            favourite = isFav,
            onClick = { onOpen(e) },
            onToggleFavourite = { prefs.toggleFavourite(e) },
            menu = listOf(MenuAction("Remove from history") { prefs.removeRecent(e.uri) }),
        )
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp),
    ) {
        item {
            HeaderCard(onPickPdf)
        }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                placeholder = { Text("Search your documents") },
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                trailingIcon = {
                    if (searching) IconButton(onClick = { query = "" }) { Icon(Icons.Rounded.Close, "Clear") }
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
            )
        }

        if (searching) {
            item { SectionTitle("Results") }
            if (results.isEmpty()) {
                item {
                    EmptyState(
                        Icons.Rounded.Search,
                        "No matches",
                        "Search covers your recent and favourite documents. Use Files to browse folders.",
                    )
                }
            } else {
                items(results, key = { it.uri }) { DocItem(it) }
            }
        } else if (recents.isEmpty() && favourites.isEmpty()) {
            item {
                EmptyState(
                    Icons.Rounded.FolderOpen,
                    "No documents yet",
                    "Open a PDF to start reading. Documents you open will show up here.",
                    actionLabel = "Open PDF",
                    onAction = onPickPdf,
                )
            }
        } else {
            if (continueEntry != null) {
                item { SectionTitle("Continue reading") }
                item {
                    val page = positions[continueEntry.uri] ?: 0
                    val progress = if (continueEntry.pageCount > 1) {
                        (page + 1f) / continueEntry.pageCount
                    } else 0f
                    Card(
                        onClick = { onOpen(continueEntry) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Text(
                                continueEntry.name,
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                if (continueEntry.pageCount > 0) "Page ${page + 1} of ${continueEntry.pageCount}" else "Tap to resume",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.75f),
                            )
                            if (progress > 0f) {
                                Spacer(Modifier.height(12.dp))
                                LinearProgressIndicator(
                                    progress = { progress.coerceIn(0f, 1f) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(50)),
                                )
                            }
                        }
                    }
                }
            }
            if (recents.isNotEmpty()) {
                item { SectionTitle("Recent") }
                items(recents, key = { "r" + it.uri }) { DocItem(it) }
            }
            if (favourites.isNotEmpty()) {
                item { SectionTitle("Favourites") }
                items(favourites.take(4), key = { "f" + it.uri }) { DocItem(it) }
            }
        }
    }
}

@Composable
private fun HeaderCard(onPickPdf: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(DocsyNavy, DocsyBlue, DocsyPurple)))
            .padding(22.dp),
    ) {
        Text("Docsy", style = MaterialTheme.typography.headlineMedium, color = Color.White, fontWeight = FontWeight.Bold)
        Text("Read. View. Manage.", style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.8f))
        Spacer(Modifier.height(18.dp))
        Button(
            onClick = onPickPdf,
            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = DocsyNavy),
            shape = RoundedCornerShape(14.dp),
        ) {
            Icon(Icons.Rounded.FolderOpen, null)
            Spacer(Modifier.width(8.dp))
            Text("Open PDF")
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 4.dp),
    )
}
