package com.docsy.app.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject

enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class PageMode { VERTICAL, HORIZONTAL }
enum class ReadingMode { LIGHT, DARK, SEPIA }
enum class SortOrder { NAME, DATE, SIZE, TYPE }

data class DocEntry(
    val uri: String,
    val name: String,
    val lastOpened: Long = 0L,
    val pageCount: Int = 0,
)

data class FolderEntry(val uri: String, val name: String)

/** A single persisted value exposed as a StateFlow. Everything is stored as a string. */
class Setting<T>(
    private val sp: SharedPreferences,
    private val key: String,
    default: T,
    decode: (String) -> T?,
    private val encode: (T) -> String,
) {
    private val _state = MutableStateFlow(sp.getString(key, null)?.let(decode) ?: default)
    val state: StateFlow<T> = _state

    var value: T
        get() = _state.value
        set(v) {
            _state.value = v
            sp.edit().putString(key, encode(v)).apply()
        }
}

class Prefs(context: Context) {
    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("docsy_prefs", Context.MODE_PRIVATE)

    private inline fun <reified E : Enum<E>> enumSetting(key: String, def: E) =
        Setting(sp, key, def, { s -> enumValues<E>().firstOrNull { it.name == s } }, { it.name })

    private fun boolSetting(key: String, def: Boolean) =
        Setting(sp, key, def, { it.toBooleanStrictOrNull() }, { it.toString() })

    private fun intSetting(key: String, def: Int) =
        Setting(sp, key, def, { it.toIntOrNull() }, { it.toString() })

    private fun floatSetting(key: String, def: Float) =
        Setting(sp, key, def, { it.toFloatOrNull() }, { it.toString() })

    // Appearance
    val themeMode = enumSetting("theme", ThemeMode.SYSTEM)
    val accent = intSetting("accent", 0)
    val fontScale = floatSetting("font_scale", 1f)

    // PDF preferences
    val pageMode = enumSetting("page_mode", PageMode.VERTICAL)
    val readingMode = enumSetting("reading_mode", ReadingMode.LIGHT)
    val defaultZoom = floatSetting("default_zoom", 1f)
    val rememberLastPage = boolSetting("remember_page", true)
    val autoRotate = boolSetting("auto_rotate", true)

    // Files
    val recentLimit = intSetting("recent_limit", 20)
    val sortOrder = enumSetting("sort", SortOrder.NAME)
    val gridView = boolSetting("grid_view", false)

    // Privacy
    val appLock = boolSetting("app_lock", false)
    val hideRecents = boolSetting("hide_recents", false)
    val secureScreen = boolSetting("secure_screen", false)

    // Data
    val recents = Setting(sp, "recents", emptyList<DocEntry>(), ::decodeDocs, ::encodeDocs)
    val favourites = Setting(sp, "favourites", emptyList<DocEntry>(), ::decodeDocs, ::encodeDocs)
    val folders = Setting(sp, "folders", emptyList<FolderEntry>(), ::decodeFolders, ::encodeFolders)
    val positions = Setting(sp, "positions", emptyMap<String, Int>(), ::decodePositions, ::encodePositions)
    val bookmarks = Setting(sp, "bookmarks", emptyMap<String, List<Int>>(), ::decodeBookmarks, ::encodeBookmarks)

    fun addRecent(uri: String, name: String, pageCount: Int) {
        if (hideRecents.value) return
        val rest = recents.value.filterNot { it.uri == uri }
        recents.value = (listOf(DocEntry(uri, name, System.currentTimeMillis(), pageCount)) + rest)
            .take(recentLimit.value)
    }

    fun removeRecent(uri: String) {
        recents.value = recents.value.filterNot { it.uri == uri }
    }

    fun setRecentLimit(n: Int) {
        recentLimit.value = n
        recents.value = recents.value.take(n)
    }

    fun clearHistory() {
        recents.value = emptyList()
        positions.value = emptyMap()
    }

    fun isFavourite(uri: String) = favourites.value.any { it.uri == uri }

    fun toggleFavourite(entry: DocEntry) {
        favourites.value = if (isFavourite(entry.uri)) {
            favourites.value.filterNot { it.uri == entry.uri }
        } else {
            listOf(entry.copy(lastOpened = System.currentTimeMillis())) + favourites.value
        }
    }

    fun lastPage(uri: String): Int = if (rememberLastPage.value) positions.value[uri] ?: 0 else 0

    fun savePage(uri: String, page: Int) {
        if (!rememberLastPage.value) return
        val map = LinkedHashMap(positions.value)
        map.remove(uri)
        map[uri] = page
        while (map.size > 500) map.remove(map.keys.first())
        positions.value = map
    }

    fun toggleBookmark(uri: String, page: Int) {
        val current = bookmarks.value[uri].orEmpty()
        val updated = if (page in current) current - page else (current + page).sorted()
        bookmarks.value = if (updated.isEmpty()) bookmarks.value - uri else bookmarks.value + (uri to updated)
    }

    fun addFolder(entry: FolderEntry) {
        if (folders.value.none { it.uri == entry.uri }) folders.value = folders.value + entry
    }

    fun removeFolder(uri: String) {
        folders.value = folders.value.filterNot { it.uri == uri }
    }
}

// ---- JSON encoding helpers ----

private fun encodeDocs(list: List<DocEntry>): String {
    val arr = JSONArray()
    list.forEach {
        arr.put(JSONObject().put("u", it.uri).put("n", it.name).put("t", it.lastOpened).put("p", it.pageCount))
    }
    return arr.toString()
}

private fun decodeDocs(s: String): List<DocEntry>? = runCatching {
    val arr = JSONArray(s)
    (0 until arr.length()).map {
        val o = arr.getJSONObject(it)
        DocEntry(o.getString("u"), o.getString("n"), o.optLong("t"), o.optInt("p"))
    }
}.getOrNull()

private fun encodeFolders(list: List<FolderEntry>): String {
    val arr = JSONArray()
    list.forEach { arr.put(JSONObject().put("u", it.uri).put("n", it.name)) }
    return arr.toString()
}

private fun decodeFolders(s: String): List<FolderEntry>? = runCatching {
    val arr = JSONArray(s)
    (0 until arr.length()).map {
        val o = arr.getJSONObject(it)
        FolderEntry(o.getString("u"), o.getString("n"))
    }
}.getOrNull()

private fun encodePositions(map: Map<String, Int>): String {
    val o = JSONObject()
    map.forEach { (k, v) -> o.put(k, v) }
    return o.toString()
}

private fun decodePositions(s: String): Map<String, Int>? = runCatching {
    val o = JSONObject(s)
    val out = LinkedHashMap<String, Int>()
    o.keys().forEach { k -> out[k] = o.getInt(k) }
    out as Map<String, Int>
}.getOrNull()

private fun encodeBookmarks(map: Map<String, List<Int>>): String {
    val o = JSONObject()
    map.forEach { (k, v) -> o.put(k, JSONArray(v)) }
    return o.toString()
}

private fun decodeBookmarks(s: String): Map<String, List<Int>>? = runCatching {
    val o = JSONObject(s)
    val out = LinkedHashMap<String, List<Int>>()
    o.keys().forEach { k ->
        val a = o.getJSONArray(k)
        out[k] = (0 until a.length()).map { a.getInt(it) }
    }
    out as Map<String, List<Int>>
}.getOrNull()
