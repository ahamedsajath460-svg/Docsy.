package com.docsy.app.ui.tools

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CallMerge
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Compress
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.FileCopy
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.RotateRight
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.text.KeyboardOptions
import android.content.Intent
import com.docsy.app.pdf.CompressLevel
import com.docsy.app.pdf.PdfTools
import com.docsy.app.pdf.ToolResult
import com.docsy.app.ui.KindBadge
import com.docsy.app.util.FileKind
import com.docsy.app.util.FileUtils
import kotlinx.coroutines.launch

enum class Tool(
    val title: String,
    val desc: String,
    val icon: ImageVector,
    val multi: Boolean = false,
    val images: Boolean = false,
) {
    MERGE("Merge PDFs", "Combine several PDFs into one", Icons.Rounded.CallMerge, multi = true),
    EXTRACT("Extract pages", "Save selected pages as a new PDF", Icons.Rounded.FileCopy),
    DELETE("Delete pages", "Remove pages from a PDF", Icons.Rounded.DeleteSweep),
    ROTATE("Rotate pages", "Turn pages 90°, 180° or 270°", Icons.Rounded.RotateRight),
    COMPRESS("Compress", "Shrink photos inside a PDF", Icons.Rounded.Compress),
    IMAGES("Images to PDF", "Turn photos into a PDF", Icons.Rounded.Image, multi = true, images = true),
    PROTECT("Add password", "Encrypt a PDF with a password", Icons.Rounded.Lock),
    UNLOCK("Remove password", "Save an unlocked copy of a PDF you can open", Icons.Rounded.LockOpen),
}

private data class InputFile(val uri: Uri, val name: String, val size: Long, val pages: Int)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ToolsScreen(onOpenPdf: (Uri) -> Unit) {
    var active by remember { mutableStateOf<Tool?>(null) }
    val tool = active
    if (tool != null) {
        BackHandler { active = null }
        ToolPane(tool, onBack = { active = null }, onOpenPdf = onOpenPdf)
        return
    }
    Column(Modifier.fillMaxSize()) {
        Text(
            "Tools",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(start = 20.dp, top = 16.dp),
        )
        Text(
            "Every tool saves a new file. Your original is never changed.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 20.dp, end = 20.dp, bottom = 8.dp),
        )
        LazyVerticalGrid(
            columns = GridCells.Adaptive(160.dp),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(Tool.entries.toList(), key = { it.name }) { t ->
                Card(
                    onClick = { active = t },
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Icon(t.icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
                        Spacer(Modifier.height(12.dp))
                        Text(t.title, style = MaterialTheme.typography.titleSmall)
                        Text(
                            t.desc,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ToolPane(tool: Tool, onBack: () -> Unit, onOpenPdf: (Uri) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var inputs by remember { mutableStateOf<List<InputFile>>(emptyList()) }
    var pageSpec by remember { mutableStateOf("") }
    var angle by remember { mutableIntStateOf(90) }
    var level by remember { mutableStateOf(CompressLevel.BALANCED) }
    var strip by remember { mutableStateOf(true) }
    var pw by remember { mutableStateOf("") }
    var pw2 by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var result by remember { mutableStateOf<ToolResult?>(null) }
    var outUri by remember { mutableStateOf<Uri?>(null) }
    var pending by remember { mutableStateOf<(suspend (Uri) -> ToolResult)?>(null) }

    fun addInputs(uris: List<Uri>, replace: Boolean) {
        scope.launch {
            val added = uris.map { u ->
                InputFile(
                    uri = u,
                    name = FileUtils.displayName(ctx, u),
                    size = PdfTools.querySize(ctx, u),
                    pages = if (tool.images) 0 else PdfTools.inspect(ctx, u),
                )
            }
            inputs = if (replace) added else inputs + added
            error = null
            result = null
        }
    }

    val pickOne = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) addInputs(listOf(uri), replace = true)
    }
    val pickMany = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { list ->
        if (list.isNotEmpty()) addInputs(list, replace = false)
    }
    val create = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val job = pending
        pending = null
        if (uri != null && job != null) {
            runCatching {
                ctx.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
                )
            }
            busy = true
            result = null
            scope.launch {
                val r = job(uri)
                busy = false
                result = r
                outUri = if (r is ToolResult.Done) uri else null
            }
        }
    }

    fun pickInputs() {
        val mimes = if (tool.images) arrayOf("image/*") else arrayOf("application/pdf")
        if (tool.multi) pickMany.launch(mimes) else pickOne.launch(mimes)
    }

    fun move(i: Int, d: Int) {
        val j = i + d
        if (j !in inputs.indices) return
        val m = inputs.toMutableList()
        m[i] = m[j].also { m[j] = m[i] }
        inputs = m
    }

    fun run() {
        error = null
        val first = inputs.firstOrNull()
        if (first == null) {
            error = if (tool.multi) "Add your files first." else "Choose a PDF first."
            return
        }
        val base = first.name.substringBeforeLast('.', first.name)
        fun start(suffix: String, job: suspend (Uri) -> ToolResult) {
            pending = job
            create.launch("$base$suffix.pdf")
        }
        when (tool) {
            Tool.MERGE -> {
                if (inputs.size < 2) { error = "Add at least two PDFs."; return }
                if (inputs.any { it.pages < 0 }) {
                    error = "Some files are protected or unreadable. Remove their password first."
                    return
                }
                val uris = inputs.map { it.uri }
                start("_merged") { PdfTools.merge(ctx, uris, it) }
            }
            Tool.IMAGES -> {
                val uris = inputs.map { it.uri }
                pending = { out -> PdfTools.imagesToPdf(ctx, uris, out) }
                create.launch("Images.pdf")
            }
            Tool.UNLOCK -> {
                if (pw.isEmpty()) { error = "Enter the PDF's password."; return }
                val pass = pw
                start("_unlocked") { PdfTools.unlock(ctx, first.uri, pass, it) }
            }
            else -> {
                if (first.pages == PdfTools.PAGES_ENCRYPTED) {
                    error = "This PDF is password-protected. Use “Remove password” first."
                    return
                }
                if (first.pages <= 0) { error = "This file can't be read as a PDF."; return }
                when (tool) {
                    Tool.EXTRACT, Tool.DELETE -> {
                        val sel = PdfTools.parsePages(pageSpec, first.pages)
                        if (sel == null) {
                            error = "Enter pages like 1-3, 5, 8- (this PDF has ${first.pages} pages)."
                            return
                        }
                        if (tool == Tool.EXTRACT) {
                            start("_pages") { PdfTools.extractPages(ctx, first.uri, sel, it) }
                        } else {
                            if (sel.size >= first.pages) { error = "A PDF must keep at least one page."; return }
                            start("_edited") { PdfTools.deletePages(ctx, first.uri, sel, it) }
                        }
                    }
                    Tool.ROTATE -> {
                        val sel = if (pageSpec.isBlank()) null else PdfTools.parsePages(pageSpec, first.pages)
                        if (pageSpec.isNotBlank() && sel == null) {
                            error = "Enter pages like 1-3, 5, 8-, or leave empty for all pages."
                            return
                        }
                        val a = angle
                        start("_rotated") { PdfTools.rotatePages(ctx, first.uri, sel, a, it) }
                    }
                    Tool.COMPRESS -> {
                        val l = level
                        val s = strip
                        start("_compressed") { PdfTools.compress(ctx, first.uri, l, s, it) }
                    }
                    Tool.PROTECT -> {
                        if (pw.length < 4) { error = "Use a password of at least 4 characters."; return }
                        if (pw != pw2) { error = "The passwords don't match."; return }
                        val pass = pw
                        start("_protected") { PdfTools.protect(ctx, first.uri, pass, it) }
                    }
                    else -> Unit
                }
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 24.dp),
    ) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") }
            Text(tool.title, style = MaterialTheme.typography.titleLarge)
        }
        Text(
            tool.desc,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 20.dp),
        )
        Spacer(Modifier.height(12.dp))

        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            // ---- Inputs ----
            inputs.forEachIndexed { i, f ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                ) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        KindBadge(if (tool.images) FileKind.IMAGE else FileKind.PDF, size = 40)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
                            val detail = when {
                                tool.images -> FileUtils.formatSize(f.size)
                                f.pages == PdfTools.PAGES_ENCRYPTED -> "Password-protected · ${FileUtils.formatSize(f.size)}"
                                f.pages == PdfTools.PAGES_INVALID -> "Can't read this file"
                                else -> "${f.pages} pages · ${FileUtils.formatSize(f.size)}"
                            }
                            Text(
                                detail,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        if (tool.multi && inputs.size > 1) {
                            IconButton(onClick = { move(i, -1) }, enabled = i > 0) { Icon(Icons.Rounded.KeyboardArrowUp, "Move up") }
                            IconButton(onClick = { move(i, 1) }, enabled = i < inputs.lastIndex) { Icon(Icons.Rounded.KeyboardArrowDown, "Move down") }
                        }
                        IconButton(onClick = { inputs = inputs.filterIndexed { j, _ -> j != i } }) {
                            Icon(Icons.Rounded.Close, "Remove")
                        }
                    }
                }
            }
            OutlinedButton(onClick = ::pickInputs, enabled = !busy) {
                Text(
                    when {
                        tool.images -> if (inputs.isEmpty()) "Choose images" else "Add more images"
                        tool.multi -> if (inputs.isEmpty()) "Choose PDFs" else "Add more PDFs"
                        else -> if (inputs.isEmpty()) "Choose PDF" else "Choose a different PDF"
                    },
                )
            }

            // ---- Options ----
            when (tool) {
                Tool.EXTRACT, Tool.DELETE, Tool.ROTATE -> OutlinedTextField(
                    value = pageSpec,
                    onValueChange = { pageSpec = it.take(200) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text(if (tool == Tool.ROTATE) "Pages (empty = all)" else "Pages") },
                    placeholder = { Text("1-3, 5, 8-") },
                )
                else -> Unit
            }
            if (tool == Tool.ROTATE) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(90, 180, 270).forEach { a ->
                        FilterChip(selected = angle == a, onClick = { angle = a }, label = { Text("$a°") })
                    }
                }
            }
            if (tool == Tool.COMPRESS) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CompressLevel.entries.forEach { l ->
                        FilterChip(selected = level == l, onClick = { level = l }, label = { Text(l.label) })
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Remove metadata", style = MaterialTheme.typography.bodyLarge)
                        Text(
                            "Clears author, title and similar document info",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(checked = strip, onCheckedChange = { strip = it })
                }
                Text(
                    "Compression recompresses photos inside the PDF. Documents that are mostly text may not shrink.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (tool == Tool.PROTECT || tool == Tool.UNLOCK) {
                OutlinedTextField(
                    value = pw,
                    onValueChange = { pw = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Password") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                )
            }
            if (tool == Tool.PROTECT) {
                OutlinedTextField(
                    value = pw2,
                    onValueChange = { pw2 = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Repeat password") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                )
                Text(
                    "There is no way to recover a forgotten password. Keep it safe.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (tool == Tool.UNLOCK) {
                Text(
                    "Only unlock documents you own or have permission to unlock. You must know the password.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            error?.let {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
            }

            Button(onClick = ::run, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                if (busy) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                    Spacer(Modifier.width(10.dp))
                    Text("Working…")
                } else {
                    Text("Choose where to save and run")
                }
            }

            // ---- Result ----
            when (val r = result) {
                is ToolResult.Done -> Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Done", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Text(r.message, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        outUri?.let { u ->
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { onOpenPdf(u) }) { Text("Open") }
                                OutlinedButton(onClick = { FileUtils.share(ctx, u, "application/pdf") }) { Text("Share") }
                            }
                        }
                    }
                }
                is ToolResult.Failed -> Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Couldn't finish", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onErrorContainer)
                        Text(r.message, color = MaterialTheme.colorScheme.onErrorContainer)
                    }
                }
                null -> Unit
            }
        }
    }
}
