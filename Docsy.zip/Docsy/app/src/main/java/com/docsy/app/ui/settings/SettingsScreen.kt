package com.docsy.app.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.docsy.app.BuildConfig
import com.docsy.app.data.PageMode
import com.docsy.app.data.Prefs
import com.docsy.app.data.ReadingMode
import com.docsy.app.data.SortOrder
import com.docsy.app.data.ThemeMode
import com.docsy.app.ui.theme.AccentColors
import com.docsy.app.ui.theme.AccentNames
import com.docsy.app.util.FileUtils

private enum class InfoDialog { PRIVACY, TERMS, ABOUT }

@Composable
fun SettingsScreen(prefs: Prefs) {
    val ctx = LocalContext.current
    val theme by prefs.themeMode.state.collectAsState()
    val accent by prefs.accent.state.collectAsState()
    val fontScale by prefs.fontScale.state.collectAsState()
    val pageMode by prefs.pageMode.state.collectAsState()
    val readingMode by prefs.readingMode.state.collectAsState()
    val defaultZoom by prefs.defaultZoom.state.collectAsState()
    val rememberPage by prefs.rememberLastPage.state.collectAsState()
    val autoRotate by prefs.autoRotate.state.collectAsState()
    val recentLimit by prefs.recentLimit.state.collectAsState()
    val sort by prefs.sortOrder.state.collectAsState()
    val grid by prefs.gridView.state.collectAsState()
    val appLock by prefs.appLock.state.collectAsState()
    val secure by prefs.secureScreen.state.collectAsState()
    val hideRecents by prefs.hideRecents.state.collectAsState()

    var info by remember { mutableStateOf<InfoDialog?>(null) }
    var confirmClear by remember { mutableStateOf(false) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 32.dp)) {
        item {
            Text(
                "Settings",
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.padding(start = 20.dp, top = 16.dp, bottom = 8.dp),
            )
        }

        item {
            Group("Appearance") {
                Choice(
                    "Theme",
                    listOf("System" to ThemeMode.SYSTEM, "Light" to ThemeMode.LIGHT, "Dark" to ThemeMode.DARK),
                    theme,
                ) { prefs.themeMode.value = it }
                Divider()
                Column(Modifier.padding(16.dp)) {
                    Text("Accent colour", style = MaterialTheme.typography.bodyLarge)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        AccentColors.forEachIndexed { i, c ->
                            Box(
                                Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(c)
                                    .border(
                                        if (i == accent) 3.dp else 0.dp,
                                        MaterialTheme.colorScheme.onSurface,
                                        CircleShape,
                                    )
                                    .clickable { prefs.accent.value = i },
                                contentAlignment = Alignment.Center,
                            ) {
                                if (i == accent) Icon(Icons.Rounded.Check, AccentNames[i] + " (selected)", tint = Color.White)
                            }
                        }
                    }
                }
                Divider()
                Choice(
                    "Text size",
                    listOf("Small" to 0.9f, "Default" to 1f, "Large" to 1.15f),
                    fontScale,
                ) { prefs.fontScale.value = it }
            }
        }

        item {
            Group("PDF reading") {
                Choice(
                    "Default page layout",
                    listOf("Scroll" to PageMode.VERTICAL, "Swipe pages" to PageMode.HORIZONTAL),
                    pageMode,
                ) { prefs.pageMode.value = it }
                Divider()
                Choice(
                    "Default reading mode",
                    listOf("Light" to ReadingMode.LIGHT, "Dark" to ReadingMode.DARK, "Sepia" to ReadingMode.SEPIA),
                    readingMode,
                ) { prefs.readingMode.value = it }
                Divider()
                Choice(
                    "Default zoom (scroll layout)",
                    listOf("Fit width" to 1f, "125%" to 1.25f, "150%" to 1.5f),
                    defaultZoom,
                ) { prefs.defaultZoom.value = it }
                Divider()
                SwitchRow("Remember last page", "Reopen documents where you stopped", rememberPage) {
                    prefs.rememberLastPage.value = it
                }
                Divider()
                SwitchRow("Auto-rotate", "Turn off to keep Docsy in portrait", autoRotate) {
                    prefs.autoRotate.value = it
                }
            }
        }

        item {
            Group("Files") {
                Choice(
                    "Recent documents limit",
                    listOf("10" to 10, "20" to 20, "50" to 50),
                    recentLimit,
                ) { prefs.setRecentLimit(it) }
                Divider()
                Choice(
                    "Default sort order",
                    listOf("Name" to SortOrder.NAME, "Date" to SortOrder.DATE, "Size" to SortOrder.SIZE, "Type" to SortOrder.TYPE),
                    sort,
                ) { prefs.sortOrder.value = it }
                Divider()
                Choice(
                    "File display",
                    listOf("List" to false, "Grid" to true),
                    grid,
                ) { prefs.gridView.value = it }
            }
        }

        item {
            Group("Privacy & security") {
                SwitchRow("App lock", "Require fingerprint, face or screen lock to open Docsy", appLock) { on ->
                    if (!on) {
                        prefs.appLock.value = false
                    } else if (FileUtils.canUseAppLock(ctx)) {
                        prefs.appLock.value = true
                    } else {
                        FileUtils.toast(ctx, "Set up a screen lock or biometrics on your device first.")
                    }
                }
                Divider()
                SwitchRow("Block screenshots", "Also hides Docsy in the recent apps view", secure) {
                    prefs.secureScreen.value = it
                }
                Divider()
                SwitchRow("Hide recent documents", "Stop recording newly opened documents", hideRecents) {
                    prefs.hideRecents.value = it
                    if (it) prefs.recents.value = emptyList()
                }
                Divider()
                ActionRow("Clear recent history", "Removes recents and saved reading positions") { confirmClear = true }
            }
        }

        item {
            Group("About") {
                ActionRow("About Docsy", "Version ${BuildConfig.VERSION_NAME}") { info = InfoDialog.ABOUT }
                Divider()
                ActionRow("Privacy policy", null) { info = InfoDialog.PRIVACY }
                Divider()
                ActionRow("Terms of service", null) { info = InfoDialog.TERMS }
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear recent history?") },
            text = { Text("Recent documents and remembered reading positions will be removed. Your files, favourites and bookmarks are not affected.") },
            confirmButton = {
                TextButton(onClick = {
                    prefs.clearHistory()
                    confirmClear = false
                }) { Text("Clear") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } },
        )
    }

    info?.let { which ->
        val (title, body) = when (which) {
            InfoDialog.ABOUT -> "Docsy ${BuildConfig.VERSION_NAME}" to
                "Read. View. Manage.\n\nDocsy is a fast, private PDF reader. Everything happens on your device."
            InfoDialog.PRIVACY -> "Privacy policy" to
                "Docsy works fully offline and does not collect, upload or share your documents or personal data.\n\n" +
                    "• Files are opened through Android's file picker or folders you choose; Docsy never asks for broad storage access.\n" +
                    "• Recent files, favourites, bookmarks and settings are stored only on this device. Clear them any time in Settings.\n" +
                    "• Temporary copies, if ever needed to open a file, are kept in private app storage and removed on the next launch."
            InfoDialog.TERMS -> "Terms of service" to
                "Docsy is provided \"as is\", without warranty of any kind. You are responsible for the documents you open, " +
                    "edit or delete with it, and for keeping backups of important files."
        }
        AlertDialog(
            onDismissRequest = { info = null },
            title = { Text(title) },
            text = { Text(body) },
            confirmButton = { TextButton(onClick = { info = null }) { Text("Close") } },
        )
    }
}

@Composable
private fun Group(title: String, content: @Composable () -> Unit) {
    Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text(
            title,
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(start = 4.dp, bottom = 6.dp),
        )
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        ) { Column { content() } }
    }
}

@Composable
private fun Divider() {
    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant, modifier = Modifier.padding(horizontal = 16.dp))
}

@Composable
private fun <T> Choice(title: String, options: List<Pair<String, T>>, selected: T, onSelect: (T) -> Unit) {
    Column(Modifier.padding(16.dp)) {
        Text(title, style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { (label, value) ->
                FilterChip(selected = value == selected, onClick = { onSelect(value) }, label = { Text(label) })
            }
        }
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onChange(!checked) }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun ActionRow(title: String, subtitle: String?, onClick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
    ) {
        Text(title, style = MaterialTheme.typography.bodyLarge)
        if (subtitle != null) {
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
