package com.docsy.app

import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.docsy.app.data.Prefs
import com.docsy.app.pdf.PdfSession
import com.docsy.app.ui.DocsyApp
import com.docsy.app.ui.theme.DocsyTheme
import com.docsy.app.util.FileUtils
import kotlinx.coroutines.launch

class MainActivity : FragmentActivity() {

    private lateinit var prefs: Prefs
    private var locked by mutableStateOf(false)
    private var incoming by mutableStateOf<Uri?>(null)
    private var stoppedAt = 0L
    private var promptShowing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        prefs = Prefs(this)
        PdfSession.clearTempFiles(this)
        locked = prefs.appLock.value
        handleIntent(intent)

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    prefs.secureScreen.state.collect { secure ->
                        if (secure) window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
                        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                    }
                }
                launch {
                    prefs.autoRotate.state.collect { auto ->
                        requestedOrientation = if (auto) ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                        else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                    }
                }
            }
        }

        setContent {
            val theme by prefs.themeMode.state.collectAsState()
            val accent by prefs.accent.state.collectAsState()
            val fontScale by prefs.fontScale.state.collectAsState()
            DocsyTheme(theme, accent, fontScale) {
                Box(Modifier.fillMaxSize()) {
                    DocsyApp(prefs, incoming, onIncomingConsumed = { incoming = null })
                    if (locked) LockScreen(onUnlock = ::authenticate)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_VIEW) {
            intent.data?.let { incoming = it }
        }
    }

    override fun onStart() {
        super.onStart()
        if (prefs.appLock.value) {
            val away = SystemClock.elapsedRealtime() - stoppedAt
            if (stoppedAt > 0 && away > LOCK_AFTER_MS) locked = true
        } else {
            locked = false
        }
        if (locked) authenticate()
    }

    override fun onStop() {
        super.onStop()
        stoppedAt = SystemClock.elapsedRealtime()
    }

    private fun authenticate() {
        if (promptShowing) return
        if (!FileUtils.canUseAppLock(this)) {
            // Screen lock was removed from the device: we can no longer enforce the lock.
            locked = false
            prefs.appLock.value = false
            return
        }
        promptShowing = true
        val prompt = BiometricPrompt(
            this,
            ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    promptShowing = false
                    locked = false
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    promptShowing = false
                }
            },
        )
        prompt.authenticate(
            BiometricPrompt.PromptInfo.Builder()
                .setTitle("Unlock Docsy")
                .setAllowedAuthenticators(FileUtils.appLockAuthenticators())
                .build(),
        )
    }

    private companion object {
        const val LOCK_AFTER_MS = 30_000L
    }
}

@androidx.compose.runtime.Composable
private fun LockScreen(onUnlock: () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .clickable(enabled = false) {},
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Rounded.Lock, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(48.dp))
            Spacer(Modifier.height(16.dp))
            Text("Docsy is locked", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(20.dp))
            Button(onClick = onUnlock) { Text("Unlock") }
        }
    }
}
