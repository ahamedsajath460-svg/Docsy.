package com.docsy.app.ui.files

import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Sort
import androidx.compose.material.icons.rounded.ViewList
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.docsy.app.data.FolderEntry
import com.docsy.app.data.Prefs
import com.docsy.app.data.SortOrder
import com.docsy.app.ui.EmptyState
import com.docsy.app.ui.KindBadge
import com.docsy.app.ui.SkeletonRows
import com.docsy.app.util.FileItem
import com.docsy.app.util.FileKind
import com.docsy.app.util.FileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class Crumb(val docId: String, val name: String)

/** Browsing state lives above the NavHost so it survives opening a document. */
class FilesState {
    var treeUri by mutableStateOf<Uri?>(null)
    val stack = mutableStateListOf<Crumb>()
    var filter by mutableStateOf<FileKind?>(null)
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FilesScreen(
    prefs: Prefs,
    state: FilesState,
    onOpenPdf: (Uri) -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val folders by prefs.folders.state.collectAsState()
    val sort by prefs.sortOrder.state.collectAsState()
    val grid by prefs.gridView.state.collectAsState()

    val treeUri = state.treeUri
    val current = state.stack.lastOrNull()

    var items by remember { mutableStateOf<List<FileItem>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var refresh by remember { mutableIntStateOf(0) }
    val selected = remember { mutableStateListOf<String>() }

    var renameTarget by remember { mutableStateOf<FileItem?>(null) }
    var deleteTargets by remember { mutableStateOf<List<FileItem>>(emptyList()) }
    var detailsTarget by remember { mutableStateOf<FileItem?>(null) }
    var showNewFolder by remember { mutableStateOf(false) }

    val addFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching {
                ctx.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
                )
            }.onFailure {
                runCatching {
                    ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            }
            val rootDoc = DocumentsContract.buildDocumentUriUsingTree(uri, DocumentsContract.getTreeDocumentId(uri))
            val name = FileUtils.documentName(ctx, rootDoc) ?: "Folder"
            prefs.addFolder(FolderEntry(uri.toString(), name))
        }
    }

    LaunchedEffect(treeUri, current?.docId, refresh) {
        selected.clear()
        if (treeUri == null || current == null) {
            items = emptyList()
            return@LaunchedEffect
        }
        loading = true
        items = try {
            withContext(Dispatchers.IO) { FileUtils.queryChildren(ctx, treeUri, current.docId) }
        } catch (e: Exception) {
            FileUtils.toast(ctx, "Could not read this folder.")
            emptyList()
        }
        loading = false
    }

    BackHandler(enabled = selected.isNotEmpty() || treeUri != null) {
        when {
            selected.isNotEmpty() -> selected.clear()
            state.stack.size > 1 -> state.stack.removeAt(state.stack.lastIndex)
            else -> {
                state.stack.clear()
                state.treeUri = null
            }
        }
    }

    val visible = remember(items, sort, state.filter) {
        val filtered = items.filter { it.isDir || state.filter == null || it.kind == state.filter }
        val comparator: Comparator<FileItem> = when (sort) {
            SortOrder.NAME -> compareBy { it.name.lowercase() }
            SortOrder.DATE -> compareByDescending { it.modified }
            SortOrder.SIZE -> compareByDescending { it.size }
            SortOrder.TYPE -> compareBy<FileItem> { it.name.substringAfterLast('.', "").lowercase() }
                .thenBy { it.name.lowercase() }
        }
        filtered.sortedWith(compareByDescending<FileItem> { it.isDir }.then(comparator))
    }

    fun openItem(item: FileItem) {
        when {
            item.isDir -> {
                state.filter = state.filter
                state.stack.add(Crumb(item.docId, item.name))
            }
            item.isPdf -> onOpenPdf(item.uri)
            else -> FileUtils.viewExternal(ctx, item.uri, item.mime)
        }
    }

    fun toggleSelect(item: FileItem) {
        if (item.docId in selected) selected.remove(item.docId) else selected.add(item.docId)
    }

    Column(Modifier.fillMaxSize()) {
        if (treeUri == null || current == null) {
            // ---- Folder list ----
            Text(
                "Files",
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.padding(start = 20.dp, top = 16.dp, bottom = 4.dp),
            )
            Text(
                "Add a folder to browse it here. Docsy only sees folders you choose.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 20.dp),
            )
            Spacer(Modifier.height(12.dp))
            Button(onClick = { addFolder.launch(null) }, modifier = Modifier.padding(horizontal = 16.dp)) {
                Icon(Icons.Rounded.CreateNewFolder, null)
                Spacer(Modifier.width(8.dp))
                Text("Add folder")
            }
            if (folders.isEmpty()) {
                EmptyState(
                    Icons.Rounded.FolderOpen,
                    "No folders added",
                    "Pick Downloads, Documents or any folder to start managing your files.",
                )
            } else {
                LazyColumn(contentPadding = PaddingValues(vertical = 12.dp)) {
                    items(folders, key = { it.uri }) { f ->
                        var menu by remember { mutableStateOf(false) }
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .combinedClickable(onClick = {
                                    val u = Uri.parse(f.uri)
                                    state.treeUri = u
                                    state.stack.clear()
                                    state.stack.add(Crumb(DocumentsContract.getTreeDocumentId(u), f.name))
                                })
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(
                                Modifier
                                    .size(44.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center,
                            ) { Icon(Icons.Rounded.Folder, null, tint = MaterialTheme.colorScheme.primary) }
                            Spacer(Modifier.width(12.dp))
                            Text(f.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Box {
                                IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, "More") }
                                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                    DropdownMenuItem(
                                        text = { Text("Remove from Docsy") },
                                        onClick = {
                                            menu = false
                                            runCatching {
                                                ctx.contentResolver.releasePersistableUriPermission(
                                                    Uri.parse(f.uri),
                                                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
                                                )
                                            }
                                            prefs.removeFolder(f.uri)
                                        },
                                    )
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // ---- Inside a folder ----
            if (selected.isNotEmpty()) {
                val chosen = visible.filter { it.docId in selected }
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = { selected.clear() }) { Icon(Icons.Rounded.Close, "Cancel selection") }
                    Text("${selected.size} selected", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    IconButton(onClick = { FileUtils.shareMany(ctx, chosen) }) { Icon(Icons.Rounded.Share, "Share") }
                    IconButton(onClick = { deleteTargets = chosen }) { Icon(Icons.Rounded.Delete, "Delete") }
                }
            } else {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = {
                        if (state.stack.size > 1) state.stack.removeAt(state.stack.lastIndex)
                        else {
                            state.stack.clear()
                            state.treeUri = null
                        }
                    }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") }
                    Text(
                        current.name,
                        style = MaterialTheme.typography.titleLarge,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    var sortMenu by remember { mutableStateOf(false) }
                    Box {
                        IconButton(onClick = { sortMenu = true }) { Icon(Icons.Rounded.Sort, "Sort") }
                        DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                            listOf(
                                SortOrder.NAME to "Name",
                                SortOrder.DATE to "Date",
                                SortOrder.SIZE to "Size",
                                SortOrder.TYPE to "Type",
                            ).forEach { (order, label) ->
                                DropdownMenuItem(
                                    text = { Text(label) },
                                    trailingIcon = { if (sort == order) Icon(Icons.Rounded.Check, null) },
                                    onClick = {
                                        prefs.sortOrder.value = order
                                        sortMenu = false
                                    },
                                )
                            }
                        }
                    }
                    IconButton(onClick = { prefs.gridView.value = !grid }) {
                        Icon(if (grid) Icons.Rounded.ViewList else Icons.Rounded.GridView, if (grid) "List view" else "Grid view")
                    }
                    IconButton(onClick = { showNewFolder = true }) { Icon(Icons.Rounded.CreateNewFolder, "New folder") }
                }
            }

            Row(
                Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                FilterChip(selected = state.filter == null, onClick = { state.filter = null }, label = { Text("All") })
                listOf(FileKind.PDF, FileKind.WORD, FileKind.EXCEL, FileKind.POWERPOINT, FileKind.IMAGE, FileKind.TEXT).forEach { k ->
                    FilterChip(
                        selected = state.filter == k,
                        onClick = { state.filter = if (state.filter == k) null else k },
                        label = { Text(k.label) },
                    )
                }
            }
            Spacer(Modifier.height(8.dp))

            when {
                loading -> SkeletonRows()
                visible.isEmpty() -> EmptyState(
                    Icons.Rounded.FolderOpen,
                    "Nothing here",
                    if (state.filter != null) "No files match this filter in this folder." else "This folder is empty.",
                )
                grid -> LazyVerticalGrid(
                    columns = GridCells.Adaptive(150.dp),
                    contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 24.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    gridItems(visible, key = { it.docId }) { item ->
                        val isSel = item.docId in selected
                        Card(
                            modifier = Modifier.combinedClickable(
                                onClick = { if (selected.isNotEmpty()) toggleSelect(item) else openItem(item) },
                                onLongClick = { toggleSelect(item) },
                            ),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                            ),
                        ) {
                            Column(Modifier.padding(14.dp)) {
                                if (item.isDir) {
                                    Box(
                                        Modifier
                                            .size(52.dp)
                                            .clip(RoundedCornerShape(14.dp))
                                            .background(MaterialTheme.colorScheme.primaryContainer),
                                        contentAlignment = Alignment.Center,
                                    ) { Icon(Icons.Rounded.Folder, null, tint = MaterialTheme.colorScheme.primary) }
                                } else KindBadge(item.kind, size = 52)
                                Spacer(Modifier.height(10.dp))
                                Text(item.name, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    if (item.isDir) "Folder" else FileUtils.formatSize(item.size),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }
                else -> LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
                    items(visible, key = { it.docId }) { item ->
                        val isSel = item.docId in selected
                        var menu by remember { mutableStateOf(false) }
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .background(if (isSel) MaterialTheme.colorScheme.primaryContainer else androidx.compose.ui.graphics.Color.Transparent)
                                .combinedClickable(
                                    onClick = { if (selected.isNotEmpty()) toggleSelect(item) else openItem(item) },
                                    onLongClick = { toggleSelect(item) },
                                )
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            if (item.isDir) {
                                Box(
                                    Modifier
                                        .size(44.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(MaterialTheme.colorScheme.primaryContainer),
                                    contentAlignment = Alignment.Center,
                                ) { Icon(Icons.Rounded.Folder, null, tint = MaterialTheme.colorScheme.primary) }
                            } else KindBadge(item.kind)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
                                Text(
                                    if (item.isDir) "Folder" else "${FileUtils.formatSize(item.size)} · ${FileUtils.formatDate(item.modified)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            Box {
                                IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, "More") }
                                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                    if (!item.isDir) {
                                        DropdownMenuItem(text = { Text("Share") }, onClick = {
                                            menu = false
                                            FileUtils.share(ctx, item.uri, item.mime)
                                        })
                                    }
                                    DropdownMenuItem(text = { Text("Rename") }, onClick = { menu = false; renameTarget = item })
                                    DropdownMenuItem(text = { Text("Details") }, onClick = { menu = false; detailsTarget = item })
                                    DropdownMenuItem(text = { Text("Delete") }, onClick = { menu = false; deleteTargets = listOf(item) })
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // ---- Dialogs ----
    if (showNewFolder && treeUri != null && current != null) {
        NameDialog(
            title = "New folder",
            initial = "",
            confirm = "Create",
            onDismiss = { showNewFolder = false },
            onConfirm = { name ->
                showNewFolder = false
                scope.launch {
                    val ok = withContext(Dispatchers.IO) {
                        runCatching {
                            val parent = DocumentsContract.buildDocumentUriUsingTree(treeUri, current.docId)
                            DocumentsContract.createDocument(ctx.contentResolver, parent, Document.MIME_TYPE_DIR, name) != null
                        }.getOrDefault(false)
                    }
                    if (!ok) FileUtils.toast(ctx, "Could not create folder here.")
                    refresh++
                }
            },
        )
    }

    renameTarget?.let { target ->
        NameDialog(
            title = "Rename",
            initial = target.name,
            confirm = "Rename",
            onDismiss = { renameTarget = null },
            onConfirm = { name ->
                renameTarget = null
                scope.launch {
                    val ok = withContext(Dispatchers.IO) {
                        runCatching { DocumentsContract.renameDocument(ctx.contentResolver, target.uri, name) != null }
                            .getOrDefault(false)
                    }
                    if (!ok) FileUtils.toast(ctx, "Could not rename this item.")
                    refresh++
                }
            },
        )
    }

    if (deleteTargets.isNotEmpty()) {
        val targets = deleteTargets
        AlertDialog(
            onDismissRequest = { deleteTargets = emptyList() },
            title = { Text(if (targets.size == 1) "Delete ${targets[0].name}?" else "Delete ${targets.size} items?") },
            text = { Text("This permanently deletes the item from your device. It cannot be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    deleteTargets = emptyList()
                    scope.launch {
                        val failed = withContext(Dispatchers.IO) {
                            targets.count { t ->
                                !runCatching { DocumentsContract.deleteDocument(ctx.contentResolver, t.uri) }.getOrDefault(false)
                            }
                        }
                        if (failed > 0) FileUtils.toast(ctx, "$failed item(s) could not be deleted.")
                        refresh++
                    }
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleteTargets = emptyList() }) { Text("Cancel") } },
        )
    }

    detailsTarget?.let { t ->
        AlertDialog(
            onDismissRequest = { detailsTarget = null },
            title = { Text("Details") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    DetailLine("Name", t.name)
                    DetailLine("Type", if (t.isDir) "Folder" else t.mime.ifBlank { t.kind.label })
                    if (!t.isDir) DetailLine("Size", FileUtils.formatSize(t.size))
                    DetailLine("Modified", FileUtils.formatDate(t.modified))
                }
            },
            confirmButton = { TextButton(onClick = { detailsTarget = null }) { Text("Close") } },
        )
    }
}

@Composable
private fun DetailLine(label: String, value: String) {
    Column {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun NameDialog(
    title: String,
    initial: String,
    confirm: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true) },
        confirmButton = {
            TextButton(onClick = { onConfirm(text.trim()) }, enabled = text.isNotBlank() && !text.contains('/')) { Text(confirm) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
