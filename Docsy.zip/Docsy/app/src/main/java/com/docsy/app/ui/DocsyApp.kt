package com.docsy.app.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.docsy.app.data.DocEntry
import com.docsy.app.data.Prefs
import com.docsy.app.ui.favourites.FavouritesScreen
import com.docsy.app.ui.files.FilesScreen
import com.docsy.app.ui.files.FilesState
import com.docsy.app.ui.home.HomeScreen
import com.docsy.app.ui.settings.SettingsScreen
import com.docsy.app.ui.tools.ToolsScreen
import com.docsy.app.ui.viewer.ViewerScreen
import com.docsy.app.util.FileUtils

private data class Tab(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

private val Tabs = listOf(
    Tab("Home", Icons.Rounded.Home),
    Tab("Files", Icons.Rounded.FolderOpen),
    Tab("Tools", Icons.Rounded.Build),
    Tab("Favourites", Icons.Rounded.Star),
    Tab("Settings", Icons.Rounded.Settings),
)

@Composable
fun DocsyApp(prefs: Prefs, incoming: Uri?, onIncomingConsumed: () -> Unit) {
    val ctx = LocalContext.current
    val nav = rememberNavController()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var viewerUri by rememberSaveable { mutableStateOf<String?>(null) }
    val filesState = remember { FilesState() }

    fun openDocument(uri: Uri) {
        viewerUri = uri.toString()
        nav.navigate("viewer") { launchSingleTop = true }
    }

    val pickPdf = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            openDocument(uri)
        }
    }

    LaunchedEffect(incoming) {
        if (incoming != null) {
            openDocument(incoming)
            onIncomingConsumed()
        }
    }

    NavHost(nav, startDestination = "main", modifier = Modifier.fillMaxSize()) {
        composable("main") {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                bottomBar = {
                    NavigationBar {
                        Tabs.forEachIndexed { i, t ->
                            NavigationBarItem(
                                selected = tab == i,
                                onClick = { tab = i },
                                icon = { Icon(t.icon, contentDescription = t.label) },
                                label = { Text(t.label) },
                            )
                        }
                    }
                },
            ) { padding ->
                val content = Modifier
                    .fillMaxSize()
                    .padding(padding)
                androidx.compose.foundation.layout.Box(content) {
                    when (tab) {
                        0 -> HomeScreen(
                            prefs = prefs,
                            onPickPdf = { pickPdf.launch(arrayOf("application/pdf")) },
                            onOpen = { e: DocEntry -> openDocument(Uri.parse(e.uri)) },
                        )
                        1 -> FilesScreen(prefs, filesState, onOpenPdf = { openDocument(it) })
                        2 -> ToolsScreen(onOpenPdf = { openDocument(it) })
                        3 -> FavouritesScreen(prefs, onOpen = { e -> openDocument(Uri.parse(e.uri)) })
                        else -> SettingsScreen(prefs)
                    }
                }
            }
        }
        composable("viewer") {
            val u = viewerUri
            if (u == null) {
                LaunchedEffect(Unit) { nav.popBackStack() }
            } else {
                ViewerScreen(prefs, Uri.parse(u), onBack = { nav.popBackStack() })
            }
        }
    }
}
