# Docsy — Read. View. Manage.

Native Android (Kotlin + Jetpack Compose, Material 3) PDF reader. **Phase 1 core.**

## Build
- GitHub: push to GitHub → Actions → *Build Docsy APK* → download `Docsy-debug-apk` / `Docsy-release-apk` artifacts.
- Local: Android Studio (Koala+) → open this folder → Run. Or `./gradlew assembleDebug` (needs Android SDK + JDK 17).
- minSdk 26 (Android 8.0), target/compile SDK 34. Package `com.docsy.app`.
- The release APK is signed with the debug key so it installs directly. Use your own keystore for Play Store.

## Implemented in Phase 1
- Home: search (recents + favourites), Continue reading with progress, Recent, Favourites, Open PDF.
- PDF viewer (Android `PdfRenderer`, lazy page rendering + size-bounded LRU cache, one render thread):
  continuous vertical scroll or horizontal page swipe, pinch zoom, double-tap zoom, page slider + counter,
  go to page, thumbnails, bookmarks, light / dark / sepia reading modes, in-app brightness,
  view rotation, tap-to-hide toolbars (distraction-free), keeps screen on, remembers last page,
  share and print (native Android share sheet / print framework). Opens `ACTION_VIEW` PDFs from other apps.
- Files (Storage Access Framework — no storage permission): add folders, browse, filter by type,
  sort (name/date/size/type), list/grid, multi-select, share, rename, delete, create folder, details.
  Non-PDF files open in an external app.
- Favourites, Settings (theme, accent, text size, PDF defaults, recents limit, sort, view,
  app lock with biometrics/device credential, block screenshots, hide/clear recents, about/privacy/terms).
- Adaptive launcher icon, splash screen, GitHub Actions workflow.

## Added in Phase 2 (v1.1.0)
- **Text search** in the viewer with highlighted matches, next/previous, result count (PDFBox-Android text layer).
- **Table of contents** (document outline) sheet.
- **Password-protected PDFs**: enter the password to read. Docsy decrypts into a private cache copy
  (deleted on close and on next start); the original file is never changed.
- **Tools tab** (every tool saves a NEW file where you choose; originals untouched):
  Merge PDFs (reorderable), Extract pages, Delete pages, Rotate pages, Compress (recompresses embedded
  photos, optional metadata removal), Images to PDF, Add password (AES-128), Remove password (needs the password).

## Known limits
- **Search/TOC need a text layer.** Scanned/image-only PDFs show "no matches" until OCR is added (Phase 3).
  Highlight positions are computed from PDF text coordinates and can be slightly off on unusual fonts/layouts.
- **Compress** only shrinks embedded images. Text/vector PDFs usually won't get smaller; the app says so honestly.
  Images with transparency/masks are left untouched. Output is not guaranteed smaller than the input.
- PDFBox loads whole documents into memory while editing: very large files (hundreds of MB) may fail with a
  "not enough memory" message on low-RAM phones.
- Add password uses 128-bit AES. Remove password only works with the correct password.
- Not yet: annotations, page reorder/insert, sign/forms, scanner, OCR, DOC/XLS/PPT viewing, conversions, AI module,
  two-page view, copy/move in Files.
- **Not compiled or run on a device by the author of this zip** (no Android SDK in the authoring environment).
  Build via GitHub Actions and report any errors.

## Layout
`data/` prefs & models · `pdf/` PdfSession, PdfTools, PdfTextIndex · `ui/` screens (home, files, tools, favourites, settings, viewer) · `util/` file helpers.
