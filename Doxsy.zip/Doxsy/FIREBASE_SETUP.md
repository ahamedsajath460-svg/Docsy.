# Firebase + Google account setup (Doxsy)

The app builds without any of this. Google sign-in, Google Drive and Gmail simply stay off until you do the steps below.
Package name: `com.doxsy.app`

## 1. Get the signing SHA-1
Run the GitHub Action. In the log, step **"Show signing SHA-1"** prints the SHA1 / SHA256 of your release key
(it needs the KEYSTORE_* secrets; with the temporary debug key Google sign-in cannot work).

## 2. Firebase (Google sign-in)
1. https://console.firebase.google.com > Add project.
2. Add an **Android app**: package `com.doxsy.app`, paste the **SHA-1** (and SHA-256).
3. Build > Authentication > Sign-in method > turn on **Google**.
4. Download **google-services.json**.
5. Give it to the build, either way:
   - GitHub > Settings > Secrets > Actions > new secret `GOOGLE_SERVICES_JSON` = the whole file content, or
   - put the file at `app/google-services.json` in the project.

## 3. Google Drive and Gmail (Files tab > Google Drive / PDFs from emails)
1. https://console.cloud.google.com (same project as Firebase) > APIs & Services > Library:
   enable **Google Drive API** and **Gmail API**.
2. OAuth consent screen: add scopes `.../auth/drive` and `.../auth/gmail.readonly`.
   While the app is in "Testing", add your Google accounts under **Test users**.
3. Credentials: an **Android** OAuth client for `com.doxsy.app` + your SHA-1
   (Firebase creates one for you in step 2; check it exists).
Other people can use Drive/Gmail only after Google verifies the app (these are sensitive scopes).
