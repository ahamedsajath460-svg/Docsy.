# Doxsy — Read. View. Manage.

Native Android (Kotlin + Jetpack Compose, Material 3) PDF reader. **Phase 1 core.**

## Build
- GitHub: push to GitHub → Actions → *Build Doxsy APK* → download `Doxsy-debug-apk` / `Doxsy-release-apk` artifacts.
- Local: Android Studio (Koala+) → open this folder → Run. Or `./gradlew assembleDebug` (needs Android SDK + JDK 17).
- minSdk 26 (Android 8.0), target/compile SDK 34. Package `com.doxsy.app`.
- The release APK is signed with the debug key so it installs directly. Use your own keystore for Play Store.

## Implemented in Phase 1
- Home: search (recents + favourites), Continue reading with progress, Recent, Favourites, Open PDF.
- PDF viewer (Android `PdfRenderer`, lazy page rendering + size-bounded LRU cache, one render thread):
  continuous vertical scroll or horizontal page swipe, pinch zoom, double-tap zoom, page slider + counter,
  go to page, thumbnails, bookmarks, light / dark / sepia reading modes, in-app brightness,
  view rotation, tap-to-hide toolbars (distraction-free), keeps screen on, remembers last page,
  share and print (native Android share sheet / print framework). Opens `ACTION_VIEW` PDFs from other apps.
- Files (Storage Access Framework — no storage permission): add folders, browse, filter by type,
  sort (name/date/size/type), list/grid, multi-select, share, rename, delete, create folder, details.
  Non-PDF files open in an external app.
- Favourites, Settings (theme, accent, text size, PDF defaults, recents limit, sort, view,
  app lock with biometrics/device credential, block screenshots, hide/clear recents, about/privacy/terms).
- Adaptive launcher icon, splash screen, GitHub Actions workflow.

## Added in Phase 2 (v1.1.0)
- **Text search** in the viewer with highlighted matches, next/previous, result count (PDFBox-Android text layer).
- **Table of contents** (document outline) sheet.
- **Password-protected PDFs**: enter the password to read. Doxsy decrypts into a private cache copy
  (deleted on close and on next start); the original file is never changed.
- **Tools tab** (every tool saves a NEW file where you choose; originals untouched):
  Merge PDFs (reorderable), Extract pages, Delete pages, Rotate pages, Compress (recompresses embedded
  photos, optional metadata removal), Images to PDF, Add password (AES-128), Remove password (needs the password).

## Known limits
- **Search/TOC need a text layer.** Scanned/image-only PDFs show "no matches" until OCR is added (Phase 3).
  Highlight positions are computed from PDF text coordinates and can be slightly off on unusual fonts/layouts.
- **Compress** only shrinks embedded images. Text/vector PDFs usually won't get smaller; the app says so honestly.
  Images with transparency/masks are left untouched. Output is not guaranteed smaller than the input.
- PDFBox loads whole documents into memory while editing: very large files (hundreds of MB) may fail with a
  "not enough memory" message on low-RAM phones.
- Add password uses 128-bit AES. Remove password only works with the correct password.
- Not yet: annotations, page reorder/insert, sign/forms, scanner, OCR, DOC/XLS/PPT viewing, conversions, AI module,
  two-page view, copy/move in Files.
- **Not compiled or run on a device by the author of this zip** (no Android SDK in the authoring environment).
  Build via GitHub Actions and report any errors.

## Layout
`data/` prefs & models · `pdf/` PdfSession, PdfTools, PdfTextIndex · `ui/` screens (home, files, tools, favourites, settings, viewer) · `util/` file helpers.

## Home redesign (v2.1, WIP)
- Splash, first-run Welcome + "Your privacy matters", new Home (Welcome, dismissible tip cards,
  Recent / Starred tabs, thumbnails, list/grid, select all, clear recent, "+" button with hint),
  bottom bar Home / Files / Search. Settings via the profile icon. Not compiled by the author.
- Home > Recent now also lists every PDF/Word/Excel/PowerPoint/ODT on the phone (MediaStore scan). Files you open in Doxsy stay on top.
  Needs storage access: Android 10 and below = READ_EXTERNAL_STORAGE prompt, Android 11+ = "All files access" screen (asked once on first start, plus an "Allow access" card on Home).
  Non-PDF documents open in another app.
- Files tab is now a hub: On this device (folder browser), Photos (pick pictures -> one PDF), Google Drive / Browse more files
  (system file picker), PDFs from emails (downloaded attachments), Added folders (the old Files screen).
- Google Drive (browse folders, open files, upload with +), PDFs from Gmail, Firebase "Sign in with Google" (profile icon). See FIREBASE_SETUP.md.

## Latest update
- Files are grouped by folder (category headers) on Home, Files > On this device and Search.
- Home cards stay between "Welcome" and "Recent"; closing one hides it for 2 hours, then it returns.
- New Sign-in card (only when not signed in).
- Adobe-style "⋮" file menu (slow slide-up): Edit/Export/Compress/Set password, Share, Star, Rename, Save to cloud storage, Save a copy, Remove from recent, Delete.
- Google Drive / Email: all added accounts are saved; tapping a saved account opens it directly (account chooser).
- Every risky action (log out, remove account/folder/star/recent, delete file, clear recent) asks for confirmation (ui/ConfirmDialog.kt). Press Back twice quickly on Home to exit.
- App state (tab, open file + page, Files/Drive folder, search) is restored after Android closes the app in the background.
- "+" menu: Open file, Compress file (pick PDF, choose Light/Balanced/Strong, saves a new _compressed copy).

## Doxsy AI: which files it reads

Attach any file in the AI screen (paper-clip). The AI gets the file itself where it can:

| File | What the AI receives |
| --- | --- |
| PDF with text | The original PDF (OpenRouter models read it directly); Groq models get the full text |
| Scanned PDF | The first 3 pages as pictures (needs a picture-capable model: Groq Qwen 3.8, OpenRouter) |
| Pictures (JPG, PNG, WEBP, BMP, GIF, HEIC) | The picture itself (long side shrunk to 1400 px) |
| Word, Excel, PowerPoint (new + old), OpenDocument, RTF, CSV, HTML, XML, JSON, EPUB, TXT / MD / LOG | The complete text of the file |
| Other plain-text files (source code, config...) | The complete text |

A long file is cut into parts; for each question the parts that match the question best are sent, together
with the start of the file and parts spread over the rest (`AiContext`). Short files are sent whole.
Password-protected files cannot be read.
