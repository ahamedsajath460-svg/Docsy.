import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Firebase: the google-services plugin is applied only when app/google-services.json is present,
// so the project still builds (with Firebase sign-in switched off) without it.
if (file("google-services.json").exists()) {
    apply(plugin = "com.google.gms.google-services")
}

// Release signing: env vars (CI secrets) win, else keystore.properties in the project root.
val ksProps = Properties().apply {
    val f = rootProject.file("keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
fun ksValue(prop: String, env: String): String? = System.getenv(env) ?: ksProps.getProperty(prop)
val ksFile = ksValue("storeFile", "KEYSTORE_FILE")?.let { rootProject.file(it) }
val releaseSigningReady = ksFile != null && ksFile.exists() &&
    ksValue("storePassword", "KEYSTORE_PASSWORD") != null &&
    ksValue("keyAlias", "KEY_ALIAS") != null &&
    ksValue("keyPassword", "KEY_PASSWORD") != null

// AI keys: env vars (CI secrets) win, else ai-keys.properties in the project root.
val aiProps = Properties().apply {
    val f = rootProject.file("ai-keys.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
fun aiKey(prop: String, env: String): String =
    (System.getenv(env)?.takeIf { it.isNotBlank() } ?: aiProps.getProperty(prop) ?: "")
        .filter { it.isLetterOrDigit() || it == '-' || it == '_' }

android {
    namespace = "com.doxsy.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.doxsy.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "1.1.0"
        buildConfigField("String", "GROQ_API_KEY", "\"${aiKey("groqKey", "GROQ_API_KEY")}\"")
        buildConfigField("String", "OPENROUTER_API_KEY", "\"${aiKey("openRouterKey", "OPENROUTER_API_KEY")}\"")
    }

    signingConfigs {
        if (releaseSigningReady) {
            create("release") {
                storeFile = ksFile
                storePassword = ksValue("storePassword", "KEYSTORE_PASSWORD")
                keyAlias = ksValue("keyAlias", "KEY_ALIAS")
                keyPassword = ksValue("keyPassword", "KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = if (releaseSigningReady) signingConfigs.getByName("release")
            else signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    // Firebase Auth + Google sign-in (Credential Manager) and Google Drive / Gmail authorization
    implementation(platform("com.google.firebase:firebase-bom:33.1.2"))
    implementation("com.google.firebase:firebase-auth")
    implementation("androidx.credentials:credentials:1.2.2")
    implementation("androidx.credentials:credentials-play-services-auth:1.2.2")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")
    implementation("com.google.android.gms:play-services-auth:21.2.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.8.1")
    val composeBom = platform("androidx.compose:compose-bom:2024.06.00")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("androidx.activity:activity-compose:1.9.1")
    implementation("androidx.fragment:fragment-ktx:1.8.2")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.4")
    implementation("androidx.navigation:navigation-compose:2.7.7")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("androidx.exifinterface:exifinterface:1.3.7")
    // PDF text extraction, encryption and page tools (Apache-2.0)
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")

    // Unit tests of the AI thinking logic (JVM only; org.json because Android's copy is a stub on the JVM)
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")
}
