package com.doxsy.app.ui.home

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.doxsy.app.convert.Conversion
import com.doxsy.app.convert.ConvertEngine
import com.doxsy.app.convert.ConvertOutcome
import com.doxsy.app.convert.ConvertSettings
import com.doxsy.app.convert.DocTarget
import com.doxsy.app.convert.EXPORT_LANGUAGES
import com.doxsy.app.convert.PdfDocExporters
import com.doxsy.app.util.FileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private class ImageChoice(val label: String, val conv: Conversion)

private val IMAGE_CHOICES = listOf(
    ImageChoice("JPEG (jpeg)", Conversion.PDF_TO_JPG),
    ImageChoice("PNG (png)", Conversion.PDF_TO_PNG),
)

private class ExportDone(val ok: Boolean, val message: String, val uri: Uri?, val mime: String)

/**
 * Full-screen "Export PDF" page (Adobe style): Document tab (Word, Word 97-2003, RTF, Excel, PowerPoint
 * with a document language) and Image tab (JPEG, PNG), and an Export button at the bottom.
 * The PDF is never changed; the new file is saved in Downloads/Doxsy.
 */
@Composable
fun ExportPage(name: String, uri: Uri, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(0) }
    var docIndex by remember { mutableStateOf(0) }
    var imgIndex by remember { mutableStateOf(0) }
    var langIndex by remember { mutableStateOf(0) }
    var pickingLang by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var done by remember { mutableStateOf<ExportDone?>(null) }
    val docs = DocTarget.entries

    fun startExport() {
        busy = true
        val isDoc = tab == 0
        val target = docs[docIndex]
        val lang = EXPORT_LANGUAGES[langIndex]
        val image = IMAGE_CHOICES[imgIndex]
        scope.launch {
            val r = withContext(Dispatchers.IO) {
                if (isDoc) PdfDocExporters.run(ctx, uri, target, lang)
                else ConvertEngine.run(ctx, image.conv, listOf(uri), ConvertSettings(), {}, { _, _ -> })
            }
            busy = false
            done = when (r) {
                is ConvertOutcome.Success -> ExportDone(true, r.message, r.outputs.firstOrNull(), r.mime)
                is ConvertOutcome.Failure -> ExportDone(false, r.message, null, "")
            }
        }
    }

    Dialog(
        onDismissRequest = { if (!busy) onClose() },
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false),
    ) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                IconButton(onClick = { if (!busy) onClose() }, modifier = Modifier.padding(start = 8.dp, top = 8.dp)) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back")
                }
                Text(
                    "Export PDF",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 24.dp, top = 8.dp, bottom = 16.dp),
                )
                TabRow(selectedTabIndex = tab, containerColor = MaterialTheme.colorScheme.background) {
                    Tab(selected = tab == 0, onClick = { if (!busy) tab = 0 }, text = { Text("Document") })
                    Tab(selected = tab == 1, onClick = { if (!busy) tab = 1 }, text = { Text("Image") })
                }
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp)) {
                    if (tab == 0) {
                        docs.forEachIndexed { i, d ->
                            ChoiceRow(d.label, docIndex == i, !busy) { docIndex = i }
                        }
                        Spacer(Modifier.height(24.dp))
                        Text(
                            "DOCUMENT LANGUAGE",
                            style = MaterialTheme.typography.labelLarge,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
                        )
                        HorizontalDivider()
                        Row(
                            Modifier.fillMaxWidth().clickable(enabled = !busy) { pickingLang = true }.padding(horizontal = 8.dp, vertical = 16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(EXPORT_LANGUAGES[langIndex].label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                            Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "The text of every page is exported. Fonts, columns and pictures are not kept, and scanned PDFs have no text to export.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 8.dp),
                        )
                    } else {
                        IMAGE_CHOICES.forEachIndexed { i, c ->
                            ChoiceRow(c.label, imgIndex == i, !busy) { imgIndex = i }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Every page becomes one picture. Several pages are saved together in one ZIP file.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 8.dp),
                        )
                    }
                }
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (busy) {
                        CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp)
                        Spacer(Modifier.width(12.dp))
                        Text("Exporting…", style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.width(16.dp))
                    }
                    Button(onClick = { startExport() }, enabled = !busy) { Text("Export") }
                }
            }
        }
    }

    if (pickingLang) {
        AlertDialog(
            onDismissRequest = { pickingLang = false },
            title = { Text("Document language") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    EXPORT_LANGUAGES.forEachIndexed { i, l ->
                        ChoiceRow(l.label, langIndex == i, true) { langIndex = i; pickingLang = false }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { pickingLang = false }) { Text("Cancel") } },
        )
    }

    done?.let { r ->
        AlertDialog(
            onDismissRequest = { done = null },
            title = { Text(if (r.ok) "Exported" else "Couldn't export") },
            text = { Text(r.message) },
            confirmButton = {
                val out = r.uri
                if (r.ok && out != null) {
                    Row {
                        TextButton(onClick = { FileUtils.share(ctx, out, r.mime) }) { Text("Share") }
                        TextButton(onClick = {
                            runCatching {
                                ctx.startActivity(
                                    Intent(Intent.ACTION_VIEW).setDataAndType(out, r.mime)
                                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK),
                                )
                            }.onFailure { FileUtils.toast(ctx, "No app found to open this file") }
                        }) { Text("Open") }
                    }
                } else TextButton(onClick = { done = null }) { Text("OK") }
            },
            dismissButton = {
                TextButton(onClick = { val ok = r.ok; done = null; if (ok) onClose() }) { Text("Close") }
            },
        )
    }
}

@Composable
private fun ChoiceRow(label: String, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(enabled = enabled, onClick = onClick).padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = if (enabled) onClick else null, enabled = enabled)
        Spacer(Modifier.width(8.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }
}
