package com.doxsy.app.ui.viewer

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.RectF
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Redo
import androidx.compose.material.icons.automirrored.rounded.Undo
import androidx.compose.material.icons.rounded.AddPhotoAlternate
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.CropSquare
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.CalendarToday
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.FlipToBack
import androidx.compose.material.icons.rounded.FlipToFront
import androidx.compose.material.icons.rounded.Square
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.exifinterface.media.ExifInterface
import com.doxsy.app.annot.PageTextLayer
import com.doxsy.app.data.ReadingMode
import com.doxsy.app.edit.EKind
import com.doxsy.app.edit.EditItem
import com.doxsy.app.edit.EditPainter
import com.doxsy.app.edit.PdfEditExporter
import com.doxsy.app.edit.coverRectOf
import com.doxsy.app.edit.findSegment
import com.doxsy.app.pdf.PdfSession
import com.doxsy.app.pdf.ToolResult
import com.doxsy.app.ui.annot.AnnotPalette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min
import android.graphics.Color as AColor

internal enum class EMode { EDIT, ADD_TEXT, WHITEOUT }

/** Everything the editor knows: the edits, undo / redo, the selected edit and the current tool. */
@Stable
internal class PdfEditState {
    var items by mutableStateOf<List<EditItem>>(emptyList())
        private set
    val images = mutableStateMapOf<String, Bitmap>()
    var selectedId by mutableStateOf<String?>(null)
    var mode by mutableStateOf(EMode.EDIT)
    /** Colour of the next box drawn in the cover mode: white (whiteout) or black (blackout). */
    var coverColor by mutableStateOf(-1)
    var draft by mutableStateOf<Pair<Int, RectF>?>(null)
    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set

    private val undoStack = ArrayList<List<EditItem>>()
    private val redoStack = ArrayList<List<EditItem>>()

    val selected: EditItem? get() = selectedId?.let { id -> items.firstOrNull { it.id == id } }

    private fun flags() {
        canUndo = undoStack.isNotEmpty()
        canRedo = redoStack.isNotEmpty()
    }

    private fun commit(newList: List<EditItem>) {
        undoStack.add(items)
        if (undoStack.size > 100) undoStack.removeAt(0)
        redoStack.clear()
        items = newList
        flags()
    }

    fun add(item: EditItem) {
        commit(items + item)
        selectedId = item.id
    }

    fun update(item: EditItem) = commit(items.map { if (it.id == item.id) item else it })

    fun remove(id: String) {
        commit(items.filterNot { it.id == id })
        if (selectedId == id) selectedId = null
    }

    /** One undo step for a whole drag. */
    fun beginGesture() {
        undoStack.add(items)
        if (undoStack.size > 100) undoStack.removeAt(0)
        redoStack.clear()
        flags()
    }

    /** Small precise move (one undo step), for the arrow buttons. */
    fun nudge(id: String, du: Float, dv: Float) =
        commit(items.map { e -> if (e.id == id) e.copy(x = e.x + du, y = e.y + dv) else e })

    fun bringToFront(id: String) {
        val e = items.firstOrNull { it.id == id } ?: return
        if (items.last().id == id) return
        commit(items.filterNot { it.id == id } + e)
    }

    fun sendToBack(id: String) {
        val e = items.firstOrNull { it.id == id } ?: return
        if (items.first().id == id) return
        commit(listOf(e) + items.filterNot { it.id == id })
    }

    fun moveBy(id: String, du: Float, dv: Float) {
        items = items.map {
            if (it.id == id) it.copy(x = (it.x + du).coerceIn(-0.2f, 1.1f), y = (it.y + dv).coerceIn(-0.2f, 1.1f)) else it
        }
    }

    fun undo() {
        val prev = undoStack.removeLastOrNull() ?: return
        redoStack.add(items)
        items = prev
        if (selectedId != null && selected == null) selectedId = null
        flags()
    }

    fun redo() {
        val next = redoStack.removeLastOrNull() ?: return
        undoStack.add(items)
        items = next
        if (selectedId != null && selected == null) selectedId = null
        flags()
    }

    /** Topmost edit under the touch point (pixels of a [w] x [h] page view). */
    fun hitTest(page: Int, px: Float, py: Float, w: Float, h: Float): EditItem? {
        val slop = 12f
        for (i in items.indices.reversed()) {
            val item = items[i]
            if (item.page != page) continue
            val b = EditPainter.bounds(item, w, h)
            if (px >= b.left - slop && px <= b.right + slop && py >= b.top - slop && py <= b.bottom + slop) return item
        }
        return null
    }
}

/** What the text box dialog is editing. */
private class EditTarget(
    val existing: EditItem?,
    val page: Int,
    val x: Float,
    val y: Float,
    val text: String,
    val size: Float,
    val color: Int,
    val cover: RectF?,
    val coverColor: Int,
)

private fun loadBitmap(ctx: android.content.Context, uri: Uri, maxDim: Int = 1600): Bitmap? {
    val cr = ctx.contentResolver
    val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    if (opts.outWidth <= 0 || opts.outHeight <= 0) return null
    var sample = 1
    while (max(opts.outWidth, opts.outHeight) / sample > maxDim) sample *= 2
    val decode = BitmapFactory.Options().apply { inSampleSize = sample }
    val bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, decode) } ?: return null
    val orientation = runCatching {
        cr.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) }
    }.getOrNull() ?: ExifInterface.ORIENTATION_NORMAL
    val degrees = when (orientation) {
        ExifInterface.ORIENTATION_ROTATE_90 -> 90f
        ExifInterface.ORIENTATION_ROTATE_180 -> 180f
        ExifInterface.ORIENTATION_ROTATE_270 -> 270f
        else -> 0f
    }
    if (degrees == 0f) return bmp
    val m = Matrix()
    m.postRotate(degrees)
    return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
}

/**
 * Edit PDF: tap any text on the page to change it, add new text, hide things with a box, add pictures.
 * The result is saved as a NEW PDF; the original is never changed.
 */
@Composable
internal fun PdfEditorDialog(
    name: String,
    uri: Uri,
    session: PdfSession,
    onClose: () -> Unit,
    onOpenPdf: (Uri) -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val st = remember { PdfEditState() }
    val n = session.pageCount
    val base = name.substringBeforeLast('.')
    val listState = rememberLazyListState()
    val layer = remember(uri) { PageTextLayer(ctx.applicationContext, uri) }
    DisposableEffect(layer) { onDispose { layer.close() } }

    var target by remember { mutableStateOf<EditTarget?>(null) }
    var showColors by remember { mutableStateOf(false) }
    var confirmExit by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var outcome by remember { mutableStateOf<Outcome?>(null) }
    var notice by remember { mutableStateOf<String?>(null) }
    var askPermanent by remember { mutableStateOf(false) }
    var permanent by remember { mutableStateOf(false) }

    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { out ->
        if (out != null) {
            busy = true
            scope.launch {
                val r = PdfEditExporter.export(ctx, uri, st.items, st.images.toMap(), out, permanent)
                busy = false
                outcome = Outcome(r, out)
            }
        }
    }

    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { picked ->
        if (picked != null) {
            scope.launch {
                val bmp = withContext(Dispatchers.IO) { runCatching { loadBitmap(ctx, picked) }.getOrNull() }
                if (bmp == null) {
                    notice = "Could not read that picture."
                } else {
                    val page = listState.firstVisibleItemIndex.coerceIn(0, n - 1)
                    val aspect = session.aspect(page, 0)
                    val w = 0.4f
                    val h = w * bmp.height / bmp.width / aspect
                    val item = EditItem(kind = EKind.IMAGE, page = page, x = 0.3f, y = (0.4f - h / 2f).coerceAtLeast(0.02f), w = w, h = h)
                    st.images[item.id] = bmp
                    st.add(item)
                }
            }
        }
    }

    /** Tap on the page where no edit is: add new text, or pick the original text under the finger. */
    suspend fun tapOriginal(page: Int, u: Float, v: Float) {
        val aspect = session.aspect(page, 0)
        val chars = runCatching { layer.chars(page) }.getOrNull() ?: return
        val covers = st.items.filter { it.page == page }.mapNotNull { coverRectOf(it) }
        val usable = chars.filter { c -> covers.none { it.contains(c.rect.centerX(), c.rect.centerY()) } }
        val seg = findSegment(usable, u, v, aspect)
        if (seg == null) {
            notice = "No text here. Use \"Add text\" to type something new."
            return
        }
        val bmp = runCatching { session.renderAsync(page, 700, 0) }.getOrNull()
        val colors = if (bmp != null) {
            runCatching { EditPainter.sampleColors(bmp, seg.rect) }.getOrNull()
        } else null
        val textColor = colors?.first ?: AColor.BLACK
        val bgColor = colors?.second ?: AColor.WHITE
        val r = seg.rect
        val cover = RectF(r.left - 0.004f, r.top - r.height() * 0.12f, r.right + 0.004f, r.bottom + r.height() * 0.12f)
        val size = EditPainter.fitSize(seg.text, 0, false, r.width())
        val lh = EditPainter.lineHeightFrac(size, 0, false)
        val y = r.centerY() - (lh / aspect) / 2f
        target = EditTarget(null, page, r.left, y, seg.text, size, textColor, cover, bgColor)
    }

    fun onTapPage(page: Int, u: Float, v: Float) {
        if (st.mode == EMode.ADD_TEXT) {
            st.mode = EMode.EDIT
            target = EditTarget(null, page, u, v, "", 0.03f, AColor.BLACK, null, AColor.WHITE)
        } else {
            scope.launch { tapOriginal(page, u, v) }
        }
    }

    fun applyText(t: EditTarget, text: String) {
        val ex = t.existing
        val cover = t.cover
        when {
            text.isBlank() && ex == null && cover != null -> st.add(
                EditItem(
                    kind = EKind.COVER, page = t.page, x = cover.left, y = cover.top,
                    w = cover.width(), h = cover.height(), color = t.coverColor,
                ),
            )
            text.isBlank() && ex != null -> {
                val exCover = ex.cover
                st.remove(ex.id)
                if (exCover != null) {
                    st.add(
                        EditItem(
                            kind = EKind.COVER, page = ex.page, x = exCover.left, y = exCover.top,
                            w = exCover.width(), h = exCover.height(), color = ex.coverColor,
                        ),
                    )
                }
            }
            text.isBlank() -> {}
            ex != null -> st.update(ex.copy(text = text))
            else -> st.add(
                EditItem(
                    kind = EKind.TEXT, page = t.page, x = t.x, y = t.y, text = text, size = t.size,
                    color = t.color, cover = t.cover, coverColor = t.coverColor,
                ),
            )
        }
    }

    fun scaleSelected(f: Float) {
        val s = st.selected ?: return
        if (s.kind == EKind.TEXT) {
            st.update(s.copy(size = (s.size * f).coerceIn(0.008f, 0.25f)))
        } else {
            val nw = s.w * f
            val nh = s.h * f
            st.update(s.copy(x = s.x + (s.w - nw) / 2f, y = s.y + (s.h - nh) / 2f, w = nw, h = nh))
        }
    }

    fun duplicateSelected() {
        val s = st.selected ?: return
        val copy = s.copy(
            id = java.util.UUID.randomUUID().toString(),
            x = (s.x + 0.03f).coerceAtMost(0.95f),
            y = (s.y + 0.02f).coerceAtMost(0.95f),
            cover = null,
        )
        if (s.kind == EKind.IMAGE) {
            val bmp = st.images[s.id] ?: return
            st.images[copy.id] = bmp
        }
        st.add(copy)
    }

    fun addDate() {
        val page = listState.firstVisibleItemIndex.coerceIn(0, n - 1)
        val text = java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.getDefault()).format(java.util.Date())
        st.add(EditItem(kind = EKind.TEXT, page = page, x = 0.62f, y = 0.04f, text = text, size = 0.03f, color = AColor.BLACK))
    }

    fun requestClose() {
        if (st.items.isNotEmpty()) {
            confirmExit = true
        } else {
            onClose()
        }
    }

    Dialog(
        onDismissRequest = { if (!busy) requestClose() },
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false),
    ) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                // ---- top bar ----
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { if (!busy) requestClose() }) { Icon(Icons.Rounded.Close, "Close") }
                    Column(Modifier.weight(1f)) {
                        Text("Edit PDF", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                        Text(
                            notice ?: when (st.mode) {
                                EMode.ADD_TEXT -> "Tap where you want the new text"
                                EMode.WHITEOUT -> "Drag a box over what you want to hide"
                                else -> if (st.selected == null) "Tap any text on the page to edit it" else "Drag to move"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                        )
                    }
                    Text(
                        "${(listState.firstVisibleItemIndex + 1).coerceIn(1, n)} / $n",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 6.dp),
                    )
                    IconButton(onClick = { st.undo() }, enabled = st.canUndo) { Icon(Icons.AutoMirrored.Rounded.Undo, "Undo") }
                    IconButton(onClick = { st.redo() }, enabled = st.canRedo) { Icon(Icons.AutoMirrored.Rounded.Redo, "Redo") }
                    if (busy) {
                        CircularProgressIndicator(Modifier.padding(horizontal = 12.dp).size(22.dp), strokeWidth = 2.dp)
                    } else {
                        TextButton(
                            onClick = {
                                val hides = st.items.any { it.kind == EKind.COVER || (it.kind == EKind.TEXT && it.cover != null) }
                                if (hides) {
                                    askPermanent = true
                                } else {
                                    permanent = false
                                    save.launch("${base}_edited.pdf")
                                }
                            },
                            enabled = st.items.isNotEmpty(),
                        ) { Text("Save") }
                    }
                }

                // ---- pages ----
                LazyColumn(
                    state = listState,
                    modifier = Modifier.weight(1f).fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant),
                    contentPadding = PaddingValues(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(n, key = { it }) { i ->
                        EditablePage(i, session, st) { page, u, v -> notice = null; onTapPage(page, u, v) }
                    }
                }

                // ---- bottom bar ----
                Surface(tonalElevation = 3.dp, shadowElevation = 6.dp) {
                    val sel = st.selected
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 6.dp, horizontal = 8.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        if (sel == null) {
                            BarButton({ Icon(Icons.Rounded.TextFields, null) }, "Add text", st.mode == EMode.ADD_TEXT) {
                                notice = null
                                st.mode = if (st.mode == EMode.ADD_TEXT) EMode.EDIT else EMode.ADD_TEXT
                            }
                            BarButton(
                                { Icon(Icons.Rounded.CropSquare, null) }, "Whiteout",
                                st.mode == EMode.WHITEOUT && st.coverColor == AndroidWhite,
                            ) {
                                notice = null
                                val on = st.mode == EMode.WHITEOUT && st.coverColor == AndroidWhite
                                st.coverColor = AndroidWhite
                                st.mode = if (on) EMode.EDIT else EMode.WHITEOUT
                            }
                            BarButton(
                                { Icon(Icons.Rounded.Square, null) }, "Redact",
                                st.mode == EMode.WHITEOUT && st.coverColor == AColor.BLACK,
                            ) {
                                notice = null
                                val on = st.mode == EMode.WHITEOUT && st.coverColor == AColor.BLACK
                                st.coverColor = AColor.BLACK
                                st.mode = if (on) EMode.EDIT else EMode.WHITEOUT
                            }
                            BarButton({ Icon(Icons.Rounded.AddPhotoAlternate, null) }, "Image", false) {
                                notice = null
                                pickImage.launch("image/*")
                            }
                            BarButton({ Icon(Icons.Rounded.CalendarToday, null) }, "Date", false) {
                                notice = null
                                addDate()
                            }
                        } else {
                            if (sel.kind == EKind.TEXT) {
                                BarButton({ Icon(Icons.Rounded.Edit, null) }, "Edit", false) {
                                    target = EditTarget(sel, sel.page, sel.x, sel.y, sel.text, sel.size, sel.color, sel.cover, sel.coverColor)
                                }
                            }
                            BarButton({ Text("A−", fontWeight = FontWeight.Bold) }, "Smaller", false) { scaleSelected(0.9f) }
                            BarButton({ Text("A+", fontWeight = FontWeight.Bold) }, "Bigger", false) { scaleSelected(1.1f) }
                            if (sel.kind == EKind.TEXT) {
                                BarButton({ Text("B", fontWeight = FontWeight.Black) }, "Bold", sel.bold) { st.update(sel.copy(bold = !sel.bold)) }
                                BarButton({ Text(listOf("Sans", "Serif", "Mono")[sel.font % 3]) }, "Font", false) {
                                    st.update(sel.copy(font = (sel.font + 1) % 3))
                                }
                            }
                            if (sel.kind != EKind.IMAGE) {
                                BarButton({ Icon(Icons.Rounded.Palette, null) }, "Colour", false) { showColors = true }
                            }
                            BarButton({ Text("◀", fontWeight = FontWeight.Bold) }, "Left", false) { st.nudge(sel.id, -0.005f, 0f) }
                            BarButton({ Text("▲", fontWeight = FontWeight.Bold) }, "Up", false) { st.nudge(sel.id, 0f, -0.004f) }
                            BarButton({ Text("▼", fontWeight = FontWeight.Bold) }, "Down", false) { st.nudge(sel.id, 0f, 0.004f) }
                            BarButton({ Text("▶", fontWeight = FontWeight.Bold) }, "Right", false) { st.nudge(sel.id, 0.005f, 0f) }
                            BarButton({ Icon(Icons.Rounded.ContentCopy, null) }, "Copy", false) { duplicateSelected() }
                            BarButton({ Icon(Icons.Rounded.FlipToFront, null) }, "Front", false) { st.bringToFront(sel.id) }
                            BarButton({ Icon(Icons.Rounded.FlipToBack, null) }, "Back", false) { st.sendToBack(sel.id) }
                            BarButton({ Icon(Icons.Rounded.Delete, null) }, "Delete", false) { st.remove(sel.id) }
                        }
                    }
                }
            }

            // ---- dialogs ----
            target?.let { t ->
                TextEditDialog(t, onDone = { text ->
                    target = null
                    if (text != null) applyText(t, text)
                })
            }
            if (showColors) {
                val sel = st.selected
                AlertDialog(
                    onDismissRequest = { showColors = false },
                    title = { Text("Colour") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            AnnotPalette.chunked(4).forEach { row ->
                                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                                    row.forEach { c ->
                                        Box(
                                            Modifier
                                                .size(44.dp)
                                                .clip(CircleShape)
                                                .background(Color(c))
                                                .clickable {
                                                    showColors = false
                                                    if (sel != null) st.update(sel.copy(color = c))
                                                },
                                        )
                                    }
                                }
                            }
                        }
                    },
                    confirmButton = { TextButton(onClick = { showColors = false }) { Text("Cancel") } },
                )
            }
            if (askPermanent) {
                AlertDialog(
                    onDismissRequest = { askPermanent = false },
                    title = { Text("Hide text for good?") },
                    text = {
                        Text(
                            "A box over text only covers it. The text is still in the file and can be copied. " +
                                "\"Remove for good\" turns the pages that have a box or replaced text into pictures, " +
                                "so what was hidden is really gone (text on those pages can no longer be selected).",
                        )
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            askPermanent = false
                            permanent = true
                            save.launch("${base}_edited.pdf")
                        }) { Text("Remove for good") }
                    },
                    dismissButton = {
                        TextButton(onClick = {
                            askPermanent = false
                            permanent = false
                            save.launch("${base}_edited.pdf")
                        }) { Text("Just cover it") }
                    },
                )
            }
            if (confirmExit) {
                AlertDialog(
                    onDismissRequest = { confirmExit = false },
                    title = { Text("Discard your edits?") },
                    text = { Text("You have not saved them yet.") },
                    confirmButton = { TextButton(onClick = { confirmExit = false; onClose() }) { Text("Discard") } },
                    dismissButton = { TextButton(onClick = { confirmExit = false }) { Text("Keep editing") } },
                )
            }
            outcome?.let { o ->
                ResultDialog(o, onOpen = onOpenPdf, onClose = { outcome = null })
            }
        }
    }
}

@Composable
private fun BarButton(icon: @Composable () -> Unit, label: String, active: Boolean, onClick: () -> Unit) {
    val tint = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
    Column(
        Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (active) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(28.dp), contentAlignment = Alignment.Center) {
            androidx.compose.runtime.CompositionLocalProvider(
                androidx.compose.material3.LocalContentColor provides tint,
            ) { icon() }
        }
        Text(label, style = MaterialTheme.typography.labelSmall, color = tint)
    }
}

@Composable
private fun TextEditDialog(t: EditTarget, onDone: (String?) -> Unit) {
    var text by remember(t) { mutableStateOf(t.text) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(t) { runCatching { focus.requestFocus() } }
    AlertDialog(
        onDismissRequest = { onDone(null) },
        title = { Text(if (t.existing != null || t.cover != null) "Edit text" else "Add text") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    modifier = Modifier.fillMaxWidth().focusRequester(focus),
                    minLines = 1,
                    maxLines = 6,
                    label = { Text("Text") },
                )
                if (t.cover != null && t.existing == null) {
                    Text(
                        "Leave it empty to remove this text.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = { onDone(text) }) { Text("Done") } },
        dismissButton = { TextButton(onClick = { onDone(null) }) { Text("Cancel") } },
    )
}

/** One page: the rendered PDF underneath, the edits painted on top, and the touch handling. */
@Composable
private fun EditablePage(page: Int, session: PdfSession, st: PdfEditState, onTapPage: (Int, Float, Float) -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    Box(Modifier.fillMaxWidth().aspectRatio(1f / session.aspect(page, 0)).background(Color.White)) {
        PageImage(session, page, 1000, 0, ReadingMode.LIGHT, Modifier.fillMaxSize())
        Canvas(
            Modifier.fillMaxSize().pointerInput(page) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val w = size.width.toFloat()
                    val h = size.height.toFloat()
                    val start = down.position
                    val mode = st.mode
                    var moved = false
                    var grabbed = false
                    var dragId: String? = null
                    var begun = false
                    var hit: EditItem? = null
                    if (mode == EMode.WHITEOUT) {
                        grabbed = true
                    } else if (mode == EMode.EDIT) {
                        hit = st.hitTest(page, start.x, start.y, w, h)
                        if (hit != null) {
                            st.selectedId = hit.id
                            grabbed = true
                            dragId = hit.id
                        }
                    }
                    var last = start
                    while (true) {
                        val ev = awaitPointerEvent()
                        val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                        if (!ch.pressed) {
                            if (!moved) {
                                if (mode == EMode.ADD_TEXT) {
                                    onTapPage(page, start.x / w, start.y / h)
                                } else if (mode == EMode.EDIT && hit == null) {
                                    st.selectedId = null
                                    onTapPage(page, start.x / w, start.y / h)
                                }
                            } else if (mode == EMode.WHITEOUT) {
                                val d = st.draft
                                st.draft = null
                                if (d != null && d.second.width() > 0.01f && d.second.height() > 0.004f) {
                                    st.add(
                                        EditItem(
                                            kind = EKind.COVER, page = page, x = d.second.left, y = d.second.top,
                                            w = d.second.width(), h = d.second.height(), color = st.coverColor,
                                        ),
                                    )
                                }
                                st.mode = EMode.EDIT
                            }
                            break
                        }
                        if (!moved && (ch.position - start).getDistance() > viewConfiguration.touchSlop) moved = true
                        if (moved && grabbed) {
                            ch.consume()
                            val id = dragId
                            if (id != null) {
                                if (!begun) {
                                    st.beginGesture()
                                    begun = true
                                }
                                st.moveBy(id, (ch.position.x - last.x) / w, (ch.position.y - last.y) / h)
                            } else if (mode == EMode.WHITEOUT) {
                                val l = min(start.x, ch.position.x).coerceIn(0f, w) / w
                                val r = max(start.x, ch.position.x).coerceIn(0f, w) / w
                                val t = min(start.y, ch.position.y).coerceIn(0f, h) / h
                                val b = max(start.y, ch.position.y).coerceIn(0f, h) / h
                                st.draft = Pair(page, RectF(l, t, r, b))
                            }
                        }
                        last = ch.position
                    }
                    if (st.draft != null) st.draft = null
                }
            },
        ) {
            val w = size.width
            val h = size.height
            val mine = st.items.filter { it.page == page }
            drawIntoCanvas { c -> EditPainter.draw(c.nativeCanvas, w, h, mine, st.images) }
            val sel = st.selected
            if (sel != null && sel.page == page) {
                val b = EditPainter.bounds(sel, w, h)
                drawRect(primary, Offset(b.left - 4f, b.top - 4f), Size(b.width() + 8f, b.height() + 8f), style = Stroke(width = 3f))
            }
            val d = st.draft
            if (d != null && d.first == page) {
                val r = d.second
                drawRect(Color(0x66000000), Offset(r.left * w, r.top * h), Size(r.width() * w, r.height() * h))
            }
        }
    }
}

private const val AndroidWhite: Int = -1
