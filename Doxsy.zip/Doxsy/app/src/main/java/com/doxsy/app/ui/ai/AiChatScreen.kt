package com.doxsy.app.ui.ai

import android.content.Context
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AttachFile
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import com.doxsy.app.ai.AiAttachment
import com.doxsy.app.ai.AiClient
import com.doxsy.app.ai.AiDocText
import com.doxsy.app.ai.AiMessage
import com.doxsy.app.ai.AiThinking
import com.doxsy.app.ai.ThinkConfig
import com.doxsy.app.ai.ThinkDepth
import com.doxsy.app.util.FileUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** [thinking] is the model's reasoning text (empty when none came back); [seconds] is how long the answer took. */
class UiMsg(
    val role: String,
    val text: String,
    val error: Boolean = false,
    val thinking: String = "",
    val seconds: Int = 0,
)

/** The chat lives here, not in the screen, so it survives leaving the screen and an answer still arrives. */
object AiSession {
    val messages = mutableStateListOf<UiMsg>()
    var sending by mutableStateOf(false)
    var attaching by mutableStateOf(false)
    var docName by mutableStateOf<String?>(null)
    var attachment by mutableStateOf<AiAttachment?>(null)

    /** Thinking settings (Think deeper / Auto-think / Depth), saved on the phone. */
    var think by mutableStateOf(ThinkConfig())
        private set

    /** True while the answer being written is a thinking one (the indicator says so). */
    var thinkingNow by mutableStateOf(false)
        private set

    private var loaded = false
    private const val PREFS = "doxsy_ai"

    fun loadSettings(ctx: Context) {
        if (loaded) return
        loaded = true
        val sp = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        think = ThinkConfig(
            always = sp.getBoolean("think_always", false),
            auto = sp.getBoolean("think_auto", true),
            depth = ThinkDepth.parse(sp.getString("think_depth", null)),
        )
    }

    fun updateThink(ctx: Context, cfg: ThinkConfig) {
        think = cfg
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean("think_always", cfg.always)
            .putBoolean("think_auto", cfg.auto)
            .putString("think_depth", cfg.depth.name)
            .apply()
    }

    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    fun clearChat() {
        messages.clear()
        removeDoc()
    }

    fun removeDoc() {
        docName = null
        attachment = null
    }

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || sending) return
        messages += UiMsg("user", t)
        sending = true
        val history = messages.filter { !it.error }.map { AiMessage(it.role, it.text) }
        val att = attachment
        val cfg = think
        thinkingNow = AiThinking.wanted(cfg, t, att != null)
        scope.launch {
            try {
                val r = AiClient.chat(history, att, cfg)
                messages += UiMsg("assistant", r.text, thinking = r.thinking, seconds = r.seconds)
            } catch (e: Exception) {
                messages += UiMsg("assistant", e.message ?: "Something went wrong.", error = true)
            }
            sending = false
            thinkingNow = false
        }
    }

    fun attach(ctx: android.content.Context, uri: Uri) {
        if (attaching) return
        attaching = true
        val app = ctx.applicationContext
        scope.launch {
            try {
                val name = withContext(Dispatchers.IO) { FileUtils.displayName(app, uri) }
                val a = AiDocText.load(app, uri, name)
                attachment = a
                docName = name
            } catch (e: Exception) {
                messages += UiMsg("assistant", e.message ?: "Could not read this file.", error = true)
            }
            attaching = false
        }
    }
}

@Composable
fun AiChatScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val msgs = AiSession.messages
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val docName = AiSession.docName
    val att = AiSession.attachment

    BackHandler { onBack() }
    LaunchedEffect(Unit) { AiSession.loadSettings(ctx) }
    LaunchedEffect(msgs.size, AiSession.sending) {
        if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.size)
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                ctx.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            AiSession.attach(ctx, uri)
        }
    }

    fun send(t: String) {
        AiSession.send(t)
        input = ""
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding(),
    ) {
        // Top bar
        Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") }
            Icon(Icons.Rounded.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
            Spacer(Modifier.size(8.dp))
            Text("Doxsy AI", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            ThinkMenu(ctx)
            if (msgs.isNotEmpty() || docName != null) {
                IconButton(onClick = { AiSession.clearChat() }) { Icon(Icons.Rounded.DeleteOutline, "New chat") }
            }
        }

        // Attached document chip
        if (docName != null || AiSession.attaching) {
            Row(
                Modifier
                    .padding(horizontal = 12.dp, vertical = 4.dp)
                    .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(12.dp))
                    .padding(start = 12.dp, top = 6.dp, bottom = 6.dp, end = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (AiSession.attaching) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.size(10.dp))
                    Text("Reading file…", style = MaterialTheme.typography.bodyMedium)
                } else {
                    Icon(
                        if (att?.isPicture == true) Icons.Rounded.Image else Icons.Rounded.Description,
                        null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.size(20.dp),
                    )
                    Spacer(Modifier.size(8.dp))
                    Column(Modifier.weight(1f, fill = false)) {
                        Text(docName.orEmpty(), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        att?.note?.let { n ->
                            Text(n, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                    }
                    IconButton(onClick = { AiSession.removeDoc() }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Rounded.Close, "Remove file", modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        // Messages
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (msgs.isEmpty()) {
                EmptyState(hasDoc = docName != null, isPicture = att?.isPicture == true, onPick = { picker.launch(arrayOf("*/*")) }, onAsk = { send(it) })
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    itemsIndexed(msgs) { _, m -> Bubble(m) }
                    item {
                        if (AiSession.sending) {
                            Row(Modifier.padding(start = 4.dp, top = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.size(10.dp))
                                Text(if (AiSession.thinkingNow) "Thinking deeply…" else "Writing…", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        } else {
                            Spacer(Modifier.height(1.dp))
                        }
                    }
                }
            }
        }

        // Input
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.Bottom,
        ) {
            IconButton(onClick = { picker.launch(arrayOf("*/*")) }) { Icon(Icons.Rounded.AttachFile, "Attach a file") }
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Ask anything") },
                maxLines = 5,
                shape = RoundedCornerShape(24.dp),
            )
            Spacer(Modifier.size(6.dp))
            val canSend = input.isNotBlank() && !AiSession.sending
            Box(
                Modifier
                    .padding(bottom = 4.dp)
                    .size(48.dp)
                    .background(if (canSend) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                    .clickable(enabled = canSend) { send(input) },
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.AutoMirrored.Rounded.Send, "Send",
                    tint = if (canSend) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

/** The lightbulb in the top bar: Think deeper (always), Auto-think (hard questions only) and the depth. */
@Composable
private fun ThinkMenu(ctx: Context) {
    var open by remember { mutableStateOf(false) }
    val cfg = AiSession.think
    Box {
        IconButton(onClick = { open = true }) {
            Icon(
                Icons.Rounded.Lightbulb,
                "Thinking settings",
                tint = if (cfg.always) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(
                text = { MenuLabel("Think deeper", "Think before every answer") },
                onClick = { AiSession.updateThink(ctx, cfg.copy(always = !cfg.always)) },
                trailingIcon = { Switch(checked = cfg.always, onCheckedChange = null) },
            )
            DropdownMenuItem(
                text = { MenuLabel("Auto-think", "Only for hard questions") },
                onClick = { AiSession.updateThink(ctx, cfg.copy(auto = !cfg.auto)) },
                trailingIcon = { Switch(checked = cfg.auto, onCheckedChange = null) },
            )
            DropdownMenuItem(
                text = {
                    Column {
                        Text("Thinking depth", style = MaterialTheme.typography.bodyLarge)
                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            for (d in ThinkDepth.values()) {
                                val on = d == cfg.depth
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (on) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier.clickable { AiSession.updateThink(ctx, cfg.copy(depth = d)) },
                                ) {
                                    Text(
                                        d.label,
                                        Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                                    )
                                }
                            }
                        }
                    }
                },
                onClick = {},
            )
        }
    }
}

@Composable
private fun MenuLabel(title: String, hint: String) {
    Column {
        Text(title, style = MaterialTheme.typography.bodyLarge)
        Text(hint, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun EmptyState(hasDoc: Boolean, isPicture: Boolean, onPick: () -> Unit, onAsk: (String) -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(64.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
        }
        Spacer(Modifier.height(16.dp))
        Text("How can I help?", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        Text(
            if (hasDoc) "Ask about your file." else "Ask anything, or attach a file (PDF, Word, Excel, PowerPoint, picture...) and ask about it.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(20.dp))
        if (hasDoc && isPicture) {
            Suggestion("Describe this picture") { onAsk("Describe this picture in detail.") }
            Suggestion("Read the text in it") { onAsk("Read out all the text you can see in this picture.") }
        } else if (hasDoc) {
            Suggestion("Summarize this document") { onAsk("Summarize this document.") }
            Suggestion("List the key points") { onAsk("List the key points of this document as bullet points.") }
            Suggestion("Explain it in simple words") { onAsk("Explain this document in very simple words.") }
        } else {
            Suggestion("Attach a file to summarize", onPick)
            Suggestion("Write a short professional email") { onAsk("Write a short professional email asking for a meeting next week.") }
            Suggestion("Explain a topic simply") { onAsk("Explain how a PDF file works in simple words.") }
        }
    }
}

@Composable
private fun Suggestion(text: String, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.padding(vertical = 4.dp).clickable(onClick = onClick),
    ) {
        Text(text, Modifier.padding(horizontal = 16.dp, vertical = 10.dp), style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun Bubble(m: UiMsg) {
    val mine = m.role == "user"
    val bg = when {
        mine -> MaterialTheme.colorScheme.primary
        m.error -> MaterialTheme.colorScheme.errorContainer
        else -> MaterialTheme.colorScheme.surfaceVariant
    }
    val fg = when {
        mine -> MaterialTheme.colorScheme.onPrimary
        m.error -> MaterialTheme.colorScheme.onErrorContainer
        else -> MaterialTheme.colorScheme.onSurface
    }
    val clipboard = LocalClipboardManager.current
    val ctx = LocalContext.current
    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
        if (!mine && !m.error && m.thinking.isNotBlank()) {
            var open by remember { mutableStateOf(false) }
            Row(
                Modifier.clickable { open = !open }.padding(vertical = 4.dp, horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.Lightbulb, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                Spacer(Modifier.size(6.dp))
                Text(
                    "Reasoning · answered in ${m.seconds} s",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Icon(
                    if (open) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                    if (open) "Hide reasoning" else "Show reasoning",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(18.dp),
                )
            }
            if (open) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.widthIn(max = 320.dp).padding(bottom = 6.dp),
                ) {
                    SelectionContainer {
                        Text(
                            m.thinking,
                            Modifier.padding(10.dp),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = bg,
            modifier = Modifier.widthIn(max = 320.dp),
        ) {
            SelectionContainer {
                Text(
                    if (mine || m.error) AnnotatedString(m.text) else markdown(m.text, fg),
                    Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    color = fg,
                    style = MaterialTheme.typography.bodyLarge,
                )
            }
        }
        if (!mine && !m.error) {
            IconButton(onClick = { clipboard.setText(AnnotatedString(m.text)); FileUtils.toast(ctx, "Copied") }, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Rounded.ContentCopy, "Copy", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
            }
        }
    }
}

/** Very small Markdown: **bold**, `code`, # headings and - bullets. */
private fun markdown(text: String, base: Color): AnnotatedString = buildAnnotatedString {
    val inline = Regex("\\*\\*(.+?)\\*\\*|`([^`]+)`")
    val lines = text.lines()
    lines.forEachIndexed { i, raw ->
        var line = raw
        val head = Regex("^#{1,6}\\s+").find(line)
        if (head != null) line = line.removeRange(head.range)
        line = line.replace(Regex("^(\\s*)[-*]\\s+"), "\$1• ")
        val start = length
        var idx = 0
        for (m in inline.findAll(line)) {
            append(line.substring(idx, m.range.first))
            if (m.groupValues[1].isNotEmpty()) {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(m.groupValues[1]) }
            } else {
                withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = base.copy(alpha = 0.12f))) { append(m.groupValues[2]) }
            }
            idx = m.range.last + 1
        }
        append(line.substring(idx))
        if (head != null) addStyle(SpanStyle(fontWeight = FontWeight.Bold), start, length)
        if (i < lines.lastIndex) append("\n")
    }
}
