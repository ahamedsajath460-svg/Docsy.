package com.doxsy.app.util

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import java.io.File
import java.io.IOException
import java.io.OutputStream

/**
 * Where Doxsy writes NEW files it produces (converted files, signed copies, exports).
 *
 * 1. If the user picked an output folder (Storage Access Framework tree), files go there.
 * 2. Otherwise Android 10+ uses Downloads/Doxsy through MediaStore (no permission needed).
 * 3. Android 8-9 falls back to the app's own external "Documents/Doxsy" folder (no permission needed).
 */
object OutputStore {
    private const val PREFS = "doxsy_output"
    private const val KEY_TREE = "tree"

    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun outputTree(ctx: Context): Uri? = sp(ctx).getString(KEY_TREE, null)?.let(Uri::parse)

    /** The caller must already hold (or have taken) persistable read+write permission for [tree]. */
    fun setOutputTree(ctx: Context, tree: Uri?) {
        sp(ctx).edit().apply { if (tree == null) remove(KEY_TREE) else putString(KEY_TREE, tree.toString()) }.apply()
    }

    fun label(ctx: Context): String {
        val tree = outputTree(ctx)
        if (tree != null) {
            val doc = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
            return FileUtils.documentName(ctx, doc) ?: "Chosen folder"
        }
        return if (Build.VERSION.SDK_INT >= 29) "Downloads/Doxsy" else "Documents/Doxsy (app folder)"
    }

    /** Creates [displayName] and lets [block] write to it. Returns the new document's Uri. Throws IOException. */
    fun write(ctx: Context, displayName: String, mime: String, block: (OutputStream) -> Unit): Uri {
        val app = ctx.applicationContext
        val name = AppFiles.safeName(displayName)
        val tree = outputTree(app)
        if (tree != null) {
            try {
                return writeToTree(app, tree, name, mime, block)
            } catch (e: SecurityException) {
                // Permission to the chosen folder was lost: forget it and use the default location.
                setOutputTree(app, null)
            }
        }
        return if (Build.VERSION.SDK_INT >= 29) writeToDownloads(app, name, mime, block)
        else writeToAppDocuments(app, name, block)
    }

    /** Writes into a specific SAF tree (used by the file manager, Save As ...). */
    fun writeToTree(ctx: Context, tree: Uri, name: String, mime: String, block: (OutputStream) -> Unit): Uri {
        val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        val doc = DocumentsContract.createDocument(ctx.contentResolver, parent, mime, name)
            ?: throw IOException("Could not create the file in the chosen folder.")
        try {
            ctx.contentResolver.openOutputStream(doc, "w")?.use(block)
                ?: throw IOException("Could not write to the chosen folder.")
        } catch (e: Exception) {
            runCatching { DocumentsContract.deleteDocument(ctx.contentResolver, doc) }
            throw e
        }
        return doc
    }

    private fun writeToDownloads(ctx: Context, name: String, mime: String, block: (OutputStream) -> Unit): Uri {
        val resolver = ctx.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Doxsy")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
        }
        val collection = if (Build.VERSION.SDK_INT >= 29) MediaStore.Downloads.EXTERNAL_CONTENT_URI
        else MediaStore.Files.getContentUri("external")
        val uri = resolver.insert(collection, values) ?: throw IOException("Could not create the output file.")
        try {
            resolver.openOutputStream(uri, "w")?.use(block) ?: throw IOException("Could not write the output file.")
            if (Build.VERSION.SDK_INT >= 29) {
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                resolver.update(uri, done, null, null)
            }
        } catch (e: Exception) {
            runCatching { resolver.delete(uri, null, null) }
            throw e
        }
        return uri
    }

    private fun writeToAppDocuments(ctx: Context, name: String, block: (OutputStream) -> Unit): Uri {
        val dir = File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: ctx.filesDir, "Doxsy").also { it.mkdirs() }
        var f = File(dir, name)
        var n = 1
        val base = name.substringBeforeLast('.', name)
        val ext = name.substringAfterLast('.', "")
        while (f.exists()) {
            f = File(dir, if (ext.isEmpty()) "$base ($n)" else "$base ($n).$ext")
            n++
        }
        try {
            f.outputStream().use(block)
        } catch (e: Exception) {
            f.delete()
            throw e
        }
        return AppFiles.uriFor(ctx, f)
    }

    fun mimeFor(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "pdf" -> "application/pdf"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "webp" -> "image/webp"
        "txt" -> "text/plain"
        "html", "htm" -> "text/html"
        "zip" -> "application/zip"
        else -> "application/octet-stream"
    }
}
