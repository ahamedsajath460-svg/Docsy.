package com.doxsy.app.ui.viewer

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.RotateLeft
import androidx.compose.material.icons.rounded.RotateRight
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.doxsy.app.data.ReadingMode
import com.doxsy.app.pdf.PdfSession
import com.doxsy.app.pdf.PdfTools
import com.doxsy.app.pdf.ToolResult
import kotlinx.coroutines.launch

private enum class PageAction(val label: String, val suffix: String) {
    ROTATE_LEFT("Rotate left", "_rotated"),
    ROTATE_RIGHT("Rotate right", "_rotated"),
    DELETE("Delete", "_edited"),
    EXTRACT("Extract", "_extract"),
}

/**
 * "Edit pages": pick pages from thumbnails, then rotate / delete / extract them.
 * The original PDF is never changed - the result is saved as a NEW file you choose.
 */
@Composable
internal fun PageEditorDialog(name: String, uri: Uri, session: PdfSession, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val n = session.pageCount
    val selected = remember { mutableStateListOf<Int>() }
    var pending by remember { mutableStateOf<PageAction?>(null) }
    var busy by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<ToolResult?>(null) }
    val base = name.substringBeforeLast('.')

    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { out ->
        val action = pending
        pending = null
        if (out != null && action != null) {
            val pages = selected.sorted()
            busy = true
            result = null
            scope.launch {
                val r = when (action) {
                    PageAction.ROTATE_LEFT -> PdfTools.rotatePages(ctx, uri, pages, -90, out)
                    PageAction.ROTATE_RIGHT -> PdfTools.rotatePages(ctx, uri, pages, 90, out)
                    PageAction.DELETE -> PdfTools.deletePages(ctx, uri, pages, out)
                    PageAction.EXTRACT -> PdfTools.extractPages(ctx, uri, pages, out)
                }
                busy = false
                result = r
                if (r is ToolResult.Done) selected.clear()
            }
        }
    }

    fun start(a: PageAction) {
        if (selected.isEmpty() || busy) return
        pending = a
        save.launch(base + a.suffix + ".pdf")
    }

    Dialog(
        onDismissRequest = { if (!busy) onClose() },
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false),
    ) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { if (!busy) onClose() }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") }
                    Column(Modifier.weight(1f)) {
                        Text("Edit pages", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                        Text(
                            if (selected.isEmpty()) "Tap pages to select" else "${selected.size} selected",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    TextButton(onClick = {
                        if (selected.size == n) selected.clear() else { selected.clear(); selected.addAll(0 until n) }
                    }) { Text(if (selected.size == n) "Clear" else "Select all") }
                }

                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.weight(1f),
                ) {
                    items((0 until n).toList(), key = { it }) { i ->
                        val on = i in selected
                        Column(
                            Modifier.clickable { if (on) selected.remove(i) else selected.add(i) },
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Box {
                                PageImage(
                                    session, i, 240, 0, ReadingMode.LIGHT,
                                    Modifier
                                        .fillMaxWidth()
                                        .aspectRatio(1f / session.aspect(i, 0))
                                        .clip(RoundedCornerShape(6.dp))
                                        .border(
                                            if (on) 3.dp else 1.dp,
                                            if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                            RoundedCornerShape(6.dp),
                                        ),
                                )
                                Icon(
                                    if (on) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                                    null,
                                    tint = if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                                    modifier = Modifier.align(Alignment.TopEnd).padding(4.dp).size(24.dp),
                                )
                            }
                            Text("${i + 1}", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }

                // Result / progress message
                val r = result
                if (busy) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                        Text("  Saving…", style = MaterialTheme.typography.bodyMedium)
                    }
                } else if (r != null) {
                    val ok = r is ToolResult.Done
                    val msg = when (r) {
                        is ToolResult.Done -> r.message
                        is ToolResult.Failed -> r.message
                    }
                    Text(
                        (if (ok) "Saved as a new file. " else "") + msg,
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                    )
                }

                // Action bar
                Surface(tonalElevation = 3.dp, shadowElevation = 6.dp) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                        ActionButton(Icons.Rounded.RotateLeft, "Rotate left", selected.isNotEmpty() && !busy) { start(PageAction.ROTATE_LEFT) }
                        ActionButton(Icons.Rounded.RotateRight, "Rotate right", selected.isNotEmpty() && !busy) { start(PageAction.ROTATE_RIGHT) }
                        ActionButton(Icons.Rounded.Delete, "Delete", selected.isNotEmpty() && !busy) { start(PageAction.DELETE) }
                        ActionButton(Icons.Rounded.ContentCopy, "Extract", selected.isNotEmpty() && !busy) { start(PageAction.EXTRACT) }
                    }
                }
            }
        }
    }
}

@Composable
private fun ActionButton(icon: ImageVector, label: String, enabled: Boolean, onClick: () -> Unit) {
    val tint = if (enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
    Column(
        Modifier.clip(RoundedCornerShape(12.dp)).clickable(enabled = enabled, onClick = onClick).padding(horizontal = 14.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, label, tint = tint)
        Text(label, style = MaterialTheme.typography.labelSmall, color = tint)
    }
}
