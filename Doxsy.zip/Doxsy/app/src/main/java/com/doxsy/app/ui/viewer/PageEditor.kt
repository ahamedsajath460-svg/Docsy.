package com.doxsy.app.ui.viewer

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.automirrored.rounded.Redo
import androidx.compose.material.icons.automirrored.rounded.Undo
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.FileCopy
import androidx.compose.material.icons.rounded.NoteAdd
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.RotateLeft
import androidx.compose.material.icons.rounded.RotateRight
import androidx.compose.material.icons.rounded.SwapVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.doxsy.app.data.ReadingMode
import com.doxsy.app.pdf.PdfSession
import com.doxsy.app.pdf.PdfTools
import com.doxsy.app.pdf.ToolResult
import kotlinx.coroutines.launch

/** One page in the organizer: a page of the original ([source] >= 0) or a blank page (-1). */
private data class PageItem(val key: Int, val source: Int, val rotation: Int)

private enum class PageSave(val suffix: String) { ALL("_organized"), EXTRACT("_extract") }

/**
 * Organize pages: rearrange, rotate, delete, duplicate, insert blank pages and extract - all staged on
 * screen with live thumbnails, then saved ONCE as a NEW PDF. The original is never changed.
 */
@Composable
internal fun PageEditorDialog(
    name: String,
    uri: Uri,
    session: PdfSession,
    onClose: () -> Unit,
    onOpenPdf: (Uri) -> Unit = {},
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val n = session.pageCount
    val base = name.substringBeforeLast('.')

    var pages by remember { mutableStateOf(List(n) { PageItem(it, it, 0) }) }
    var nextKey by remember { mutableIntStateOf(n) }
    val selected = remember { mutableStateListOf<Int>() }
    val undo = remember { ArrayList<List<PageItem>>() }
    val redo = remember { ArrayList<List<PageItem>>() }
    var historyTick by remember { mutableIntStateOf(0) }

    var pending by remember { mutableStateOf<PageSave?>(null) }
    var busy by remember { mutableStateOf(false) }
    var outcome by remember { mutableStateOf<Outcome?>(null) }
    var confirmExit by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf<String?>(null) }

    val changed = pages.size != n || pages.withIndex().any { (i, p) -> p.source != i || p.rotation != 0 }
    val canUndo = historyTick >= 0 && undo.isNotEmpty()
    val canRedo = historyTick >= 0 && redo.isNotEmpty()

    fun change(newList: List<PageItem>) {
        if (newList == pages) return
        undo.add(pages)
        if (undo.size > 100) undo.removeAt(0)
        redo.clear()
        pages = newList
        historyTick++
        notice = null
    }

    fun keepSelectionValid() {
        val alive = pages.map { it.key }.toSet()
        selected.removeAll { it !in alive }
    }

    fun doUndo() {
        val prev = undo.removeLastOrNull() ?: return
        redo.add(pages)
        pages = prev
        historyTick++
        keepSelectionValid()
    }

    fun doRedo() {
        val next = redo.removeLastOrNull() ?: return
        undo.add(pages)
        pages = next
        historyTick++
        keepSelectionValid()
    }

    fun rotateSelected(deg: Int) {
        if (selected.isEmpty()) return
        val sel = selected.toSet()
        change(pages.map { if (it.key in sel) it.copy(rotation = ((it.rotation + deg) % 360 + 360) % 360) else it })
    }

    fun deleteSelected() {
        if (selected.isEmpty()) return
        val sel = selected.toSet()
        val rest = pages.filter { it.key !in sel }
        if (rest.isEmpty()) {
            notice = "At least one page must stay."
            return
        }
        change(rest)
        selected.clear()
    }

    fun duplicateSelected() {
        if (selected.isEmpty()) return
        val sel = selected.toSet()
        val out = ArrayList<PageItem>()
        for (p in pages) {
            out.add(p)
            if (p.key in sel) out.add(p.copy(key = nextKey++))
        }
        change(out)
    }

    fun addBlank() {
        val blank = PageItem(nextKey++, -1, 0)
        val last = pages.indexOfLast { it.key in selected }
        val out = pages.toMutableList()
        out.add(if (last >= 0) last + 1 else out.size, blank)
        change(out)
        selected.clear()
        selected.add(blank.key)
    }

    fun moveSelected(dir: Int) {
        if (selected.isEmpty()) return
        val sel = selected.toSet()
        val list = pages.toMutableList()
        if (dir < 0) {
            for (i in 1 until list.size) {
                if (list[i].key in sel && list[i - 1].key !in sel) java.util.Collections.swap(list, i, i - 1)
            }
        } else {
            for (i in list.size - 2 downTo 0) {
                if (list[i].key in sel && list[i + 1].key !in sel) java.util.Collections.swap(list, i, i + 1)
            }
        }
        change(list)
    }

    fun selectWhere(test: (Int, PageItem) -> Boolean) {
        selected.clear()
        pages.forEachIndexed { i, p -> if (test(i, p)) selected.add(p.key) }
    }

    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { out ->
        val action = pending
        pending = null
        if (out != null && action != null) {
            val chosen = if (action == PageSave.EXTRACT) pages.filter { it.key in selected } else pages
            val plan = chosen.map { PdfTools.PagePlan(it.source, it.rotation) }
            busy = true
            scope.launch {
                val r = PdfTools.organize(ctx, uri, plan, out)
                busy = false
                outcome = Outcome(r, out)
            }
        }
    }

    fun startSave(a: PageSave) {
        if (busy) return
        if (a == PageSave.EXTRACT && selected.isEmpty()) return
        pending = a
        save.launch(base + a.suffix + ".pdf")
    }

    fun requestClose() {
        if (changed) {
            confirmExit = true
        } else {
            onClose()
        }
    }

    Dialog(
        onDismissRequest = { if (!busy) requestClose() },
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false),
    ) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                // ---- top bar ----
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { if (!busy) requestClose() }) { Icon(Icons.Rounded.Close, "Close") }
                    Column(Modifier.weight(1f)) {
                        Text("Organize pages", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                        Text(
                            notice ?: ("${pages.size} pages" +
                                (if (selected.isNotEmpty()) " · ${selected.size} selected" else " · tap pages to select") +
                                (if (changed) " · edited" else "")),
                            style = MaterialTheme.typography.bodySmall,
                            color = if (notice != null) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                        )
                    }
                    IconButton(onClick = { doUndo() }, enabled = canUndo) { Icon(Icons.AutoMirrored.Rounded.Undo, "Undo") }
                    IconButton(onClick = { doRedo() }, enabled = canRedo) { Icon(Icons.AutoMirrored.Rounded.Redo, "Redo") }
                    if (busy) {
                        CircularProgressIndicator(Modifier.padding(horizontal = 12.dp).size(22.dp), strokeWidth = 2.dp)
                    } else {
                        TextButton(onClick = { startSave(PageSave.ALL) }, enabled = changed) { Text("Save") }
                    }
                }

                // ---- quick selection ----
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Pill("All") { selectWhere { _, _ -> true } }
                    Pill("None") { selected.clear() }
                    Pill("Odd") { selectWhere { i, _ -> i % 2 == 0 } }
                    Pill("Even") { selectWhere { i, _ -> i % 2 == 1 } }
                    Pill("Rotate all") { change(pages.map { it.copy(rotation = (it.rotation + 90) % 360) }) }
                    Pill("Invert") {
                        val keep = pages.filter { it.key !in selected }.map { it.key }
                        selected.clear()
                        selected.addAll(keep)
                    }
                }

                // ---- page grid ----
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    contentPadding = PaddingValues(14.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.weight(1f),
                ) {
                    items(pages, key = { it.key }) { item ->
                        val index = pages.indexOf(item)
                        PageCell(item, index, item.key in selected, session) {
                            if (item.key in selected) selected.remove(item.key) else selected.add(item.key)
                        }
                    }
                }

                // ---- actions ----
                Surface(tonalElevation = 3.dp, shadowElevation = 6.dp) {
                    val any = selected.isNotEmpty() && !busy
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 6.dp, horizontal = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(2.dp),
                    ) {
                        ActionButton(Icons.Rounded.RotateLeft, "Rotate left", any) { rotateSelected(-90) }
                        ActionButton(Icons.Rounded.RotateRight, "Rotate right", any) { rotateSelected(90) }
                        ActionButton(Icons.AutoMirrored.Rounded.ArrowBack, "Move back", any) { moveSelected(-1) }
                        ActionButton(Icons.AutoMirrored.Rounded.ArrowForward, "Move on", any) { moveSelected(1) }
                        ActionButton(Icons.Rounded.ContentCopy, "Duplicate", any) { duplicateSelected() }
                        ActionButton(Icons.Rounded.NoteAdd, "Blank page", !busy) { addBlank() }
                        ActionButton(Icons.Rounded.Delete, "Delete", any) { deleteSelected() }
                        ActionButton(Icons.Rounded.SwapVert, "Reverse", !busy && pages.size > 1) { change(pages.reversed()) }
                        ActionButton(Icons.Rounded.FileCopy, "Extract", any) { startSave(PageSave.EXTRACT) }
                    }
                }
            }

            if (confirmExit) {
                AlertDialog(
                    onDismissRequest = { confirmExit = false },
                    title = { Text("Discard your changes?") },
                    text = { Text("You have not saved them yet.") },
                    confirmButton = { TextButton(onClick = { confirmExit = false; onClose() }) { Text("Discard") } },
                    dismissButton = { TextButton(onClick = { confirmExit = false }) { Text("Keep editing") } },
                )
            }
            outcome?.let { o ->
                ResultDialog(o, onOpen = onOpenPdf, onClose = { outcome = null })
            }
        }
    }
}

@Composable
private fun Pill(label: String, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.clip(RoundedCornerShape(50)).clickable(onClick = onClick),
        shape = RoundedCornerShape(50),
        color = MaterialTheme.colorScheme.secondaryContainer,
    ) {
        Text(
            label,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 7.dp),
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSecondaryContainer,
        )
    }
}

@Composable
private fun PageCell(item: PageItem, index: Int, on: Boolean, session: PdfSession, onClick: () -> Unit) {
    val blank = item.source < 0
    val aspect = if (blank) session.aspect(0, 0) else session.aspect(item.source, item.rotation)
    val primary = MaterialTheme.colorScheme.primary
    val shape = RoundedCornerShape(10.dp)
    Column(Modifier.clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.fillMaxWidth().aspectRatio(1f / aspect)) {
            Box(
                Modifier
                    .fillMaxSize()
                    .clip(shape)
                    .background(Color.White)
                    .border(if (on) 3.dp else 1.dp, if (on) primary else MaterialTheme.colorScheme.outlineVariant, shape),
            ) {
                if (blank) {
                    Text("Blank", Modifier.align(Alignment.Center), color = Color.Gray, style = MaterialTheme.typography.labelMedium)
                } else {
                    PageImage(session, item.source, 280, item.rotation, ReadingMode.LIGHT, Modifier.fillMaxSize())
                }
                if (on) Box(Modifier.fillMaxSize().background(primary.copy(alpha = 0.14f)))
            }
            Icon(
                if (on) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                null,
                tint = if (on) primary else Color.Gray,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(5.dp)
                    .size(24.dp)
                    .background(Color.White.copy(alpha = 0.85f), CircleShape),
            )
            if (item.rotation != 0) {
                Text(
                    "${item.rotation}°",
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(5.dp)
                        .background(Color(0xCC000000), RoundedCornerShape(6.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                    color = Color.White,
                    style = MaterialTheme.typography.labelSmall,
                )
            }
        }
        Text(
            "${index + 1}",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
            color = if (on) primary else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp),
        )
    }
}

@Composable
private fun ActionButton(icon: ImageVector, label: String, enabled: Boolean, onClick: () -> Unit) {
    val tint = if (enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
    Column(
        Modifier.clip(RoundedCornerShape(12.dp)).clickable(enabled = enabled, onClick = onClick).padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, label, tint = tint)
        Text(label, style = MaterialTheme.typography.labelSmall, color = tint)
    }
}
