package com.doxsy.app.cloud

import java.io.IOException
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class CloudException(val code: Int, message: String) : IOException(message)

fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

/** Tiny HTTP helper for the Google REST APIs (no extra libraries, keeps the APK small). */
object Net {
    private fun open(url: String, token: String, method: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 15_000
        c.readTimeout = 60_000
        c.setRequestProperty("Authorization", "Bearer $token")
        return c
    }

    private fun check(c: HttpURLConnection) {
        val code = c.responseCode
        if (code !in 200..299) {
            val err = runCatching { c.errorStream?.bufferedReader()?.readText().orEmpty() }.getOrDefault("")
            val msg = when (code) {
                401 -> "Google sign-in expired. Reconnect your account."
                403 -> "Google refused access (HTTP 403). Make sure the Drive API and Gmail API are enabled for your project."
                else -> "HTTP $code ${err.take(160)}"
            }
            throw CloudException(code, msg)
        }
    }

    fun request(
        url: String,
        token: String,
        method: String = "GET",
        body: ByteArray? = null,
        contentType: String? = null,
    ): ByteArray {
        val c = open(url, token, method)
        try {
            if (body != null) {
                c.doOutput = true
                if (contentType != null) c.setRequestProperty("Content-Type", contentType)
                c.setFixedLengthStreamingMode(body.size)
                c.outputStream.use { it.write(body) }
            }
            check(c)
            return c.inputStream.use { it.readBytes() }
        } finally {
            c.disconnect()
        }
    }

    fun stream(url: String, token: String, out: OutputStream) {
        val c = open(url, token, "GET")
        try {
            check(c)
            c.inputStream.use { it.copyTo(out) }
        } finally {
            c.disconnect()
        }
    }
}
