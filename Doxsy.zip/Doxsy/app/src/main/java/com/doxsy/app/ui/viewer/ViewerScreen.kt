package com.doxsy.app.ui.viewer

import android.graphics.RectF
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import com.doxsy.app.pdf.OutlineEntry
import com.doxsy.app.pdf.PdfTextIndex
import com.doxsy.app.pdf.SearchHit
import kotlinx.coroutines.Job
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material.icons.rounded.BrokenImage
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.RotateRight
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.doxsy.app.data.PageMode
import com.doxsy.app.data.Prefs
import com.doxsy.app.data.ReadingMode
import com.doxsy.app.pdf.OpenResult
import com.doxsy.app.pdf.PdfSession
import com.doxsy.app.ui.EmptyState
import com.doxsy.app.ui.SkeletonBox
import com.doxsy.app.util.FileUtils
import com.doxsy.app.util.findActivity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.launch
import kotlin.math.roundToInt
import android.content.pm.ActivityInfo
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.runtime.withFrameNanos
import com.doxsy.app.annot.PageTextLayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private sealed interface ViewerState {
    data object Loading : ViewerState
    data class Ready(val session: PdfSession) : ViewerState
    data class Password(val wrong: Boolean = false, val busy: Boolean = false) : ViewerState
    data class Error(val message: String) : ViewerState
}

private suspend fun prepare(session: PdfSession): ViewerState {
    try {
        session.loadPageSizes()
    } catch (e: CancellationException) {
        session.close()
        throw e
    }
    return ViewerState.Ready(session)
}

@Composable
fun ViewerScreen(prefs: Prefs, uri: Uri, onBack: () -> Unit, onOpenPdf: (Uri) -> Unit = {}, onSign: (Uri) -> Unit = {}) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val name = remember(uri) { FileUtils.displayName(ctx, uri) }
    var state by remember(uri) { mutableStateOf<ViewerState>(ViewerState.Loading) }

    LaunchedEffect(uri) {
        state = when (val r = PdfSession.open(ctx, uri)) {
            is OpenResult.Success -> prepare(r.session)
            OpenResult.PasswordRequired -> ViewerState.Password()
            OpenResult.WrongPassword -> ViewerState.Password(wrong = true)
            is OpenResult.Failure -> ViewerState.Error(r.message)
        }
    }
    DisposableEffect(uri) {
        onDispose { (state as? ViewerState.Ready)?.session?.close() }
    }

    fun submitPassword(pw: String) {
        state = ViewerState.Password(busy = true)
        scope.launch {
            state = when (val r = PdfSession.openWithPassword(ctx, uri, pw)) {
                is OpenResult.Success -> prepare(r.session)
                OpenResult.PasswordRequired, OpenResult.WrongPassword -> ViewerState.Password(wrong = true)
                is OpenResult.Failure -> ViewerState.Error(r.message)
            }
        }
    }

    when (val s = state) {
        is ViewerState.Ready -> {
            LaunchedEffect(s) { prefs.addRecent(uri.toString(), name, s.session.pageCount) }
            ViewerContent(prefs, s.session, uri, name, onBack, onOpenPdf, onSign)
        }
        else -> Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
            IconButton(onClick = onBack, modifier = Modifier.statusBarsPadding().padding(8.dp)) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back")
            }
            when (s) {
                ViewerState.Loading -> Column(
                    Modifier.fillMaxSize().statusBarsPadding().padding(top = 72.dp, start = 24.dp, end = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    SkeletonBox(Modifier.fillMaxWidth().aspectRatio(0.72f), 16)
                    SkeletonBox(Modifier.fillMaxWidth(0.5f).height(14.dp), 6)
                }
                is ViewerState.Password -> {
                    var pw by remember { mutableStateOf("") }
                    EmptyState(
                        Icons.Rounded.Lock,
                        "Password required",
                        "This PDF is protected. Doxsy reads it from a private temporary copy that is deleted when you close it.",
                        Modifier.align(Alignment.Center),
                    )
                    AlertDialog(
                        onDismissRequest = onBack,
                        title = { Text("Enter password") },
                        text = {
                            Column {
                                OutlinedTextField(
                                    value = pw,
                                    onValueChange = { pw = it },
                                    singleLine = true,
                                    enabled = !s.busy,
                                    isError = s.wrong,
                                    supportingText = { if (s.wrong) Text("Incorrect password") },
                                    visualTransformation = PasswordVisualTransformation(),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                                )
                                if (s.busy) CircularProgressIndicator(Modifier.padding(top = 12.dp).size(22.dp), strokeWidth = 2.dp)
                            }
                        },
                        confirmButton = {
                            TextButton(onClick = { submitPassword(pw) }, enabled = pw.isNotEmpty() && !s.busy) { Text("Open") }
                        },
                        dismissButton = { TextButton(onClick = onBack) { Text("Cancel") } },
                    )
                }
                is ViewerState.Error -> EmptyState(
                    Icons.Rounded.ErrorOutline,
                    "Can't open this file",
                    s.message,
                    Modifier.align(Alignment.Center),
                    actionLabel = "Remove from history",
                    onAction = {
                        prefs.removeRecent(uri.toString())
                        onBack()
                    },
                )
                else -> Unit
            }
        }
    }
}

// ---- Reading-mode appearance ----

private val DarkMatrix = ColorMatrix(
    floatArrayOf(
        -0.88f, 0f, 0f, 0f, 232f,
        0f, -0.88f, 0f, 0f, 232f,
        0f, 0f, -0.88f, 0f, 232f,
        0f, 0f, 0f, 1f, 0f,
    ),
)
private val SepiaMatrix = ColorMatrix(
    floatArrayOf(
        0.393f, 0.769f, 0.189f, 0f, 0f,
        0.349f, 0.686f, 0.168f, 0f, 0f,
        0.272f, 0.534f, 0.131f, 0f, 0f,
        0f, 0f, 0f, 1f, 0f,
    ),
)

private fun filterFor(mode: ReadingMode): ColorFilter? = when (mode) {
    ReadingMode.LIGHT -> null
    ReadingMode.DARK -> ColorFilter.colorMatrix(DarkMatrix)
    ReadingMode.SEPIA -> ColorFilter.colorMatrix(SepiaMatrix)
}

private fun paperColor(mode: ReadingMode) = when (mode) {
    ReadingMode.LIGHT -> Color.White
    ReadingMode.DARK -> Color(0xFF080808)
    ReadingMode.SEPIA -> Color(0xFFFFFBEF)
}

private fun canvasColor(mode: ReadingMode) = when (mode) {
    ReadingMode.LIGHT -> Color(0xFFE4E7F1)
    ReadingMode.DARK -> Color.Black
    ReadingMode.SEPIA -> Color(0xFFE6DCC3)
}

@Composable
internal fun PageImage(
    session: PdfSession,
    page: Int,
    renderWidth: Int,
    rotation: Int,
    mode: ReadingMode,
    modifier: Modifier,
    marks: List<HitMark> = emptyList(),
) {
    var failed by remember(session, page, renderWidth, rotation) { mutableStateOf(false) }
    val bitmap by produceState<ImageBitmap?>(null, session, page, renderWidth, rotation) {
        val b = session.renderAsync(page, renderWidth, rotation)
        if (b != null) value = b.asImageBitmap() else failed = true
    }
    Box(modifier.background(paperColor(mode)), contentAlignment = Alignment.Center) {
        val bmp = bitmap
        when {
            bmp != null -> Image(
                bmp,
                contentDescription = "Page ${page + 1}",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds,
                colorFilter = filterFor(mode),
            )
            failed -> Icon(Icons.Rounded.BrokenImage, "Page failed to render", tint = Color.Gray)
            else -> SkeletonBox(Modifier.fillMaxSize(), 0)
        }
        if (marks.isNotEmpty() && bitmap != null) {
            val yellow = Color(0xFFFFD60A)
            val orange = Color(0xFFFF7A1A)
            Canvas(Modifier.fillMaxSize()) {
                marks.forEach { m ->
                    m.rects.forEach { r ->
                        val q = rotateRect(r, rotation)
                        drawRect(
                            color = (if (m.current) orange else yellow).copy(alpha = if (m.current) 0.5f else 0.38f),
                            topLeft = Offset(q.left * size.width, q.top * size.height),
                            size = Size(q.width() * size.width, q.height() * size.height),
                        )
                    }
                }
            }
        }
    }
}

internal data class HitMark(val rects: List<RectF>, val current: Boolean)

/** Maps a normalised rect from the unrotated page into the page as displayed after [rotation] (clockwise). */
private fun rotateRect(r: RectF, rotation: Int): RectF = when (((rotation % 360) + 360) % 360) {
    90 -> RectF(1f - r.bottom, r.left, 1f - r.top, r.right)
    180 -> RectF(1f - r.right, 1f - r.bottom, 1f - r.left, 1f - r.top)
    270 -> RectF(r.top, 1f - r.right, r.bottom, 1f - r.left)
    else -> r
}

/** Two-finger pinch handled before children so scrolling never fights zooming. */
private fun Modifier.pinchToZoom(onLive: (Float) -> Unit, onCommit: (Float) -> Unit): Modifier =
    pointerInput(Unit) {
        awaitEachGesture {
            awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            var live = 1f
            do {
                val event = awaitPointerEvent(PointerEventPass.Initial)
                if (event.changes.size >= 2) {
                    val z = event.calculateZoom()
                    if (z != 1f) {
                        live *= z
                        onLive(live)
                        event.changes.forEach { it.consume() }
                    }
                }
            } while (event.changes.any { it.pressed })
            if (live != 1f) onCommit(live)
        }
    }

private const val MAX_RENDER_WIDTH = 2400
private const val MAX_ZOOM = 4f

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class, FlowPreview::class)
@Composable
private fun ViewerContent(
    prefs: Prefs,
    session: PdfSession,
    uri: Uri,
    name: String,
    onBack: () -> Unit,
    onOpenPdf: (Uri) -> Unit,
    onSign: (Uri) -> Unit,
) {
    val ctx = LocalContext.current
    val activity = ctx.findActivity()
    val view = LocalView.current
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val uriStr = uri.toString()
    val n = session.pageCount

    var pageMode by remember { mutableStateOf(prefs.pageMode.value) }
    var readingMode by remember { mutableStateOf(prefs.readingMode.value) }
    var rotation by remember { mutableIntStateOf(0) }
    var zoom by remember { mutableFloatStateOf(prefs.defaultZoom.value.coerceIn(1f, MAX_ZOOM)) }
    var liveZoom by remember { mutableFloatStateOf(1f) }
    var barsVisible by remember { mutableStateOf(true) }
    var brightness by remember { mutableFloatStateOf(-1f) }

    var showThumbs by remember { mutableStateOf(false) }
    var showBookmarks by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showGoTo by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    var showEditPages by remember { mutableStateOf(false) }
    var showMoreTools by remember { mutableStateOf(false) }
    var showEditPdf by remember { mutableStateOf(false) }
    var showAnnotate by remember { mutableStateOf(false) }
    var showToc by remember { mutableStateOf(false) }

    // Extra reading tools
    var keepAwake by remember { mutableStateOf(true) }
    var lockOrientation by remember { mutableStateOf(false) }
    var autoScroll by remember { mutableStateOf(false) }
    var autoSpeed by remember { mutableFloatStateOf(1.5f) }
    var reading by remember { mutableStateOf(false) }
    val readerLazy = remember { lazy { PageReader(ctx.applicationContext) } }
    val textLayer = remember(session) { PageTextLayer(ctx.applicationContext, uri, session.backingFile) }
    DisposableEffect(textLayer) { onDispose { textLayer.close() } }
    DisposableEffect(readerLazy) { onDispose { if (readerLazy.isInitialized()) readerLazy.value.shutdown() } }

    var searchOpen by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var hits by remember { mutableStateOf<List<SearchHit>>(emptyList()) }
    var hitIndex by remember { mutableIntStateOf(0) }
    var searching by remember { mutableStateOf(false) }
    var searchDone by remember { mutableStateOf(false) }
    var searchJob by remember { mutableStateOf<Job?>(null) }
    var searchSeq by remember { mutableIntStateOf(0) }
    var outline by remember { mutableStateOf<List<OutlineEntry>?>(null) }
    val index = remember(session) { PdfTextIndex(ctx.applicationContext, uri, session) }
    DisposableEffect(index) { onDispose { index.close() } }

    val startPage = remember { prefs.lastPage(uriStr).coerceIn(0, n - 1) }
    var page by remember { mutableIntStateOf(startPage) }
    LaunchedEffect(Unit) {
        if (startPage > 0) FileUtils.toast(ctx, "Continued from page ${startPage + 1}")
    }
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = startPage)
    val pagerState = rememberPagerState(initialPage = startPage) { n }

    val vertPage by remember {
        derivedStateOf {
            val info = listState.layoutInfo
            val center = (info.viewportStartOffset + info.viewportEndOffset) / 2
            info.visibleItemsInfo.firstOrNull { it.offset <= center && it.offset + it.size >= center }?.index
                ?: listState.firstVisibleItemIndex
        }
    }

    val bookmarks by prefs.bookmarks.state.collectAsState()
    val marks = bookmarks[uriStr].orEmpty()
    val isBookmarked = page in marks

    fun jumpTo(p: Int) {
        val t = p.coerceIn(0, n - 1)
        scope.launch {
            if (pageMode == PageMode.VERTICAL) listState.scrollToItem(t) else pagerState.scrollToPage(t)
        }
    }

    fun closeSearch() {
        searchJob?.cancel()
        searchSeq++
        searching = false
        searchDone = false
        hits = emptyList()
        hitIndex = 0
        searchOpen = false
    }

    fun runSearch() {
        val q = query.trim()
        searchJob?.cancel()
        hits = emptyList()
        hitIndex = 0
        searchDone = false
        if (q.length < 2) return
        val id = ++searchSeq
        searching = true
        searchJob = scope.launch {
            try {
                val found = index.search(q) { partial -> if (id == searchSeq) hits = partial }
                if (id == searchSeq) {
                    hits = found
                    searchDone = true
                    if (found.isNotEmpty()) jumpTo(found[0].page)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (id == searchSeq) {
                    searchDone = true
                    FileUtils.toast(ctx, "Search isn't available for this document.")
                }
            } finally {
                if (id == searchSeq) searching = false
            }
        }
    }

    fun goToHit(i: Int) {
        if (hits.isEmpty()) return
        val t = ((i % hits.size) + hits.size) % hits.size
        hitIndex = t
        jumpTo(hits[t].page)
    }

    BackHandler(enabled = searchOpen) { closeSearch() }

    val marksByPage = remember(hits, hitIndex) {
        hits.withIndex().groupBy({ it.value.page }, { HitMark(it.value.rects, it.index == hitIndex) })
    }

    LaunchedEffect(showToc) {
        if (showToc && outline == null) {
            outline = try {
                index.outline()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                emptyList()
            }
        }
    }

    // Keep one shared "current page", and move to it when the layout mode changes.
    LaunchedEffect(pageMode) {
        zoom = if (pageMode == PageMode.VERTICAL) prefs.defaultZoom.value.coerceIn(1f, MAX_ZOOM) else 1f
        if (pageMode == PageMode.VERTICAL) listState.scrollToItem(page) else pagerState.scrollToPage(page)
        snapshotFlow { if (pageMode == PageMode.VERTICAL) vertPage else pagerState.currentPage }
            .collect { page = it }
    }
    LaunchedEffect(Unit) {
        snapshotFlow { page }.debounce(400).collect { prefs.savePage(uriStr, it) }
    }

    // System bars follow the toolbar: tap to enter distraction-free reading.
    LaunchedEffect(barsVisible) {
        val w = activity?.window ?: return@LaunchedEffect
        val c = WindowCompat.getInsetsController(w, w.decorView)
        if (barsVisible) {
            c.show(WindowInsetsCompat.Type.systemBars())
        } else {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        }
    }
    LaunchedEffect(brightness) {
        activity?.window?.let { w ->
            val attrs = w.attributes
            attrs.screenBrightness = brightness
            w.attributes = attrs
        }
    }
    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose {
            view.keepScreenOn = false
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            prefs.savePage(uriStr, page)
            activity?.window?.let { w ->
                WindowCompat.getInsetsController(w, w.decorView).show(WindowInsetsCompat.Type.systemBars())
                val attrs = w.attributes
                attrs.screenBrightness = -1f
                w.attributes = attrs
            }
        }
    }

    LaunchedEffect(keepAwake) { view.keepScreenOn = keepAwake }
    LaunchedEffect(lockOrientation) {
        activity?.requestedOrientation =
            if (lockOrientation) ActivityInfo.SCREEN_ORIENTATION_LOCKED else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }

    suspend fun pageText(p: Int): String = withContext(Dispatchers.IO) {
        try {
            textLayer.textOf(textLayer.chars(p))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            ""
        }
    }

    // Hands-free reading: scroll slowly (scroll mode) or turn the page now and then (swipe mode).
    LaunchedEffect(autoScroll, autoSpeed, pageMode) {
        if (!autoScroll) return@LaunchedEffect
        if (pageMode == PageMode.VERTICAL) {
            val pxPerSecond = with(density) { 30.dp.toPx() } * autoSpeed
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                val dt = (now - last) / 1_000_000_000f
                last = now
                listState.scrollBy(pxPerSecond * dt)
                if (!listState.canScrollForward) {
                    autoScroll = false
                    break
                }
            }
        } else {
            while (true) {
                delay((9000 / autoSpeed).toLong())
                if (pagerState.currentPage >= n - 1) {
                    autoScroll = false
                    break
                }
                pagerState.animateScrollToPage(pagerState.currentPage + 1)
            }
        }
    }

    // Read aloud: speaks the current page, then moves on to the next one.
    LaunchedEffect(reading, page) {
        if (!reading) {
            if (readerLazy.isInitialized()) readerLazy.value.stop()
            return@LaunchedEffect
        }
        val text = pageText(page)
        if (text.isBlank()) {
            if (page < n - 1) {
                delay(250)
                jumpTo(page + 1)
            } else {
                reading = false
                FileUtils.toast(ctx, "Nothing more to read")
            }
            return@LaunchedEffect
        }
        val finished = readerLazy.value.speak(text)
        if (!finished) {
            reading = false
            FileUtils.toast(ctx, "Could not read this page aloud. Check the phone's text-to-speech settings.")
        } else if (page < n - 1) {
            jumpTo(page + 1)
        } else {
            reading = false
            FileUtils.toast(ctx, "Finished reading")
        }
    }

    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    Box(
        Modifier
            .fillMaxSize()
            .background(canvasColor(readingMode))
            .pinchToZoom(
                onLive = { liveZoom = it },
                onCommit = { live ->
                    zoom = (zoom * live).coerceIn(1f, MAX_ZOOM)
                    liveZoom = 1f
                },
            )
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { barsVisible = !barsVisible },
                    onDoubleTap = { zoom = if (zoom > 1.2f) 1f else 2.5f },
                )
            },
    ) {
        androidx.compose.foundation.layout.BoxWithConstraints(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    val s = (zoom * liveZoom).coerceIn(1f, MAX_ZOOM) / zoom
                    scaleX = s
                    scaleY = s
                },
        ) {
            val viewW = with(density) { maxWidth.toPx() }
            val viewH = with(density) { maxHeight.toPx() }

            if (pageMode == PageMode.VERTICAL) {
                val layoutW = (viewW * zoom).roundToInt()
                val renderW = layoutW.coerceAtMost(MAX_RENDER_WIDTH)
                val hScroll = rememberScrollState()
                Box(Modifier.fillMaxSize().horizontalScroll(hScroll)) {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.width(with(density) { layoutW.toDp() }).fillMaxHeight(),
                        contentPadding = PaddingValues(top = topInset + 76.dp, bottom = bottomInset + 92.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        items(n, key = { it }) { i ->
                            PageImage(
                                session, i, renderW, rotation, readingMode,
                                Modifier.fillMaxWidth().aspectRatio(1f / session.aspect(i, rotation)),
                                marks = marksByPage[i].orEmpty(),
                            )
                        }
                    }
                }
            } else {
                HorizontalPager(
                    state = pagerState,
                    userScrollEnabled = zoom <= 1.01f,
                    key = { it },
                    modifier = Modifier.fillMaxSize(),
                ) { i ->
                    val aspect = session.aspect(i, rotation)
                    val fitW = minOf(viewW, viewH / aspect)
                    val wPx = (fitW * zoom).roundToInt().coerceAtLeast(1)
                    val hPx = (fitW * aspect * zoom).roundToInt().coerceAtLeast(1)
                    val vs = rememberScrollState()
                    val hs = rememberScrollState()
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Box(Modifier.verticalScroll(vs).horizontalScroll(hs)) {
                            PageImage(
                                session, i, wPx.coerceAtMost(MAX_RENDER_WIDTH), rotation, readingMode,
                                Modifier.size(with(density) { wPx.toDp() }, with(density) { hPx.toDp() }),
                                marks = marksByPage[i].orEmpty(),
                            )
                        }
                    }
                }
            }
        }

        // ---- Top bar ----
        AnimatedVisibility(
            visible = barsVisible && !searchOpen,
            modifier = Modifier.align(Alignment.TopCenter),
            enter = fadeIn(tween(140)) + slideInVertically(tween(160)) { -it },
            exit = fadeOut(tween(110)) + slideOutVertically(tween(140)) { -it },
        ) {
            Surface(
                modifier = Modifier.statusBarsPadding().padding(12.dp),
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
                tonalElevation = 3.dp,
                shadowElevation = 6.dp,
            ) {
                Row(Modifier.padding(horizontal = 4.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") }
                    Text(
                        name,
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    IconButton(onClick = { searchOpen = true }) { Icon(Icons.Rounded.Search, "Search in document") }
                    IconButton(onClick = { prefs.toggleBookmark(uriStr, page) }) {
                        Icon(
                            if (isBookmarked) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder,
                            if (isBookmarked) "Remove bookmark" else "Bookmark this page",
                            tint = if (isBookmarked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                        )
                    }
                    IconButton(onClick = { rotation = (rotation + 90) % 360 }) {
                        Icon(Icons.Rounded.RotateRight, "Rotate view")
                    }
                    Box {
                        IconButton(onClick = { showMenu = true }) { Icon(Icons.Rounded.MoreVert, "More") }
                        DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                            DropdownMenuItem(text = { Text("Contents") }, onClick = { showMenu = false; showToc = true })
                            DropdownMenuItem(text = { Text("Go to page") }, onClick = { showMenu = false; showGoTo = true })
                            DropdownMenuItem(text = { Text("Bookmarks") }, onClick = { showMenu = false; showBookmarks = true })
                            DropdownMenuItem(
                                text = { Text(if (reading) "Stop reading aloud" else "Read aloud") },
                                onClick = {
                                    showMenu = false
                                    autoScroll = false
                                    reading = !reading
                                },
                            )
                            DropdownMenuItem(
                                text = { Text(if (autoScroll) "Stop auto-scroll" else "Auto-scroll") },
                                onClick = {
                                    showMenu = false
                                    reading = false
                                    autoScroll = !autoScroll
                                    if (autoScroll) barsVisible = false
                                },
                            )
                            DropdownMenuItem(text = { Text("Copy page text") }, onClick = {
                                showMenu = false
                                scope.launch {
                                    val t = pageText(page)
                                    if (t.isBlank()) {
                                        FileUtils.toast(ctx, "No text on this page. Scanned pages have none.")
                                    } else {
                                        copyText(ctx, t)
                                        FileUtils.toast(ctx, "Page ${page + 1} text copied")
                                    }
                                }
                            })
                            DropdownMenuItem(text = { Text("Share page text") }, onClick = {
                                showMenu = false
                                scope.launch {
                                    val t = pageText(page)
                                    if (t.isBlank()) {
                                        FileUtils.toast(ctx, "No text on this page. Scanned pages have none.")
                                    } else {
                                        shareText(ctx, t)
                                    }
                                }
                            })
                            DropdownMenuItem(text = { Text("Reset zoom") }, onClick = { showMenu = false; zoom = 1f })
                            DropdownMenuItem(text = { Text("Annotate") }, onClick = { showMenu = false; showAnnotate = true })
                            DropdownMenuItem(text = { Text("Edit PDF") }, onClick = { showMenu = false; showEditPdf = true })
                            DropdownMenuItem(text = { Text("Edit pages") }, onClick = { showMenu = false; showEditPages = true })
                            DropdownMenuItem(text = { Text("More tools") }, onClick = { showMenu = false; showMoreTools = true })
                            DropdownMenuItem(text = { Text("Share") }, onClick = {
                                showMenu = false
                                FileUtils.share(ctx, uri, "application/pdf")
                            })
                            DropdownMenuItem(text = { Text("Print") }, onClick = {
                                showMenu = false
                                FileUtils.printPdf(ctx, uri, name)
                            })
                        }
                    }
                }
            }
        }

        // ---- Search bar ----
        AnimatedVisibility(
            visible = searchOpen,
            modifier = Modifier.align(Alignment.TopCenter),
            enter = fadeIn(tween(140)) + slideInVertically(tween(160)) { -it },
            exit = fadeOut(tween(110)) + slideOutVertically(tween(140)) { -it },
        ) {
            val focus = remember { FocusRequester() }
            val keyboard = LocalSoftwareKeyboardController.current
            LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
            Surface(
                modifier = Modifier.statusBarsPadding().padding(12.dp),
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.97f),
                tonalElevation = 3.dp,
                shadowElevation = 6.dp,
            ) {
                Column(Modifier.padding(bottom = 6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { keyboard?.hide(); closeSearch() }) { Icon(Icons.Rounded.Close, "Close search") }
                        TextField(
                            value = query,
                            onValueChange = { query = it },
                            modifier = Modifier.weight(1f).focusRequester(focus),
                            singleLine = true,
                            placeholder = { Text("Search in document") },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent,
                            ),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = { keyboard?.hide(); runSearch() }),
                        )
                        IconButton(onClick = { goToHit(hitIndex - 1) }, enabled = hits.isNotEmpty()) {
                            Icon(Icons.Rounded.KeyboardArrowUp, "Previous result")
                        }
                        IconButton(onClick = { goToHit(hitIndex + 1) }, enabled = hits.isNotEmpty()) {
                            Icon(Icons.Rounded.KeyboardArrowDown, "Next result")
                        }
                    }
                    val capped = hits.size >= PdfTextIndex.MAX_HITS
                    val status = when {
                        hits.isNotEmpty() && searching -> "Searching… ${hits.size} found"
                        hits.isNotEmpty() -> "${hitIndex + 1} of ${hits.size}" + if (capped) "+" else ""
                        searching -> "Searching…"
                        searchDone -> "No matches. Scanned pages have no searchable text yet."
                        query.trim().length in 1..1 -> "Type at least 2 characters, then press search"
                        else -> ""
                    }
                    if (status.isNotEmpty()) {
                        Text(
                            status,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 20.dp),
                        )
                    }
                }
            }
        }

        // ---- Auto-scroll / read-aloud controls ----
        if (autoScroll || reading) {
            Surface(
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = bottomInset + 84.dp),
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                shadowElevation = 6.dp,
            ) {
                Row(Modifier.padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (autoScroll) {
                        TextButton(onClick = { autoSpeed = (autoSpeed - 0.5f).coerceAtLeast(0.5f) }) { Text("−") }
                        Text("Auto-scroll ${(autoSpeed * 2).roundToInt() / 2f}×", style = MaterialTheme.typography.labelLarge)
                        TextButton(onClick = { autoSpeed = (autoSpeed + 0.5f).coerceAtMost(6f) }) { Text("+") }
                    } else {
                        Text(
                            "Reading page ${page + 1}",
                            style = MaterialTheme.typography.labelLarge,
                            modifier = Modifier.padding(start = 12.dp),
                        )
                    }
                    IconButton(onClick = { autoScroll = false; reading = false }) { Icon(Icons.Rounded.Close, "Stop") }
                }
            }
        }

        // ---- Bottom bar ----
        AnimatedVisibility(
            visible = barsVisible,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn(tween(140)) + slideInVertically(tween(160)) { it },
            exit = fadeOut(tween(110)) + slideOutVertically(tween(140)) { it },
        ) {
            Surface(
                modifier = Modifier.navigationBarsPadding().padding(12.dp),
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
                tonalElevation = 3.dp,
                shadowElevation = 6.dp,
            ) {
                Row(Modifier.padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { showThumbs = true }) { Icon(Icons.Rounded.Apps, "Page thumbnails") }
                    var sliding by remember { mutableStateOf<Float?>(null) }
                    if (n > 1) {
                        Slider(
                            value = sliding ?: page.toFloat(),
                            onValueChange = {
                                sliding = it
                                jumpTo(it.roundToInt())
                            },
                            onValueChangeFinished = { sliding = null },
                            valueRange = 0f..(n - 1).toFloat(),
                            modifier = Modifier.weight(1f),
                        )
                    } else {
                        Spacer(Modifier.weight(1f))
                    }
                    Text(
                        "${page + 1} / $n · ${(page + 1) * 100 / n}%",
                        style = MaterialTheme.typography.labelLarge,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 6.dp),
                    )
                    IconButton(onClick = { showSettings = true }) { Icon(Icons.Rounded.Tune, "Reading settings") }
                }
            }
        }
    }

    // ---- Sheets & dialogs ----
    if (showAnnotate) {
        AnnotateDialog(name, uri, session, onClose = { showAnnotate = false }, onOpenPdf = onOpenPdf)
    }

    if (showEditPdf) {
        PdfEditorDialog(name, uri, session, onClose = { showEditPdf = false }, onOpenPdf = onOpenPdf)
    }

    if (showMoreTools) {
        MoreToolsHost(name, uri, session, onDismiss = { showMoreTools = false }, onOpenPdf = onOpenPdf, onSign = onSign)
    }

    if (showEditPages) {
        PageEditorDialog(name, uri, session, onClose = { showEditPages = false }, onOpenPdf = onOpenPdf)
    }

    if (showThumbs) {
        ModalBottomSheet(
            onDismissRequest = { showThumbs = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        ) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxHeight(0.8f),
            ) {
                gridItems((0 until n).toList(), key = { it }) { i ->
                    Column(
                        Modifier.clickable {
                            showThumbs = false
                            jumpTo(i)
                        },
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        PageImage(
                            session, i, 240, 0, ReadingMode.LIGHT,
                            Modifier
                                .fillMaxWidth()
                                .aspectRatio(1f / session.aspect(i, 0))
                                .clip(RoundedCornerShape(6.dp))
                                .border(
                                    if (i == page) 3.dp else 1.dp,
                                    if (i == page) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                    RoundedCornerShape(6.dp),
                                ),
                        )
                        Text("${i + 1}", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
        }
    }

    if (showToc) {
        ModalBottomSheet(onDismissRequest = { showToc = false }) {
            Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 28.dp)) {
                Text("Contents", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(8.dp))
                val entries = outline
                when {
                    entries == null -> CircularProgressIndicator(Modifier.padding(16.dp).size(26.dp), strokeWidth = 2.dp)
                    entries.isEmpty() -> Text(
                        "This document has no table of contents.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    else -> LazyColumn(Modifier.fillMaxHeight(0.7f)) {
                        items(entries.size) { i ->
                            val e = entries[i]
                            Text(
                                e.title,
                                style = if (e.level == 0) MaterialTheme.typography.titleSmall else MaterialTheme.typography.bodyMedium,
                                color = if (e.page >= 0) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable(enabled = e.page >= 0) {
                                        showToc = false
                                        jumpTo(e.page)
                                    }
                                    .padding(start = (e.level * 16).dp, top = 10.dp, bottom = 10.dp),
                            )
                        }
                    }
                }
            }
        }
    }

    if (showBookmarks) {
        ModalBottomSheet(onDismissRequest = { showBookmarks = false }) {
            Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 28.dp)) {
                Text("Bookmarks", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(8.dp))
                if (marks.isEmpty()) {
                    Text(
                        "No bookmarks yet. Tap the bookmark icon to save a page.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    marks.forEach { p ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    showBookmarks = false
                                    jumpTo(p)
                                }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(Icons.Rounded.Bookmark, null, tint = MaterialTheme.colorScheme.primary)
                            Text("Page ${p + 1}", Modifier.weight(1f).padding(start = 12.dp))
                            IconButton(onClick = { prefs.toggleBookmark(uriStr, p) }) {
                                Icon(Icons.Rounded.Close, "Remove bookmark")
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSettings) {
        ModalBottomSheet(onDismissRequest = { showSettings = false }) {
            Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Reading settings", style = MaterialTheme.typography.titleLarge)
                Text("Reading mode", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(ReadingMode.LIGHT to "Light", ReadingMode.DARK to "Dark", ReadingMode.SEPIA to "Sepia").forEach { (m, l) ->
                        FilterChip(selected = readingMode == m, onClick = { readingMode = m }, label = { Text(l) })
                    }
                }
                Text("Page layout", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = pageMode == PageMode.VERTICAL,
                        onClick = { pageMode = PageMode.VERTICAL },
                        label = { Text("Scroll") },
                    )
                    FilterChip(
                        selected = pageMode == PageMode.HORIZONTAL,
                        onClick = { pageMode = PageMode.HORIZONTAL },
                        label = { Text("Swipe pages") },
                    )
                }
                Text("Brightness", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Slider(
                        value = if (brightness < 0f) 0.5f else brightness,
                        onValueChange = { brightness = it.coerceIn(0.05f, 1f) },
                        valueRange = 0.05f..1f,
                        modifier = Modifier.weight(1f),
                    )
                    TextButton(onClick = { brightness = -1f }, enabled = brightness >= 0f) { Text("Auto") }
                }
                Text("Screen", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = keepAwake, onClick = { keepAwake = !keepAwake }, label = { Text("Keep screen on") })
                    FilterChip(selected = lockOrientation, onClick = { lockOrientation = !lockOrientation }, label = { Text("Lock rotation") })
                }
                Text(
                    "Tip: tap the page to hide or show the toolbars. Double-tap or pinch to zoom.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }

    if (showGoTo) {
        var text by remember { mutableStateOf("") }
        val target = text.toIntOrNull()
        AlertDialog(
            onDismissRequest = { showGoTo = false },
            title = { Text("Go to page") },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it.filter(Char::isDigit).take(6) },
                    singleLine = true,
                    placeholder = { Text("1 – $n") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showGoTo = false
                        target?.let { jumpTo(it - 1) }
                    },
                    enabled = target != null && target in 1..n,
                ) { Text("Go") }
            },
            dismissButton = { TextButton(onClick = { showGoTo = false }) { Text("Cancel") } },
        )
    }
}
