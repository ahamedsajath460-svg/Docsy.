package com.doxsy.app.ui.sign

import android.graphics.Bitmap
import android.graphics.PointF
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.doxsy.app.sign.SignatureRenderer

private val InkColors = listOf(Color(0xFF111111), Color(0xFF1B3FA6), Color(0xFF2D3A55))
private val InkNames = listOf("Black", "Blue", "Slate")

/**
 * Touch signature pad. The pad itself is always a light surface so ink is visible in dark mode.
 * [onSave] receives a trimmed transparent bitmap and the chosen name.
 */
@Composable
fun SignaturePadDialog(
    onDismiss: () -> Unit,
    onSave: (name: String, bitmap: Bitmap) -> Unit,
) {
    val density = LocalDensity.current
    val strokes = remember { mutableStateListOf<List<Offset>>() }
    val current = remember { mutableStateListOf<Offset>() }
    var colorIdx by remember { mutableIntStateOf(0) }
    var thickness by remember { mutableFloatStateOf(3f) }
    var name by remember { mutableStateOf("My signature") }
    var error by remember { mutableStateOf<String?>(null) }
    val ink = InkColors[colorIdx]

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
        ) {
            Column(
                Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
            ) {
                Text("Draw your signature", style = MaterialTheme.typography.titleLarge)
                Text(
                    "Use your finger or a stylus. It is saved as a transparent image you can reuse.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp, bottom = 12.dp),
                )
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.White)
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp)),
                ) {
                    Canvas(
                        Modifier
                            .fillMaxSize()
                            .semantics { contentDescription = "Signature drawing area" }
                            .pointerInput(Unit) {
                                detectDragGestures(
                                    onDragStart = { o ->
                                        current.clear()
                                        current.add(o)
                                    },
                                    onDrag = { change, _ ->
                                        change.consume()
                                        current.add(change.position)
                                    },
                                    onDragEnd = {
                                        if (current.isNotEmpty()) strokes.add(current.toList())
                                        current.clear()
                                    },
                                    onDragCancel = {
                                        if (current.isNotEmpty()) strokes.add(current.toList())
                                        current.clear()
                                    },
                                )
                            },
                    ) {
                        val w = thickness.dp.toPx()
                        strokes.forEach { drawInk(it, ink, w) }
                        if (current.isNotEmpty()) drawInk(current.toList(), ink, w)
                    }
                    if (strokes.isEmpty() && current.isEmpty()) {
                        Text(
                            "Sign here",
                            color = Color(0xFF9AA0B5),
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.align(Alignment.Center),
                        )
                    }
                }
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    InkColors.forEachIndexed { i, c ->
                        Box(
                            Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(c)
                                .border(
                                    if (i == colorIdx) 3.dp else 1.dp,
                                    if (i == colorIdx) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                                    CircleShape,
                                )
                                .semantics { contentDescription = "Ink colour ${InkNames[i]}" }
                                .clickable { colorIdx = i },
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    TextButton(
                        onClick = { if (strokes.isNotEmpty()) strokes.removeAt(strokes.lastIndex) },
                        enabled = strokes.isNotEmpty(),
                    ) { Text("Undo stroke") }
                    TextButton(
                        onClick = {
                            strokes.clear()
                            current.clear()
                        },
                        enabled = strokes.isNotEmpty(),
                    ) { Text("Clear") }
                }
                Text("Pen thickness", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Slider(value = thickness, onValueChange = { thickness = it }, valueRange = 1.5f..8f)
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(40) },
                    label = { Text("Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                error?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
                }
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp),
                    horizontalArrangement = Arrangement.End,
                ) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(Modifier.size(8.dp))
                    Button(onClick = {
                        val pts = strokes.map { s -> s.map { PointF(it.x, it.y) } }
                        val bmp = try {
                            SignatureRenderer.render(pts, ink.toArgb(), with(density) { thickness.dp.toPx() })
                        } catch (e: OutOfMemoryError) {
                            null
                        }
                        if (bmp == null) error = "Draw your signature first." else onSave(name, bmp)
                    }) { Text("Save signature") }
                }
            }
        }
    }
}

private fun DrawScope.drawInk(points: List<Offset>, color: Color, widthPx: Float) {
    if (points.isEmpty()) return
    if (points.size == 1) {
        drawCircle(color, widthPx / 2f, points[0])
        return
    }
    val path = Path()
    path.moveTo(points[0].x, points[0].y)
    for (i in 1 until points.size) {
        val a = points[i - 1]
        val b = points[i]
        path.quadraticBezierTo(a.x, a.y, (a.x + b.x) / 2f, (a.y + b.y) / 2f)
    }
    val last = points.last()
    path.lineTo(last.x, last.y)
    drawPath(path, color, style = Stroke(width = widthPx, cap = StrokeCap.Round, join = StrokeJoin.Round))
}
