package com.doxsy.app.docview

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Xml
import com.doxsy.app.util.AppFiles
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayOutputStream
import java.io.Closeable
import java.io.File
import java.io.InputStream
import java.util.zip.ZipFile
import kotlin.math.max

/**
 * An OOXML (zip) package opened from a content Uri. The data is copied to a private cache file so
 * [ZipFile] can seek; the copy is deleted on [close].
 */
class OoxmlPackage private constructor(private val file: File, private val zip: ZipFile) : Closeable {

    fun has(name: String): Boolean = zip.getEntry(name) != null

    fun open(name: String): InputStream? = zip.getEntry(name)?.let { zip.getInputStream(it) }

    /** Reads an entry fully, or returns null when missing or larger than [maxBytes]. */
    fun readBytes(name: String, maxBytes: Int = 20 * 1024 * 1024): ByteArray? {
        val e = zip.getEntry(name) ?: return null
        if (e.size > maxBytes) return null
        zip.getInputStream(e).use { input ->
            val out = ByteArrayOutputStream(if (e.size > 0) e.size.toInt() else 8192)
            val buf = ByteArray(16 * 1024)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                out.write(buf, 0, n)
                if (out.size() > maxBytes) return null
            }
            return out.toByteArray()
        }
    }

    override fun close() {
        runCatching { zip.close() }
        file.delete()
    }

    companion object {
        /** [kind] is a human label used in error messages, e.g. "Word". */
        fun open(ctx: Context, uri: Uri, kind: String): OoxmlPackage {
            val f = File(AppFiles.cacheDir(ctx, "docview"), "pkg_${System.nanoTime()}.zip")
            try {
                val input = ctx.contentResolver.openInputStream(uri)
                    ?: throw DocReadException("Could not open this file.")
                input.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                val head = ByteArray(8)
                val n = f.inputStream().use { it.read(head) }
                if (n >= 4 && head[0] == 0xD0.toByte() && head[1] == 0xCF.toByte() &&
                    head[2] == 0x11.toByte() && head[3] == 0xE0.toByte()
                ) {
                    throw DocReadException(
                        "This $kind file is password-protected or uses the old binary format, " +
                            "so Doxsy cannot read it. Open it with another app.",
                    )
                }
                if (n < 4 || head[0] != 'P'.code.toByte() || head[1] != 'K'.code.toByte()) {
                    throw DocReadException("This is not a valid $kind document. The file may be corrupted.")
                }
                val zip = try {
                    ZipFile(f)
                } catch (e: Exception) {
                    throw DocReadException("This $kind document is corrupted and cannot be opened.", e)
                }
                return OoxmlPackage(f, zip)
            } catch (e: Throwable) {
                f.delete()
                throw e
            }
        }
    }
}

data class Rel(val id: String, val type: String, val target: String, val external: Boolean)

internal fun newParser(input: InputStream): XmlPullParser =
    Xml.newPullParser().also { it.setInput(input, null) }

/** Local element name without namespace prefix ("w:p" -> "p"). */
internal fun XmlPullParser.ln(): String {
    val n = name ?: return ""
    val i = n.indexOf(':')
    return if (i < 0) n else n.substring(i + 1)
}

/** Attribute by local name ignoring prefix ("w:val" -> "val"). */
internal fun XmlPullParser.attr(local: String): String? {
    for (i in 0 until attributeCount) {
        val n = getAttributeName(i)
        val j = n.indexOf(':')
        if ((if (j < 0) n else n.substring(j + 1)) == local) return getAttributeValue(i)
    }
    return null
}

/** Call right after a START_TAG: consumes everything up to and including the matching END_TAG. */
internal fun XmlPullParser.skipTree() {
    var depth = 1
    while (depth > 0) {
        when (next()) {
            XmlPullParser.START_TAG -> depth++
            XmlPullParser.END_TAG -> depth--
            XmlPullParser.END_DOCUMENT -> return
        }
    }
}

/** True for `<w:b/>` and `<w:b w:val="1"/>`, false for val 0/false/off. */
internal fun XmlPullParser.on(): Boolean {
    val v = attr("val")
    return v == null || (v != "0" && v != "false" && v != "off")
}

/** Resolves a relationship [target] against the folder of the part that owns it. */
internal fun resolvePath(baseDir: String, target: String): String {
    if (target.startsWith("/")) return target.trimStart('/')
    val parts = ArrayList<String>()
    if (baseDir.isNotEmpty()) parts.addAll(baseDir.split('/'))
    for (seg in target.split('/')) {
        when (seg) {
            "", "." -> {}
            ".." -> if (parts.isNotEmpty()) parts.removeAt(parts.lastIndex)
            else -> parts.add(seg)
        }
    }
    return parts.joinToString("/")
}

/** Relationships of [partPath] (e.g. "word/document.xml"), keyed by relationship id. */
internal fun OoxmlPackage.rels(partPath: String): Map<String, Rel> {
    val dir = partPath.substringBeforeLast('/', "")
    val name = partPath.substringAfterLast('/')
    val relPath = (if (dir.isEmpty()) "" else "$dir/") + "_rels/$name.rels"
    val stream = open(relPath) ?: return emptyMap()
    val out = LinkedHashMap<String, Rel>()
    stream.use { s ->
        val p = newParser(s)
        while (true) {
            val ev = p.next()
            if (ev == XmlPullParser.END_DOCUMENT) break
            if (ev == XmlPullParser.START_TAG && p.ln() == "Relationship") {
                val id = p.attr("Id") ?: continue
                val target = p.attr("Target") ?: continue
                val ext = p.attr("TargetMode") == "External"
                val type = (p.attr("Type") ?: "").substringAfterLast('/')
                out[id] = Rel(id, type, if (ext) target else resolvePath(dir, target), ext)
            }
        }
    }
    return out
}

class ImgData(val bytes: ByteArray, val width: Int, val height: Int)

/**
 * Validates and downsizes an embedded picture. Returns null if it cannot be decoded
 * (EMF/WMF/TIFF and similar are not supported by Android's decoder).
 */
internal fun downscaleImage(bytes: ByteArray, maxDim: Int = 1600): ImgData? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
    val w = bounds.outWidth
    val h = bounds.outHeight
    if (w <= 0 || h <= 0) return null
    if (max(w, h) <= maxDim && bytes.size <= 1_500_000) return ImgData(bytes, w, h)
    var sample = 1
    while (max(w, h) / sample > maxDim) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return null
    return try {
        val out = ByteArrayOutputStream()
        if (bmp.hasAlpha()) bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        else bmp.compress(Bitmap.CompressFormat.JPEG, 85, out)
        ImgData(out.toByteArray(), w, h)
    } finally {
        bmp.recycle()
    }
}

/** "RRGGBB" -> opaque ARGB, or null if invalid. */
internal fun parseHexColor(s: String?): Int? {
    if (s == null || s.length != 6) return null
    val v = s.toLongOrNull(16) ?: return null
    return (0xFF000000L or v).toInt()
}
