package com.doxsy.app.convert

import android.net.Uri

/** Raised for problems the user can understand (bad input, password-protected PDF, unsupported format...). */
class ConvertException(message: String, cause: Throwable? = null) : Exception(message, cause)

enum class PaperSize(val label: String, val w: Int, val h: Int) {
    A4("A4", 595, 842),
    A3("A3", 842, 1191),
    A5("A5", 420, 595),
    LETTER("Letter", 612, 792),
    LEGAL("Legal", 612, 1008),
}

enum class OrientationPref(val label: String) { AUTO("Auto"), PORTRAIT("Portrait"), LANDSCAPE("Landscape") }

enum class MarginPref(val label: String, val pt: Int) {
    NONE("None", 0),
    NARROW("Narrow", 24),
    NORMAL("Normal", 48),
    WIDE("Wide", 72),
}

enum class ImageFormat(val ext: String, val mime: String) {
    JPG("jpg", "image/jpeg"),
    PNG("png", "image/png"),
    WEBP("webp", "image/webp"),
}

/** What the user has to pick as the input of a conversion. */
enum class SourceKind(val label: String, val mimes: Array<String>, val multi: Boolean = false) {
    PDF("PDF file", arrayOf("application/pdf")),
    IMAGES("images", arrayOf("image/jpeg", "image/png", "image/webp"), multi = true),
    DOCX("Word (.docx) file", arrayOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document")),
    XLSX("Excel (.xlsx) file", arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")),
    PPTX("PowerPoint (.pptx) file", arrayOf("application/vnd.openxmlformats-officedocument.presentationml.presentation")),
    TXT("text file", arrayOf("text/plain")),
    CSV("CSV file", arrayOf("text/csv", "text/comma-separated-values", "application/csv", "text/plain")),
    HTML("HTML file", arrayOf("text/html", "application/xhtml+xml")),
}

enum class Conversion(
    val title: String,
    val desc: String,
    val fromPdf: Boolean,
    val source: SourceKind,
    val outExt: String,
    val outMime: String,
    val usesPages: Boolean = false,
    val usesQuality: Boolean = false,
    val usesDpi: Boolean = false,
    val usesPaper: Boolean = false,
    val note: String? = null,
) {
    PDF_TO_JPG("PDF to JPG", "Each selected page as a JPG image", true, SourceKind.PDF, "jpg", "image/jpeg",
        usesPages = true, usesQuality = true, usesDpi = true,
        note = "One page gives a single image. Several pages are saved together in one ZIP file."),
    PDF_TO_PNG("PDF to PNG", "Each selected page as a PNG image", true, SourceKind.PDF, "png", "image/png",
        usesPages = true, usesDpi = true,
        note = "One page gives a single image. Several pages are saved together in one ZIP file."),
    PDF_TO_WEBP("PDF to WEBP", "Each selected page as a WEBP image", true, SourceKind.PDF, "webp", "image/webp",
        usesPages = true, usesQuality = true, usesDpi = true,
        note = "One page gives a single image. Several pages are saved together in one ZIP file."),
    PDF_TO_TXT("PDF to Text", "Extract the text of a PDF into a TXT file", true, SourceKind.PDF, "txt", "text/plain",
        usesPages = true,
        note = "Works on PDFs that contain real text. Scanned PDFs (photos of pages) have no text to extract."),
    PDF_TO_HTML("PDF to HTML", "Text-based HTML page of a PDF", true, SourceKind.PDF, "html", "text/html",
        usesPages = true,
        note = "Text-based HTML: the text of each page is kept, layout, fonts and pictures are not."),

    IMAGES_TO_PDF("Images to PDF", "JPG, PNG or WEBP photos into one PDF", false, SourceKind.IMAGES, "pdf", "application/pdf",
        usesQuality = true, usesPaper = true),
    DOCX_TO_PDF("Word to PDF", "DOCX document to PDF", false, SourceKind.DOCX, "pdf", "application/pdf",
        usesPaper = true,
        note = "Text, headings, lists, tables and pictures are converted. Complex layouts (text boxes, columns, headers, footers) are simplified."),
    XLSX_TO_PDF("Excel to PDF", "XLSX workbook to PDF", false, SourceKind.XLSX, "pdf", "application/pdf",
        usesPaper = true,
        note = "Every sheet is printed as a table. Wide sheets continue on extra pages. Charts and cell colours are not converted."),
    PPTX_TO_PDF("PowerPoint to PDF", "PPTX slides to PDF, one page per slide", false, SourceKind.PPTX, "pdf", "application/pdf",
        usesPaper = true,
        note = "Slides are drawn from their text, pictures and basic shapes. Animations, charts and special effects are not converted."),
    TXT_TO_PDF("Text to PDF", "Plain text file to PDF", false, SourceKind.TXT, "pdf", "application/pdf",
        usesPaper = true),
    CSV_TO_PDF("CSV to PDF", "CSV table to PDF", false, SourceKind.CSV, "pdf", "application/pdf",
        usesPaper = true),
    HTML_TO_PDF("HTML to PDF", "HTML file to PDF (simple rendering)", false, SourceKind.HTML, "pdf", "application/pdf",
        usesPaper = true,
        note = "Simple HTML rendering: headings, text styles, lists and links are kept. Pictures, CSS and JavaScript are ignored. Nothing is loaded from the internet."),
}

data class ConvertSettings(
    /** JPEG / WEBP quality, and image detail for Images to PDF. 30..100. */
    val quality: Int = 90,
    /** Render resolution for PDF to image. */
    val dpi: Int = 150,
    /** "" or "all" = every page, otherwise e.g. "1-3,5". */
    val pages: String = "",
    val orientation: OrientationPref = OrientationPref.AUTO,
    val paper: PaperSize = PaperSize.A4,
    val margin: MarginPref = MarginPref.NORMAL,
    /** Output file name without extension; blank = use the source name. */
    val outName: String = "",
)

sealed interface ConvertOutcome {
    data class Success(val outputs: List<Uri>, val mime: String, val message: String) : ConvertOutcome
    data class Failure(val message: String) : ConvertOutcome
}

data class HistoryItem(
    val time: Long,
    val source: String,
    val target: String,
    val outputUri: String?,
    val mime: String,
    val ok: Boolean,
    val message: String,
)
