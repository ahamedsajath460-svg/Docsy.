package com.doxsy.app.util

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.pdf.PdfDocument
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Makes brand-new, completely empty files (nothing copied from anywhere). */
object NewFiles {
    const val DOCX_MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    const val XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

    /** One empty A4 page. More pages can be added later with "Edit pages" in the viewer. */
    suspend fun blankPdf(ctx: Context, out: Uri): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val doc = PdfDocument()
            try {
                val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
                doc.finishPage(page)
                val stream = ctx.contentResolver.openOutputStream(out, "wt") ?: error("no output")
                stream.use { doc.writeTo(it) }
            } finally {
                doc.close()
            }
        }.isSuccess
    }

    suspend fun blankDocx(ctx: Context, out: Uri): Boolean = zip(
        ctx, out,
        "[Content_Types].xml" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>""",
        "_rels/.rels" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>""",
        "word/document.xml" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p/><w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr></w:body></w:document>""",
    )

    suspend fun blankXlsx(ctx: Context, out: Uri): Boolean = zip(
        ctx, out,
        "[Content_Types].xml" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>""",
        "_rels/.rels" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""",
        "xl/workbook.xml" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Sheet1" sheetId="1" r:id="rId1"/></sheets></workbook>""",
        "xl/_rels/workbook.xml.rels" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>""",
        "xl/worksheets/sheet1.xml" to """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData/></worksheet>""",
    )

    suspend fun writeText(ctx: Context, out: Uri, text: String): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val stream = ctx.contentResolver.openOutputStream(out, "wt") ?: error("no output")
            stream.use { it.write(text.toByteArray(Charsets.UTF_8)) }
        }.isSuccess
    }

    private suspend fun zip(ctx: Context, out: Uri, vararg parts: Pair<String, String>): Boolean =
        withContext(Dispatchers.IO) {
            runCatching {
                val stream = ctx.contentResolver.openOutputStream(out, "wt") ?: error("no output")
                ZipOutputStream(stream).use { z ->
                    for ((name, body) in parts) {
                        z.putNextEntry(ZipEntry(name))
                        z.write(body.toByteArray(Charsets.UTF_8))
                        z.closeEntry()
                    }
                }
            }.isSuccess
        }

    /** Opens the new file in an editing app (Word, Docs, Sheets ...), with permission to save back into it. */
    fun editExternal(ctx: Context, uri: Uri, mime: String) {
        val edit = Intent(Intent.ACTION_EDIT).apply {
            setDataAndType(uri, mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(edit, "Edit with").apply {
            putExtra(
                Intent.EXTRA_EXCLUDE_COMPONENTS,
                arrayOf(ComponentName(ctx, com.doxsy.app.MainActivity::class.java)),
            )
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            if (ctx !is android.app.Activity) addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            ctx.startActivity(chooser)
        } catch (e: Exception) {
            FileUtils.viewExternal(ctx, uri, mime)
        }
    }
}
