package com.doxsy.app.convert

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.ParcelFileDescriptor
import com.doxsy.app.pdf.PdfEngine
import com.doxsy.app.pdf.PdfTools
import com.doxsy.app.util.FileUtils
import com.doxsy.app.util.OutputStore
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.BufferedWriter
import java.io.Closeable
import java.io.File
import java.io.IOException
import java.io.OutputStreamWriter
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.max
import kotlin.math.roundToInt

private const val PASSWORD_MSG =
    "This PDF is password-protected. Remove the password first (Tools > Remove password), then convert the unlocked copy."

/** Resolves "All" / "" / "1-3,5" into 0-based page indexes, or null when the text is not valid. */
internal fun selectPages(spec: String, total: Int): List<Int>? {
    val t = spec.trim()
    if (t.isEmpty() || t.equals("all", ignoreCase = true)) return (0 until total).toList()
    return PdfTools.parsePages(t, total)
}

private const val INVALID_PAGES = "Page selection is not valid. Use All, or a list such as 1-3, 5 (the document has %d pages)."

/** Opens a PDF with the native renderer; falls back to a private cache copy if the provider cannot seek. */
internal class PdfSource private constructor(
    val renderer: PdfRenderer,
    private val pfd: ParcelFileDescriptor,
    private val temp: File?,
) : Closeable {
    override fun close() {
        runCatching { renderer.close() }
        runCatching { pfd.close() }
        temp?.delete()
    }

    companion object {
        fun open(ctx: Context, uri: Uri): PdfSource {
            val cr = ctx.contentResolver
            try {
                val pfd = cr.openFileDescriptor(uri, "r") ?: throw ConvertException("Could not open the PDF.")
                try {
                    return build(pfd, null)
                } catch (e: SecurityException) {
                    runCatching { pfd.close() }
                    throw ConvertException(PASSWORD_MSG, e)
                } catch (e: IOException) {
                    runCatching { pfd.close() }
                }
            } catch (e: ConvertException) {
                throw e
            } catch (e: java.io.FileNotFoundException) {
                throw ConvertException("The PDF was not found, or permission to it was lost. Pick it again.", e)
            } catch (e: SecurityException) {
                throw ConvertException("Permission to the PDF was lost. Pick it again.", e)
            }
            // Retry from a copy.
            val temp = File(ctx.cacheDir, "doxsy_tmp_conv_${System.nanoTime()}.pdf")
            try {
                cr.openInputStream(uri)?.use { i -> temp.outputStream().use { o -> i.copyTo(o) } }
                    ?: throw ConvertException("Could not open the PDF.")
                val pfd = ParcelFileDescriptor.open(temp, ParcelFileDescriptor.MODE_READ_ONLY)
                try {
                    return build(pfd, temp)
                } catch (e: Exception) {
                    runCatching { pfd.close() }
                    throw e
                }
            } catch (e: SecurityException) {
                temp.delete()
                throw ConvertException(PASSWORD_MSG, e)
            } catch (e: ConvertException) {
                temp.delete()
                throw e
            } catch (e: Exception) {
                temp.delete()
                throw ConvertException("This file is damaged or is not a valid PDF.", e)
            }
        }

        private fun build(pfd: ParcelFileDescriptor, temp: File?): PdfSource {
            val r = PdfRenderer(pfd)
            if (r.pageCount <= 0) {
                r.close()
                throw ConvertException("This PDF has no pages.")
            }
            return PdfSource(r, pfd, temp)
        }
    }
}

object PdfConverters {

    private fun compressFormat(fmt: ImageFormat): Bitmap.CompressFormat = when (fmt) {
        ImageFormat.JPG -> Bitmap.CompressFormat.JPEG
        ImageFormat.PNG -> Bitmap.CompressFormat.PNG
        ImageFormat.WEBP ->
            if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY
            else @Suppress("DEPRECATION") Bitmap.CompressFormat.WEBP
    }

    private fun renderPage(r: PdfRenderer, index: Int, dpi: Int): Bitmap {
        r.openPage(index).use { p ->
            var scale = dpi.coerceIn(36, 400) / 72f
            val longest = max(p.width, p.height) * scale
            if (longest > MAX_SIDE) scale *= MAX_SIDE / longest
            val w = (p.width * scale).roundToInt().coerceAtLeast(1)
            val h = (p.height * scale).roundToInt().coerceAtLeast(1)
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
            return bmp
        }
    }

    fun pdfToImages(
        ctx: Context,
        uri: Uri,
        fmt: ImageFormat,
        s: ConvertSettings,
        baseName: String,
        ensure: () -> Unit,
        progress: (Int, Int) -> Unit,
    ): ConvertOutcome {
        PdfSource.open(ctx, uri).use { src ->
            val r = src.renderer
            val pages = selectPages(s.pages, r.pageCount)
                ?: return ConvertOutcome.Failure(INVALID_PAGES.format(r.pageCount))
            val cf = compressFormat(fmt)
            val q = if (fmt == ImageFormat.PNG) 100 else s.quality.coerceIn(30, 100)
            progress(0, pages.size)
            val out: Uri
            val mime: String
            if (pages.size == 1) {
                mime = fmt.mime
                out = OutputStore.write(ctx, "$baseName.${fmt.ext}", mime) { os ->
                    val bmp = renderPage(r, pages[0], s.dpi)
                    try {
                        ensure()
                        if (!bmp.compress(cf, q, os)) throw IOException("Could not encode the image.")
                    } finally {
                        bmp.recycle()
                    }
                }
                progress(1, 1)
            } else {
                mime = "application/zip"
                out = OutputStore.write(ctx, "$baseName-images.zip", mime) { os ->
                    ZipOutputStream(os.buffered()).use { zip ->
                        zip.setLevel(Deflater.BEST_SPEED)
                        val digits = pages.size.toString().length.coerceAtLeast(3)
                        pages.forEachIndexed { n, idx ->
                            ensure()
                            val bmp = renderPage(r, idx, s.dpi)
                            try {
                                val num = (idx + 1).toString().padStart(digits, '0')
                                zip.putNextEntry(ZipEntry("$baseName-page-$num.${fmt.ext}"))
                                if (!bmp.compress(cf, q, zip)) throw IOException("Could not encode page ${idx + 1}.")
                                zip.closeEntry()
                            } finally {
                                bmp.recycle()
                            }
                            progress(n + 1, pages.size)
                        }
                    }
                }
            }
            val size = PdfTools.querySize(ctx, out)
            val msg = if (pages.size == 1) "Saved page ${pages[0] + 1} as ${fmt.ext.uppercase()} (${FileUtils.formatSize(size)})."
            else "Saved ${pages.size} pages as ${fmt.ext.uppercase()} images in one ZIP file (${FileUtils.formatSize(size)})."
            return ConvertOutcome.Success(listOf(out), mime, msg)
        }
    }

    /** Extracts text page by page. Returns the number of pages that contained text. */
    private fun extractPages(
        ctx: Context,
        uri: Uri,
        pageSpec: String,
        ensure: () -> Unit,
        progress: (Int, Int) -> Unit,
        sink: (pageNumber: Int, text: String) -> Unit,
    ): Pair<Int, Int> {
        PdfEngine.init(ctx)
        val temp = File(ctx.cacheDir, "doxsy_tmp_conv_${System.nanoTime()}.pdf")
        try {
            ctx.contentResolver.openInputStream(uri)?.use { i -> temp.outputStream().use { o -> i.copyTo(o) } }
                ?: throw ConvertException("Could not open the PDF.")
            val doc = try {
                PDDocument.load(temp)
            } catch (e: InvalidPasswordException) {
                throw ConvertException(PASSWORD_MSG, e)
            } catch (e: IOException) {
                throw ConvertException("This file is damaged or is not a valid PDF.", e)
            }
            doc.use { d ->
                val total = d.numberOfPages
                val pages = selectPages(pageSpec, total) ?: throw ConvertException(INVALID_PAGES.format(total))
                val stripper = PDFTextStripper()
                stripper.sortByPosition = true
                var withText = 0
                progress(0, pages.size)
                pages.forEachIndexed { n, idx ->
                    ensure()
                    stripper.startPage = idx + 1
                    stripper.endPage = idx + 1
                    val text = stripper.getText(d).replace("\r\n", "\n").trim()
                    if (text.isNotBlank()) withText++
                    sink(idx + 1, text)
                    progress(n + 1, pages.size)
                }
                return Pair(pages.size, withText)
            }
        } finally {
            temp.delete()
        }
    }

    private const val NO_TEXT =
        "No text found. This PDF probably contains scanned images, which have no text layer to extract (OCR is not part of Doxsy yet)."

    fun pdfToText(
        ctx: Context, uri: Uri, s: ConvertSettings, baseName: String,
        ensure: () -> Unit, progress: (Int, Int) -> Unit,
    ): ConvertOutcome {
        val tmp = File(ctx.cacheDir, "doxsy_tmp_conv_txt_${System.nanoTime()}.txt")
        try {
            val (count, withText) = BufferedWriter(OutputStreamWriter(tmp.outputStream(), Charsets.UTF_8)).use { w ->
                extractPages(ctx, uri, s.pages, ensure, progress) { n, text ->
                    w.write("--- Page $n ---\n")
                    w.write(text)
                    w.write("\n\n")
                }
            }
            if (withText == 0) return ConvertOutcome.Failure(NO_TEXT)
            val out = OutputStore.write(ctx, "$baseName.txt", "text/plain") { os ->
                tmp.inputStream().use { it.copyTo(os) }
            }
            val note = if (withText < count) " ${count - withText} page(s) had no text." else ""
            return ConvertOutcome.Success(
                listOf(out), "text/plain",
                "Extracted text from $withText of $count page(s) (${FileUtils.formatSize(PdfTools.querySize(ctx, out))}).$note",
            )
        } finally {
            tmp.delete()
        }
    }

    private fun esc(t: String): String =
        t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    fun pdfToHtml(
        ctx: Context, uri: Uri, s: ConvertSettings, baseName: String,
        ensure: () -> Unit, progress: (Int, Int) -> Unit,
    ): ConvertOutcome {
        val tmp = File(ctx.cacheDir, "doxsy_tmp_conv_html_${System.nanoTime()}.html")
        try {
            val (count, withText) = BufferedWriter(OutputStreamWriter(tmp.outputStream(), Charsets.UTF_8)).use { w ->
                w.write(
                    "<!DOCTYPE html>\n<html><head><meta charset=\"utf-8\">" +
                        "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">" +
                        "<title>${esc(baseName)}</title>" +
                        "<style>body{font-family:sans-serif;max-width:46em;margin:2em auto;padding:0 1em;line-height:1.5}" +
                        "section{border-top:1px solid #ccc;padding-top:.5em;margin-top:1.5em}" +
                        "h2{font-size:.9em;color:#666;font-weight:normal}</style></head><body>\n" +
                        "<h1>${esc(baseName)}</h1>\n<p><em>Text-based HTML created by Doxsy: text is kept, layout and pictures are not.</em></p>\n",
                )
                val result = extractPages(ctx, uri, s.pages, ensure, progress) { n, text ->
                    w.write("<section id=\"page-$n\"><h2>Page $n</h2>\n")
                    text.split(Regex("\\n\\s*\\n")).map { it.trim() }.filter { it.isNotEmpty() }.forEach { para ->
                        w.write("<p>" + para.split('\n').joinToString("<br>\n") { esc(it) } + "</p>\n")
                    }
                    w.write("</section>\n")
                }
                w.write("</body></html>\n")
                result
            }
            if (withText == 0) return ConvertOutcome.Failure(NO_TEXT)
            val out = OutputStore.write(ctx, "$baseName.html", "text/html") { os ->
                tmp.inputStream().use { it.copyTo(os) }
            }
            val note = if (withText < count) " ${count - withText} page(s) had no text." else ""
            return ConvertOutcome.Success(
                listOf(out), "text/html",
                "Created text-based HTML from $withText of $count page(s) (${FileUtils.formatSize(PdfTools.querySize(ctx, out))}).$note",
            )
        } finally {
            tmp.delete()
        }
    }

    private const val MAX_SIDE = 4600f
}
