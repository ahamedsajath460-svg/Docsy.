package com.doxsy.app.ui.convert

import android.content.Context
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Slideshow
import androidx.compose.material.icons.rounded.TableChart
import androidx.compose.material.icons.rounded.TextSnippet
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.doxsy.app.convert.Conversion
import com.doxsy.app.convert.ConversionHistory
import com.doxsy.app.convert.HistoryItem
import com.doxsy.app.data.Prefs
import com.doxsy.app.ui.KindBadge
import com.doxsy.app.util.FileKind
import com.doxsy.app.util.FileUtils
import java.text.DateFormat
import java.util.Date

/**
 * Conversion Center. The landing page lists every conversion and the recent history; picking one opens
 * [ConvertPane]. All work happens on this device.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConverterScreen(
    prefs: Prefs,
    onBack: () -> Unit,
    onOpenPdf: (Uri) -> Unit,
    onOpenDocument: (Uri) -> Unit,
) {
    val ctx = LocalContext.current
    val history = remember { ConversionHistory(ctx) }
    var active by remember { mutableStateOf<Conversion?>(null) }
    var version by remember { mutableIntStateOf(0) }

    val picked = active
    if (picked != null) {
        BackHandler { active = null }
        ConvertPane(
            conv = picked,
            history = history,
            onBack = { active = null },
            onOpenPdf = onOpenPdf,
            onOpenDocument = onOpenDocument,
        )
        return
    }

    val items = remember(version) { history.load() }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") }
            Text("Convert files", style = MaterialTheme.typography.titleLarge)
        }
        Text(
            "Everything runs on this device. Your originals are never changed.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 20.dp, end = 20.dp, bottom = 8.dp),
        )

        SectionHeader("From PDF", "Pages to images (JPG, PNG, WEBP), text and HTML")
        ConversionGrid(
            listOf(
                Conversion.PDF_TO_JPG,
                Conversion.PDF_TO_PNG,
                Conversion.PDF_TO_WEBP,
                Conversion.PDF_TO_TXT,
                Conversion.PDF_TO_HTML,
            ),
        ) { active = it }

        Spacer(Modifier.height(18.dp))
        SectionHeader("To PDF", "Pictures, Word, Excel, PowerPoint, text, HTML and CSV")
        ConversionGrid(
            listOf(
                Conversion.IMAGES_TO_PDF,
                Conversion.DOCX_TO_PDF,
                Conversion.XLSX_TO_PDF,
                Conversion.PPTX_TO_PDF,
                Conversion.TXT_TO_PDF,
                Conversion.HTML_TO_PDF,
                Conversion.CSV_TO_PDF,
            ),
        ) { active = it }

        Text(
            "Old Word (.doc), Excel (.xls) and PowerPoint (.ppt) files are not supported. They use an older " +
                "binary format that is hard to read reliably on a phone, so Doxsy cannot convert them. Open the " +
                "file in its Office app, save it as .docx, .xlsx or .pptx, then convert that copy.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 14.dp),
        )

        HistorySection(
            items = items,
            onOpen = { item ->
                val raw = item.outputUri
                if (raw != null) openOutput(ctx, Uri.parse(raw), item.mime, onOpenPdf, onOpenDocument)
            },
            onRemove = { item ->
                history.remove(item.time)
                version++
            },
            onClear = {
                history.clear()
                version++
            },
        )
    }
}

/** Opens a converted file in the right place: PDFs and text go to the viewer, everything else to another app. */
internal fun openOutput(
    ctx: Context,
    uri: Uri,
    mime: String,
    onOpenPdf: (Uri) -> Unit,
    onOpenDocument: (Uri) -> Unit,
) {
    when {
        mime == "application/pdf" -> onOpenPdf(uri)
        mime.startsWith("text/") -> onOpenDocument(uri)
        else -> FileUtils.viewExternal(ctx, uri, mime)
    }
}

internal fun conversionIcon(c: Conversion): ImageVector = when (c) {
    Conversion.PDF_TO_JPG, Conversion.PDF_TO_PNG, Conversion.PDF_TO_WEBP -> Icons.Rounded.Image
    Conversion.PDF_TO_TXT -> Icons.Rounded.TextSnippet
    Conversion.PDF_TO_HTML -> Icons.Rounded.Code
    Conversion.IMAGES_TO_PDF -> Icons.Rounded.PictureAsPdf
    Conversion.DOCX_TO_PDF -> Icons.Rounded.Description
    Conversion.XLSX_TO_PDF, Conversion.CSV_TO_PDF -> Icons.Rounded.TableChart
    Conversion.PPTX_TO_PDF -> Icons.Rounded.Slideshow
    Conversion.TXT_TO_PDF -> Icons.Rounded.TextSnippet
    Conversion.HTML_TO_PDF -> Icons.Rounded.Code
}

@Composable
private fun SectionHeader(title: String, subtitle: String) {
    Column(Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
        Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun ConversionGrid(list: List<Conversion>, onPick: (Conversion) -> Unit) {
    Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        list.chunked(2).forEach { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEach { c ->
                    ConversionTile(c, Modifier.weight(1f)) { onPick(c) }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun ConversionTile(c: Conversion, modifier: Modifier, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Column(Modifier.padding(14.dp)) {
            Icon(conversionIcon(c), null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(26.dp))
            Spacer(Modifier.height(10.dp))
            Text(c.title, style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(
                c.desc,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun HistorySection(
    items: List<HistoryItem>,
    onOpen: (HistoryItem) -> Unit,
    onRemove: (HistoryItem) -> Unit,
    onClear: () -> Unit,
) {
    var confirmClear by remember { mutableStateOf(false) }
    Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Recent conversions", style = MaterialTheme.typography.titleMedium)
                Text(
                    "The latest 50 results. Removing an entry does not delete its file.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (items.isNotEmpty()) {
                TextButton(onClick = { confirmClear = true }) { Text("Clear all") }
            }
        }
        if (items.isEmpty()) {
            Text(
                "Nothing converted yet.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        items.forEach { item -> HistoryRow(item, onOpen, onRemove) }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear conversion history?") },
            text = { Text("Only the list is cleared. Converted files are not deleted.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmClear = false
                    onClear()
                }) { Text("Clear") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun HistoryRow(item: HistoryItem, onOpen: (HistoryItem) -> Unit, onRemove: (HistoryItem) -> Unit) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Row(
            Modifier.padding(start = 12.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            KindBadge(kindForMime(item.mime), size = 40)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    "${item.target} · ${item.source}",
                    style = MaterialTheme.typography.bodyLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                val status = if (item.ok) stamp(item.time) else "${stamp(item.time)} · Failed"
                Text(
                    status,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    item.message,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (item.ok) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.error,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            if (item.ok && item.outputUri != null) {
                IconButton(onClick = { onOpen(item) }) { Icon(Icons.Rounded.OpenInNew, "Open") }
            }
            IconButton(onClick = { onRemove(item) }) { Icon(Icons.Rounded.Delete, "Remove from history") }
        }
    }
}

private fun kindForMime(mime: String): FileKind = when {
    mime == "application/pdf" -> FileKind.PDF
    mime.startsWith("image/") -> FileKind.IMAGE
    mime.startsWith("text/") -> FileKind.TEXT
    else -> FileKind.OTHER
}

private fun stamp(ms: Long): String =
    DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(ms))
