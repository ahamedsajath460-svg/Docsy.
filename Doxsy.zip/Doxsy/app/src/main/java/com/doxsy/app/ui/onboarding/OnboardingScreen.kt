package com.doxsy.app.ui.onboarding

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.doxsy.app.ui.DoxsyLogo
import com.doxsy.app.ui.theme.DoxsyBlue
import com.doxsy.app.ui.theme.DoxsyNavy
import com.doxsy.app.ui.theme.DoxsyPurple

/** First-run screens: Welcome, then "Your privacy matters". Shown once. */
@Composable
fun OnboardingScreen(onFinished: () -> Unit) {
    var page by rememberSaveable { mutableIntStateOf(0) }
    BackHandler(enabled = page == 1) { page = 0 }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
    ) {
        Hero()
        Column(
            Modifier
                .weight(1f)
                .padding(horizontal = 24.dp, vertical = 20.dp),
        ) {
            DoxsyLogo(44.dp)
            Spacer(Modifier.height(20.dp))
            Text(
                if (page == 0) "Welcome to Doxsy" else "Your privacy matters",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.SemiBold,
            )
            Spacer(Modifier.height(12.dp))
            Text(
                if (page == 0) {
                    "Easy-to-use PDF tools to read, view and manage your documents, right on your phone."
                } else {
                    "Your documents stay on your phone. Files are only sent to Google when you " +
                        "choose to connect Google Drive or Gmail, and an account is optional. You can " +
                        "change reading and privacy options in Settings at any time."
                },
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Row(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalArrangement = Arrangement.End,
        ) {
            Button(onClick = { if (page == 0) page = 1 else onFinished() }) {
                Text(if (page == 0) "Get started" else "Continue")
            }
        }
    }
}

@Composable
private fun Hero() {
    Box(
        Modifier
            .fillMaxWidth()
            .height(250.dp)
            .background(Brush.linearGradient(listOf(DoxsyNavy, DoxsyBlue, DoxsyPurple))),
    ) {
        // A loose collage of tilted "pages", echoing a document wall.
        val pages = listOf(
            Triple(-30, 30, -16f),
            Triple(70, -10, 12f),
            Triple(170, 40, -10f),
            Triple(260, 0, 14f),
            Triple(40, 130, 10f),
            Triple(210, 140, -14f),
        )
        pages.forEach { (x, y, deg) ->
            Box(
                Modifier
                    .offset(x = x.dp, y = y.dp)
                    .rotate(deg)
                    .size(width = 110.dp, height = 140.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color.White.copy(alpha = 0.14f)),
            )
        }
        Icon(
            Icons.Rounded.PictureAsPdf,
            null,
            tint = Color.White,
            modifier = Modifier
                .align(Alignment.Center)
                .size(96.dp),
        )
    }
}
