package com.doxsy.app.ui.docview

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.doxsy.app.docview.Sheet

/** Excel-style column label: 0 -> A, 25 -> Z, 26 -> AA. */
internal fun columnName(index: Int): String {
    var n = index
    val sb = StringBuilder()
    do {
        sb.insert(0, 'A' + n % 26)
        n = n / 26 - 1
    } while (n >= 0)
    return sb.toString()
}

/** Sheet tabs for workbooks with more than one sheet. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun SheetTabs(names: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    ScrollableTabRow(selectedTabIndex = selected.coerceIn(0, (names.size - 1).coerceAtLeast(0)), edgePadding = 8.dp) {
        names.forEachIndexed { i, n ->
            Tab(
                selected = i == selected,
                onClick = { onSelect(i) },
                text = { Text(n, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            )
        }
    }
}

/**
 * A spreadsheet grid with A, B, C column headers and row numbers. Both directions scroll: the
 * rows scroll vertically in the LazyColumn, and every row and the header share one horizontal
 * scroll state, so they move together. [zoom] scales cell sizes and text.
 */
@Composable
internal fun SheetGridView(
    sheet: Sheet,
    zoom: Float,
    listState: LazyListState,
    hl: Highlights,
    modifier: Modifier = Modifier,
) {
    val ink = MaterialTheme.colorScheme.onSurface
    val border = MaterialTheme.colorScheme.outlineVariant
    val chrome = MaterialTheme.colorScheme.surfaceVariant
    val hs = rememberScrollState()

    val cols = maxOf(sheet.rows.maxOfOrNull { it.size } ?: 0, sheet.colWidthsChars.size).coerceIn(1, 200)
    val widths: List<Dp> = List(cols) { c ->
        val chars = sheet.colWidthsChars.getOrNull(c) ?: 8.43f
        (chars * 7.2f * zoom).coerceIn(56f * zoom, 280f * zoom).dp
    }
    val rowNumWidth: Dp = (44f * zoom).dp
    val rowHeight: Dp = (26f * zoom).dp
    val textSize = (13f * zoom).sp

    Column(modifier.fillMaxWidth()) {
        // Header: corner cell plus column letters.
        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(hs)
                .background(chrome),
        ) {
            GridCell(rowNumWidth, rowHeight, AnnotatedString(""), border, chrome)
            for (c in 0 until cols) {
                GridCell(
                    widths[c],
                    rowHeight,
                    AnnotatedString(columnName(c)),
                    border,
                    chrome,
                    textSize = textSize,
                    color = ink,
                    centered = true,
                )
            }
        }
        if (sheet.rows.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Text("This sheet is empty.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            return@Column
        }
        LazyColumn(state = listState, modifier = Modifier.fillMaxWidth().weight(1f)) {
            itemsIndexed(sheet.rows) { r, row ->
                Row(Modifier.horizontalScroll(hs)) {
                    GridCell(rowNumWidth, rowHeight, AnnotatedString("${r + 1}"), border, chrome, textSize, ink, centered = true)
                    for (c in 0 until cols) {
                        val v = row.getOrNull(c).orEmpty()
                        val key = "$r/$c"
                        val shown = AnnotatedString(v).withHighlights(hl.ranges(key), hl.currentIn(key))
                        GridCell(widths[c], rowHeight, shown, border, Color.Transparent, textSize, ink)
                    }
                }
            }
            if (sheet.truncated) {
                item { Notice("This sheet is very large, so only the first rows are shown.") }
            }
        }
    }
}

@Composable
private fun GridCell(
    width: Dp,
    height: Dp,
    text: AnnotatedString,
    border: Color,
    background: Color,
    textSize: androidx.compose.ui.unit.TextUnit = 13.sp,
    color: Color = Color.Unspecified,
    centered: Boolean = false,
) {
    Box(
        Modifier
            .width(width)
            .height(height)
            .border(0.5.dp, border)
            .background(background)
            .padding(horizontal = 4.dp),
        contentAlignment = if (centered) Alignment.Center else Alignment.CenterStart,
    ) {
        Text(
            text,
            fontSize = textSize,
            color = color,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}
