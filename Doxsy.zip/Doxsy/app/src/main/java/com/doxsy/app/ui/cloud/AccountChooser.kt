package com.doxsy.app.ui.cloud

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.doxsy.app.cloud.AuthOutcome
import com.doxsy.app.cloud.GoogleAuth
import com.doxsy.app.cloud.GoogleScopes
import com.doxsy.app.data.Prefs
import com.doxsy.app.ui.ConfirmDialog
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Shown before Google Drive / PDFs from emails when accounts were added earlier:
 * tap a saved account to open it directly, or add another one (it is saved for both Drive and Email).
 */
@Composable
fun AccountChooserScreen(prefs: Prefs, forGmail: Boolean, onBack: () -> Unit, onChosen: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val saved by prefs.savedAccounts.state.collectAsState()
    val active by prefs.googleAccount.state.collectAsState()
    val connect = rememberConnectState()
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var pending by remember { mutableStateOf("") }
    var removing by remember { mutableStateOf<String?>(null) }

    val scopes = if (forGmail) listOf(GoogleScopes.GMAIL) else listOf(GoogleScopes.DRIVE)

    fun proceed(email: String) {
        prefs.googleAccount.value = email
        if (forGmail) prefs.gmailOn.value = true
        busy = false
        onChosen()
    }

    val consent = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            when (val o = GoogleAuth.tokenFromIntent(ctx, r.data)) {
                is AuthOutcome.Token -> proceed(pending)
                is AuthOutcome.Failed -> { busy = false; error = o.message }
                is AuthOutcome.Consent -> busy = false
            }
        } else {
            busy = false
        }
    }

    fun pick(email: String) {
        if (busy) return
        busy = true
        pending = email
        scope.launch {
            when (val o = GoogleAuth.authorize(ctx, email, scopes)) {
                is AuthOutcome.Token -> proceed(email)
                is AuthOutcome.Consent -> consent.launch(IntentSenderRequest.Builder(o.sender).build())
                is AuthOutcome.Failed -> { busy = false; error = o.message }
            }
        }
    }

    BackHandler { onBack() }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") }
        }
        Text(
            if (forGmail) "PDFs from emails" else "Google Drive",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(start = 16.dp, bottom = 4.dp),
        )
        Text(
            "Choose an account",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 16.dp, bottom = 12.dp),
        )
        Box(Modifier.weight(1f)) {
            LazyColumn {
                items(saved, key = { it }) { email ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { pick(email) }
                            .padding(start = 16.dp, end = 4.dp, top = 10.dp, bottom = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            Modifier.size(40.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                email.take(1).uppercase(Locale.ROOT),
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                            )
                        }
                        Spacer(Modifier.width(16.dp))
                        Text(email, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                        if (email.equals(active, true)) {
                            Icon(Icons.Rounded.Check, "Current", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                        }
                        IconButton(onClick = { removing = email }) { Icon(Icons.Rounded.Close, "Remove account") }
                    }
                }
                item {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable {
                                connect.begin(forGmail = forGmail)
                            }
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(Modifier.size(40.dp), contentAlignment = Alignment.Center) {
                            Icon(Icons.Rounded.Add, null, tint = MaterialTheme.colorScheme.primary)
                        }
                        Spacer(Modifier.width(16.dp))
                        Text("Add another account", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
            if (busy) CircularProgressIndicator(Modifier.align(Alignment.Center))
        }
    }

    GoogleConnectHost(connect, prefs, onDone = { if (forGmail) prefs.gmailOn.value = true; onChosen() })

    removing?.let { email ->
        ConfirmDialog(
            title = "Remove account",
            message = "$email will be removed from Google Drive and Email in Doxsy.",
            confirmLabel = "Remove",
            onDismiss = { removing = null },
            onConfirm = { removing = null; prefs.forgetAccount(email) },
        )
    }

    error?.let { msg ->
        AlertDialog(
            onDismissRequest = { error = null },
            title = { Text("Couldn't open account") },
            text = { Text(msg) },
            confirmButton = { TextButton(onClick = { error = null }) { Text("OK") } },
        )
    }
}
