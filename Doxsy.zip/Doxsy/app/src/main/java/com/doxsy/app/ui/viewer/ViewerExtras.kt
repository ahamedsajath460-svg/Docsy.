package com.doxsy.app.ui.viewer

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import kotlin.coroutines.resume

/**
 * Reads page text aloud with the phone's own text-to-speech engine (nothing is sent anywhere).
 * Tamil and Sinhala text switch the voice language when the phone has that voice installed.
 */
internal class PageReader(app: Context) {
    private var ready = false
    private var failed = false
    private var tts: TextToSpeech? = null
    private var lastLocale: Locale? = null

    init {
        tts = TextToSpeech(app.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) ready = true else failed = true
        }
    }

    /** False when the phone has no speech engine at all. */
    val available: Boolean get() = !failed

    private fun localeFor(text: String): Locale {
        var tamil = 0
        var sinhala = 0
        for (c in text) {
            if (c in '஀'..'௿') tamil++
            if (c in '඀'..'෿') sinhala++
        }
        return when {
            tamil > 8 && tamil >= sinhala -> Locale("ta", "IN")
            sinhala > 8 -> Locale("si", "LK")
            else -> Locale.getDefault()
        }
    }

    private fun chunks(text: String): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        for (line in text.split('\n')) {
            val l = line.trim()
            if (l.isEmpty()) continue
            if (sb.length + l.length + 1 > MAX_CHUNK && sb.isNotEmpty()) {
                out.add(sb.toString())
                sb.setLength(0)
            }
            if (l.length > MAX_CHUNK) {
                l.chunked(MAX_CHUNK).forEach { out.add(it) }
            } else {
                if (sb.isNotEmpty()) sb.append(' ')
                sb.append(l)
            }
        }
        if (sb.isNotEmpty()) out.add(sb.toString())
        return out
    }

    /**
     * Speaks [text] and returns true when it was read to the end, false when it was stopped or could not be read.
     * Cancelling the caller stops the speech.
     */
    suspend fun speak(text: String): Boolean {
        // The engine starts up in the background; wait a little for it.
        var waited = 0
        while (!ready && !failed && waited < 40) {
            kotlinx.coroutines.delay(100)
            waited++
        }
        val engine = tts ?: return false
        if (!ready) return false
        val parts = chunks(text)
        if (parts.isEmpty()) return true

        val loc = localeFor(text)
        if (loc != lastLocale) {
            val r = engine.setLanguage(loc)
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                engine.setLanguage(Locale.getDefault())
            }
            lastLocale = loc
        }

        return suspendCancellableCoroutine { cont ->
            val lastId = "doxsy-last-${System.nanoTime()}"
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    if (utteranceId == lastId && cont.isActive) cont.resume(true)
                }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    if (cont.isActive) cont.resume(false)
                }
                override fun onStop(utteranceId: String?, interrupted: Boolean) {
                    if (cont.isActive) cont.resume(false)
                }
            })
            parts.forEachIndexed { i, p ->
                val id = if (i == parts.lastIndex) lastId else "doxsy-$i-${System.nanoTime()}"
                val mode = if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
                val res = engine.speak(p, mode, Bundle(), id)
                if (res == TextToSpeech.ERROR && cont.isActive) cont.resume(false)
            }
            cont.invokeOnCancellation { runCatching { engine.stop() } }
        }
    }

    fun stop() {
        runCatching { tts?.stop() }
    }

    fun shutdown() {
        runCatching {
            tts?.stop()
            tts?.shutdown()
        }
        tts = null
    }

    private companion object {
        // TextToSpeech refuses more than ~4000 characters at once.
        const val MAX_CHUNK = 3000
    }
}

internal fun copyText(ctx: Context, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return
    cm.setPrimaryClip(ClipData.newPlainText("Doxsy", text))
}

internal fun shareText(ctx: Context, text: String) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    val chooser = Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    runCatching { ctx.startActivity(chooser) }
}
