package com.doxsy.app.annot

import android.content.Context
import android.graphics.PointF
import android.net.Uri
import com.doxsy.app.pdf.PdfEngine
import com.tom_roush.pdfbox.cos.COSDictionary
import com.tom_roush.pdfbox.cos.COSFloat
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.PDResources
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.graphics.color.PDColor
import com.tom_roush.pdfbox.pdmodel.graphics.color.PDDeviceRGB
import com.tom_roush.pdfbox.pdmodel.graphics.state.PDExtendedGraphicsState
import com.tom_roush.pdfbox.pdmodel.interactive.annotation.PDAnnotation
import com.tom_roush.pdfbox.pdmodel.interactive.annotation.PDAnnotationText
import com.tom_roush.pdfbox.pdmodel.interactive.annotation.PDAnnotationTextMarkup
import com.tom_roush.pdfbox.pdmodel.interactive.annotation.PDAppearanceDictionary
import com.tom_roush.pdfbox.pdmodel.interactive.annotation.PDAppearanceStream
import com.tom_roush.pdfbox.util.Matrix
import java.io.File
import java.io.IOException
import java.io.OutputStream
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Writes annotations into a COPY of a PDF with PDFBox. The source file is never modified.
 *
 *  - highlight / underline / strikethrough -> real PDF markup annotations with quad points, colour, contents
 *    and an explicit appearance stream (so every viewer shows exactly one rendering);
 *  - sticky notes / comments -> real PDF "Text" annotations (comment stored in /Contents) with an appearance;
 *  - freehand, marker, shapes, text -> drawn permanently into the page content stream.
 */
object PdfAnnotExporter {

    /** Maps annotation space (displayed page, normalised) to PDF default user space for one page. */
    private class Mapper(box: PDRectangle, private val rot: Int) {
        private val bx = box.lowerLeftX
        private val by = box.lowerLeftY
        private val bw = box.width
        private val bh = box.height
        val dw: Float = if (rot == 90 || rot == 270) bh else bw
        val dh: Float = if (rot == 90 || rot == 270) bw else bh

        /** (X, Y) in points of the displayed page, origin top-left, Y down. */
        fun pt(X: Float, Y: Float): PointF {
            val px: Float
            val py: Float
            when (rot) {
                90 -> { px = Y; py = bh - X }
                180 -> { px = bw - X; py = bh - Y }
                270 -> { px = bw - Y; py = X }
                else -> { px = X; py = Y }
            }
            return PointF(bx + px, by + bh - py)
        }

        fun uv(u: Float, v: Float): PointF = pt(u * dw, v * dh)

        /** Rotation (radians) of the displayed +X direction in PDF space. */
        fun angle(): Float {
            val a = pt(0f, 0f)
            val b = pt(10f, 0f)
            return atan2(b.y - a.y, b.x - a.x)
        }
    }

    fun describe(e: Throwable): String = when (e) {
        is InvalidPasswordException -> "This PDF is password protected. Open it with its password first."
        is OutOfMemoryError -> "Not enough memory to export this PDF."
        is IOException -> e.message?.takeIf { it.isNotBlank() } ?: "Could not read or write the file."
        else -> "Could not export the annotated PDF."
    }

    /**
     * Blocking; call on Dispatchers.IO. Reads [source], applies [annots] and writes the new PDF to [out].
     * Throws on failure (use [describe]).
     */
    fun export(
        ctx: Context,
        source: Uri,
        password: String,
        annots: List<Annot>,
        out: OutputStream,
        onProgress: (done: Int, total: Int) -> Unit = { _, _ -> },
    ) {
        val app = ctx.applicationContext
        PdfEngine.init(app)
        val tmp = File(app.cacheDir, "doxsy_tmp_annot_${System.nanoTime()}.pdf")
        var doc: PDDocument? = null
        try {
            app.contentResolver.openInputStream(source)?.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                ?: throw IOException("Could not open the source PDF.")
            val d = PDDocument.load(tmp, password)
            doc = d
            if (d.isEncrypted) d.isAllSecurityToBeRemoved = true
            val byPage = annots.groupBy { it.page }.toSortedMap()
            var done = 0
            onProgress(0, byPage.size)
            for ((pageIdx, list) in byPage) {
                if (pageIdx < 0 || pageIdx >= d.numberOfPages) continue
                drawPage(d, d.getPage(pageIdx), list)
                done++
                onProgress(done, byPage.size)
            }
            d.save(out)
        } finally {
            runCatching { doc?.close() }
            tmp.delete()
        }
    }

    // ------------------------------------------------------------------ per page

    private fun drawPage(doc: PDDocument, page: PDPage, list: List<Annot>) {
        val box = page.cropBox ?: page.mediaBox
        val rot = ((page.rotation % 360) + 360) % 360
        val m = Mapper(box, rot)
        val native = list.filter {
            it.type == AnnotType.HIGHLIGHT || it.type == AnnotType.UNDERLINE ||
                it.type == AnnotType.STRIKE || it.type == AnnotType.NOTE
        }
        val drawn = list.filter { it !in native }

        if (drawn.isNotEmpty()) {
            PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                for (a in drawn) {
                    runCatching { drawContent(cs, m, a) }
                }
            }
        }
        if (native.isNotEmpty()) {
            val existing = ArrayList<PDAnnotation>(page.annotations)
            for (a in native) {
                val ann = runCatching { buildNative(doc, m, a) }.getOrNull() ?: continue
                existing.add(ann)
            }
            page.annotations = existing
        }
    }

    // ------------------------------------------------------------------ content stream drawing

    private fun red(c: Int) = ((c shr 16) and 0xFF)
    private fun grn(c: Int) = ((c shr 8) and 0xFF)
    private fun blu(c: Int) = (c and 0xFF)

    private fun drawContent(cs: PDPageContentStream, m: Mapper, a: Annot) {
        cs.saveGraphicsState()
        try {
            val width = max(a.strokeFrac * m.dw, 0.3f)
            when (a.type) {
                AnnotType.INK, AnnotType.MARKER -> {
                    if (a.points.isEmpty()) return
                    val marker = a.type == AnnotType.MARKER
                    if (marker) {
                        val gs = PDExtendedGraphicsState()
                        gs.strokingAlphaConstant = 0.4f
                        gs.nonStrokingAlphaConstant = 0.4f
                        cs.setGraphicsStateParameters(gs)
                    }
                    cs.setStrokingColor(red(a.color), grn(a.color), blu(a.color))
                    cs.setNonStrokingColor(red(a.color), grn(a.color), blu(a.color))
                    cs.setLineWidth(if (marker) width * 3f else width)
                    cs.setLineCapStyle(if (marker) 0 else 1)
                    cs.setLineJoinStyle(1)
                    val first = m.uv(a.points[0].x, a.points[0].y)
                    if (a.points.size == 1) {
                        cs.setLineCapStyle(1)
                        cs.moveTo(first.x, first.y)
                        cs.lineTo(first.x + 0.01f, first.y)
                        cs.stroke()
                    } else {
                        cs.moveTo(first.x, first.y)
                        for (i in 1 until a.points.size) {
                            val p = m.uv(a.points[i].x, a.points[i].y)
                            cs.lineTo(p.x, p.y)
                        }
                        cs.stroke()
                    }
                }
                AnnotType.LINE, AnnotType.ARROW -> {
                    if (a.points.size < 2) return
                    cs.setStrokingColor(red(a.color), grn(a.color), blu(a.color))
                    cs.setLineWidth(width)
                    cs.setLineCapStyle(1)
                    val x1 = a.points[0].x * m.dw
                    val y1 = a.points[0].y * m.dh
                    val x2 = a.points[1].x * m.dw
                    val y2 = a.points[1].y * m.dh
                    val p1 = m.pt(x1, y1)
                    val p2 = m.pt(x2, y2)
                    cs.moveTo(p1.x, p1.y)
                    cs.lineTo(p2.x, p2.y)
                    cs.stroke()
                    if (a.type == AnnotType.ARROW) {
                        val ang = atan2(y2 - y1, x2 - x1)
                        val head = max(width * 5f, m.dw * 0.02f)
                        for (sign in intArrayOf(-1, 1)) {
                            val th = ang + Math.PI.toFloat() + sign * 0.5f
                            val hx = x2 + head * cos(th)
                            val hy = y2 + head * sin(th)
                            val ph = m.pt(hx, hy)
                            cs.moveTo(p2.x, p2.y)
                            cs.lineTo(ph.x, ph.y)
                            cs.stroke()
                        }
                    }
                }
                AnnotType.RECT -> {
                    if (a.points.size < 2) return
                    cs.setStrokingColor(red(a.color), grn(a.color), blu(a.color))
                    cs.setLineWidth(width)
                    cs.setLineJoinStyle(0)
                    val l = min(a.points[0].x, a.points[1].x)
                    val r = max(a.points[0].x, a.points[1].x)
                    val t = min(a.points[0].y, a.points[1].y)
                    val b = max(a.points[0].y, a.points[1].y)
                    val c1 = m.uv(l, t)
                    val c2 = m.uv(r, t)
                    val c3 = m.uv(r, b)
                    val c4 = m.uv(l, b)
                    cs.moveTo(c1.x, c1.y)
                    cs.lineTo(c2.x, c2.y)
                    cs.lineTo(c3.x, c3.y)
                    cs.lineTo(c4.x, c4.y)
                    cs.closeAndStroke()
                }
                AnnotType.CIRCLE -> {
                    if (a.points.size < 2) return
                    cs.setStrokingColor(red(a.color), grn(a.color), blu(a.color))
                    cs.setLineWidth(width)
                    val l = min(a.points[0].x, a.points[1].x) * m.dw
                    val r = max(a.points[0].x, a.points[1].x) * m.dw
                    val t = min(a.points[0].y, a.points[1].y) * m.dh
                    val b = max(a.points[0].y, a.points[1].y) * m.dh
                    val cx = (l + r) / 2f
                    val cy = (t + b) / 2f
                    val rx = (r - l) / 2f
                    val ry = (b - t) / 2f
                    val k = 0.5522848f
                    fun P(x: Float, y: Float) = m.pt(x, y)
                    val s = P(cx + rx, cy)
                    cs.moveTo(s.x, s.y)
                    // four Bezier quarter arcs, mapped point by point (the mapping is affine)
                    val segs = arrayOf(
                        floatArrayOf(cx + rx, cy + k * ry, cx + k * rx, cy + ry, cx, cy + ry),
                        floatArrayOf(cx - k * rx, cy + ry, cx - rx, cy + k * ry, cx - rx, cy),
                        floatArrayOf(cx - rx, cy - k * ry, cx - k * rx, cy - ry, cx, cy - ry),
                        floatArrayOf(cx + k * rx, cy - ry, cx + rx, cy - k * ry, cx + rx, cy),
                    )
                    for (g in segs) {
                        val c1 = P(g[0], g[1])
                        val c2 = P(g[2], g[3])
                        val e = P(g[4], g[5])
                        cs.curveTo(c1.x, c1.y, c2.x, c2.y, e.x, e.y)
                    }
                    cs.closeAndStroke()
                }
                AnnotType.TEXT -> {
                    val p0 = a.points.firstOrNull() ?: return
                    if (a.text.isBlank()) return
                    val fs = max(a.sizeFrac * m.dw, 2f)
                    val lh = fs * 1.2f
                    val ang = m.angle()
                    cs.setNonStrokingColor(red(a.color), grn(a.color), blu(a.color))
                    val lines = a.text.split('\n')
                    for ((i, raw) in lines.withIndex()) {
                        val line = sanitize(raw)
                        if (line.isBlank()) continue
                        val base = m.pt(p0.x * m.dw, p0.y * m.dh + i * lh + fs * 0.9f)
                        cs.beginText()
                        cs.setFont(PDType1Font.HELVETICA, fs)
                        cs.setTextMatrix(Matrix.getRotateInstance(ang.toDouble(), base.x, base.y))
                        cs.showText(line)
                        cs.endText()
                    }
                }
                else -> Unit
            }
        } finally {
            cs.restoreGraphicsState()
        }
    }

    /** Helvetica uses WinAnsi: keep printable ASCII and Latin-1, replace everything else. */
    private fun sanitize(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s) {
            sb.append(
                when {
                    c == '\t' -> ' '
                    c.code in 32..126 || c.code in 160..255 -> c
                    else -> '?'
                },
            )
        }
        return sb.toString()
    }

    // ------------------------------------------------------------------ native annotations

    private fun f(v: Float): String = String.format(Locale.US, "%.3f", v)

    private fun rgbF(c: Int): FloatArray = floatArrayOf(red(c) / 255f, grn(c) / 255f, blu(c) / 255f)

    private fun buildNative(doc: PDDocument, m: Mapper, a: Annot): PDAnnotation? {
        val rgb = rgbF(a.color)
        val pdColor = PDColor(rgb, PDDeviceRGB.INSTANCE)
        return when (a.type) {
            AnnotType.HIGHLIGHT, AnnotType.UNDERLINE, AnnotType.STRIKE -> {
                if (a.rects.isEmpty()) return null
                val sub = when (a.type) {
                    AnnotType.HIGHLIGHT -> PDAnnotationTextMarkup.SUB_TYPE_HIGHLIGHT
                    AnnotType.UNDERLINE -> PDAnnotationTextMarkup.SUB_TYPE_UNDERLINE
                    else -> PDAnnotationTextMarkup.SUB_TYPE_STRIKEOUT
                }
                val ann = PDAnnotationTextMarkup(sub)
                val quad = FloatArray(a.rects.size * 8)
                var minX = Float.MAX_VALUE
                var minY = Float.MAX_VALUE
                var maxX = -Float.MAX_VALUE
                var maxY = -Float.MAX_VALUE
                val ops = StringBuilder()
                val lineW = max(0.7f, (a.rects.map { (it.bottom - it.top) * m.dh }.average().toFloat()) * 0.07f)
                if (a.type == AnnotType.HIGHLIGHT) ops.append("/GS0 gs ${f(rgb[0])} ${f(rgb[1])} ${f(rgb[2])} rg\n")
                else ops.append("${f(rgb[0])} ${f(rgb[1])} ${f(rgb[2])} RG ${f(lineW)} w 1 J\n")
                a.rects.forEachIndexed { i, r ->
                    val tl = m.uv(r.left, r.top)
                    val tr = m.uv(r.right, r.top)
                    val bl = m.uv(r.left, r.bottom)
                    val br = m.uv(r.right, r.bottom)
                    // Acrobat order: top-left, top-right, bottom-left, bottom-right (as seen on the displayed page)
                    val pts = arrayOf(tl, tr, bl, br)
                    for (k in 0 until 4) {
                        quad[i * 8 + k * 2] = pts[k].x
                        quad[i * 8 + k * 2 + 1] = pts[k].y
                        minX = min(minX, pts[k].x); maxX = max(maxX, pts[k].x)
                        minY = min(minY, pts[k].y); maxY = max(maxY, pts[k].y)
                    }
                    when (a.type) {
                        AnnotType.HIGHLIGHT ->
                            ops.append("${f(tl.x)} ${f(tl.y)} m ${f(tr.x)} ${f(tr.y)} l ${f(br.x)} ${f(br.y)} l ${f(bl.x)} ${f(bl.y)} l h f\n")
                        AnnotType.UNDERLINE ->
                            ops.append("${f(bl.x)} ${f(bl.y)} m ${f(br.x)} ${f(br.y)} l S\n")
                        else -> {
                            val ml = m.uv(r.left, (r.top + r.bottom) / 2f)
                            val mr = m.uv(r.right, (r.top + r.bottom) / 2f)
                            ops.append("${f(ml.x)} ${f(ml.y)} m ${f(mr.x)} ${f(mr.y)} l S\n")
                        }
                    }
                }
                val pad = lineW + 1f
                val rect = PDRectangle(minX - pad, minY - pad, (maxX - minX) + 2 * pad, (maxY - minY) + 2 * pad)
                ann.setQuadPoints(quad)
                ann.rectangle = rect
                ann.color = pdColor
                ann.contents = a.comment.ifBlank { a.text }
                ann.isPrinted = true
                ann.appearance = makeAppearance(doc, rect, ops.toString(), if (a.type == AnnotType.HIGHLIGHT) 0.4f else null)
                ann
            }
            AnnotType.NOTE -> {
                val c = a.points.firstOrNull() ?: return null
                val half = NOTE_SIZE_FRAC * m.dw / 2f
                val cx = c.x * m.dw
                val cy = c.y * m.dh
                val corners = listOf(
                    m.pt(cx - half, cy - half), m.pt(cx + half, cy - half),
                    m.pt(cx + half, cy + half), m.pt(cx - half, cy + half),
                )
                val minX = corners.minOf { it.x }
                val maxX = corners.maxOf { it.x }
                val minY = corners.minOf { it.y }
                val maxY = corners.maxOf { it.y }
                val rect = PDRectangle(minX, minY, maxX - minX, maxY - minY)
                val ops = StringBuilder()
                ops.append("1 0.85 0.2 rg 0.45 0.35 0 RG 0.8 w\n")
                ops.append("${f(corners[0].x)} ${f(corners[0].y)} m ${f(corners[1].x)} ${f(corners[1].y)} l ")
                ops.append("${f(corners[2].x)} ${f(corners[2].y)} l ${f(corners[3].x)} ${f(corners[3].y)} l h B\n")
                for (dy in floatArrayOf(-0.4f, -0.05f, 0.3f)) {
                    val p = m.pt(cx - half * 0.6f, cy + half * dy)
                    val q = m.pt(cx + half * 0.6f, cy + half * dy)
                    ops.append("${f(p.x)} ${f(p.y)} m ${f(q.x)} ${f(q.y)} l S\n")
                }
                val ann = PDAnnotationText()
                ann.rectangle = rect
                ann.contents = a.comment.ifBlank { a.text }
                ann.color = pdColor
                ann.isPrinted = true
                ann.appearance = makeAppearance(doc, rect, ops.toString(), null)
                ann
            }
            else -> null
        }
    }

    /** Builds a normal appearance stream from raw PDF operators expressed in page coordinates. */
    private fun makeAppearance(doc: PDDocument, bbox: PDRectangle, ops: String, alpha: Float?): PDAppearanceDictionary {
        val stream = PDAppearanceStream(doc)
        stream.bBox = bbox
        val res = PDResources()
        if (alpha != null) {
            val gs = COSDictionary()
            gs.setItem(COSName.getPDFName("CA"), COSFloat(alpha))
            gs.setItem(COSName.getPDFName("ca"), COSFloat(alpha))
            val ext = COSDictionary()
            ext.setItem(COSName.getPDFName("GS0"), gs)
            res.cosObject.setItem(COSName.getPDFName("ExtGState"), ext)
        }
        stream.resources = res
        stream.cosObject.createOutputStream().use { it.write(ops.toByteArray(Charsets.ISO_8859_1)) }
        val ap = PDAppearanceDictionary()
        ap.setNormalAppearance(stream)
        return ap
    }
}
