package com.doxsy.app.docview

import android.content.Context
import android.net.Uri
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.nio.charset.Charset

/**
 * Minimal RTF reader that returns plain text. Formatting, pictures, fonts and colours are dropped;
 * paragraphs and tabs are kept as line breaks and tab characters.
 */
object RtfReader {
    private const val MAX_BYTES = 30 * 1024 * 1024

    /** Destinations whose content is never document text. */
    private val SKIP_DESTINATIONS = setOf("fonttbl", "colortbl", "stylesheet", "pict", "info")

    private val CP1252: Charset = Charset.forName("windows-1252")

    /** Byte value to character, using Windows-1252 for bytes 0x80..0xFF. */
    private val HIGH: Array<Char> = Array(256) { i ->
        if (i < 0x80) i.toChar() else String(byteArrayOf(i.toByte()), CP1252)[0]
    }

    fun readText(ctx: Context, uri: Uri): String {
        val bytes = try {
            ctx.contentResolver.openInputStream(uri)?.use { readLimited(it) }
                ?: throw DocReadException("Could not open this file.")
        } catch (e: DocReadException) {
            throw e
        } catch (e: OutOfMemoryError) {
            throw DocReadException("Not enough memory to open this file.", e)
        } catch (e: Exception) {
            throw DocReadException("This RTF file could not be read.", e)
        }
        if (String(bytes, 0, minOf(bytes.size, 5), Charsets.US_ASCII) != "{\\rtf") {
            throw DocReadException("This is not a valid RTF document. The file may be corrupted.")
        }
        try {
            return Parser(bytes).run()
                .replace(Regex("\n{3,}"), "\n\n")
                .trim()
        } catch (e: Exception) {
            throw DocReadException("This RTF document could not be read. It may be corrupted.", e)
        }
    }

    private fun readLimited(input: InputStream): ByteArray {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(64 * 1024)
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            out.write(buf, 0, n)
            if (out.size() > MAX_BYTES) throw DocReadException("This RTF file is too large to open.")
        }
        return out.toByteArray()
    }

    /** Per-group state: whether the group is an ignorable destination, and the \uc fallback count. */
    private class Frame(var skip: Boolean, var uc: Int)

    private class Parser(private val d: ByteArray) {
        private val out = StringBuilder()
        private val stack = ArrayList<Frame>()
        private var cur = Frame(false, 1)
        /** Fallback units still to swallow after a \uN control word. */
        private var skipUnits = 0
        private var i = 0

        fun run(): String {
            while (i < d.size) {
                val b = d[i].toInt() and 0xFF
                when (b) {
                    0x7B -> { // {
                        stack.add(cur)
                        cur = Frame(cur.skip, cur.uc)
                        i++
                    }
                    0x7D -> { // }
                        if (stack.isNotEmpty()) cur = stack.removeAt(stack.lastIndex)
                        i++
                    }
                    0x5C -> { // backslash
                        i++
                        control()
                    }
                    0x0D, 0x0A -> i++ // raw CR/LF are not text in RTF
                    else -> {
                        unit(HIGH[b])
                        i++
                    }
                }
            }
            return out.toString()
        }

        private fun emit(c: Char) {
            if (!cur.skip) out.append(c)
        }

        /** A text unit that may be swallowed as a \uN fallback. */
        private fun unit(c: Char) {
            if (skipUnits > 0) skipUnits-- else emit(c)
        }

        private fun at(k: Int): Int = if (i + k < d.size) d[i + k].toInt() and 0xFF else -1

        private fun control() {
            val c = at(0)
            if (c < 0) return
            if (isLetter(c)) {
                val start = i
                while (i < d.size && isLetter(d[i].toInt() and 0xFF)) i++
                val word = String(d, start, i - start, Charsets.US_ASCII)
                var param: Int? = null
                val first = at(0)
                if (first == 0x2D || isDigit(first)) {
                    val neg = first == 0x2D
                    if (neg) i++
                    var v = 0
                    var any = false
                    while (i < d.size && isDigit(d[i].toInt() and 0xFF)) {
                        if (v < 100_000_000) v = v * 10 + (d[i].toInt() - 0x30)
                        any = true
                        i++
                    }
                    if (any) param = if (neg) -v else v
                }
                if (at(0) == 0x20) i++ // one space delimiter belongs to the control word
                word(word, param)
            } else {
                i++
                symbol(c)
            }
        }

        private fun word(name: String, param: Int?) {
            if (name in SKIP_DESTINATIONS) {
                cur.skip = true
                return
            }
            when (name) {
                "par", "row" -> emit('\n')
                "line" -> emit('\n')
                "page", "sect" -> emit('\n')
                "tab" -> emit('\t')
                "cell" -> emit('\t')
                "emspace", "enspace" -> emit(' ')
                "emdash" -> emit('—')
                "endash" -> emit('–')
                "lquote" -> emit('‘')
                "rquote" -> emit('’')
                "ldblquote" -> emit('“')
                "rdblquote" -> emit('”')
                "bullet" -> emit('•')
                "uc" -> cur.uc = (param ?: 1).coerceIn(0, 10)
                "u" -> {
                    val v = param ?: return
                    val code = if (v < 0) v + 65536 else v
                    emit(code.toChar())
                    skipUnits = cur.uc
                }
                "bin" -> {
                    val len = param ?: 0
                    if (len > 0) i = (i + len).coerceAtMost(d.size)
                }
            }
        }

        private fun symbol(c: Int) {
            when (c) {
                0x27 -> { // \'hh
                    val hi = hexVal(at(0))
                    val lo = hexVal(at(1))
                    if (hi >= 0 && lo >= 0) {
                        i += 2
                        unit(HIGH[hi * 16 + lo])
                    }
                }
                0x2A -> cur.skip = true // \* marks an ignorable destination
                0x7E -> unit(' ') // \~ non-breaking space
                0x5F -> unit('-') // \_ non-breaking hyphen
                0x2D -> Unit // \- optional hyphen: nothing to show
                0x7B, 0x7D, 0x5C -> unit(c.toChar()) // \{ \} \\
                0x0A, 0x0D -> emit('\n') // backslash + newline is \par
                else -> Unit
            }
        }

        private fun isLetter(c: Int): Boolean = c in 0x61..0x7A || c in 0x41..0x5A

        private fun isDigit(c: Int): Boolean = c in 0x30..0x39

        private fun hexVal(c: Int): Int = when (c) {
            in 0x30..0x39 -> c - 0x30
            in 0x61..0x66 -> c - 0x61 + 10
            in 0x41..0x46 -> c - 0x41 + 10
            else -> -1
        }
    }
}
