package com.doxsy.app.ui.settings

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.doxsy.app.BuildConfig
import com.doxsy.app.cloud.Accounts
import com.doxsy.app.data.Prefs
import com.doxsy.app.util.FileUtils
import java.io.File

/** The only Google account that can see the admin panel. */
internal const val ADMIN_EMAIL = "ahamedsajath160@gmail.com"

/** True only while the signed-in Google account is the admin. */
@Composable
internal fun rememberIsAdmin(): Boolean {
    val user by Accounts.user.collectAsState()
    return user?.email.orEmpty().trim().equals(ADMIN_EMAIL, ignoreCase = true)
}

private fun dirSize(f: File): Long =
    if (f.isFile) f.length() else f.listFiles()?.sumOf { dirSize(it) } ?: 0L

private fun fmtSize(b: Long): String = when {
    b < 1024 -> "$b B"
    b < 1024 * 1024 -> "%.1f KB".format(b / 1024.0)
    else -> "%.1f MB".format(b / 1024.0 / 1024.0)
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(start = 16.dp),
        )
    }
}

@Composable
fun AdminPanel(prefs: Prefs, onBack: () -> Unit) {
    val ctx = LocalContext.current
    BackHandler(onBack = onBack)

    val user by Accounts.user.collectAsState()
    val recents by prefs.recents.state.collectAsState()
    val favourites by prefs.favourites.state.collectAsState()
    val folders by prefs.folders.state.collectAsState()
    val positions by prefs.positions.state.collectAsState()
    val bookmarks by prefs.bookmarks.state.collectAsState()
    val accounts by prefs.savedAccounts.state.collectAsState()
    val recentLimit by prefs.recentLimit.state.collectAsState()
    val gmailOn by prefs.gmailOn.state.collectAsState()
    val rememberPage by prefs.rememberLastPage.state.collectAsState()
    val autoRotate by prefs.autoRotate.state.collectAsState()
    val homeGrid by prefs.homeGrid.state.collectAsState()

    var refresh by remember { mutableIntStateOf(0) }
    val cacheBytes = remember(refresh) { dirSize(ctx.cacheDir) }
    var confirm by remember { mutableStateOf<Triple<String, String, () -> Unit>?>(null) }

    fun debugInfo(): String = buildString {
        appendLine("Doxsy ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})")
        appendLine("Package: ${ctx.packageName}")
        appendLine("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL}")
        appendLine("Signed in: ${user?.email ?: "no"}")
        appendLine("Google accounts saved: ${accounts.size}")
        appendLine("Recents: ${recents.size}, starred: ${favourites.size}, folders: ${folders.size}")
        appendLine("Saved positions: ${positions.size}, bookmarked files: ${bookmarks.size}")
        append("Cache: ${fmtSize(cacheBytes)}")
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 32.dp)) {
        item {
            Column {
                Text(
                    "Admin panel",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 20.dp, top = 8.dp, bottom = 4.dp),
                )
                Text(
                    "Visible only to " + ADMIN_EMAIL,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 20.dp, bottom = 12.dp),
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            }
        }

        item {
            Group("App & device") {
                InfoRow("Version", BuildConfig.VERSION_NAME + " (" + BuildConfig.VERSION_CODE + ")")
                InfoRow("Package", ctx.packageName)
                InfoRow("Android", Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")")
                InfoRow("Device", Build.MANUFACTURER + " " + Build.MODEL)
                InfoRow("Signed in as", user?.email ?: "-")
            }
        }

        item {
            Group("Usage") {
                InfoRow("Recent files", recents.size.toString())
                InfoRow("Starred files", favourites.size.toString())
                InfoRow("Saved folders", folders.size.toString())
                InfoRow("Remembered reading positions", positions.size.toString())
                InfoRow("Files with bookmarks", bookmarks.size.toString())
                InfoRow("Google accounts saved", accounts.size.toString())
                InfoRow("Cache size", fmtSize(cacheBytes))
            }
        }

        item {
            Group("Feature controls") {
                SwitchRow("Gmail (PDFs from emails)", "Turn the Gmail feature on or off", gmailOn) { prefs.gmailOn.value = it }
                Divider()
                SwitchRow("Remember last page", null, rememberPage) { prefs.rememberLastPage.value = it }
                Divider()
                SwitchRow("Auto rotate", null, autoRotate) { prefs.autoRotate.value = it }
                Divider()
                SwitchRow("Grid view on Home", null, homeGrid) { prefs.homeGrid.value = it }
                Divider()
                Choice(
                    "Recent files limit",
                    listOf("10" to 10, "20" to 20, "50" to 50, "100" to 100),
                    recentLimit,
                ) { prefs.setRecentLimit(it) }
            }
        }

        item {
            Group("Maintenance") {
                ActionRow("Clear cache", "Frees " + fmtSize(cacheBytes) + " of temporary files", Icons.Rounded.Storage) {
                    ctx.cacheDir.listFiles()?.forEach { it.deleteRecursively() }
                    refresh++
                    FileUtils.toast(ctx, "Cache cleared")
                }
                Divider()
                ActionRow("Show Home hints again", "Brings back the welcome tip and Home cards", Icons.Rounded.Refresh) {
                    prefs.resetHints()
                    FileUtils.toast(ctx, "Hints reset")
                }
                Divider()
                ActionRow("Copy debug info", "Copies app, device and usage details", Icons.Rounded.ContentCopy) {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("Doxsy debug info", debugInfo()))
                    FileUtils.toast(ctx, "Copied")
                }
            }
        }

        item {
            Group("Danger zone") {
                ActionRow("Disconnect Google accounts", "Removes all saved Drive / Gmail accounts", Icons.Rounded.DeleteSweep) {
                    confirm = Triple("Disconnect Google accounts?", "All saved Google accounts will be removed from Doxsy.") {
                        accounts.toList().forEach { prefs.forgetAccount(it) }
                    }
                }
                Divider()
                ActionRow("Reset all settings", "Theme, PDF and privacy options go back to default", Icons.Rounded.Refresh) {
                    confirm = Triple("Reset all settings?", "Every setting returns to its default. Your files and data are not touched.") {
                        prefs.resetSettings()
                    }
                }
                Divider()
                ActionRow("Erase all app data", "Recents, stars, folders, bookmarks and reading positions", Icons.Rounded.DeleteSweep) {
                    confirm = Triple("Erase all app data?", "Recents, starred files, folders, bookmarks and reading positions will be removed. Your files stay on the phone.") {
                        prefs.clearAllData()
                    }
                }
            }
        }
    }

    confirm?.let { (title, message, action) ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(title) },
            text = { Text(message) },
            confirmButton = {
                TextButton(onClick = { confirm = null; action(); refresh++ }) { Text("Confirm") }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancel") } },
        )
    }
}
