package com.doxsy.app.ui.home

import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddToDrive
import androidx.compose.material.icons.rounded.AddToHomeScreen
import androidx.compose.material.icons.rounded.CloudUpload
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Compress
import androidx.compose.material.icons.rounded.FileUpload
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DriveFileRenameOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.FileCopy
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.RemoveCircleOutline
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.doxsy.app.data.DocEntry
import com.doxsy.app.data.Prefs
import com.doxsy.app.ui.ConfirmDialog
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import com.doxsy.app.MainActivity
import com.doxsy.app.R
import com.doxsy.app.cloud.DriveApi
import com.doxsy.app.cloud.GoogleAuth
import com.doxsy.app.convert.ConvertEngine
import com.doxsy.app.convert.ConvertOutcome
import com.doxsy.app.convert.ConvertSettings
import com.doxsy.app.convert.Conversion
import com.doxsy.app.fileman.DeviceFiles
import com.doxsy.app.pdf.PdfTools
import com.doxsy.app.pdf.ToolResult
import com.doxsy.app.util.FileKind
import com.doxsy.app.util.FileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date

/** Which file's "⋮" menu is open. The entry is kept after closing so the slide-down animation can finish. */
class FileMenuState {
    var entry by mutableStateOf<DocEntry?>(null)
        private set
    var visible by mutableStateOf(false)
        private set

    fun show(e: DocEntry) { entry = e; visible = true }
    fun hide() { visible = false }
}

@Composable
fun rememberFileMenuState(): FileMenuState = remember { FileMenuState() }

private const val SHEET_IN_MS = 650
private const val SHEET_OUT_MS = 450

/**
 * Adobe-style bottom sheet for one file: Edit PDF, Export PDF, Compress PDF, Set password, then
 * Share, Star, Rename, Save to cloud storage, Save a copy, Remove from recent,
 * Details, Add to Home Screen, Upload to Drive, Delete.
 * It slides up slowly (like the screen recording). Put it last inside a full-size Box.
 */
@Composable
fun FileMenuHost(
    state: FileMenuState,
    prefs: Prefs,
    onOpen: (DocEntry) -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val recents by prefs.recents.state.collectAsState()
    val favourites by prefs.favourites.state.collectAsState()

    var renaming by remember { mutableStateOf<DocEntry?>(null) }
    var deleting by remember { mutableStateOf<DocEntry?>(null) }
    var copySource by remember { mutableStateOf<DocEntry?>(null) }
    var unstarring by remember { mutableStateOf<DocEntry?>(null) }
    var removingRecent by remember { mutableStateOf<DocEntry?>(null) }

    // Export PDF / Compress PDF / Set password
    var exporting by remember { mutableStateOf<DocEntry?>(null) }
    var compressing by remember { mutableStateOf<DocEntry?>(null) }
    var protecting by remember { mutableStateOf<DocEntry?>(null) }
    var busyLabel by remember { mutableStateOf<String?>(null) }
    var detailsFor by remember { mutableStateOf<DocEntry?>(null) }

    val saveCopy = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { out ->
        val src = copySource
        copySource = null
        if (out != null && src != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    runCatching {
                        ctx.contentResolver.openInputStream(Uri.parse(src.uri))!!.use { i ->
                            ctx.contentResolver.openOutputStream(out)!!.use { o -> i.copyTo(o) }
                        }
                    }.isSuccess
                }
                FileUtils.toast(ctx, if (ok) "Copy saved" else "Could not save a copy")
            }
        }
    }

    BackHandler(enabled = state.visible) { state.hide() }

    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(
            visible = state.visible,
            enter = fadeIn(tween(SHEET_IN_MS)),
            exit = fadeOut(tween(SHEET_OUT_MS)),
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.5f))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { state.hide() },
            )
        }
        AnimatedVisibility(
            visible = state.visible,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(tween(SHEET_IN_MS, easing = FastOutSlowInEasing)) { it },
            exit = slideOutVertically(tween(SHEET_OUT_MS, easing = FastOutSlowInEasing)) { it },
        ) {
            val e = state.entry
            if (e != null) {
                val isPdf = FileKind.of(e.name) == FileKind.PDF
                val isStar = favourites.any { it.uri == e.uri }
                val inRecent = recents.any { it.uri == e.uri }
                fun act(block: () -> Unit): () -> Unit = { state.hide(); block() }
                Surface(
                    shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 3.dp,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(
                        Modifier
                            .navigationBarsPadding()
                            .verticalScroll(rememberScrollState())
                            .padding(bottom = 8.dp),
                    ) {
                        SheetHeader(e)
                        if (isPdf) {
                            MenuRow(Icons.Rounded.Edit, "Edit PDF", act { onOpen(e) })
                            MenuRow(Icons.Rounded.FileUpload, "Export PDF", act { exporting = e })
                            MenuRow(Icons.Rounded.Compress, "Compress PDF", act { compressing = e })
                            MenuRow(Icons.Rounded.Lock, "Set password", act { protecting = e })
                            Box(
                                Modifier
                                    .padding(vertical = 6.dp)
                                    .fillMaxWidth()
                                    .height(1.dp)
                                    .background(MaterialTheme.colorScheme.outlineVariant),
                            )
                        }
                        MenuRow(Icons.Rounded.Share, "Share", act { FileUtils.share(ctx, Uri.parse(e.uri), DeviceFiles.mimeOf(e.name)) })
                        MenuRow(
                            if (isStar) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                            if (isStar) "Remove star" else "Star",
                            act { if (isStar) unstarring = e else prefs.toggleFavourite(e) },
                        )
                        MenuRow(Icons.Rounded.DriveFileRenameOutline, "Rename", act { renaming = e })
                        MenuRow(Icons.Rounded.CloudUpload, "Save to cloud storage", act {
                            FileUtils.toast(ctx, "Choose Google Drive")
                            FileUtils.share(ctx, Uri.parse(e.uri), DeviceFiles.mimeOf(e.name))
                        })
                        MenuRow(Icons.Rounded.FileCopy, "Save a copy", act { copySource = e; saveCopy.launch(e.name) })
                        if (inRecent) MenuRow(Icons.Rounded.RemoveCircleOutline, "Remove from recent", act { removingRecent = e })
                        MenuRow(Icons.Rounded.Info, "Details", act { detailsFor = e })
                        MenuRow(Icons.Rounded.AddToHomeScreen, "Add to Home Screen", act { addToHomeScreen(ctx, e) })
                        MenuRow(Icons.Rounded.AddToDrive, "Upload to Drive", act {
                            scope.launch {
                                busyLabel = "Uploading"
                                val msg = uploadToDrive(ctx, prefs, e)
                                busyLabel = null
                                FileUtils.toast(ctx, msg)
                            }
                        })
                        MenuRow(Icons.Rounded.Delete, "Delete", act { deleting = e })
                    }
                }
            }
        }
    }

    exporting?.let { e ->
        ExportPage(name = e.name, uri = Uri.parse(e.uri), onClose = { exporting = null })
    }
    compressing?.let { e ->
        CompressPage(
            name = e.name,
            uri = Uri.parse(e.uri),
            onClose = { compressing = null },
            onOpenPdf = { u, n -> onOpen(DocEntry(u.toString(), n)) },
        )
    }
    protecting?.let { e ->
        SetPasswordPage(
            name = e.name,
            uri = Uri.parse(e.uri),
            onClose = { protecting = null },
            onOpenPdf = { u, n -> onOpen(DocEntry(u.toString(), n)) },
        )
    }
    busyLabel?.let { label ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text(label) },
            text = { Row(verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(Modifier.size(28.dp)); Spacer(Modifier.width(16.dp)); Text("Please wait…") } },
            confirmButton = {},
        )
    }
    detailsFor?.let { e ->
        val rows by produceState<List<Pair<String, String>>?>(null, e.uri) { value = loadDetails(ctx, e) }
        AlertDialog(
            onDismissRequest = { detailsFor = null },
            title = { Text("Details") },
            text = {
                val list = rows
                if (list == null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(28.dp)); Spacer(Modifier.width(16.dp)); Text("Loading…")
                    }
                } else {
                    Column(Modifier.verticalScroll(rememberScrollState())) {
                        list.forEach { (k, v) ->
                            Text(k, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(v, style = MaterialTheme.typography.bodyLarge)
                            Spacer(Modifier.height(10.dp))
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { detailsFor = null }) { Text("Close") } },
        )
    }
    renaming?.let { e ->
        var text by remember(e.uri) { mutableStateOf(e.name.substringBeforeLast('.')) }
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text("Rename") },
            text = { OutlinedTextField(text, { text = it }, singleLine = true) },
            confirmButton = {
                TextButton(
                    enabled = text.isNotBlank(),
                    onClick = {
                        renaming = null
                        scope.launch { renameFile(ctx, prefs, e, text.trim()) }
                    },
                ) { Text("Rename") }
            },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text("Cancel") } },
        )
    }
    unstarring?.let { e ->
        ConfirmDialog(
            title = "Remove star",
            message = "\"${e.name}\" will be removed from your starred files.",
            confirmLabel = "Remove",
            onDismiss = { unstarring = null },
            onConfirm = { unstarring = null; prefs.toggleFavourite(e) },
        )
    }
    removingRecent?.let { e ->
        ConfirmDialog(
            title = "Remove from recent",
            message = "\"${e.name}\" will be removed from the recent list. The file stays on your phone.",
            confirmLabel = "Remove",
            onDismiss = { removingRecent = null },
            onConfirm = { removingRecent = null; prefs.removeRecent(e.uri) },
        )
    }
    deleting?.let { e ->
        ConfirmDialog(
            title = "Delete file",
            message = "\"${e.name}\" will be deleted from this phone. This can't be undone.",
            confirmLabel = "Delete",
            onDismiss = { deleting = null },
            onConfirm = { deleting = null; scope.launch { deleteFile(ctx, prefs, e) } },
        )
    }
}

/** Name, type, size, pages, date and folder of a file, for the "Details" dialog. */
private suspend fun loadDetails(ctx: android.content.Context, e: DocEntry): List<Pair<String, String>> {
    val uri = Uri.parse(e.uri)
    val path = withContext(Dispatchers.IO) { DeviceFiles.pathOf(ctx, uri) }
    val f = path?.let { File(it) }?.takeIf { it.exists() }
    val size = withContext(Dispatchers.IO) { f?.length() ?: PdfTools.querySize(ctx, uri) }
    val kind = FileKind.of(e.name)
    val out = mutableListOf<Pair<String, String>>()
    out += "Name" to e.name
    out += "Type" to kind.label
    if (size > 0) out += "Size" to FileUtils.formatSize(size)
    if (kind == FileKind.PDF) {
        val pages = if (e.pageCount > 0) e.pageCount else runCatching { PdfTools.inspect(ctx, uri) }.getOrDefault(0)
        if (pages > 0) out += "Pages" to pages.toString()
    }
    if (f != null && f.lastModified() > 0) {
        out += "Modified" to DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(f.lastModified()))
    }
    if (e.lastOpened > 0) {
        out += "Last opened" to DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(e.lastOpened))
    }
    out += "Location" to (f?.parent ?: "On this phone")
    return out
}

/** Pins a shortcut to this file on the phone's home screen (the launcher asks the user to confirm). */
private fun addToHomeScreen(ctx: android.content.Context, e: DocEntry) {
    if (!ShortcutManagerCompat.isRequestPinShortcutSupported(ctx)) {
        FileUtils.toast(ctx, "Your launcher does not support home screen shortcuts")
        return
    }
    val open = Intent(ctx, MainActivity::class.java)
        .setAction(Intent.ACTION_VIEW)
        .setDataAndType(Uri.parse(e.uri), DeviceFiles.mimeOf(e.name))
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    val label = e.name.substringBeforeLast('.').ifBlank { e.name }.take(25)
    val info = ShortcutInfoCompat.Builder(ctx, "doxsy_" + e.uri.hashCode())
        .setShortLabel(label)
        .setLongLabel(e.name)
        .setIcon(IconCompat.createWithResource(ctx, R.mipmap.ic_launcher))
        .setIntent(open)
        .build()
    val ok = runCatching { ShortcutManagerCompat.requestPinShortcut(ctx, info, null) }.getOrDefault(false)
    FileUtils.toast(ctx, if (ok) "Confirm on your home screen to add the shortcut" else "Could not add the shortcut")
}

/** Uploads the file to the root of the connected Google Drive. Returns the message to show. */
private suspend fun uploadToDrive(ctx: android.content.Context, prefs: Prefs, e: DocEntry): String {
    val account = prefs.googleAccount.value.ifBlank { prefs.savedAccounts.value.firstOrNull().orEmpty() }
    if (account.isBlank()) return "Connect Google Drive first: Files > Google Drive"
    return try {
        val token = GoogleAuth.freshToken(ctx, account, false)
            ?: return "Connect Google Drive again: Files > Google Drive"
        val uri = Uri.parse(e.uri)
        withContext(Dispatchers.IO) {
            val size = PdfTools.querySize(ctx, uri)
            if (size > 50L * 1024 * 1024) error("Files over 50 MB can't be uploaded from here.")
            val bytes = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            val mime = ctx.contentResolver.getType(uri)?.takeIf { it.isNotBlank() } ?: DeviceFiles.mimeOf(e.name)
            DriveApi.upload(token, null, e.name, mime, bytes)
        }
        "Uploaded to Google Drive"
    } catch (ex: kotlinx.coroutines.CancellationException) {
        throw ex
    } catch (ex: Exception) {
        ex.message?.takeIf { it.isNotBlank() } ?: "Upload failed"
    }
}

private suspend fun renameFile(ctx: android.content.Context, prefs: Prefs, e: DocEntry, base: String) {
    val ext = e.name.substringAfterLast('.', "")
    val newName = if (ext.isEmpty()) base else "$base.$ext"
    val path = DeviceFiles.pathOf(ctx, Uri.parse(e.uri))
    val ok = withContext(Dispatchers.IO) {
        runCatching {
            val f = File(path ?: return@runCatching false)
            val target = File(f.parentFile, newName)
            if (target.exists()) false
            else f.renameTo(target).also { if (it) MediaScannerConnection.scanFile(ctx, arrayOf(f.absolutePath, target.absolutePath), null, null) }
        }.getOrDefault(false)
    }
    if (ok) {
        prefs.recents.value = prefs.recents.value.map { if (it.uri == e.uri) it.copy(name = newName) else it }
        prefs.favourites.value = prefs.favourites.value.map { if (it.uri == e.uri) it.copy(name = newName) else it }
        DeviceFiles.scan(ctx)
        FileUtils.toast(ctx, "Renamed")
    } else {
        FileUtils.toast(ctx, "Could not rename this file")
    }
}

private suspend fun deleteFile(ctx: android.content.Context, prefs: Prefs, e: DocEntry) {
    val uri = Uri.parse(e.uri)
    val path = DeviceFiles.pathOf(ctx, uri)
    val ok = withContext(Dispatchers.IO) {
        runCatching {
            val viaFile = path?.let { p ->
                File(p).delete().also { if (it) MediaScannerConnection.scanFile(ctx, arrayOf(p), null, null) }
            } ?: false
            viaFile || ctx.contentResolver.delete(uri, null, null) > 0
        }.getOrDefault(false)
    }
    if (ok) {
        prefs.removeRecent(e.uri)
        if (prefs.isFavourite(e.uri)) prefs.toggleFavourite(e)
        DeviceFiles.scan(ctx)
        FileUtils.toast(ctx, "Deleted")
    } else {
        FileUtils.toast(ctx, "Could not delete this file")
    }
}

@Composable
private fun SheetHeader(e: DocEntry) {
    val size by rememberDocSize(e.uri)
    val meta = listOfNotNull(
        FileKind.of(e.name).label,
        relativeTime(e.lastOpened).ifBlank { null },
        size?.let { FileUtils.formatSize(it) },
    ).joinToString(" • ")
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        PdfThumb(e.uri, e.name, Modifier.size(width = 36.dp, height = 46.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                e.name.substringBeforeLast('.'),
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(meta, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.width(6.dp))
                Icon(Icons.Rounded.PhoneAndroid, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(13.dp))
            }
        }
    }
}

@Composable
private fun MenuRow(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(18.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }
}
