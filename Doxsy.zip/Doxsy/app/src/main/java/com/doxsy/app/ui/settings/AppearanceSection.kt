package com.doxsy.app.ui.settings

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.SettingsBrightness
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.doxsy.app.data.Prefs
import com.doxsy.app.data.ThemeMode
import com.doxsy.app.ui.theme.AccentColors
import com.doxsy.app.ui.theme.AccentNames

/** Settings > Appearance: theme mode, colour palette, AMOLED black, Material You, text size and a live preview. */
@Composable
internal fun AppearanceGroup(prefs: Prefs) {
    val theme by prefs.themeMode.state.collectAsState()
    val accent by prefs.accent.state.collectAsState()
    val fontScale by prefs.fontScale.state.collectAsState()
    val amoled by prefs.amoled.state.collectAsState()
    val dynamic by prefs.dynamicColor.state.collectAsState()

    val systemDark = isSystemInDarkTheme()
    val dark = when (theme) {
        ThemeMode.SYSTEM -> systemDark
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val dynamicSupported = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    val dynamicOn = dynamic && dynamicSupported

    Group("Appearance") {
        ThemePreview()
        Divider()

        Column(Modifier.padding(16.dp)) {
            Text("Theme", style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(10.dp))
            ThemeModeSelector(theme) { prefs.themeMode.value = it }
        }
        Divider()

        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Colour palette", style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                Text(
                    if (dynamicOn) "Wallpaper" else AccentNames[accent.coerceIn(0, AccentNames.lastIndex)],
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Spacer(Modifier.height(12.dp))
            AccentColors.indices.chunked(4).forEach { rowIdx ->
                Row(Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                    rowIdx.forEach { i ->
                        AccentSwatch(
                            color = AccentColors[i],
                            name = AccentNames[i],
                            selected = i == accent && !dynamicOn,
                            enabled = !dynamicOn,
                            modifier = Modifier.weight(1f),
                        ) { prefs.accent.value = i }
                    }
                }
            }
        }
        Divider()

        if (dynamicSupported) {
            SwitchRow("Dynamic colour", "Use colours from your wallpaper (Material You)", dynamic) {
                prefs.dynamicColor.value = it
            }
            Divider()
        }
        SwitchRow(
            "Pure black dark theme",
            if (dark) "True black background, saves battery on OLED screens" else "Applies when the dark theme is on",
            amoled,
            enabled = dark,
        ) { prefs.amoled.value = it }
        Divider()

        Choice(
            "Text size",
            listOf("Small" to 0.9f, "Default" to 1f, "Large" to 1.15f),
            fontScale,
        ) { prefs.fontScale.value = it }
        Divider()

        ActionRow("Reset appearance", "Back to the default theme, colour and text size") {
            prefs.themeMode.value = ThemeMode.SYSTEM
            prefs.accent.value = 0
            prefs.fontScale.value = 1f
            prefs.amoled.value = false
            prefs.dynamicColor.value = false
        }
    }
}

/** Small mock of a document row + buttons, drawn with the current theme so the user sees the change at once. */
@Composable
private fun ThemePreview() {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier
            .padding(16.dp)
            .fillMaxWidth()
            .clip(shape)
            .background(cs.background)
            .border(1.dp, cs.outlineVariant, shape)
            .padding(14.dp),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(cs.surface)
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)).background(cs.primaryContainer),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.Description, null, tint = cs.primary, modifier = Modifier.size(22.dp)) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Annual report.pdf", style = MaterialTheme.typography.bodyMedium, color = cs.onSurface, fontWeight = FontWeight.Medium)
                Text("PDF  •  2.4 MB", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.clip(RoundedCornerShape(20.dp)).background(cs.primary).padding(horizontal = 18.dp, vertical = 8.dp),
            ) { Text("Open", color = cs.onPrimary, style = MaterialTheme.typography.labelLarge) }
            Box(
                Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.dp, cs.outline, RoundedCornerShape(20.dp))
                    .padding(horizontal = 18.dp, vertical = 8.dp),
            ) { Text("Share", color = cs.primary, style = MaterialTheme.typography.labelLarge) }
            Box(
                Modifier.clip(RoundedCornerShape(20.dp)).background(cs.primaryContainer).padding(horizontal = 14.dp, vertical = 8.dp),
            ) { Text("Starred", color = cs.onPrimaryContainer, style = MaterialTheme.typography.labelLarge) }
        }
    }
}

/** System / Light / Dark as one segmented control. */
@Composable
private fun ThemeModeSelector(selected: ThemeMode, onSelect: (ThemeMode) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val items = listOf(
        Triple("System", Icons.Rounded.SettingsBrightness, ThemeMode.SYSTEM),
        Triple("Light", Icons.Rounded.LightMode, ThemeMode.LIGHT),
        Triple("Dark", Icons.Rounded.DarkMode, ThemeMode.DARK),
    )
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(cs.surfaceVariant)
            .padding(4.dp),
    ) {
        items.forEach { (label, icon, mode) ->
            val sel = mode == selected
            Row(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(11.dp))
                    .background(if (sel) cs.surface else Color.Transparent)
                    .clickable { onSelect(mode) }
                    .padding(vertical = 10.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(icon, null, tint = if (sel) cs.primary else cs.onSurfaceVariant, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(
                    label,
                    style = MaterialTheme.typography.labelLarge,
                    color = if (sel) cs.primary else cs.onSurfaceVariant,
                    fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal,
                )
            }
        }
    }
}

@Composable
private fun AccentSwatch(
    color: Color,
    name: String,
    selected: Boolean,
    enabled: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Column(
        modifier.alpha(if (enabled) 1f else 0.4f).clickable(enabled = enabled, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .size(50.dp)
                .border(if (selected) 2.5.dp else 0.dp, if (selected) color else Color.Transparent, CircleShape)
                .padding(5.dp)
                .clip(CircleShape)
                .background(color),
            contentAlignment = Alignment.Center,
        ) {
            if (selected) Icon(Icons.Rounded.Check, "$name (selected)", tint = Color.White, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.height(4.dp))
        Text(
            name,
            style = MaterialTheme.typography.labelSmall,
            color = if (selected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            textAlign = TextAlign.Center,
            maxLines = 1,
        )
    }
}
