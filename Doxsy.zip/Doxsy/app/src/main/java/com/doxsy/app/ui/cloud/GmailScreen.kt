package com.doxsy.app.ui.cloud

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Email
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.doxsy.app.cloud.GmailApi
import com.doxsy.app.cloud.GoogleAuth
import com.doxsy.app.cloud.MailPdf
import com.doxsy.app.data.DocEntry
import com.doxsy.app.data.Prefs
import com.doxsy.app.ui.ConfirmDialog
import com.doxsy.app.fileman.DeviceFiles
import com.doxsy.app.ui.KindBadge
import com.doxsy.app.ui.MenuAction
import com.doxsy.app.ui.files.AccessPrompt
import com.doxsy.app.ui.files.rememberDeviceAccess
import com.doxsy.app.ui.home.DocListRow
import com.doxsy.app.util.FileKind
import com.doxsy.app.util.FileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** "PDFs from emails": PDF attachments from Gmail (after connecting) + PDFs saved on the phone. */
@Composable
fun GmailPdfsScreen(prefs: Prefs, onBack: () -> Unit, onOpenEntry: (DocEntry) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val account by prefs.googleAccount.state.collectAsState()
    val gmailOn by prefs.gmailOn.state.collectAsState()
    val favourites by prefs.favourites.state.collectAsState()
    var unstar by remember { mutableStateOf<DocEntry?>(null) }
    val local by DeviceFiles.emailFiles.collectAsState()
    val access = rememberDeviceAccess()
    val connect = rememberConnectState()

    var mails by remember { mutableStateOf<List<MailPdf>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var reload by remember { mutableIntStateOf(0) }
    var busyKey by remember { mutableStateOf<String?>(null) }
    val connected = account.isNotEmpty() && gmailOn

    BackHandler { onBack() }
    LaunchedEffect(access.granted) { DeviceFiles.scan(ctx) }
    LaunchedEffect(account, gmailOn, reload) {
        if (!connected) return@LaunchedEffect
        loading = true
        error = null
        mails = emptyList()
        try {
            val token = GoogleAuth.freshGmailToken(ctx, account)
            if (token == null) error = "Google needs you to connect again."
            else mails = withContext(Dispatchers.IO) { GmailApi.listPdfs(token) }
        } catch (e: Exception) {
            error = e.message ?: "Could not load Gmail."
        }
        loading = false
    }

    fun open(p: MailPdf) {
        if (busyKey != null) return
        busyKey = p.messageId + p.attachmentId
        scope.launch {
            try {
                val token = GoogleAuth.freshGmailToken(ctx, account) ?: throw IllegalStateException("Connect your account again.")
                val file = cloudCacheFile(ctx, p.messageId + "_" + p.attachmentId.takeLast(8), p.filename)
                withContext(Dispatchers.IO) { file.outputStream().use { GmailApi.downloadTo(token, p, it) } }
                onOpenEntry(cloudEntry(ctx, file, p.filename))
            } catch (e: Exception) {
                FileUtils.toast(ctx, e.message ?: "Could not open the attachment")
            }
            busyKey = null
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") }
        }
        Text(
            "PDFs from emails",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(start = 16.dp),
        )
        Text(
            if (connected) account else "Gmail",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 16.dp, bottom = 8.dp),
        )
        LazyColumn(Modifier.weight(1f)) {
            if (!connected) {
                item {
                    Column(
                        Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Icon(androidx.compose.ui.res.painterResource(com.doxsy.app.R.drawable.ic_gmail), null, tint = Color.Unspecified, modifier = Modifier.size(72.dp))
                        Spacer(Modifier.height(12.dp))
                        Text("See the PDFs sent to your Gmail", fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                        Text("Connect your Google account to open PDF attachments right here.", textAlign = TextAlign.Center)
                        Spacer(Modifier.height(14.dp))
                        Button(onClick = { prefs.gmailOn.value = true; connect.begin(forGmail = true) }) { Text("Add account") }
                    }
                }
            } else {
                item { SectionLabel("Gmail attachments") }
                when {
                    loading && mails.isEmpty() -> item {
                        Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                    }
                    error != null -> item {
                        Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(error ?: "", textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.error)
                            Spacer(Modifier.height(10.dp))
                            Button(onClick = { connect.begin(forGmail = true) }) { Text("Connect again") }
                        }
                    }
                    mails.isEmpty() -> item {
                        Text("No PDF attachments found in your recent emails.", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    else -> items(mails, key = { it.messageId + it.attachmentId }) { p ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { open(p) }
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            KindBadge(FileKind.PDF, size = 44)
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(p.filename, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    listOfNotNull(
                                        p.from.ifBlank { null },
                                        if (p.date > 0) FileUtils.formatDate(p.date) else null,
                                        if (p.size > 0) FileUtils.formatSize(p.size) else null,
                                    ).joinToString(" • "),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                            if (busyKey == p.messageId + p.attachmentId) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                        }
                    }
                }
            }

            item { SectionLabel("Saved on this phone") }
            when {
                !access.granted -> item { AccessPrompt("Allow access to find PDF attachments saved on this phone.", access.request) }
                local.isEmpty() -> item {
                    Text(
                        "No downloaded email PDFs found in Downloads, Gmail or Attachments folders.",
                        Modifier.padding(16.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                else -> items(local, key = { "l" + it.uri }) { e ->
                    val isStar = favourites.any { it.uri == e.uri }
                    DocListRow(
                        entry = e,
                        selecting = false,
                        selected = false,
                        onClick = { onOpenEntry(e) },
                        onLongClick = {},
                        menu = listOf(
                            MenuAction(if (isStar) "Remove star" else "Add star") { if (isStar) unstar = e else prefs.toggleFavourite(e) },
                            MenuAction("Share") { FileUtils.share(ctx, Uri.parse(e.uri), "application/pdf") },
                        ),
                    )
                }
            }
        }
    }
    unstar?.let { e ->
        ConfirmDialog(
            title = "Remove star",
            message = "\"${e.name}\" will be removed from your starred files.",
            confirmLabel = "Remove",
            onDismiss = { unstar = null },
            onConfirm = { unstar = null; prefs.toggleFavourite(e) },
        )
    }
    GoogleConnectHost(connect, prefs, onDone = { reload++ })
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 16.dp, top = 14.dp, bottom = 4.dp),
    )
}
