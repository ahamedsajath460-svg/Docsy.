package com.doxsy.app.ui.home

import android.content.Context
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.OpenableColumns
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.doxsy.app.util.FileKind
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

/** First-page thumbnails, rendered one at a time and kept in a small memory cache. */
object PdfThumbs {
    private val cache = object : LruCache<String, Bitmap>(16 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val gate = Semaphore(1)

    suspend fun load(ctx: Context, uri: String, widthPx: Int): Bitmap? {
        val key = "$uri@$widthPx"
        cache.get(key)?.let { return it }
        return withContext(Dispatchers.IO) {
            gate.withPermit {
                cache.get(key) ?: runCatching { render(ctx.applicationContext, uri, widthPx) }
                    .getOrNull()
                    ?.also { cache.put(key, it) }
            }
        }
    }

    private fun render(ctx: Context, uri: String, widthPx: Int): Bitmap? {
        val pfd = ctx.contentResolver.openFileDescriptor(Uri.parse(uri), "r") ?: return null
        try {
            val r = PdfRenderer(pfd)
            try {
                if (r.pageCount <= 0) return null
                val p = r.openPage(0)
                try {
                    val h = (widthPx * p.height.toFloat() / p.width.toFloat()).toInt().coerceAtLeast(1)
                    val bmp = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(android.graphics.Color.WHITE)
                    p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    return bmp
                } finally {
                    p.close()
                }
            } finally {
                r.close()
            }
        } finally {
            runCatching { pfd.close() }
        }
    }
}

@Composable
fun PdfThumb(uri: String, name: String, modifier: Modifier = Modifier, widthPx: Int = 200) {
    val kind = FileKind.of(name)
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, uri, widthPx) {
        value = if (kind == FileKind.PDF) PdfThumbs.load(ctx, uri, widthPx) else null
    }
    Box(
        modifier
            .clip(RoundedCornerShape(4.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        val b = bmp
        if (b != null) {
            Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        } else {
            Icon(
                kind.icon,
                null,
                tint = kind.color.copy(alpha = 0.7f),
                modifier = Modifier.size(22.dp),
            )
        }
    }
}

/** File size in bytes, read off the main thread; null while loading or when unknown. */
@Composable
fun rememberDocSize(uri: String): State<Long?> {
    val ctx = LocalContext.current
    return produceState<Long?>(null, uri) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                ctx.contentResolver.query(Uri.parse(uri), arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                    if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else null
                }
            }.getOrNull()
        }
    }
}
