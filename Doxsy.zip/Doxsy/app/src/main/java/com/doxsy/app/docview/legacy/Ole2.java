package com.doxsy.app.docview.legacy;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

/**
 * Minimal reader for OLE2 / Compound File Binary containers (the wrapper around .xls, .doc, .ppt
 * and password-protected OOXML files). Only top-level streams are exposed.
 */
public final class Ole2 {
    public static final int KIND_UNKNOWN = 0;
    public static final int KIND_XLS = 1;
    public static final int KIND_DOC = 2;
    public static final int KIND_PPT = 3;
    public static final int KIND_ENCRYPTED_OOXML = 4;

    private static final long MAX_FILE = 160L * 1024 * 1024;
    private static final int ENDOFCHAIN = -2;
    private static final int FREESECT = -1;

    private static final class Entry {
        String name;
        int type;
        int left;
        int right;
        int child;
        int start;
        long size;
    }

    private final byte[] data;
    private final int sectorSize;
    private final int miniSectorSize;
    private final int miniCutoff;
    private int[] fat;
    private int[] miniFat;
    private byte[] miniStream;
    private Entry root;
    private final Map<String, Entry> streams = new HashMap<>();

    public static boolean hasMagic(byte[] head, int n) {
        return n >= 8 && (head[0] & 0xFF) == 0xD0 && (head[1] & 0xFF) == 0xCF && (head[2] & 0xFF) == 0x11
                && (head[3] & 0xFF) == 0xE0 && (head[4] & 0xFF) == 0xA1 && (head[5] & 0xFF) == 0xB1
                && (head[6] & 0xFF) == 0x1A && (head[7] & 0xFF) == 0xE1;
    }

    /** Reads the whole stream (at most {@code MAX_FILE} bytes) into memory. */
    public static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream(64 * 1024);
        byte[] buf = new byte[64 * 1024];
        long total = 0;
        int n;
        while ((n = in.read(buf)) >= 0) {
            total += n;
            if (total > MAX_FILE) throw new IOException("File too large");
            out.write(buf, 0, n);
        }
        return out.toByteArray();
    }

    public static Ole2 open(byte[] bytes) throws LegacyException {
        try {
            return new Ole2(bytes);
        } catch (LegacyException e) {
            throw e;
        } catch (RuntimeException e) {
            throw new LegacyException("This file is damaged and cannot be opened.", false, e);
        }
    }

    private Ole2(byte[] d) throws LegacyException {
        this.data = d;
        if (d.length < 512 || !hasMagic(d, 8)) throw new LegacyException("This is not a valid Office file.");
        int sectorShift = u16(d, 0x1E);
        int miniShift = u16(d, 0x20);
        if (sectorShift < 7 || sectorShift > 16 || miniShift < 3 || miniShift > sectorShift) {
            throw new LegacyException("This file is damaged and cannot be opened.");
        }
        sectorSize = 1 << sectorShift;
        miniSectorSize = 1 << miniShift;
        miniCutoff = i32(d, 0x38);
        int numFat = i32(d, 0x2C);
        int firstDir = i32(d, 0x30);
        int firstMiniFat = i32(d, 0x3C);
        int numMiniFat = i32(d, 0x40);
        int firstDifat = i32(d, 0x44);
        int numDifat = i32(d, 0x48);

        // FAT sector list: 109 entries in the header, the rest in DIFAT sectors.
        ArrayList<Integer> fatSectors = new ArrayList<>();
        for (int i = 0; i < 109 && fatSectors.size() < numFat; i++) {
            int s = i32(d, 0x4C + i * 4);
            if (s >= 0) fatSectors.add(s);
        }
        int difat = firstDifat;
        int guard = 0;
        int perDifat = sectorSize / 4 - 1;
        while (difat >= 0 && guard++ < numDifat + 4 && fatSectors.size() < numFat) {
            int off = sectorOffset(difat);
            if (off < 0) break;
            for (int i = 0; i < perDifat && fatSectors.size() < numFat; i++) {
                int s = i32(d, off + i * 4);
                if (s >= 0) fatSectors.add(s);
            }
            difat = i32(d, off + perDifat * 4);
        }
        int per = sectorSize / 4;
        fat = new int[fatSectors.size() * per];
        for (int i = 0; i < fatSectors.size(); i++) {
            int off = sectorOffset(fatSectors.get(i));
            if (off < 0) {
                java.util.Arrays.fill(fat, i * per, (i + 1) * per, FREESECT);
                continue;
            }
            for (int j = 0; j < per; j++) fat[i * per + j] = i32(d, off + j * 4);
        }

        // Directory
        byte[] dir = readChain(firstDir, -1, false);
        int count = dir.length / 128;
        Entry[] entries = new Entry[count];
        for (int i = 0; i < count; i++) {
            int o = i * 128;
            int type = dir[o + 0x42] & 0xFF;
            if (type == 0) continue;
            Entry e = new Entry();
            int nameLen = Math.max(0, Math.min(64, u16(dir, o + 0x40)));
            e.name = nameLen >= 2 ? new String(dir, o, nameLen - 2, StandardCharsets.UTF_16LE) : "";
            e.type = type;
            e.left = i32(dir, o + 0x44);
            e.right = i32(dir, o + 0x48);
            e.child = i32(dir, o + 0x4C);
            e.start = i32(dir, o + 0x74);
            long lo = i32(dir, o + 0x78) & 0xFFFFFFFFL;
            e.size = sectorSize == 512 ? lo : lo | ((long) i32(dir, o + 0x7C) << 32);
            entries[i] = e;
        }
        if (count == 0 || entries[0] == null) throw new LegacyException("This file is damaged and cannot be opened.");
        root = entries[0];

        // Mini FAT + mini stream
        if (numMiniFat > 0 && firstMiniFat >= 0) {
            byte[] mf = readChain(firstMiniFat, -1, false);
            miniFat = new int[mf.length / 4];
            for (int i = 0; i < miniFat.length; i++) miniFat[i] = i32(mf, i * 4);
        } else {
            miniFat = new int[0];
        }
        miniStream = root.start >= 0 ? readChain(root.start, (int) Math.min(root.size, Integer.MAX_VALUE), false) : new byte[0];

        // Walk the red-black tree below the root to find top-level streams.
        HashSet<Integer> seen = new HashSet<>();
        ArrayList<Integer> stack = new ArrayList<>();
        if (root.child >= 0) stack.add(root.child);
        while (!stack.isEmpty()) {
            int idx = stack.remove(stack.size() - 1);
            if (idx < 0 || idx >= count || entries[idx] == null || !seen.add(idx)) continue;
            Entry e = entries[idx];
            if (e.type == 2) streams.putIfAbsent(e.name, e);
            if (e.left >= 0) stack.add(e.left);
            if (e.right >= 0) stack.add(e.right);
        }
    }

    public boolean has(String name) {
        return streams.containsKey(name);
    }

    /** Which application wrote this container, judged by the streams it holds. */
    public int kind() {
        if (has("EncryptedPackage") || has("EncryptionInfo")) return KIND_ENCRYPTED_OOXML;
        if (has("Workbook") || has("Book")) return KIND_XLS;
        if (has("WordDocument")) return KIND_DOC;
        if (has("PowerPoint Document")) return KIND_PPT;
        return KIND_UNKNOWN;
    }

    /** Returns the stream's bytes, or null when absent. */
    public byte[] stream(String name) {
        Entry e = streams.get(name);
        if (e == null) return null;
        int size = (int) Math.min(e.size, Integer.MAX_VALUE);
        if (e.size < miniCutoff) {
            return readMini(e.start, size);
        }
        return readChain(e.start, size, false);
    }

    private int sectorOffset(int sector) {
        long off = ((long) sector + 1) * sectorSize;
        if (sector < 0 || off >= data.length) return -1;
        return (int) off;
    }

    /** Follows a FAT chain. {@code size < 0} means "whole chain". */
    private byte[] readChain(int start, int size, boolean unused) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int s = start;
        int guard = 0;
        int maxSectors = fat == null ? 1 << 20 : fat.length + 1;
        while (s >= 0 && guard++ <= maxSectors) {
            int off = sectorOffset(s);
            if (off < 0) break;
            int len = Math.min(sectorSize, data.length - off);
            out.write(data, off, len);
            if (size >= 0 && out.size() >= size) break;
            if (fat == null || s >= fat.length) break;
            s = fat[s];
            if (s == ENDOFCHAIN) break;
        }
        byte[] r = out.toByteArray();
        if (size >= 0 && r.length > size) return java.util.Arrays.copyOf(r, size);
        return r;
    }

    private byte[] readMini(int start, int size) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int s = start;
        int guard = 0;
        while (s >= 0 && guard++ <= miniFat.length + 1) {
            long off = (long) s * miniSectorSize;
            if (off >= miniStream.length) break;
            int len = (int) Math.min(miniSectorSize, miniStream.length - off);
            out.write(miniStream, (int) off, len);
            if (out.size() >= size) break;
            if (s >= miniFat.length) break;
            s = miniFat[s];
            if (s == ENDOFCHAIN) break;
        }
        byte[] r = out.toByteArray();
        return r.length > size ? java.util.Arrays.copyOf(r, size) : r;
    }

    static int u16(byte[] b, int o) {
        return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8);
    }

    static int i32(byte[] b, int o) {
        return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8) | ((b[o + 2] & 0xFF) << 16) | ((b[o + 3] & 0xFF) << 24);
    }
}
