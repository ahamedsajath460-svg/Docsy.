package com.doxsy.app.docview

/**
 * Neutral document models produced by the readers (DocxReader / XlsxReader / PptxReader) and consumed by
 * BOTH the All Documents viewer and the PDF Conversion Center, so one parser serves both.
 */
class DocReadException(message: String, cause: Throwable? = null) : Exception(message, cause)

data class TextRun(
    val text: String,
    val bold: Boolean = false,
    val italic: Boolean = false,
    val underline: Boolean = false,
    val strike: Boolean = false,
    /** Font size in points; 0 = default for the context. */
    val sizePt: Float = 0f,
    /** ARGB colour; 0 = default text colour. */
    val color: Int = 0,
    val link: String? = null,
)

enum class Align { START, CENTER, END, JUSTIFY }

sealed interface Block

data class Para(
    val runs: List<TextRun>,
    /** 0 = body text, 1..6 = heading level. */
    val heading: Int = 0,
    val align: Align = Align.START,
    /** Bullet or number label such as "•" or "1." when the paragraph is a list item. */
    val bullet: String? = null,
    val indentLevel: Int = 0,
) : Block {
    val plain: String get() = runs.joinToString("") { it.text }
}

/** Raster image (already downscaled by the reader to a sane size). */
class ImageBlock(val bytes: ByteArray, val widthPt: Float, val heightPt: Float) : Block

/** rows -> cells -> blocks inside the cell. */
data class TableBlock(val rows: List<List<List<Block>>>) : Block

data object PageBreak : Block

/** [truncated] is true when the reader stopped early to protect memory (very large files). */
data class WordDoc(val title: String?, val blocks: List<Block>, val truncated: Boolean = false)

data class Sheet(
    val name: String,
    /** Formatted cell text; ragged rows allowed. */
    val rows: List<List<String>>,
    /** Suggested width per column in characters (may be shorter than the widest row). */
    val colWidthsChars: List<Float> = emptyList(),
    val truncated: Boolean = false,
)

data class Workbook(val sheets: List<Sheet>)

sealed interface SlideElement {
    /** Position and size as fractions (0..1) of the slide width / height. */
    val x: Float
    val y: Float
    val w: Float
    val h: Float
}

data class SlideText(
    override val x: Float, override val y: Float, override val w: Float, override val h: Float,
    val paras: List<Para>,
    val fill: Int? = null,
) : SlideElement

class SlideImage(
    override val x: Float, override val y: Float, override val w: Float, override val h: Float,
    val bytes: ByteArray,
) : SlideElement

data class SlideShape(
    override val x: Float, override val y: Float, override val w: Float, override val h: Float,
    val fill: Int?, val line: Int?, val ellipse: Boolean = false,
) : SlideElement

data class Slide(
    val index: Int,
    /** Slide aspect ratio, width / height (e.g. 16f/9f). */
    val aspect: Float,
    val background: Int?,
    val elements: List<SlideElement>,
    val notes: String? = null,
    /** Slide width in points (font sizes in [TextRun.sizePt] are relative to this). 960 = 13.33in widescreen, 720 = 10in. */
    val widthPt: Float = 960f,
)

data class Deck(val slides: List<Slide>)
