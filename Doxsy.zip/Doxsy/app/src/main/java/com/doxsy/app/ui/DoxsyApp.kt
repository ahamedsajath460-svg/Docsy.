package com.doxsy.app.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.IconButton
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.runtime.collectAsState
import kotlinx.coroutines.delay
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.activity.compose.BackHandler
import com.doxsy.app.util.findActivity
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.NavHost
import com.doxsy.app.ui.sign.PdfSignatureScreen
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.doxsy.app.data.DocEntry
import com.doxsy.app.data.Prefs
import com.doxsy.app.ui.account.AccountScreen
import com.doxsy.app.ui.onboarding.OnboardingScreen
import com.doxsy.app.ui.search.SearchScreen
import com.doxsy.app.ui.files.FilesHubScreen
import com.doxsy.app.ui.files.FilesState
import com.doxsy.app.ui.home.HomeScreen
import com.doxsy.app.ui.settings.SettingsScreen
import com.doxsy.app.ui.viewer.ViewerScreen
import com.doxsy.app.fileman.DeviceFiles
import com.doxsy.app.util.DocFormat
import com.doxsy.app.docview.DocRecents
import com.doxsy.app.ui.docview.DocViewerScreen
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.doxsy.app.util.FileUtils

private data class Tab(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

private val Tabs = listOf(
    Tab("Home", Icons.Rounded.Home),
    Tab("Files", Icons.Rounded.FolderOpen),
    Tab("Search", Icons.Rounded.Search),
)

@Composable
fun DoxsyApp(prefs: Prefs, incoming: Uri?, onIncomingConsumed: () -> Unit) {
    val onboarded by prefs.onboarded.state.collectAsState()
    var showSplash by rememberSaveable { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        delay(600)
        showSplash = false
    }
    Box(Modifier.fillMaxSize()) {
        if (onboarded) DoxsyAppContent(prefs, incoming, onIncomingConsumed)
        else OnboardingScreen(onFinished = { prefs.onboarded.value = true })
        AnimatedVisibility(
            visible = showSplash,
            enter = EnterTransition.None,
            exit = fadeOut(tween(150)),
        ) { SplashOverlay() }
    }
}

@Composable
private fun DoxsyAppContent(prefs: Prefs, incoming: Uri?, onIncomingConsumed: () -> Unit) {
    val ctx = LocalContext.current
    val nav = rememberNavController()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var viewerUri by rememberSaveable { mutableStateOf<String?>(null) }
    var signUri by rememberSaveable { mutableStateOf<String?>(null) }
    val filesState = rememberSaveable(saver = FilesState.Saver) { FilesState() }

    var docUri by rememberSaveable { mutableStateOf<String?>(null) }
    var docName by rememberSaveable { mutableStateOf("") }
    var docFormat by rememberSaveable { mutableStateOf(DocFormat.UNKNOWN.name) }
    val appScope = rememberCoroutineScope()

    /** Opens any file: PDFs in the PDF viewer, other documents in Doxsy's document viewer, the rest in another app. */
    fun openDocument(uri: Uri, nameHint: String? = null) {
        appScope.launch {
            val name = nameHint ?: withContext(Dispatchers.IO) { FileUtils.displayName(ctx, uri) }
            val fmt = withContext(Dispatchers.IO) {
                runCatching { DocFormat.detect(ctx, uri, name) }.getOrDefault(DocFormat.UNKNOWN)
            }
            when {
                fmt == DocFormat.PDF -> {
                    viewerUri = uri.toString()
                    nav.navigate("viewer") { launchSingleTop = true }
                }
                fmt.inApp -> {
                    DocRecents.add(ctx, uri, name, fmt)
                    prefs.addRecent(uri.toString(), name, 0)
                    docUri = uri.toString()
                    docName = name
                    docFormat = fmt.name
                    nav.navigate("docviewer") { launchSingleTop = true }
                }
                else -> {
                    prefs.addRecent(uri.toString(), name, 0)
                    FileUtils.viewExternal(ctx, uri, DeviceFiles.mimeOf(name))
                }
            }
        }
    }

    fun openEntry(e: DocEntry) = openDocument(Uri.parse(e.uri), e.name)

    val pickPdf = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            openDocument(uri)
        }
    }

    LaunchedEffect(incoming) {
        if (incoming != null) {
            openDocument(incoming)
            onIncomingConsumed()
        }
    }

    NavHost(
        nav,
        startDestination = "main",
        modifier = Modifier.fillMaxSize(),
        // quick page changes (the default fade is 700 ms)
        enterTransition = { fadeIn(tween(120)) },
        exitTransition = { fadeOut(tween(90)) },
        popEnterTransition = { fadeIn(tween(120)) },
        popExitTransition = { fadeOut(tween(90)) },
    ) {
        composable("main") {
            // Back: other tabs -> Home; on Home press Back twice quickly to close the app.
            var lastBack by remember { mutableLongStateOf(0L) }
            BackHandler {
                if (tab != 0) {
                    tab = 0
                } else {
                    val now = System.currentTimeMillis()
                    if (now - lastBack < 2000) {
                        ctx.findActivity()?.finish()
                    } else {
                        lastBack = now
                        FileUtils.toast(ctx, "Press back again to exit")
                    }
                }
            }
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                bottomBar = {
                    NavigationBar {
                        Tabs.forEachIndexed { i, t ->
                            NavigationBarItem(
                                selected = tab == i,
                                onClick = { tab = i },
                                icon = { Icon(t.icon, contentDescription = t.label) },
                                label = { Text(t.label) },
                                colors = NavigationBarItemDefaults.colors(
                                    indicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                                    selectedIconColor = MaterialTheme.colorScheme.primary,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                ),
                            )
                        }
                    }
                },
            ) { padding ->
                val content = Modifier
                    .fillMaxSize()
                    .padding(padding)
                androidx.compose.foundation.layout.Box(content) {
                    when (tab) {
                        0 -> HomeScreen(
                            prefs = prefs,
                            onPickPdf = { pickPdf.launch(arrayOf("*/*")) },
                            onOpen = { e: DocEntry -> openEntry(e) },
                            onOpenSettings = { nav.navigate("account") { launchSingleTop = true } },
                            onOpenAi = { nav.navigate("ai") { launchSingleTop = true } },
                            onNewText = { nav.navigate("newtext") { launchSingleTop = true } },
                            onPickDocuments = {
                                pickPdf.launch(
                                    arrayOf(
                                        "application/pdf",
                                        "application/msword",
                                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                        "application/vnd.ms-excel",
                                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                        "application/vnd.ms-powerpoint",
                                        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                                        "application/rtf",
                                        "application/vnd.oasis.opendocument.text",
                                        "application/vnd.oasis.opendocument.spreadsheet",
                                        "application/vnd.oasis.opendocument.presentation",
                                        "text/*",
                                    ),
                                )
                            },
                        )
                        1 -> FilesHubScreen(
                            prefs = prefs,
                            state = filesState,
                            onOpenSettings = { nav.navigate("account") { launchSingleTop = true } },
                            onOpenPdf = { openDocument(it) },
                            onOpenEntry = { e -> openEntry(e) },
                        )
                        else -> SearchScreen(prefs, onOpen = { e -> openEntry(e) })
                    }
                }
            }
        }
        composable("ai") {
            com.doxsy.app.ui.ai.AiChatScreen(onBack = { nav.popBackStack() })
        }
        composable("account") {
            Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
                Box(Modifier.fillMaxSize().padding(padding)) {
                    AccountScreen(
                        prefs,
                        onBack = { nav.popBackStack() },
                        onOpenSettings = { nav.navigate("settings") { launchSingleTop = true } },
                    )
                }
            }
        }
        composable("settings") {
            Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
                Column(Modifier.fillMaxSize().padding(padding)) {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                    Box(Modifier.weight(1f)) { SettingsScreen(prefs) }
                }
            }
        }
        composable("newtext") {
            com.doxsy.app.ui.create.NewTextScreen(
                onBack = { nav.popBackStack() },
                onSaved = { saved ->
                    nav.popBackStack()
                    openDocument(saved)
                },
            )
        }
        composable("docviewer") {
            val u = docUri
            if (u == null) {
                LaunchedEffect(Unit) { nav.popBackStack() }
            } else {
                DocViewerScreen(
                    uri = Uri.parse(u),
                    format = runCatching { DocFormat.valueOf(docFormat) }.getOrDefault(DocFormat.UNKNOWN),
                    name = docName,
                    onBack = { nav.popBackStack() },
                )
            }
        }
        composable("viewer") {
            val u = viewerUri
            if (u == null) {
                LaunchedEffect(Unit) { nav.popBackStack() }
            } else {
                ViewerScreen(
                    prefs, Uri.parse(u),
                    onBack = { nav.popBackStack() },
                    onOpenPdf = { openDocument(it) },
                    onSign = { signUri = it.toString(); nav.navigate("sign") { launchSingleTop = true } },
                )
            }
        }
        composable("sign") {
            val u = signUri
            if (u == null) {
                LaunchedEffect(Unit) { nav.popBackStack() }
            } else {
                PdfSignatureScreen(prefs, Uri.parse(u), onBack = { nav.popBackStack() }, onOpenPdf = { openDocument(it) })
            }
        }
    }
}
