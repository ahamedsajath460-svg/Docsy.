package com.doxsy.app.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.IconButton
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.runtime.collectAsState
import kotlinx.coroutines.delay
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.doxsy.app.data.DocEntry
import com.doxsy.app.data.Prefs
import com.doxsy.app.ui.account.AccountScreen
import com.doxsy.app.ui.onboarding.OnboardingScreen
import com.doxsy.app.ui.search.SearchScreen
import com.doxsy.app.ui.files.FilesHubScreen
import com.doxsy.app.ui.files.FilesState
import com.doxsy.app.ui.home.HomeScreen
import com.doxsy.app.ui.settings.SettingsScreen
import com.doxsy.app.ui.tools.ToolsScreen
import com.doxsy.app.ui.viewer.ViewerScreen
import com.doxsy.app.fileman.DeviceFiles
import com.doxsy.app.util.FileKind
import com.doxsy.app.util.FileUtils

private data class Tab(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

private val Tabs = listOf(
    Tab("Home", Icons.Rounded.Home),
    Tab("Files", Icons.Rounded.FolderOpen),
    Tab("Search", Icons.Rounded.Search),
    Tab("Tools", Icons.Rounded.Build),
)

@Composable
fun DoxsyApp(prefs: Prefs, incoming: Uri?, onIncomingConsumed: () -> Unit) {
    val onboarded by prefs.onboarded.state.collectAsState()
    var showSplash by rememberSaveable { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        delay(1200)
        showSplash = false
    }
    Box(Modifier.fillMaxSize()) {
        if (onboarded) DoxsyAppContent(prefs, incoming, onIncomingConsumed)
        else OnboardingScreen(onFinished = { prefs.onboarded.value = true })
        AnimatedVisibility(
            visible = showSplash,
            enter = EnterTransition.None,
            exit = fadeOut(tween(300)),
        ) { SplashOverlay() }
    }
}

@Composable
private fun DoxsyAppContent(prefs: Prefs, incoming: Uri?, onIncomingConsumed: () -> Unit) {
    val ctx = LocalContext.current
    val nav = rememberNavController()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var viewerUri by rememberSaveable { mutableStateOf<String?>(null) }
    val filesState = remember { FilesState() }

    fun openDocument(uri: Uri) {
        viewerUri = uri.toString()
        nav.navigate("viewer") { launchSingleTop = true }
    }

    fun openEntry(e: DocEntry) {
        val u = Uri.parse(e.uri)
        if (FileKind.of(e.name) == FileKind.PDF) {
            openDocument(u)
        } else {
            prefs.addRecent(e.uri, e.name, 0)
            FileUtils.viewExternal(ctx, u, DeviceFiles.mimeOf(e.name))
        }
    }

    val pickPdf = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            openDocument(uri)
        }
    }

    LaunchedEffect(incoming) {
        if (incoming != null) {
            openDocument(incoming)
            onIncomingConsumed()
        }
    }

    NavHost(nav, startDestination = "main", modifier = Modifier.fillMaxSize()) {
        composable("main") {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                bottomBar = {
                    NavigationBar {
                        Tabs.forEachIndexed { i, t ->
                            NavigationBarItem(
                                selected = tab == i,
                                onClick = { tab = i },
                                icon = { Icon(t.icon, contentDescription = t.label) },
                                label = { Text(t.label) },
                                colors = NavigationBarItemDefaults.colors(
                                    indicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                                    selectedIconColor = MaterialTheme.colorScheme.primary,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                ),
                            )
                        }
                    }
                },
            ) { padding ->
                val content = Modifier
                    .fillMaxSize()
                    .padding(padding)
                androidx.compose.foundation.layout.Box(content) {
                    when (tab) {
                        0 -> HomeScreen(
                            prefs = prefs,
                            onPickPdf = { pickPdf.launch(arrayOf("application/pdf")) },
                            onOpen = { e: DocEntry -> openEntry(e) },
                            onOpenSettings = { nav.navigate("account") { launchSingleTop = true } },
                            onOpenTools = { tab = 3 },
                        )
                        1 -> FilesHubScreen(
                            prefs = prefs,
                            state = filesState,
                            onOpenSettings = { nav.navigate("account") { launchSingleTop = true } },
                            onOpenPdf = { openDocument(it) },
                            onOpenEntry = { e -> openEntry(e) },
                        )
                        2 -> SearchScreen(prefs, onOpen = { e -> openEntry(e) })
                        else -> ToolsScreen(onOpenPdf = { openDocument(it) })
                    }
                }
            }
        }
        composable("account") {
            Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
                Box(Modifier.fillMaxSize().padding(padding)) {
                    AccountScreen(
                        prefs,
                        onBack = { nav.popBackStack() },
                        onOpenSettings = { nav.navigate("settings") { launchSingleTop = true } },
                    )
                }
            }
        }
        composable("settings") {
            Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
                Column(Modifier.fillMaxSize().padding(padding)) {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                    Box(Modifier.weight(1f)) { SettingsScreen(prefs) }
                }
            }
        }
        composable("viewer") {
            val u = viewerUri
            if (u == null) {
                LaunchedEffect(Unit) { nav.popBackStack() }
            } else {
                ViewerScreen(prefs, Uri.parse(u), onBack = { nav.popBackStack() })
            }
        }
    }
}
