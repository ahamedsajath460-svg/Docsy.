package com.doxsy.app.docview

import android.content.Context
import android.net.Uri
import org.xmlpull.v1.XmlPullParser

/** Lightweight streaming reader for .docx (WordprocessingML). Not a full Word engine: see viewer limitations. */
object DocxReader {
    private const val MAX_BLOCKS = 25_000
    private const val MAX_CHARS = 4_000_000
    private const val MAX_IMAGE_BYTES = 60L * 1024 * 1024

    fun read(ctx: Context, uri: Uri): WordDoc {
        try {
            // Old binary .doc (or a .docx that is really one) is read by the legacy reader.
            LegacyOffice.open(ctx, uri)?.let { return LegacyOffice.word(it) }
            OoxmlPackage.open(ctx, uri, "Word").use { pkg ->
                if (!pkg.has("word/document.xml")) {
                    throw DocReadException("This is not a valid Word document (word/document.xml is missing).")
                }
                val st = State(pkg, readStyles(pkg), readNumbering(pkg), pkg.rels("word/document.xml"))
                val blocks = ArrayList<Block>()
                val stream = pkg.open("word/document.xml")
                    ?: throw DocReadException("This Word document has no readable content.")
                stream.use { s -> st.parseBlocks(newParser(s), null, blocks) }
                return WordDoc(readTitle(pkg), blocks, st.truncated)
            }
        } catch (e: DocReadException) {
            throw e
        } catch (e: OutOfMemoryError) {
            throw DocReadException("Not enough memory to open this document.", e)
        } catch (e: Exception) {
            throw DocReadException("This Word document could not be read. It may be corrupted.", e)
        }
    }

    // ---------- run properties & styles ----------

    private data class RunProps(
        var bold: Boolean? = null,
        var italic: Boolean? = null,
        var underline: Boolean? = null,
        var strike: Boolean? = null,
        var sizePt: Float? = null,
        var color: Int? = null,
    ) {
        fun overlay(o: RunProps) {
            o.bold?.let { bold = it }
            o.italic?.let { italic = it }
            o.underline?.let { underline = it }
            o.strike?.let { strike = it }
            o.sizePt?.let { sizePt = it }
            o.color?.let { color = it }
        }
    }

    private class StyleInfo(val id: String) {
        var name: String = ""
        var basedOn: String? = null
        val props = RunProps()
        var align: Align? = null
        var outline: Int = -1
    }

    private fun alignOf(v: String?): Align? = when (v) {
        "center" -> Align.CENTER
        "right", "end" -> Align.END
        "both", "distribute", "justify" -> Align.JUSTIFY
        "left", "start" -> Align.START
        else -> null
    }

    private fun applyRunProp(p: XmlPullParser, props: RunProps) {
        when (p.ln()) {
            "b" -> props.bold = p.on()
            "i" -> props.italic = p.on()
            "u" -> props.underline = p.attr("val") != "none"
            "strike", "dstrike" -> props.strike = p.on()
            "sz" -> p.attr("val")?.toFloatOrNull()?.let { if (it > 0f) props.sizePt = it / 2f }
            "color" -> parseHexColor(p.attr("val"))?.let { props.color = it }
        }
    }

    private fun readStyles(pkg: OoxmlPackage): Map<String, StyleInfo> {
        val out = HashMap<String, StyleInfo>()
        val s = pkg.open("word/styles.xml") ?: return out
        s.use { input ->
            val p = newParser(input)
            var cur: StyleInfo? = null
            var inR = false
            var inP = false
            while (true) {
                val ev = p.next()
                if (ev == XmlPullParser.END_DOCUMENT) break
                if (ev == XmlPullParser.START_TAG) {
                    when (p.ln()) {
                        "style" -> {
                            val id = p.attr("styleId")
                            cur = if (id != null && p.attr("type") == "paragraph") StyleInfo(id).also { out[id] = it } else null
                        }
                        "name" -> if (!inP && !inR) cur?.name = p.attr("val") ?: ""
                        "basedOn" -> cur?.basedOn = p.attr("val")
                        "rPr" -> if (!inP) inR = true
                        "pPr" -> inP = true
                        "jc" -> if (inP) cur?.align = alignOf(p.attr("val"))
                        "outlineLvl" -> if (inP) cur?.outline = p.attr("val")?.toIntOrNull() ?: -1
                        "b", "i", "u", "strike", "dstrike", "sz", "color" -> if (inR) cur?.let { applyRunProp(p, it.props) }
                    }
                } else if (ev == XmlPullParser.END_TAG) {
                    when (p.ln()) {
                        "rPr" -> inR = false
                        "pPr" -> inP = false
                        "style" -> cur = null
                    }
                }
            }
        }
        return out
    }

    private fun headingOf(styles: Map<String, StyleInfo>, id: String?): Int {
        var cur = id?.let { styles[it] }
        var depth = 0
        while (cur != null && depth < 8) {
            val n = cur.name.lowercase()
            if (n.startsWith("heading ")) return n.removePrefix("heading ").trim().toIntOrNull()?.coerceIn(1, 6) ?: 1
            if (n == "title") return 1
            if (n == "subtitle") return 2
            if (cur.outline in 0..5) return cur.outline + 1
            cur = cur.basedOn?.let { styles[it] }
            depth++
        }
        return 0
    }

    private fun styleProps(styles: Map<String, StyleInfo>, id: String?): RunProps {
        val chain = ArrayList<StyleInfo>()
        var cur = id?.let { styles[it] }
        while (cur != null && chain.size < 8) {
            chain.add(cur)
            cur = cur.basedOn?.let { styles[it] }
        }
        val out = RunProps()
        for (s in chain.asReversed()) out.overlay(s.props)
        return out
    }

    private fun styleAlign(styles: Map<String, StyleInfo>, id: String?): Align? {
        var cur = id?.let { styles[it] }
        var d = 0
        while (cur != null && d < 8) {
            cur.align?.let { return it }
            cur = cur.basedOn?.let { styles[it] }
            d++
        }
        return null
    }

    // ---------- numbering ----------

    private class Lvl(val fmt: String)

    private class Numbering(
        val abstracts: Map<String, Map<Int, Lvl>>,
        val nums: Map<String, String>,
    )

    private fun readNumbering(pkg: OoxmlPackage): Numbering {
        val abs = HashMap<String, HashMap<Int, Lvl>>()
        val nums = HashMap<String, String>()
        val s = pkg.open("word/numbering.xml") ?: return Numbering(abs, nums)
        s.use { input ->
            val p = newParser(input)
            var curAbs: String? = null
            var curLvl = 0
            var curNum: String? = null
            while (true) {
                val ev = p.next()
                if (ev == XmlPullParser.END_DOCUMENT) break
                if (ev == XmlPullParser.START_TAG) {
                    when (p.ln()) {
                        "abstractNum" -> curAbs = p.attr("abstractNumId")
                        "lvl" -> curLvl = p.attr("ilvl")?.toIntOrNull() ?: 0
                        "numFmt" -> curAbs?.let { a ->
                            abs.getOrPut(a) { HashMap() }[curLvl] = Lvl(p.attr("val") ?: "decimal")
                        }
                        "num" -> curNum = p.attr("numId")
                        "abstractNumId" -> curNum?.let { n -> p.attr("val")?.let { nums[n] = it } }
                    }
                } else if (ev == XmlPullParser.END_TAG) {
                    when (p.ln()) {
                        "abstractNum" -> curAbs = null
                        "num" -> curNum = null
                    }
                }
            }
        }
        return Numbering(abs, nums)
    }

    private fun roman(n: Int): String {
        val v = intArrayOf(1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1)
        val s = arrayOf("M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I")
        var x = n.coerceIn(1, 3999)
        val sb = StringBuilder()
        for (i in v.indices) while (x >= v[i]) { sb.append(s[i]); x -= v[i] }
        return sb.toString()
    }

    private fun letters(n: Int): String {
        var x = n.coerceAtLeast(1)
        val sb = StringBuilder()
        while (x > 0) {
            x--
            sb.insert(0, ('a' + x % 26))
            x /= 26
        }
        return sb.toString()
    }

    private fun readTitle(pkg: OoxmlPackage): String? {
        val s = pkg.open("docProps/core.xml") ?: return null
        return runCatching {
            s.use { input ->
                val p = newParser(input)
                var res: String? = null
                while (true) {
                    val ev = p.next()
                    if (ev == XmlPullParser.END_DOCUMENT) break
                    if (ev == XmlPullParser.START_TAG && p.ln() == "title") {
                        res = p.nextText()?.trim()?.ifBlank { null }
                        break
                    }
                }
                res
            }
        }.getOrNull()
    }

    // ---------- document body ----------

    private class State(
        val pkg: OoxmlPackage,
        val styles: Map<String, StyleInfo>,
        val numbering: Numbering,
        val rels: Map<String, Rel>,
    ) {
        var truncated = false
        private var count = 0
        private var chars = 0L
        private var imageBytes = 0L
        private val counters = HashMap<String, IntArray>()

        private fun overLimit(): Boolean {
            if (count > MAX_BLOCKS || chars > MAX_CHARS) truncated = true
            return truncated
        }

        fun parseBlocks(p: XmlPullParser, endTag: String?, out: MutableList<Block>) {
            while (true) {
                if (overLimit()) return
                val ev = p.next()
                if (ev == XmlPullParser.END_DOCUMENT) return
                if (ev == XmlPullParser.END_TAG) {
                    if (endTag != null && p.ln() == endTag) return
                    continue
                }
                if (ev != XmlPullParser.START_TAG) continue
                when (p.ln()) {
                    "p" -> parsePara(p, out)
                    "tbl" -> {
                        out.add(parseTable(p))
                        count++
                    }
                    "Fallback", "sectPr" -> p.skipTree()
                }
            }
        }

        private fun parseTable(p: XmlPullParser): TableBlock {
            val rows = ArrayList<List<List<Block>>>()
            while (true) {
                if (overLimit()) break
                val ev = p.next()
                if (ev == XmlPullParser.END_DOCUMENT) break
                if (ev == XmlPullParser.END_TAG) {
                    if (p.ln() == "tbl") break
                    continue
                }
                if (ev != XmlPullParser.START_TAG) continue
                when (p.ln()) {
                    "tr" -> rows.add(parseRow(p))
                    "tblPr", "tblGrid" -> p.skipTree()
                }
            }
            return TableBlock(rows)
        }

        private fun parseRow(p: XmlPullParser): List<List<Block>> {
            val cells = ArrayList<List<Block>>()
            while (true) {
                if (overLimit()) break
                val ev = p.next()
                if (ev == XmlPullParser.END_DOCUMENT) break
                if (ev == XmlPullParser.END_TAG) {
                    if (p.ln() == "tr") break
                    continue
                }
                if (ev != XmlPullParser.START_TAG) continue
                when (p.ln()) {
                    "tc" -> {
                        val b = ArrayList<Block>()
                        parseBlocks(p, "tc", b)
                        cells.add(b)
                    }
                    "trPr" -> p.skipTree()
                }
            }
            return cells
        }

        private fun listLabel(numId: String, ilvl: Int): String {
            val absId = numbering.nums[numId]
            val fmt = absId?.let { numbering.abstracts[it]?.get(ilvl)?.fmt } ?: "bullet"
            if (fmt == "bullet" || fmt == "none") return if (ilvl == 0) "•" else if (ilvl == 1) "◦" else "▪"
            val c = counters.getOrPut(numId) { IntArray(10) }
            val lv = ilvl.coerceIn(0, 9)
            c[lv]++
            for (k in lv + 1 until 10) c[k] = 0
            val n = c[lv]
            return when (fmt) {
                "lowerLetter" -> letters(n) + "."
                "upperLetter" -> letters(n).uppercase() + "."
                "lowerRoman" -> roman(n).lowercase() + "."
                "upperRoman" -> roman(n) + "."
                else -> "$n."
            }
        }

        private fun parsePara(p: XmlPullParser, out: MutableList<Block>) {
            var styleId: String? = null
            var align: Align? = null
            var numId: String? = null
            var ilvl = 0
            var indLeft = 0
            var link: String? = null
            var base: RunProps? = null
            val runs = ArrayList<TextRun>()
            val images = ArrayList<ImageBlock>()
            var breakAfter = false
            loop@ while (true) {
                val ev = p.next()
                if (ev == XmlPullParser.END_DOCUMENT) break
                if (ev == XmlPullParser.END_TAG) {
                    when (p.ln()) {
                        "p" -> break@loop
                        "hyperlink" -> link = null
                    }
                    continue
                }
                if (ev != XmlPullParser.START_TAG) continue
                when (p.ln()) {
                    "pStyle" -> styleId = p.attr("val")
                    "jc" -> align = alignOf(p.attr("val"))
                    "ilvl" -> ilvl = p.attr("val")?.toIntOrNull() ?: 0
                    "numId" -> numId = p.attr("val")
                    "ind" -> indLeft = (p.attr("left") ?: p.attr("start"))?.toIntOrNull() ?: 0
                    "rPr", "sectPr", "Fallback", "txbxContent" -> p.skipTree()
                    "hyperlink" -> {
                        val id = p.attr("id")
                        link = if (id != null) rels[id]?.takeIf { it.external }?.target else null
                    }
                    "r" -> {
                        val b = base ?: styleProps(styles, styleId).also { base = it }
                        if (parseRun(p, b, link, runs, images)) breakAfter = true
                    }
                }
            }
            val heading = headingOf(styles, styleId)
            val finalAlign = align ?: styleAlign(styles, styleId) ?: Align.START
            val label = numId?.takeIf { it != "0" }?.let { listLabel(it, ilvl) }
            val indent = if (label != null) ilvl else (indLeft / 720).coerceIn(0, 6)
            if (runs.isNotEmpty() || images.isEmpty()) {
                out.add(Para(runs, heading, finalAlign, label, indent))
                count++
            }
            for (img in images) {
                out.add(img)
                count++
            }
            if (breakAfter) out.add(PageBreak)
        }

        /** Returns true if the run contains a page break. */
        private fun parseRun(
            p: XmlPullParser,
            base: RunProps,
            link: String?,
            runs: MutableList<TextRun>,
            images: MutableList<ImageBlock>,
        ): Boolean {
            val props = base.copy()
            val sb = StringBuilder()
            var pageBreak = false
            while (true) {
                val ev = p.next()
                if (ev == XmlPullParser.END_DOCUMENT) break
                if (ev == XmlPullParser.END_TAG) {
                    if (p.ln() == "r") break
                    continue
                }
                if (ev != XmlPullParser.START_TAG) continue
                when (p.ln()) {
                    "rPr" -> readRunProps(p, props)
                    "t" -> sb.append(p.nextText())
                    "tab" -> sb.append('\t')
                    "br" -> {
                        if (p.attr("type") == "page") pageBreak = true else sb.append('\n')
                    }
                    "cr" -> sb.append('\n')
                    "noBreakHyphen" -> sb.append('-')
                    "drawing", "pict" -> readDrawing(p, p.ln())?.let { images.add(it) }
                    "Fallback", "txbxContent" -> p.skipTree()
                }
            }
            if (sb.isNotEmpty()) {
                chars += sb.length
                runs.add(
                    TextRun(
                        text = sb.toString(),
                        bold = props.bold == true,
                        italic = props.italic == true,
                        underline = props.underline == true,
                        strike = props.strike == true,
                        sizePt = props.sizePt ?: 0f,
                        color = props.color ?: 0,
                        link = link,
                    ),
                )
            }
            return pageBreak
        }

        private fun readRunProps(p: XmlPullParser, props: RunProps) {
            while (true) {
                val ev = p.next()
                if (ev == XmlPullParser.END_DOCUMENT) return
                if (ev == XmlPullParser.END_TAG) {
                    if (p.ln() == "rPr") return
                    continue
                }
                if (ev != XmlPullParser.START_TAG) continue
                if (p.ln() == "rPrChange") p.skipTree() else applyRunProp(p, props)
            }
        }

        private fun readDrawing(p: XmlPullParser, endName: String): ImageBlock? {
            var cx = 0L
            var cy = 0L
            var gotExtent = false
            var embed: String? = null
            while (true) {
                val ev = p.next()
                if (ev == XmlPullParser.END_DOCUMENT) break
                if (ev == XmlPullParser.END_TAG) {
                    if (p.ln() == endName) break
                    continue
                }
                if (ev != XmlPullParser.START_TAG) continue
                when (p.ln()) {
                    "extent" -> if (!gotExtent) {
                        cx = p.attr("cx")?.toLongOrNull() ?: 0L
                        cy = p.attr("cy")?.toLongOrNull() ?: 0L
                        gotExtent = true
                    }
                    "blip" -> if (embed == null) embed = p.attr("embed")
                    "imagedata" -> if (embed == null) embed = p.attr("id")
                    "txbxContent", "Fallback" -> p.skipTree()
                }
            }
            val id = embed ?: return null
            val rel = rels[id] ?: return null
            if (rel.external || imageBytes > MAX_IMAGE_BYTES) return null
            val bytes = pkg.readBytes(rel.target, 8 * 1024 * 1024) ?: return null
            val img = runCatching { downscaleImage(bytes) }.getOrNull() ?: return null
            imageBytes += img.bytes.size
            var w = if (cx > 0) cx / 12700f else img.width * 0.75f
            var h = if (cy > 0) cy / 12700f else img.height * 0.75f
            if (w <= 0f || h <= 0f) {
                w = img.width * 0.75f
                h = img.height * 0.75f
            }
            return ImageBlock(img.bytes, w, h)
        }
    }
}
