package com.doxsy.app.ai

import java.util.TreeSet
import kotlin.math.ln

/**
 * Picks which parts of a long document go into one AI request. The AI models behind the app only take a
 * limited amount of text at a time, so a long file is cut into parts and, for each question, the parts that
 * match the question best are sent (always with the beginning, and spread over the rest of the file).
 * A short file is sent whole.
 */
object AiContext {
    private const val CHUNK = 2_400
    private val WORD = Regex("[\\p{L}\\p{N}]{3,}")

    private val GENERAL = listOf(
        "summar", "overview", "key point", "main point", "gist", "simple word",
        "what is in", "what's in", "whole", "entire", "full document", "this document", "this file",
    )

    private val STOP = setOf(
        "the", "and", "for", "are", "was", "what", "who", "how", "this", "that", "with", "from", "about",
        "tell", "give", "show", "please", "can", "you", "your", "does", "did", "has", "have", "not", "all",
        "any", "its", "into", "there", "their", "them", "then", "than", "when", "where", "which", "will",
        "would", "could", "should", "file", "document", "enna", "epdi", "irukku", "sollu", "panni",
    )

    fun select(text: String, query: String, budget: Int): String {
        if (text.length <= budget) return text
        val chunks = split(text)
        val n = chunks.size
        if (n <= 1) return text.take(budget)
        val maxChunks = maxOf(2, budget / CHUNK)

        val picked = TreeSet<Int>()
        picked.add(0)

        val terms = terms(query)
        val general = terms.isEmpty() || GENERAL.any { query.contains(it, ignoreCase = true) }
        if (!general) {
            val counts = chunks.map { tokenCounts(it) }
            val df = HashMap<String, Int>()
            for (c in counts) for (k in c.keys) df[k] = (df[k] ?: 0) + 1
            val scores = DoubleArray(n)
            for (i in 0 until n) {
                var s = 0.0
                for (t in terms) {
                    val tf = counts[i][t] ?: 0
                    if (tf > 0) s += (1.0 + ln(tf.toDouble())) * ln(1.0 + n.toDouble() / (df[t] ?: 1))
                }
                scores[i] = s
            }
            val ranked = (0 until n).filter { scores[it] > 0.0 }.sortedByDescending { scores[it] }
            for (i in ranked) {
                if (picked.size >= maxChunks) break
                picked.add(i)
            }
            // The part after a match often finishes the answer.
            for (i in ranked) {
                if (picked.size >= maxChunks) break
                if (i + 1 < n) picked.add(i + 1)
            }
        }

        // Spread the remaining room over the whole file so the AI still sees its overall shape.
        val step = n.toDouble() / maxChunks
        var k = 0
        while (picked.size < maxChunks && k < maxChunks * 2) {
            picked.add((k * step).toInt().coerceIn(0, n - 1))
            k++
        }

        val sb = StringBuilder()
        var prev = -2
        for (i in picked) {
            if (i != prev + 1) sb.append("\n[… part ").append(i + 1).append(" of ").append(n).append(" …]\n")
            sb.append(chunks[i]).append('\n')
            prev = i
        }
        return sb.toString().trim()
    }

    private fun split(text: String): List<String> {
        val out = ArrayList<String>()
        val cur = StringBuilder()
        for (line in text.lineSequence()) {
            if (cur.isNotEmpty() && cur.length + line.length + 1 > CHUNK) {
                out.add(cur.toString())
                cur.setLength(0)
            }
            var l = line
            while (l.length > CHUNK) {
                out.add(l.substring(0, CHUNK))
                l = l.substring(CHUNK)
            }
            cur.append(l).append('\n')
        }
        if (cur.isNotEmpty()) out.add(cur.toString())
        return out
    }

    private fun terms(q: String): List<String> =
        WORD.findAll(q.lowercase()).map { it.value }.filter { it !in STOP }.distinct().toList()

    private fun tokenCounts(chunk: String): Map<String, Int> {
        val m = HashMap<String, Int>()
        for (w in WORD.findAll(chunk.lowercase())) m[w.value] = (m[w.value] ?: 0) + 1
        return m
    }
}
