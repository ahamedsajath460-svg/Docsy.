package com.doxsy.app.cloud

import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.time.Instant

data class DriveItem(
    val id: String,
    val name: String,
    val mime: String,
    val size: Long,
    val modified: Long,
) {
    val isFolder: Boolean get() = mime == DriveApi.FOLDER
    val isGoogleDoc: Boolean get() = mime.startsWith("application/vnd.google-apps.") && !isFolder

    /** Name to save the downloaded copy under (Google Docs/Sheets/Slides are exported as PDF). */
    val fileName: String get() = if (isGoogleDoc && !name.endsWith(".pdf", true)) "$name.pdf" else name

    val typeLabel: String
        get() = when {
            isFolder -> "FOLDER"
            mime == "application/vnd.google-apps.document" -> "DOC"
            mime == "application/vnd.google-apps.spreadsheet" -> "SHEET"
            mime == "application/vnd.google-apps.presentation" -> "SLIDES"
            name.contains('.') -> name.substringAfterLast('.').uppercase().take(5)
            else -> "FILE"
        }
}

object DriveApi {
    const val FOLDER = "application/vnd.google-apps.folder"
    const val SHARED = "__shared__"
    private const val BASE = "https://www.googleapis.com/drive/v3"

    /** parentId: null = My Drive root, SHARED = "Shared with me", otherwise a folder id. */
    fun list(token: String, parentId: String?): List<DriveItem> {
        val q = when (parentId) {
            null -> "'root' in parents and trashed=false"
            SHARED -> "sharedWithMe=true and trashed=false"
            else -> "'$parentId' in parents and trashed=false"
        }
        val out = ArrayList<DriveItem>()
        if (parentId == null) out += DriveItem(SHARED, "Shared with me", FOLDER, 0, 0)
        var page: String? = null
        var pages = 0
        do {
            val url = buildString {
                append("$BASE/files?q=${enc(q)}")
                append("&fields=${enc("nextPageToken,files(id,name,mimeType,size,modifiedTime)")}")
                append("&orderBy=${enc("folder,name")}&pageSize=200")
                append("&supportsAllDrives=true&includeItemsFromAllDrives=true")
                if (page != null) append("&pageToken=${enc(page!!)}")
            }
            val json = JSONObject(String(Net.request(url, token)))
            val files: JSONArray = json.optJSONArray("files") ?: JSONArray()
            for (i in 0 until files.length()) {
                val f = files.getJSONObject(i)
                out += DriveItem(
                    id = f.getString("id"),
                    name = f.optString("name", "Untitled"),
                    mime = f.optString("mimeType"),
                    size = f.optString("size").toLongOrNull() ?: -1L,
                    modified = runCatching { Instant.parse(f.optString("modifiedTime")).toEpochMilli() }.getOrDefault(0L),
                )
            }
            page = json.optString("nextPageToken").ifEmpty { null }
            pages++
        } while (page != null && pages < 5)
        return out
    }

    private fun contentUrl(item: DriveItem): String =
        if (item.isGoogleDoc) "$BASE/files/${item.id}/export?mimeType=${enc("application/pdf")}"
        else "$BASE/files/${item.id}?alt=media&supportsAllDrives=true"

    fun downloadTo(token: String, item: DriveItem, out: OutputStream) = Net.stream(contentUrl(item), token, out)

    fun upload(token: String, parentId: String?, name: String, mime: String, bytes: ByteArray) {
        val boundary = "doxsy" + System.currentTimeMillis()
        val meta = JSONObject().put("name", name).apply {
            if (parentId != null && parentId != SHARED) put("parents", JSONArray().put(parentId))
        }.toString()
        val body = ByteArrayOutputStream()
        body.write("--$boundary\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n$meta\r\n".toByteArray())
        body.write("--$boundary\r\nContent-Type: ${mime.ifBlank { "application/octet-stream" }}\r\n\r\n".toByteArray())
        body.write(bytes)
        body.write("\r\n--$boundary--".toByteArray())
        Net.request(
            "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&supportsAllDrives=true",
            token,
            "POST",
            body.toByteArray(),
            "multipart/related; boundary=$boundary",
        )
    }
}
