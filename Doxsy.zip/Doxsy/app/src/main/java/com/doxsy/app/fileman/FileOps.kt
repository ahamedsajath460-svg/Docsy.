package com.doxsy.app.fileman

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document
import com.doxsy.app.util.FileItem
import com.doxsy.app.util.FileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.util.UUID

/** Shared, thread-safe progress holder for long running operations. */
class Progress {
    @Volatile var total: Int = 0
    @Volatile var done: Int = 0
    @Volatile var current: String = ""
    @Volatile var cancelled: Boolean = false
}

/** Items waiting to be pasted. [cut] = move, otherwise copy. */
data class Clipboard(val cut: Boolean, val items: List<IndexedFile>)

sealed interface OpResult {
    data class Ok(val message: String) : OpResult
    data class Failed(val message: String) : OpResult
}

/** Result of sending an item to the trash. [Unsupported] means the provider could not move it. */
sealed interface TrashResult {
    data object Trashed : TrashResult
    data class Unsupported(val reason: String) : TrashResult
}

object FileOps {

    private fun docUri(tree: Uri, docId: String): Uri = DocumentsContract.buildDocumentUriUsingTree(tree, docId)

    private fun flags(ctx: Context, uri: Uri): Int = runCatching {
        ctx.contentResolver.query(uri, arrayOf(Document.COLUMN_FLAGS), null, null, null)?.use { c ->
            if (c.moveToFirst() && !c.isNull(0)) c.getInt(0) else 0
        }
    }.getOrNull() ?: 0

    private fun children(ctx: Context, tree: Uri, parentId: String): List<FileItem> =
        FileUtils.queryChildren(ctx, tree, parentId)

    /** "name (1).ext" style name that does not collide with anything in [parentId]. */
    fun uniqueName(ctx: Context, tree: Uri, parentId: String, name: String): String {
        val existing = runCatching { children(ctx, tree, parentId).map { it.name.lowercase() }.toSet() }
            .getOrDefault(emptySet())
        if (name.lowercase() !in existing) return name
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var n = 1
        while (true) {
            val candidate = "$base ($n)$ext"
            if (candidate.lowercase() !in existing) return candidate
            n++
        }
    }

    private fun isInside(folderDocId: String, targetDocId: String): Boolean =
        targetDocId == folderDocId || targetDocId.startsWith("$folderDocId/")

    // ---- Copy ----

    /** Copies [src] (file or folder) into [destParentId] of [destTree]. Returns the new document id or null. */
    private fun copyOne(
        ctx: Context,
        src: IndexedFile,
        destTree: Uri,
        destParentId: String,
        p: Progress,
        newName: String? = null,
    ): String? {
        if (p.cancelled) return null
        val srcTree = src.treeUri ?: throw IOException("${src.item.name} cannot be copied from here.")
        val item = src.item
        val name = uniqueName(ctx, destTree, destParentId, newName ?: item.name)
        p.current = item.name
        val destParent = docUri(destTree, destParentId)
        if (item.isDir) {
            if (srcTree == destTree && isInside(item.docId, destParentId)) {
                throw IOException("A folder cannot be copied into itself.")
            }
            // Snapshot the children BEFORE creating the destination so we never recurse into the copy.
            val kids = children(ctx, srcTree, item.docId)
            val created = DocumentsContract.createDocument(ctx.contentResolver, destParent, Document.MIME_TYPE_DIR, name)
                ?: throw IOException("Could not create folder $name")
            val newId = DocumentsContract.getDocumentId(created)
            for (k in kids) {
                if (p.cancelled) return newId
                copyOne(ctx, IndexedFile(k, srcTree, item.docId, ""), destTree, newId, p)
            }
            return newId
        }
        // Fast path: provider-side copy inside the same tree, only when no rename is needed.
        if (srcTree == destTree && name == item.name &&
            (flags(ctx, item.uri) and Document.FLAG_SUPPORTS_COPY) != 0
        ) {
            val copied = runCatching { DocumentsContract.copyDocument(ctx.contentResolver, item.uri, destParent) }.getOrNull()
            if (copied != null) {
                p.done++
                return DocumentsContract.getDocumentId(copied)
            }
        }
        val mime = item.mime.ifBlank { "application/octet-stream" }
        val created = DocumentsContract.createDocument(ctx.contentResolver, destParent, mime, name)
            ?: throw IOException("Could not create $name")
        try {
            ctx.contentResolver.openInputStream(item.uri).use { input ->
                ctx.contentResolver.openOutputStream(created, "w").use { out ->
                    if (input == null || out == null) throw IOException("Could not open $name")
                    val buf = ByteArray(128 * 1024)
                    while (true) {
                        if (p.cancelled) throw IOException("Cancelled")
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                    }
                }
            }
        } catch (e: Exception) {
            runCatching { DocumentsContract.deleteDocument(ctx.contentResolver, created) }
            throw e
        }
        p.done++
        return DocumentsContract.getDocumentId(created)
    }

    /** Number of files (not folders) under [items]; used as the progress total for copy and move alike. */
    fun countFiles(ctx: Context, items: List<IndexedFile>): Int {
        var n = 0
        fun walk(tree: Uri, f: FileItem) {
            if (f.isDir) {
                runCatching { children(ctx, tree, f.docId) }.getOrDefault(emptyList()).forEach { walk(tree, it) }
            } else n++
        }
        items.forEach { i -> i.treeUri?.let { walk(it, i.item) } }
        return n.coerceAtLeast(1)
    }

    // ---- Move ----

    /** Moves one item; uses the provider's move when possible, else copy + delete. */
    private fun moveOne(ctx: Context, src: IndexedFile, destTree: Uri, destParentId: String, p: Progress, newName: String? = null) {
        val srcTree = src.treeUri ?: throw IOException("This item cannot be modified.")
        val srcParent = src.parentDocId ?: throw IOException("Unknown source folder.")
        val item = src.item
        if (item.isDir && srcTree == destTree && isInside(item.docId, destParentId)) {
            throw IOException("A folder cannot be moved into itself.")
        }
        if (srcTree == destTree && srcParent == destParentId && newName == null) return
        val unique = uniqueName(ctx, destTree, destParentId, newName ?: item.name)
        if (srcTree == destTree && unique == item.name &&
            (flags(ctx, item.uri) and Document.FLAG_SUPPORTS_MOVE) != 0
        ) {
            val moved = runCatching {
                DocumentsContract.moveDocument(ctx.contentResolver, item.uri, docUri(srcTree, srcParent), docUri(destTree, destParentId))
            }.getOrNull()
            if (moved != null) {
                p.done += countFiles(ctx, listOf(src))
                return
            }
        }
        // Fallback: copy then delete. Only delete when the copy fully succeeded.
        val before = p.done
        copyOne(ctx, src, destTree, destParentId, p, unique)
        if (p.cancelled) throw IOException("Cancelled")
        if (p.done == before && !item.isDir) throw IOException("Copy failed")
        if (!DocumentsContract.deleteDocument(ctx.contentResolver, item.uri)) {
            throw IOException("Copied, but could not remove the original ${item.name}")
        }
    }

    suspend fun paste(ctx: Context, clip: Clipboard, destTree: Uri, destParentId: String, p: Progress): OpResult =
        withContext(Dispatchers.IO) {
            p.total = countFiles(ctx, clip.items)
            p.done = 0
            var failures = 0
            var lastError = ""
            for (it in clip.items) {
                if (p.cancelled) break
                try {
                    if (clip.cut) moveOne(ctx, it, destTree, destParentId, p) else copyOne(ctx, it, destTree, destParentId, p)
                } catch (e: SecurityException) {
                    failures++
                    lastError = "Permission to this folder was lost."
                } catch (e: Exception) {
                    failures++
                    lastError = e.message ?: "Unknown error"
                }
            }
            val verb = if (clip.cut) "Moved" else "Copied"
            when {
                p.cancelled -> OpResult.Failed("Cancelled. Items already processed were kept.")
                failures == 0 -> OpResult.Ok("$verb ${clip.items.size} item(s).")
                else -> OpResult.Failed("$failures item(s) failed: $lastError")
            }
        }

    suspend fun duplicate(ctx: Context, items: List<IndexedFile>, p: Progress): OpResult = withContext(Dispatchers.IO) {
        p.total = countFiles(ctx, items)
        p.done = 0
        var failures = 0
        for (it in items) {
            val tree = it.treeUri
            val parent = it.parentDocId
            if (tree == null || parent == null) {
                failures++
                continue
            }
            try {
                copyOne(ctx, it, tree, parent, p)
            } catch (e: Exception) {
                failures++
            }
        }
        if (failures == 0) OpResult.Ok("Duplicated ${items.size} item(s).") else OpResult.Failed("$failures item(s) could not be duplicated.")
    }

    suspend fun rename(ctx: Context, item: FileItem, newName: String): Boolean = withContext(Dispatchers.IO) {
        runCatching { DocumentsContract.renameDocument(ctx.contentResolver, item.uri, newName) != null }.getOrDefault(false)
    }

    suspend fun createFolder(ctx: Context, tree: Uri, parentId: String, name: String): String? = withContext(Dispatchers.IO) {
        runCatching {
            val u = DocumentsContract.createDocument(
                ctx.contentResolver, docUri(tree, parentId), Document.MIME_TYPE_DIR, uniqueName(ctx, tree, parentId, name),
            )
            u?.let { DocumentsContract.getDocumentId(it) }
        }.getOrNull()
    }

    /** "Organize": moves [items] into the folder named [folderName] under [parentId] (created when missing). */
    suspend fun organizeInto(ctx: Context, items: List<IndexedFile>, tree: Uri, parentId: String, folderName: String, p: Progress): OpResult =
        withContext(Dispatchers.IO) {
            val existing = runCatching { children(ctx, tree, parentId) }.getOrDefault(emptyList())
                .firstOrNull { it.isDir && it.name.equals(folderName, ignoreCase = true) }
            val targetId = existing?.docId ?: runCatching {
                DocumentsContract.createDocument(ctx.contentResolver, docUri(tree, parentId), Document.MIME_TYPE_DIR, folderName)
                    ?.let { DocumentsContract.getDocumentId(it) }
            }.getOrNull() ?: return@withContext OpResult.Failed("Could not create the folder.")
            p.total = items.size
            p.done = 0
            var failures = 0
            for (it in items) {
                if (p.cancelled) break
                if (it.item.docId == targetId) continue
                try {
                    moveOne(ctx, it, tree, targetId, p)
                } catch (e: Exception) {
                    failures++
                }
            }
            if (failures == 0) OpResult.Ok("Organised ${items.size} item(s) into $folderName.") else OpResult.Failed("$failures item(s) could not be moved.")
        }

    // ---- Delete / Trash ----

    suspend fun deletePermanently(ctx: Context, items: List<FileItem>): Int = withContext(Dispatchers.IO) {
        items.count { !runCatching { DocumentsContract.deleteDocument(ctx.contentResolver, it.uri) }.getOrDefault(false) }
    }

    private fun trashFolderId(ctx: Context, tree: Uri, create: Boolean): String? {
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        val found = runCatching { children(ctx, tree, rootId) }.getOrDefault(emptyList())
            .firstOrNull { it.isDir && it.name == FileIndexer.TRASH_NAME }
        if (found != null) return found.docId
        if (!create) return null
        return runCatching {
            DocumentsContract.createDocument(ctx.contentResolver, docUri(tree, rootId), Document.MIME_TYPE_DIR, FileIndexer.TRASH_NAME)
                ?.let { DocumentsContract.getDocumentId(it) }
        }.getOrNull()
    }

    /** Moves [src] to the trash folder of its tree and records it for restore. Never deletes unless the move succeeded. */
    suspend fun moveToTrash(ctx: Context, src: IndexedFile): TrashResult = withContext(Dispatchers.IO) {
        val tree = src.treeUri
        val parent = src.parentDocId
        if (tree == null || parent == null) return@withContext TrashResult.Unsupported("This item is not inside a folder you added.")
        try {
            val trashId = trashFolderId(ctx, tree, true)
                ?: return@withContext TrashResult.Unsupported("This storage provider does not allow a trash folder.")
            val trashName = uniqueName(ctx, tree, trashId, src.item.name)
            moveOne(ctx, src, tree, trashId, Progress().also { it.total = 1 }, trashName)
            TrashStore.add(
                ctx,
                TrashEntry(
                    id = UUID.randomUUID().toString(),
                    treeUri = tree.toString(),
                    origParentDocId = parent,
                    origName = src.item.name,
                    trashName = trashName,
                    deletedAt = System.currentTimeMillis(),
                    isDir = src.item.isDir,
                    size = src.item.size,
                ),
            )
            TrashResult.Trashed
        } catch (e: SecurityException) {
            TrashResult.Unsupported("Permission to this folder was lost.")
        } catch (e: Exception) {
            TrashResult.Unsupported(e.message ?: "The move failed.")
        }
    }

    private fun findInTrash(ctx: Context, e: TrashEntry): IndexedFile? {
        val tree = Uri.parse(e.treeUri)
        val trashId = trashFolderId(ctx, tree, false) ?: return null
        val item = children(ctx, tree, trashId).firstOrNull { it.name == e.trashName } ?: return null
        return IndexedFile(item, tree, trashId, FileIndexer.TRASH_NAME)
    }

    suspend fun restore(ctx: Context, e: TrashEntry): OpResult = withContext(Dispatchers.IO) {
        try {
            val tree = Uri.parse(e.treeUri)
            val src = findInTrash(ctx, e)
            if (src == null) {
                TrashStore.remove(ctx, e.id)
                return@withContext OpResult.Failed("The item is no longer in the trash.")
            }
            val parentOk = runCatching { children(ctx, tree, e.origParentDocId); true }.getOrDefault(false)
            val dest = if (parentOk) e.origParentDocId else DocumentsContract.getTreeDocumentId(tree)
            moveOne(ctx, src, tree, dest, Progress().also { it.total = 1 }, uniqueName(ctx, tree, dest, e.origName))
            TrashStore.remove(ctx, e.id)
            OpResult.Ok(if (parentOk) "Restored ${e.origName}." else "Original folder missing; restored ${e.origName} to the top folder.")
        } catch (ex: Exception) {
            OpResult.Failed(ex.message ?: "Could not restore.")
        }
    }

    suspend fun purge(ctx: Context, e: TrashEntry): Boolean = withContext(Dispatchers.IO) {
        val src = runCatching { findInTrash(ctx, e) }.getOrNull()
        val ok = src == null || runCatching { DocumentsContract.deleteDocument(ctx.contentResolver, src.item.uri) }.getOrDefault(false)
        if (ok) TrashStore.remove(ctx, e.id)
        ok
    }

    suspend fun purgeExpired(ctx: Context) {
        TrashStore.expired(ctx).forEach { purge(ctx, it) }
    }
}
