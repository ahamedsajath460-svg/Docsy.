package com.doxsy.app.docview

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.StaticLayout
import android.text.TextPaint
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StrikethroughSpan
import android.text.style.StyleSpan
import android.text.style.UnderlineSpan
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Draws a [Slide] into a bitmap. Used by the slide viewer and by the PDF converter, so both show
 * the same layout. Text boxes are shrunk until their paragraphs fit.
 */
object SlideRenderer {
    private const val DEFAULT_PT = 18f
    private const val MIN_FIT = 0.35f
    private const val PAD_PX = 3f
    private const val INDENT_PT = 24f

    private class Laid(val layout: StaticLayout, val dx: Float)

    /** Renders at [widthPx] wide; height follows the slide's aspect ratio. */
    fun render(slide: Slide, widthPx: Int): Bitmap {
        val w = widthPx.coerceIn(16, 4096)
        val aspect = if (slide.aspect > 0f) slide.aspect else 16f / 9f
        val h = (w / aspect).roundToInt().coerceIn(1, 4096)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val bg = slide.background ?: Color.WHITE
        canvas.drawColor(bg)
        val widthPt = if (slide.widthPt > 0f) slide.widthPt else 960f
        val pxPerPt = w / widthPt
        val darkBg = luminance(bg) < 0.5f
        for (el in slide.elements) {
            val r = RectF(el.x * w, el.y * h, (el.x + el.w) * w, (el.y + el.h) * h)
            when (el) {
                is SlideShape -> drawShape(canvas, el, r, pxPerPt)
                is SlideImage -> drawImage(canvas, el, r)
                is SlideText -> drawText(canvas, el, r, pxPerPt, darkBg)
            }
        }
        return bmp
    }

    private fun drawShape(c: Canvas, el: SlideShape, r: RectF, pxPerPt: Float) {
        val fill = el.fill
        if (fill != null) {
            val p = paintOf(Paint.Style.FILL, fill, 0f)
            if (el.ellipse) c.drawOval(r, p) else c.drawRect(r, p)
        }
        val line = el.line
        if (line != null) {
            val p = paintOf(Paint.Style.STROKE, line, max(1f, pxPerPt))
            if (el.ellipse) c.drawOval(r, p) else c.drawRect(r, p)
        }
    }

    private fun drawImage(c: Canvas, el: SlideImage, r: RectF) {
        val bmp = decodeFit(el.bytes, max(1, r.width().roundToInt()), max(1, r.height().roundToInt())) ?: return
        try {
            c.drawBitmap(bmp, null, r, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        } finally {
            bmp.recycle()
        }
    }

    private fun drawText(c: Canvas, el: SlideText, r: RectF, pxPerPt: Float, darkBg: Boolean) {
        val fill = el.fill
        if (fill != null) c.drawRect(r, paintOf(Paint.Style.FILL, fill, 0f))

        val boxW = max(1f, r.width() - 2 * PAD_PX)
        val boxH = max(1f, r.height() - 2 * PAD_PX)
        var fit = 1f
        var laid = layoutAll(el.paras, boxW, pxPerPt, fit, darkBg)
        while (fit > MIN_FIT && totalHeight(laid) > boxH) {
            fit -= 0.08f
            laid = layoutAll(el.paras, boxW, pxPerPt, fit, darkBg)
        }

        c.save()
        c.clipRect(r)
        var y = r.top + PAD_PX
        for (l in laid) {
            c.save()
            c.translate(r.left + PAD_PX + l.dx, y)
            l.layout.draw(c)
            c.restore()
            y += l.layout.height
        }
        c.restore()
    }

    private fun layoutAll(paras: List<Para>, boxW: Float, pxPerPt: Float, fit: Float, darkBg: Boolean): List<Laid> {
        val out = ArrayList<Laid>(paras.size)
        val base = TextPaint(TextPaint.ANTI_ALIAS_FLAG).apply {
            textSize = DEFAULT_PT * pxPerPt * fit
            color = defaultText(darkBg)
        }
        for (p in paras) {
            val indentPx = p.indentLevel * INDENT_PT * pxPerPt * fit
            val width = (boxW - indentPx).roundToInt().coerceAtLeast(1)
            val sb = SpannableStringBuilder()
            val bullet = p.bullet
            if (bullet != null) sb.append(bullet).append(' ')
            for (run in p.runs) {
                val start = sb.length
                sb.append(run.text)
                if (sb.length > start) applyRun(sb, start, sb.length, run, pxPerPt, fit, darkBg)
            }
            val align = when (p.align) {
                Align.CENTER -> Layout.Alignment.ALIGN_CENTER
                Align.END -> Layout.Alignment.ALIGN_OPPOSITE
                else -> Layout.Alignment.ALIGN_NORMAL
            }
            val layout = StaticLayout.Builder.obtain(sb, 0, sb.length, base, width)
                .setAlignment(align)
                .setIncludePad(false)
                .build()
            out.add(Laid(layout, indentPx))
        }
        return out
    }

    private fun applyRun(
        sb: SpannableStringBuilder,
        start: Int,
        end: Int,
        run: TextRun,
        pxPerPt: Float,
        fit: Float,
        darkBg: Boolean,
    ) {
        val flags = Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        val style = when {
            run.bold && run.italic -> Typeface.BOLD_ITALIC
            run.bold -> Typeface.BOLD
            run.italic -> Typeface.ITALIC
            else -> -1
        }
        if (style >= 0) sb.setSpan(StyleSpan(style), start, end, flags)
        if (run.underline) sb.setSpan(UnderlineSpan(), start, end, flags)
        if (run.strike) sb.setSpan(StrikethroughSpan(), start, end, flags)
        if (run.sizePt > 0f) {
            val px = (run.sizePt * pxPerPt * fit).roundToInt().coerceAtLeast(1)
            sb.setSpan(AbsoluteSizeSpan(px, false), start, end, flags)
        }
        val col = if (run.color != 0) run.color else defaultText(darkBg)
        sb.setSpan(ForegroundColorSpan(col), start, end, flags)
    }

    private fun totalHeight(laid: List<Laid>): Float {
        var t = 0f
        for (l in laid) t += l.layout.height
        return t
    }

    /** Decodes [bytes] at a sample size that keeps the bitmap at least as large as the target box. */
    private fun decodeFit(bytes: ByteArray, maxW: Int, maxH: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        val w = bounds.outWidth
        val h = bounds.outHeight
        if (w <= 0 || h <= 0) return null
        var sample = 1
        while (w / (sample * 2) >= maxW && h / (sample * 2) >= maxH) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return try {
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
        } catch (e: OutOfMemoryError) {
            null
        }
    }

    private fun paintOf(style: Paint.Style, argb: Int, strokeW: Float): Paint =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.style = style
            color = argb
            strokeWidth = strokeW
        }

    private fun defaultText(darkBg: Boolean): Int = if (darkBg) Color.WHITE else Color.BLACK

    private fun luminance(argb: Int): Float =
        (0.299f * Color.red(argb) + 0.587f * Color.green(argb) + 0.114f * Color.blue(argb)) / 255f
}
