package com.doxsy.app.ui.cloud

import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.SubdirectoryArrowLeft
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.doxsy.app.cloud.CloudException
import com.doxsy.app.cloud.DriveApi
import com.doxsy.app.cloud.DriveItem
import com.doxsy.app.cloud.GoogleAuth
import com.doxsy.app.data.DocEntry
import com.doxsy.app.data.Prefs
import com.doxsy.app.ui.ConfirmDialog
import com.doxsy.app.ui.KindBadge
import com.doxsy.app.ui.home.EmptyList
import com.doxsy.app.util.FileKind
import com.doxsy.app.util.FileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.core.content.FileProvider
import java.io.File

/** Copies a cloud file into the cache and hands it to the app (PDF viewer or another app). */
fun cloudEntry(ctx: android.content.Context, file: File, name: String): DocEntry {
    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", file)
    return DocEntry(uri.toString(), name)
}

fun cloudCacheFile(ctx: android.content.Context, id: String, name: String): File {
    var safe = name.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim()
    if (safe.isBlank() || safe.all { it == '.' }) safe = "file"
    return File(ctx.cacheDir, "cloud/$id/$safe").also { it.parentFile?.mkdirs() }
}

/** Google Drive tab: connect screen first, then a folder browser (like the video). */
@Composable
fun DriveScreen(prefs: Prefs, onBack: () -> Unit, onOpenEntry: (DocEntry) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val account by prefs.googleAccount.state.collectAsState()
    var confirmRemove by remember { mutableStateOf(false) }
    val connect = rememberConnectState()
    val gate = rememberAccessGate()
    val driveScopes = listOf(com.doxsy.app.cloud.GoogleScopes.DRIVE)

    // folder stack: id (null = My Drive) + name
    val stack = rememberSaveable(
        saver = androidx.compose.runtime.saveable.listSaver<androidx.compose.runtime.snapshots.SnapshotStateList<Pair<String?, String>>, String>(
            save = { l -> l.map { (id, name) -> (id ?: "\u0001") + "\u0000" + name } },
            restore = { l ->
                mutableStateListOf<Pair<String?, String>>().also { out ->
                    l.forEach { s ->
                        val id = s.substringBefore('\u0000')
                        out.add((if (id == "\u0001") null else id) to s.substringAfter('\u0000'))
                    }
                }
            },
        ),
    ) { mutableStateListOf<Pair<String?, String>>() }
    var driveItems by remember { mutableStateOf<List<DriveItem>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var nextPage by remember { mutableStateOf<String?>(null) }
    var loadingMore by remember { mutableStateOf(false) }
    var reload by remember { mutableIntStateOf(0) }
    var busyId by remember { mutableStateOf<String?>(null) }
    var menuOpen by remember { mutableStateOf(false) }
    var saveItem by remember { mutableStateOf<DriveItem?>(null) }

    val currentId: String? = stack.lastOrNull()?.first
    val path = if (stack.isEmpty()) "" else "/" + stack.joinToString("/") { it.second }

    BackHandler { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex) else onBack() }

    LaunchedEffect(account, currentId to stack.size, reload) {
        if (account.isEmpty()) return@LaunchedEffect
        loading = true
        loadError = null
        driveItems = emptyList() // don't show the previous folder while the new one loads
        nextPage = null
        try {
            val token = gate.token(account, driveScopes)
            if (token == null) {
                loadError = PERMISSION_NEEDED
                driveItems = emptyList()
            } else {
                var page = withContext(Dispatchers.IO) { DriveApi.listPage(token, currentId, null) }
                var all = page.items
                // a page can be empty after hiding Forms etc.; keep fetching so the folder isn't shown as empty
                var guard = 0
                while (all.isEmpty() && page.next != null && guard++ < 5) {
                    val pt = page.next!!
                    page = withContext(Dispatchers.IO) { DriveApi.listPage(token, currentId, pt) }
                    all = page.items
                }
                driveItems = all
                nextPage = page.next
            }
        } catch (e: Exception) {
            loadError = e.message ?: "Could not load Google Drive."
            driveItems = emptyList()
        }
        loading = false
    }

    // Loads the next page when the user scrolls to the end of a long folder.
    fun loadMore() {
        val pageToken = nextPage ?: return
        if (loadingMore) return
        val forId = currentId
        loadingMore = true
        scope.launch {
            try {
                val token = gate.token(account, driveScopes) ?: error(PERMISSION_NEEDED)
                val page = withContext(Dispatchers.IO) { DriveApi.listPage(token, forId, pageToken) }
                if (forId == currentId) { // ignore if the user already moved to another folder
                    driveItems = driveItems + page.items
                    nextPage = page.next
                }
            } catch (e: Exception) {
                nextPage = null
                FileUtils.toast(ctx, (e as? CloudException)?.message ?: e.message ?: "Could not load more files")
            }
            loadingMore = false
        }
    }

    val upload = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            try {
                val token = gate.token(account, driveScopes) ?: error(PERMISSION_NEEDED)
                val (name, size) = withContext(Dispatchers.IO) { nameAndSize(ctx, uri) }
                if (size > 50L * 1024 * 1024) error("Files over 50 MB can't be uploaded from here.")
                withContext(Dispatchers.IO) {
                    val bytes = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                    val mime = ctx.contentResolver.getType(uri).orEmpty()
                    DriveApi.upload(token, currentId, name, mime, bytes)
                }
                FileUtils.toast(ctx, "Saved to Google Drive")
                reload++
            } catch (e: Exception) {
                FileUtils.toast(ctx, e.message ?: "Upload failed")
            }
        }
    }

    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { out ->
        val item = saveItem
        saveItem = null
        if (out != null && item != null) scope.launch {
            try {
                val token = gate.token(account, driveScopes) ?: error(PERMISSION_NEEDED)
                withContext(Dispatchers.IO) {
                    ctx.contentResolver.openOutputStream(out)!!.use { DriveApi.downloadTo(token, item, it) }
                }
                FileUtils.toast(ctx, "Saved to your phone")
            } catch (e: Exception) {
                FileUtils.toast(ctx, e.message ?: "Download failed")
            }
        }
    }

    fun openItem(item: DriveItem) {
        if (item.isFolder) {
            stack.add(item.id to item.name)
            return
        }
        if (busyId != null) return
        busyId = item.id
        scope.launch {
            try {
                val token = gate.token(account, driveScopes) ?: error(PERMISSION_NEEDED)
                val file = cloudCacheFile(ctx, item.id, item.fileName)
                withContext(Dispatchers.IO) { file.outputStream().use { DriveApi.downloadTo(token, item, it) } }
                onOpenEntry(cloudEntry(ctx, file, item.fileName))
            } catch (e: Exception) {
                FileUtils.toast(ctx, (e as? CloudException)?.message ?: e.message ?: "Could not open the file")
            }
            busyId = null
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex) else onBack() }) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back")
                }
                Spacer(Modifier.weight(1f))
                if (account.isNotEmpty()) {
                    Box {
                        IconButton(onClick = { menuOpen = true }) { Icon(Icons.Rounded.MoreVert, "More") }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(text = { Text("Refresh") }, onClick = { menuOpen = false; reload++ })
                            DropdownMenuItem(
                                text = { Text("Remove $account") },
                                onClick = {
                                    menuOpen = false
                                    confirmRemove = true
                                },
                            )
                        }
                    }
                }
            }
            Text(
                "Google Drive",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(start = 16.dp, bottom = 12.dp),
            )

            if (account.isEmpty()) {
                Column(
                    Modifier.fillMaxSize().padding(bottom = 120.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    DriveLogo(80.dp)
                    Spacer(Modifier.height(20.dp))
                    Text("Now you can access your Google Drive files", fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                    Text("Connect your personal or business account.", textAlign = TextAlign.Center)
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = { connect.begin() }) { Text("Add account") }
                }
            } else {
                if (stack.isNotEmpty()) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { stack.removeAt(stack.lastIndex) }
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Rounded.SubdirectoryArrowLeft, "Up", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.width(12.dp))
                        Text(path, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                when {
                    loading && driveItems.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                    loadError != null -> Column(
                        Modifier.fillMaxWidth().padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text(loadError!!, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.error)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { reload++ }) { Text("Allow access") }
                    }
                    driveItems.isEmpty() -> EmptyList(Icons.Rounded.Folder, "This folder is empty", "Tap + to upload a file from your phone.")
                    else -> LazyColumn(Modifier.weight(1f)) {
                        items(driveItems, key = { it.key }) { item ->
                            DriveRow(
                                item = item,
                                busy = busyId == item.id,
                                onClick = { openItem(item) },
                                onOpen = { openItem(item) },
                                onSave = { saveItem = item; save.launch(item.fileName) },
                            )
                        }
                        if (nextPage != null) item(key = "load_more") {
                            LaunchedEffect(nextPage) { loadMore() }
                            Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
                            }
                        }
                    }
                }
            }
        }
        if (account.isNotEmpty()) {
            FloatingActionButton(
                onClick = { upload.launch(arrayOf("*/*")) },
                shape = CircleShape,
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
            ) { Icon(Icons.Rounded.Add, "Upload to Google Drive") }
        }
    }

    if (confirmRemove) {
        ConfirmDialog(
            title = "Remove account",
            message = "$account will be removed from Google Drive and Email in Doxsy.",
            confirmLabel = "Remove",
            onDismiss = { confirmRemove = false },
            onConfirm = {
                confirmRemove = false
                prefs.forgetAccount(account)
                stack.clear()
            },
        )
    }
    GoogleConnectHost(connect, prefs, onDone = { reload++ })
}

@Composable
private fun DriveRow(
    item: DriveItem,
    busy: Boolean,
    onClick: () -> Unit,
    onOpen: () -> Unit,
    onSave: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    Column {
        Row(
            Modifier
                .fillMaxWidth()
                .clickable(onClick = onClick)
                .padding(start = 16.dp, top = 10.dp, bottom = 10.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (item.isFolder) {
                Icon(Icons.Rounded.Folder, null, tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(40.dp))
            } else {
                KindBadge(FileKind.of(item.fileName), size = 40)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(item.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    if (item.isFolder) "FOLDER" else listOfNotNull(
                        item.typeLabel,
                        if (item.modified > 0) FileUtils.formatDate(item.modified) else null,
                        if (item.size >= 0) FileUtils.formatSize(item.size) else null,
                    ).joinToString(" • "),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
            if (!item.isFolder) {
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, "More") }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("Open") }, onClick = { menu = false; onOpen() })
                        DropdownMenuItem(text = { Text("Save to phone") }, onClick = { menu = false; onSave() })
                    }
                }
            } else {
                Spacer(Modifier.width(48.dp))
            }
        }
        Box(
            Modifier
                .padding(horizontal = 16.dp)
                .fillMaxWidth()
                .height(1.dp)
                .background(MaterialTheme.colorScheme.outlineVariant),
        )
    }
}

private fun nameAndSize(ctx: android.content.Context, uri: Uri): Pair<String, Long> {
    var name = "file"
    var size = 0L
    ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
        if (c.moveToFirst()) {
            name = c.getString(0) ?: name
            size = if (c.isNull(1)) 0L else c.getLong(1)
        }
    }
    return name to size
}
