package com.doxsy.app.ui.cloud

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.IntentSender
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import com.doxsy.app.cloud.AuthOutcome
import com.doxsy.app.cloud.GoogleAuth
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Gets an access token for ONE Google service (Drive or Gmail). When Google still needs the user's
 * permission, Google's own permission popup opens right away and the call carries on by itself after
 * "Allow" - so the screen never needs a "connect again / try again" step.
 *
 * Returns the token, or null when the user pressed Cancel / Deny in Google's popup.
 * Throws an Exception with a readable message when Google itself reports an error.
 */
class AccessGate internal constructor(private val ctx: Context) {
    internal var launchConsent: (IntentSender) -> Unit = {}
    private var waiting: CompletableDeferred<AuthOutcome?>? = null
    private val lock = Mutex()

    suspend fun token(account: String, scopes: List<String>): String? = lock.withLock {
        when (val first = GoogleAuth.authorize(ctx, account, scopes)) {
            is AuthOutcome.Token -> first.value
            is AuthOutcome.Failed -> throw IllegalStateException(first.message)
            is AuthOutcome.Consent -> {
                val d = CompletableDeferred<AuthOutcome?>()
                waiting = d
                launchConsent(first.sender)
                when (val r = d.await()) {
                    is AuthOutcome.Token -> r.value
                    is AuthOutcome.Failed -> throw IllegalStateException(r.message)
                    else -> null
                }
            }
        }
    }

    internal fun onResult(resultCode: Int, data: Intent?) {
        val d = waiting ?: return
        waiting = null
        if (resultCode != Activity.RESULT_OK) {
            d.complete(null)
            return
        }
        d.complete(GoogleAuth.tokenFromIntent(ctx, data))
    }
}

@Composable
fun rememberAccessGate(): AccessGate {
    val ctx = LocalContext.current
    val gate = remember { AccessGate(ctx) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        gate.onResult(r.resultCode, r.data)
    }
    gate.launchConsent = { sender -> launcher.launch(IntentSenderRequest.Builder(sender).build()) }
    return gate
}

const val PERMISSION_NEEDED = "Allow Doxsy to access this account to continue."
