package com.doxsy.app.fileman

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** One item that was moved to the app-managed ".DoxsyTrash" folder at the root of a user folder tree. */
data class TrashEntry(
    val id: String,
    val treeUri: String,
    val origParentDocId: String,
    val origName: String,
    /** Name of the item inside the trash folder (may differ from [origName] after a collision). */
    val trashName: String,
    val deletedAt: Long,
    val isDir: Boolean,
    val size: Long,
)

/** Records what is in the trash so items can be restored to where they came from. */
object TrashStore {
    const val RETENTION_MS = 30L * 24 * 60 * 60 * 1000
    private const val KEY = "entries"

    private fun sp(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("doxsy_trash", Context.MODE_PRIVATE)

    @Synchronized
    fun list(ctx: Context): List<TrashEntry> = runCatching {
        val arr = JSONArray(sp(ctx).getString(KEY, "[]") ?: "[]")
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            TrashEntry(
                id = o.getString("id"),
                treeUri = o.getString("tree"),
                origParentDocId = o.getString("parent"),
                origName = o.getString("name"),
                trashName = o.getString("tname"),
                deletedAt = o.optLong("at"),
                isDir = o.optBoolean("dir"),
                size = o.optLong("size", -1L),
            )
        }
    }.getOrDefault(emptyList())

    @Synchronized
    private fun save(ctx: Context, list: List<TrashEntry>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("tree", it.treeUri).put("parent", it.origParentDocId)
                    .put("name", it.origName).put("tname", it.trashName).put("at", it.deletedAt)
                    .put("dir", it.isDir).put("size", it.size),
            )
        }
        sp(ctx).edit().putString(KEY, arr.toString()).apply()
    }

    @Synchronized
    fun add(ctx: Context, e: TrashEntry) = save(ctx, list(ctx) + e)

    @Synchronized
    fun remove(ctx: Context, id: String) = save(ctx, list(ctx).filterNot { it.id == id })

    fun expired(ctx: Context, now: Long = System.currentTimeMillis()): List<TrashEntry> =
        list(ctx).filter { now - it.deletedAt > RETENTION_MS }
}

/** Small file-manager preferences kept outside Prefs (so the shared Prefs class is untouched). */
object FileManPrefs {
    private fun sp(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("doxsy_fileman", Context.MODE_PRIVATE)

    /** True when the user reversed the default direction of the current sort order. */
    fun reversed(ctx: Context): Boolean = sp(ctx).getBoolean("reversed", false)

    fun setReversed(ctx: Context, v: Boolean) {
        sp(ctx).edit().putBoolean("reversed", v).apply()
    }
}
