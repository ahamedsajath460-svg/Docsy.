package com.doxsy.app.sign

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import com.doxsy.app.util.AppFiles
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import kotlin.math.max
import kotlin.math.min

/** A signature image the user saved for reuse. [aspect] = width / height of the PNG. */
data class SavedSignature(
    val id: String,
    val name: String,
    val fileName: String,
    val created: Long,
    val aspect: Float,
)

/**
 * Saved signatures: transparent PNGs in filesDir/signatures plus a small JSON index kept in its own
 * SharedPreferences file (Doxsy's main Prefs is not touched).
 */
class SignatureStore(context: Context) {
    private val app = context.applicationContext
    private val sp = app.getSharedPreferences("doxsy_signatures", Context.MODE_PRIVATE)

    /** True once the user has acknowledged the "image signature, not a digital signature" notice. */
    var infoSeen: Boolean
        get() = sp.getBoolean(KEY_INFO, false)
        set(v) {
            sp.edit().putBoolean(KEY_INFO, v).apply()
        }

    fun file(sig: SavedSignature): File = File(AppFiles.dir(app, "signatures"), sig.fileName)

    fun list(): List<SavedSignature> = runCatching {
        val arr = JSONArray(sp.getString(KEY_INDEX, "[]"))
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val s = SavedSignature(
                id = o.getString("id"),
                name = o.optString("name", "Signature"),
                fileName = o.getString("file"),
                created = o.optLong("t"),
                aspect = o.optDouble("a", 3.0).toFloat().coerceIn(0.1f, 20f),
            )
            if (file(s).exists()) s else null
        }
    }.getOrDefault(emptyList())

    private fun write(list: List<SavedSignature>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("name", it.name).put("file", it.fileName)
                    .put("t", it.created).put("a", it.aspect.toDouble()),
            )
        }
        sp.edit().putString(KEY_INDEX, arr.toString()).apply()
    }

    /** Saves [bitmap] (ARGB, transparent background) as a new signature. Throws IOException on failure. */
    fun save(name: String, bitmap: Bitmap): SavedSignature {
        val id = UUID.randomUUID().toString()
        val f = File(AppFiles.dir(app, "signatures"), "$id.png")
        FileOutputStream(f).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val sig = SavedSignature(
            id = id,
            name = name.trim().ifBlank { "Signature" }.take(40),
            fileName = f.name,
            created = System.currentTimeMillis(),
            aspect = bitmap.width.toFloat() / bitmap.height.toFloat().coerceAtLeast(1f),
        )
        write(list() + sig)
        return sig
    }

    fun rename(id: String, name: String) {
        write(list().map { if (it.id == id) it.copy(name = name.trim().ifBlank { "Signature" }.take(40)) else it })
    }

    fun delete(id: String) {
        val all = list()
        all.firstOrNull { it.id == id }?.let { file(it).delete() }
        write(all.filterNot { it.id == id })
    }

    /** Decodes the signature PNG (at most ~1000 px wide, so cheap). */
    fun load(sig: SavedSignature): Bitmap? = runCatching {
        BitmapFactory.decodeFile(file(sig).absolutePath)
    }.getOrNull()

    private companion object {
        const val KEY_INDEX = "index"
        const val KEY_INFO = "info_seen"
    }
}

/** Turns touch strokes into a trimmed, transparent bitmap. */
object SignatureRenderer {
    /**
     * @param strokes each stroke is a list of points in pad pixels
     * @param strokePx pen thickness in pad pixels
     * @return bitmap cropped to the ink bounds (plus pen margin) or null if nothing was drawn
     */
    fun render(strokes: List<List<PointF>>, color: Int, strokePx: Float): Bitmap? {
        val all = strokes.filter { it.isNotEmpty() }
        if (all.isEmpty()) return null
        var minX = Float.MAX_VALUE
        var minY = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE
        var maxY = -Float.MAX_VALUE
        all.forEach { s ->
            s.forEach { p ->
                minX = min(minX, p.x)
                minY = min(minY, p.y)
                maxX = max(maxX, p.x)
                maxY = max(maxY, p.y)
            }
        }
        val pad = strokePx
        val bw = (maxX - minX) + 2 * pad
        val bh = (maxY - minY) + 2 * pad
        if (bw < 2f || bh < 2f) return null
        // Up-scale small signatures for smoothness, but keep the PNG a sensible size.
        val scale = min(3f, min(1000f / bw, 1500f / bh))
        val w = (bw * scale).toInt().coerceAtLeast(2)
        val h = (bh * scale).toInt().coerceAtLeast(2)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            strokeWidth = strokePx * scale
        }
        val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            style = Paint.Style.FILL
        }
        fun tx(x: Float) = (x - minX + pad) * scale
        fun ty(y: Float) = (y - minY + pad) * scale
        all.forEach { s ->
            if (s.size == 1) {
                canvas.drawCircle(tx(s[0].x), ty(s[0].y), strokePx * scale / 2f, dot)
            } else {
                val path = Path()
                path.moveTo(tx(s[0].x), ty(s[0].y))
                for (i in 1 until s.size) {
                    val a = s[i - 1]
                    val b = s[i]
                    path.quadTo(tx(a.x), ty(a.y), tx((a.x + b.x) / 2f), ty((a.y + b.y) / 2f))
                }
                val last = s.last()
                path.lineTo(tx(last.x), ty(last.y))
                canvas.drawPath(path, paint)
            }
        }
        return bmp
    }
}
