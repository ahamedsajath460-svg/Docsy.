package com.doxsy.app.util

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File

/** Hands app-private files to other apps (share / open with) through the app FileProvider. */
object AppFiles {
    fun authority(ctx: Context) = "${ctx.packageName}.fileprovider"

    fun uriFor(ctx: Context, file: File): Uri = FileProvider.getUriForFile(ctx, authority(ctx), file)

    /** Folder for data Doxsy keeps for the user (annotations, signatures, trash ...). Created on demand. */
    fun dir(ctx: Context, name: String): File = File(ctx.filesDir, name).also { it.mkdirs() }

    /** Scratch folder inside cacheDir (cleared by the system, also swept on app start). */
    fun cacheDir(ctx: Context, name: String): File = File(ctx.cacheDir, name).also { it.mkdirs() }

    fun safeName(name: String): String =
        name.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), "_").trim().trim('.').ifBlank { "Document" }.take(120)
}
