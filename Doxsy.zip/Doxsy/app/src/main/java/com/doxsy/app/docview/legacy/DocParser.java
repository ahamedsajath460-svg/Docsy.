package com.doxsy.app.docview.legacy;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Extracts the text of a Word 6 / 95 / 97-2003 (.doc) file: paragraphs, tables and page breaks. */
public final class DocParser {
    public static final int PARA = 0, TABLE = 1, PAGE_BREAK = 2;

    public static final class Block {
        public int type;
        public String text;
        public List<List<String>> rows;
    }

    public static final class Result {
        public final ArrayList<Block> blocks = new ArrayList<>();
        public boolean truncated;
    }

    private static final int MAX_CHARS = 4_000_000;
    private static final Charset CP1252 = Charset.forName("windows-1252");

    private DocParser() {
    }

    private static int u16(byte[] b, int o) {
        return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8);
    }

    private static int i32(byte[] b, int o) {
        return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8) | ((b[o + 2] & 0xFF) << 16) | ((b[o + 3] & 0xFF) << 24);
    }

    public static Result parse(Ole2 ole) throws LegacyException {
        byte[] wd = ole.stream("WordDocument");
        if (wd == null || wd.length < 0x40) throw new LegacyException("This Word file has no readable content.");
        try {
            return parseDoc(ole, wd);
        } catch (LegacyException e) {
            throw e;
        } catch (RuntimeException e) {
            throw new LegacyException("This Word document could not be read. It may be corrupted.", false, e);
        }
    }

    private static Result parseDoc(Ole2 ole, byte[] wd) throws LegacyException {
        int ident = u16(wd, 0);
        int flags = u16(wd, 0x0A);
        if ((flags & 0x0100) != 0) {
            throw new LegacyException(
                    "This Word file is password-protected, so Doxsy cannot read it. Remove the password, then open it again.",
                    true, null);
        }
        String text;
        boolean truncated = false;
        if (ident == 0xA5EC) {
            int pos = 32;
            int csw = u16(wd, pos);
            pos += 2 + csw * 2;
            int cslw = u16(wd, pos);
            int lw = pos + 2;
            pos = lw + cslw * 4;
            int cbRg = u16(wd, pos);
            int blob = pos + 2;
            int ccpText = i32(wd, lw + 12);
            if (ccpText < 0) ccpText = 0;
            if (cbRg < 34 || blob + 34 * 8 > wd.length) {
                throw new LegacyException("This Word document could not be read. It may be corrupted.");
            }
            int fcClx = i32(wd, blob + 33 * 8);
            int lcbClx = i32(wd, blob + 33 * 8 + 4);
            byte[] table = ole.stream((flags & 0x0200) != 0 ? "1Table" : "0Table");
            if (table == null) throw new LegacyException("This Word document could not be read. It may be corrupted.");
            if (ccpText > MAX_CHARS) {
                ccpText = MAX_CHARS;
                truncated = true;
            }
            text = readPieces(wd, table, fcClx, lcbClx, ccpText);
        } else if (ident == 0xA5DC || ident == 0xA697) {
            // Word 6.0 / 95: one contiguous run of 8-bit text
            int fcMin = i32(wd, 0x18);
            int fcMac = i32(wd, 0x1C);
            if (fcMin < 0 || fcMac > wd.length || fcMac <= fcMin) {
                throw new LegacyException("This Word document could not be read. It may be corrupted.");
            }
            int n = Math.min(fcMac - fcMin, MAX_CHARS);
            truncated = fcMac - fcMin > MAX_CHARS;
            text = new String(wd, fcMin, n, CP1252);
        } else {
            throw new LegacyException("This is not a valid Word document. The file may be corrupted.");
        }
        Result r = build(text);
        r.truncated = truncated;
        return r;
    }

    private static String readPieces(byte[] wd, byte[] table, int fcClx, int lcbClx, int ccpText) throws LegacyException {
        if (fcClx < 0 || lcbClx <= 0 || (long) fcClx + lcbClx > table.length) {
            throw new LegacyException("This Word document could not be read. It may be corrupted.");
        }
        int p = fcClx;
        int end = fcClx + lcbClx;
        while (p < end && (table[p] & 0xFF) == 0x01) { // Prc: skip property modifiers
            int cb = u16(table, p + 1);
            p += 3 + cb;
        }
        if (p >= end || (table[p] & 0xFF) != 0x02) {
            throw new LegacyException("This Word document could not be read. It may be corrupted.");
        }
        int lcb = i32(table, p + 1);
        int plc = p + 5;
        int n = (lcb - 4) / 12;
        StringBuilder sb = new StringBuilder(Math.min(ccpText, 1 << 20));
        for (int i = 0; i < n && sb.length() < ccpText; i++) {
            int cpStart = i32(table, plc + i * 4);
            int cpEnd = i32(table, plc + (i + 1) * 4);
            int pcd = plc + (n + 1) * 4 + i * 8;
            int fc = i32(table, pcd + 2);
            boolean compressed = (fc & 0x40000000) != 0;
            int off = fc & 0x3FFFFFFF;
            int count = cpEnd - cpStart;
            if (count <= 0) continue;
            if (cpStart >= ccpText) break;
            if (cpStart + count > ccpText) count = ccpText - cpStart;
            if (compressed) {
                int o = off / 2;
                if (o < 0 || o >= wd.length) continue;
                count = Math.min(count, wd.length - o);
                sb.append(new String(wd, o, count, CP1252));
            } else {
                if (off < 0 || off >= wd.length) continue;
                count = Math.min(count, (wd.length - off) / 2);
                sb.append(new String(wd, off, count * 2, StandardCharsets.UTF_16LE));
            }
        }
        return sb.toString();
    }

    /** Turns Word's control-character text stream into paragraphs, tables and page breaks. */
    private static Result build(String text) {
        Result res = new Result();
        StringBuilder seg = new StringBuilder();
        ArrayList<List<String>> tableRows = new ArrayList<>();
        ArrayList<String> row = new ArrayList<>();
        // field handling: 0x13 begin, 0x14 separator, 0x15 end. A field's code is hidden, its result is shown.
        ArrayList<Boolean> fieldShowing = new ArrayList<>();

        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == 0x13) {
                fieldShowing.add(false);
                continue;
            }
            if (c == 0x14) {
                if (!fieldShowing.isEmpty()) fieldShowing.set(fieldShowing.size() - 1, true);
                continue;
            }
            if (c == 0x15) {
                if (!fieldShowing.isEmpty()) fieldShowing.remove(fieldShowing.size() - 1);
                continue;
            }
            boolean visible = true;
            for (boolean b : fieldShowing) {
                if (!b) {
                    visible = false;
                    break;
                }
            }
            if (!visible) continue;

            if (c == 0x07) { // end of a table cell; an empty one right after a cell ends the row
                String cell = seg.toString();
                seg.setLength(0);
                if (cell.isEmpty() && !row.isEmpty()) {
                    tableRows.add(row);
                    row = new ArrayList<>();
                } else {
                    row.add(cell);
                }
            } else if (c == 0x0D) {
                if (!row.isEmpty()) {
                    seg.append('\n'); // second paragraph inside a table cell
                    continue;
                }
                if (!tableRows.isEmpty()) flushTable(res, tableRows);
                addPara(res, seg.toString());
                seg.setLength(0);
            } else if (c == 0x0C) {
                if (!tableRows.isEmpty()) flushTable(res, tableRows);
                if (seg.length() > 0) {
                    addPara(res, seg.toString());
                    seg.setLength(0);
                }
                Block b = new Block();
                b.type = PAGE_BREAK;
                res.blocks.add(b);
            } else if (c == 0x0B) {
                seg.append('\n');
            } else if (c == 0x1E) {
                seg.append('-');
            } else if (c == 0xA0) {
                seg.append(' ');
            } else if (c >= 0x20 || c == 0x09) {
                seg.append(c);
            }
        }
        if (!row.isEmpty()) tableRows.add(row);
        if (!tableRows.isEmpty()) flushTable(res, tableRows);
        if (seg.length() > 0) addPara(res, seg.toString());
        // trim trailing empty paragraphs
        while (!res.blocks.isEmpty()) {
            Block last = res.blocks.get(res.blocks.size() - 1);
            if (last.type == PARA && last.text.trim().isEmpty()) res.blocks.remove(res.blocks.size() - 1);
            else break;
        }
        return res;
    }

    private static void addPara(Result res, String s) {
        Block b = new Block();
        b.type = PARA;
        b.text = s;
        res.blocks.add(b);
    }

    private static void flushTable(Result res, ArrayList<List<String>> rows) {
        ArrayList<List<String>> keep = new ArrayList<>();
        for (List<String> r : rows) {
            if (r.size() == 1 && r.get(0).isEmpty()) continue;
            keep.add(r);
        }
        rows.clear();
        if (keep.isEmpty()) return;
        Block b = new Block();
        b.type = TABLE;
        b.rows = keep;
        res.blocks.add(b);
    }
}
