package com.doxsy.app.convert

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Conversion history, last [MAX] entries, kept in a private SharedPreferences file on this device. */
class ConversionHistory(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("doxsy_convert_history", Context.MODE_PRIVATE)

    fun load(): List<HistoryItem> = runCatching {
        val arr = JSONArray(sp.getString(KEY, "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            HistoryItem(
                time = o.optLong("t"),
                source = o.optString("s"),
                target = o.optString("g"),
                outputUri = if (o.has("u") && !o.isNull("u")) o.getString("u") else null,
                mime = o.optString("m"),
                ok = o.optBoolean("k"),
                message = o.optString("x"),
            )
        }
    }.getOrDefault(emptyList())

    private fun save(list: List<HistoryItem>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("t", it.time).put("s", it.source).put("g", it.target)
                    .put("u", it.outputUri ?: JSONObject.NULL).put("m", it.mime).put("k", it.ok).put("x", it.message),
            )
        }
        sp.edit().putString(KEY, arr.toString()).apply()
    }

    fun add(item: HistoryItem) {
        save((listOf(item) + load()).take(MAX))
    }

    fun remove(time: Long) {
        save(load().filterNot { it.time == time })
    }

    fun clear() {
        sp.edit().remove(KEY).apply()
    }

    private companion object {
        const val KEY = "items"
        const val MAX = 50
    }
}
