package com.doxsy.app.docview

import android.content.Context
import android.net.Uri
import com.doxsy.app.docview.legacy.DocParser
import com.doxsy.app.docview.legacy.LegacyException
import com.doxsy.app.docview.legacy.Ole2
import com.doxsy.app.docview.legacy.PptParser
import com.doxsy.app.docview.legacy.XlsParser
import java.io.InputStream

/**
 * Old binary Office files (.xls, .doc, .ppt) and OLE2-wrapped files in general.
 *
 * The readers for the modern formats ([XlsxReader], [DocxReader], [PptxReader]) call into here first,
 * so a file opens by what it really contains, whatever its extension says (a legacy Excel file saved
 * as "report.xlsx" is the most common cause of "this file can't be opened").
 */
internal object LegacyOffice {

    /** The kind of OLE2 container: [Ole2.KIND_XLS], [Ole2.KIND_DOC], [Ole2.KIND_PPT] ... */
    internal class Opened(val ole: Ole2) {
        val kind: Int get() = ole.kind()
    }

    private fun readHead(input: InputStream, head: ByteArray): Int {
        var n = 0
        while (n < head.size) {
            val r = input.read(head, n, head.size - n)
            if (r < 0) break
            n += r
        }
        return n
    }

    /** Opens [uri] when it is an OLE2 container, else returns null (caller continues with the zip formats). */
    fun open(ctx: Context, uri: Uri): Opened? {
        val head = ByteArray(8)
        val n = ctx.contentResolver.openInputStream(uri)?.use { readHead(it, head) }
            ?: throw DocReadException("Could not open this file.")
        if (!Ole2.hasMagic(head, n)) return null
        val bytes = try {
            ctx.contentResolver.openInputStream(uri)?.use { Ole2.readAll(it) }
                ?: throw DocReadException("Could not open this file.")
        } catch (e: java.io.IOException) {
            throw DocReadException("This file is too large to open.", e)
        }
        val ole = try {
            Ole2.open(bytes)
        } catch (e: LegacyException) {
            throw DocReadException(e.message ?: "This file is damaged and cannot be opened.", e)
        }
        return Opened(ole)
    }

    private fun mismatch(want: String, o: Opened): DocReadException = DocReadException(
        when (o.kind) {
            Ole2.KIND_ENCRYPTED_OOXML ->
                "This file is password-protected, so Doxsy cannot read it. Remove the password, then open it again."
            Ole2.KIND_XLS -> "This is an Excel file, not a $want document."
            Ole2.KIND_DOC -> "This is a Word file, not a $want document."
            Ole2.KIND_PPT -> "This is a PowerPoint file, not a $want document."
            else -> "This is not a valid $want document. The file may be corrupted."
        },
    )

    private fun <T> guard(block: () -> T): T = try {
        block()
    } catch (e: LegacyException) {
        throw DocReadException(e.message ?: "This file could not be read.", e)
    } catch (e: OutOfMemoryError) {
        throw DocReadException("Not enough memory to open this file.", e)
    }

    // ------------------------------------------------------------------ Excel

    fun workbook(o: Opened, maxRows: Int): Workbook {
        if (o.kind != Ole2.KIND_XLS) throw mismatch("Excel", o)
        return guard {
            val book = XlsParser.parse(o.ole, maxRows)
            val fmt = XlsxReader.NumFormatter(book.formatCodes, book.date1904)
            val sheets = ArrayList<Sheet>()
            for (sd in book.sheets) {
                val rows = ArrayList<List<String>>(sd.rows.size)
                var maxCol = 0
                for (r in sd.rows) {
                    if (r == null) {
                        rows.add(emptyList())
                        continue
                    }
                    var last = r.size - 1
                    while (last >= 0 && r[last] == null) last--
                    val out = ArrayList<String>(last + 1)
                    for (c in 0..last) {
                        out.add(r[c]?.let { cellText(it, book, fmt) } ?: "")
                    }
                    var trim = out.size
                    while (trim > 0 && out[trim - 1].isEmpty()) trim--
                    while (out.size > trim) out.removeAt(out.lastIndex)
                    if (out.size > maxCol) maxCol = out.size
                    rows.add(out)
                }
                while (rows.isNotEmpty() && rows.last().isEmpty()) rows.removeAt(rows.lastIndex)
                val widths = sd.widths.take(maxCol.coerceAtMost(200))
                sheets.add(Sheet(sd.name.ifBlank { "Sheet ${sheets.size + 1}" }, rows, widths, sd.truncated))
            }
            if (sheets.isEmpty()) throw DocReadException("This workbook contains no readable sheets.")
            Workbook(sheets)
        }
    }

    private fun cellText(c: XlsParser.Cell, book: XlsParser.Book, fmt: XlsxReader.NumFormatter): String = when (c.kind) {
        XlsParser.NUM -> fmt.format(c.num, book.xfFormat.getOrNull(c.xf) ?: 0)
        XlsParser.BOOL -> if (c.num != 0.0) "TRUE" else "FALSE"
        else -> c.str ?: ""
    }

    // ------------------------------------------------------------------ Word

    fun word(o: Opened): WordDoc {
        if (o.kind != Ole2.KIND_DOC) throw mismatch("Word", o)
        return guard {
            val r = DocParser.parse(o.ole)
            val blocks = ArrayList<Block>(r.blocks.size)
            for (b in r.blocks) {
                when (b.type) {
                    DocParser.PARA -> blocks.add(Para(listOf(TextRun(b.text ?: ""))))
                    DocParser.PAGE_BREAK -> blocks.add(PageBreak)
                    DocParser.TABLE -> {
                        val rows = b.rows.map { row ->
                            row.map { cell ->
                                cell.split('\n').map { line -> Para(listOf(TextRun(line))) as Block }
                            }
                        }
                        blocks.add(TableBlock(rows))
                    }
                }
            }
            if (blocks.isEmpty()) throw DocReadException("This Word document has no readable text.")
            WordDoc(null, blocks, r.truncated)
        }
    }

    // ------------------------------------------------------------------ PowerPoint

    fun deck(o: Opened): Deck {
        if (o.kind != Ole2.KIND_PPT) throw mismatch("PowerPoint", o)
        return guard {
            val r = PptParser.parse(o.ole)
            val slides = r.slides.mapIndexed { i, s -> slideOf(i, s, r.aspect, r.widthPt) }
            if (slides.isEmpty()) throw DocReadException("This presentation has no readable slides.")
            Deck(slides)
        }
    }

    private fun slideOf(index: Int, s: PptParser.SlideData, aspect: Float, widthPt: Float): Slide {
        val titles = s.texts.filter { it.type == 0 || it.type == 6 }
        val rest = s.texts.filter { it.type != 0 && it.type != 6 }
        val els = ArrayList<SlideElement>()
        if (titles.isNotEmpty()) {
            val centred = titles.first().type == 6
            val paras = titles.flatMap { t ->
                t.text.split('\n').filter { it.isNotBlank() }.map { line ->
                    Para(
                        listOf(TextRun(line, bold = true, sizePt = widthPt / 22f)),
                        heading = 1,
                        align = if (centred) Align.CENTER else Align.START,
                    )
                }
            }
            els.add(SlideText(0.06f, 0.05f, 0.88f, if (rest.isEmpty()) 0.9f else 0.2f, paras))
        }
        if (rest.isNotEmpty()) {
            val top = if (titles.isEmpty()) 0.06f else 0.28f
            val totalH = 0.94f - top
            val each = totalH / rest.size
            rest.forEachIndexed { i, t ->
                val bulleted = t.type == 1 || t.type == 7 || t.type == 8
                val centred = t.type == 5
                val paras = t.text.split('\n').filter { it.isNotBlank() }.map { line ->
                    Para(
                        listOf(TextRun(line, sizePt = widthPt / 36f)),
                        align = if (centred) Align.CENTER else Align.START,
                        bullet = if (bulleted) "•" else null,
                    )
                }
                els.add(SlideText(0.06f, top + each * i, 0.88f, each, paras))
            }
        }
        return Slide(index, aspect, null, els, null, widthPt)
    }
}
