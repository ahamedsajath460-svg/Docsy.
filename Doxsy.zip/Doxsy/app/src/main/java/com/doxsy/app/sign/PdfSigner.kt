package com.doxsy.app.sign

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import com.doxsy.app.pdf.PdfEngine
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import com.tom_roush.pdfbox.util.Matrix
import java.io.File
import java.io.IOException
import java.io.OutputStream
import kotlin.math.cos
import kotlin.math.sin

/**
 * Embeds signature IMAGES into a PDF with PDFBox. These are ordinary pictures drawn into the page
 * content: they are NOT cryptographic digital signatures (no certificate, no tamper evidence).
 */
object PdfSigner {

    class SignException(message: String) : Exception(message)

    /**
     * One placed signature. Coordinates are normalised to the page AS DISPLAYED (after /Rotate):
     * [cx],[cy] centre as a fraction of width / height from the top-left, [width] as a fraction of
     * the page width, [rotationDeg] clockwise on screen.
     */
    data class Item(
        val image: File,
        val aspect: Float,
        val page: Int,
        val cx: Float,
        val cy: Float,
        val width: Float,
        val rotationDeg: Float,
    )

    /**
     * Reads [input], draws every item into its page and writes the new PDF to [out]. The input is
     * never modified. Blocking: call from Dispatchers.IO. Throws [SignException] / IOException.
     */
    fun export(ctx: Context, input: Uri, items: List<Item>, out: OutputStream) {
        val app = ctx.applicationContext
        PdfEngine.init(app)
        val tmp = File(app.cacheDir, "doxsy_tmp_sign_${System.nanoTime()}.pdf")
        try {
            app.contentResolver.openInputStream(input)?.use { i ->
                tmp.outputStream().use { o -> i.copyTo(o) }
            } ?: throw SignException("Could not read the PDF.")

            val doc = try {
                PDDocument.load(tmp)
            } catch (e: InvalidPasswordException) {
                throw SignException("This PDF is password-protected. Remove the password first, then sign it.")
            }
            doc.use { d ->
                if (d.isEncrypted && !d.currentAccessPermission.canModify()) {
                    throw SignException("This PDF does not allow changes, so a signature cannot be added.")
                }
                val pageCount = d.numberOfPages
                val images = HashMap<File, PDImageXObject>()
                val byPage = items.filter { it.page in 0 until pageCount }.groupBy { it.page }
                for (pageIndex in byPage.keys.sorted()) {
                    val page = d.getPage(pageIndex)
                    val geo = Geometry(page)
                    PDPageContentStream(d, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                        for (item in byPage.getValue(pageIndex)) {
                            val img = images.getOrPut(item.image) { createImage(d, item.image) }
                            val m = geo.matrixFor(item)
                            cs.saveGraphicsState()
                            cs.transform(m)
                            cs.drawImage(img, 0f, 0f, 1f, 1f)
                            cs.restoreGraphicsState()
                        }
                    }
                }
                d.save(out)
            }
        } finally {
            tmp.delete()
        }
    }

    private fun createImage(doc: PDDocument, file: File): PDImageXObject {
        val bmp = BitmapFactory.decodeFile(file.absolutePath)
            ?: throw SignException("A saved signature image could not be read.")
        return LosslessFactory.createFromImage(doc, bmp)
    }

    /** Maps the displayed (rotated, top-left origin) page frame onto PDF user space. */
    private class Geometry(page: com.tom_roush.pdfbox.pdmodel.PDPage) {
        private val box = page.cropBox ?: page.mediaBox
        private val bx = box.lowerLeftX
        private val by = box.lowerLeftY
        private val bw = box.width
        private val bh = box.height
        private val rot = ((((page.rotation % 360) + 360) % 360) / 90) * 90
        val dw: Float = if (rot == 90 || rot == 270) bh else bw
        val dh: Float = if (rot == 90 || rot == 270) bw else bh

        /** Displayed coordinates (x right, y down, in points) to user space. */
        fun toUser(x: Float, y: Float): Pair<Float, Float> = when (rot) {
            90 -> Pair(bx + y, by + x)
            180 -> Pair(bx + bw - x, by + y)
            270 -> Pair(bx + bw - y, by + bh - x)
            else -> Pair(bx + x, by + bh - y)
        }

        /** Matrix taking the unit square (the image space used by drawImage(img,0,0,1,1)) to user space. */
        fun matrixFor(item: Item): Matrix {
            val w = item.width * dw
            val h = w / item.aspect
            val cx = item.cx * dw
            val cy = item.cy * dh
            val th = Math.toRadians(item.rotationDeg.toDouble())
            val c = cos(th).toFloat()
            val s = sin(th).toFloat()
            fun disp(px: Float, py: Float): Pair<Float, Float> {
                val lx = (px - 0.5f) * w
                val ly = (0.5f - py) * h
                return toUser(cx + lx * c - ly * s, cy + lx * s + ly * c)
            }
            val p0 = disp(0f, 0f)
            val p1 = disp(1f, 0f)
            val p2 = disp(0f, 1f)
            return Matrix(
                p1.first - p0.first, p1.second - p0.second,
                p2.first - p0.first, p2.second - p0.second,
                p0.first, p0.second,
            )
        }
    }

    fun describe(t: Throwable): String = when (t) {
        is SignException -> t.message ?: "Could not sign this PDF."
        is InvalidPasswordException -> "This PDF is password-protected. Remove the password first."
        is OutOfMemoryError -> "Not enough memory to sign this PDF. Try a smaller file."
        is IOException -> "Could not read or write the file. ${t.message.orEmpty()}".trim()
        else -> "Could not sign this PDF."
    }
}
