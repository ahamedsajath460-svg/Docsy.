package com.doxsy.app.pdf

/** Lines that are on a page of one file but not on the same page of the other file. */
class PageDiff(val page: Int, val removed: List<String>, val added: List<String>)

class CompareResult(val pagesA: Int, val pagesB: Int, val diffs: List<PageDiff>) {
    val identical: Boolean get() = pagesA == pagesB && diffs.isEmpty()
}

object PdfCompare {
    private fun lines(text: String?): List<String> =
        text.orEmpty().lines().map { it.replace(Regex("\\s+"), " ").trim() }.filter { it.isNotEmpty() }

    /** Page by page, line by line. [a] is the first file's page texts, [b] the second file's. */
    fun compare(a: List<String>, b: List<String>): CompareResult {
        val diffs = ArrayList<PageDiff>()
        for (i in 0 until maxOf(a.size, b.size)) {
            val la = lines(a.getOrNull(i))
            val lb = lines(b.getOrNull(i))
            val countB = HashMap<String, Int>()
            lb.forEach { countB[it] = (countB[it] ?: 0) + 1 }
            val removed = ArrayList<String>()
            for (line in la) {
                val c = countB[line] ?: 0
                if (c > 0) countB[line] = c - 1 else removed.add(line)
            }
            val countA = HashMap<String, Int>()
            la.forEach { countA[it] = (countA[it] ?: 0) + 1 }
            val added = ArrayList<String>()
            for (line in lb) {
                val c = countA[line] ?: 0
                if (c > 0) countA[line] = c - 1 else added.add(line)
            }
            if (removed.isNotEmpty() || added.isNotEmpty()) diffs.add(PageDiff(i + 1, removed, added))
        }
        return CompareResult(a.size, b.size, diffs)
    }

    /** A readable report, at most [maxLines] changed lines are listed. */
    fun report(nameA: String, nameB: String, r: CompareResult, maxLines: Int = 200): String {
        val sb = StringBuilder()
        sb.append("A: ").append(nameA).append(" (").append(r.pagesA).append(" pages)\n")
        sb.append("B: ").append(nameB).append(" (").append(r.pagesB).append(" pages)\n\n")
        if (r.identical) {
            sb.append("No text differences found.")
        } else {
            if (r.pagesA != r.pagesB) sb.append("The page counts are different.\n\n")
            sb.append(r.diffs.size).append(" page(s) with differences. − only in A, + only in B.\n")
            var shown = 0
            for (d in r.diffs) {
                if (shown >= maxLines) {
                    sb.append("\n… more differences not shown.")
                    break
                }
                sb.append("\nPage ").append(d.page).append('\n')
                for (l in d.removed) { if (shown++ < maxLines) sb.append("− ").append(l).append('\n') }
                for (l in d.added) { if (shown++ < maxLines) sb.append("+ ").append(l).append('\n') }
            }
        }
        sb.append("\n\nThis compares the text of each page. Pictures and layout are not compared. Scanned pages have no text.")
        return sb.toString().trim()
    }
}
