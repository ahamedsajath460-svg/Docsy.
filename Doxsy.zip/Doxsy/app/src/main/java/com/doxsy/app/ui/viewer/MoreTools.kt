package com.doxsy.app.ui.viewer

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Compare
import androidx.compose.material.icons.rounded.NoteAdd
import androidx.compose.material.icons.rounded.AddPhotoAlternate
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.BrandingWatermark
import androidx.compose.material.icons.rounded.Brush
import androidx.compose.material.icons.rounded.Gesture
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.ListAlt
import androidx.compose.material.icons.rounded.CallSplit
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Compress
import androidx.compose.material.icons.rounded.Crop
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.FileDownload
import androidx.compose.material.icons.rounded.FormatListNumbered
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MergeType
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.doxsy.app.pdf.PdfSession
import com.doxsy.app.pdf.PdfTools
import com.doxsy.app.pdf.ToolResult
import com.doxsy.app.ui.home.CompressPage
import com.doxsy.app.ui.home.ExportPage
import com.doxsy.app.ui.home.SetPasswordPage
import com.doxsy.app.util.FileUtils
import com.doxsy.app.util.OutputStore
import kotlinx.coroutines.launch

/** Everything in the "More tools" sheet. Each tool saves a NEW file; the original PDF is never changed. */
internal enum class Tool(val title: String, val desc: String, val icon: ImageVector, val tint: Color) {
    ANNOTATE("Annotate", "Highlight, draw, shapes and notes", Icons.Rounded.Brush, Color(0xFF1FA463)),
    SIGN("Fill and sign", "Add your signature, date or initials", Icons.Rounded.Gesture, Color(0xFF2F6BFF)),
    FORM("Fill form", "Type into the form fields of a PDF", Icons.Rounded.ListAlt, Color(0xFFE0762B)),
    PROPS("Properties", "Title, author, remove hidden info", Icons.Rounded.Info, Color(0xFF607D8B)),
    EDIT("Edit PDF", "Change text, add text, pictures or hide parts", Icons.Rounded.Edit, Color(0xFFD6336C)),
    ORGANIZE("Organize pages", "Rotate, delete or extract pages", Icons.Rounded.GridView, Color(0xFF3F6FE0)),
    CROP("Crop pages", "Trim the margins of every page", Icons.Rounded.Crop, Color(0xFF1E9E8F)),
    SPLIT("Split PDF", "Cut into smaller files", Icons.Rounded.CallSplit, Color(0xFFE0762B)),
    NUMBERS("Page numbers", "Add 1 / 10 on every page", Icons.Rounded.FormatListNumbered, Color(0xFF8A56D8)),
    COMBINE("Combine files", "Join several PDFs into one", Icons.Rounded.MergeType, Color(0xFF5A67D8)),
    COMPRESS("Compress PDF", "Make the file smaller", Icons.Rounded.Compress, Color(0xFF0E9AA7)),
    EXPORT("Export PDF", "Word, Excel, images and more", Icons.Rounded.FileDownload, Color(0xFF2F9E5B)),
    IMAGES("Create PDF", "Make a PDF from photos", Icons.Rounded.AddPhotoAlternate, Color(0xFFD64B6C)),
    PASSWORD("Set password", "Lock this PDF", Icons.Rounded.Lock, Color(0xFF4C5BD4)),
    WATERMARK("Watermark", "Stamp text or a picture on every page", Icons.Rounded.BrandingWatermark, Color(0xFFC2308C)),
    INSERT("Insert pages", "Add pages from another PDF", Icons.Rounded.NoteAdd, Color(0xFF3F8EE0)),
    COMPARE("Compare PDFs", "See what changed between two files", Icons.Rounded.Compare, Color(0xFF7A5AF8)),
}

private val Groups = listOf(
    "Edit and sign" to listOf(Tool.EDIT, Tool.ANNOTATE, Tool.SIGN, Tool.FORM),
    "Pages" to listOf(Tool.ORGANIZE, Tool.INSERT, Tool.CROP, Tool.SPLIT, Tool.NUMBERS),
    "Files" to listOf(Tool.COMBINE, Tool.COMPRESS, Tool.EXPORT, Tool.IMAGES, Tool.COMPARE),
    "Protect and mark" to listOf(Tool.PASSWORD, Tool.WATERMARK, Tool.PROPS),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun MoreToolsHost(
    name: String,
    uri: Uri,
    session: PdfSession,
    onDismiss: () -> Unit,
    onOpenPdf: (Uri) -> Unit,
    onSign: (Uri) -> Unit = {},
) {
    var active by remember { mutableStateOf<Tool?>(null) }
    val base = name.substringBeforeLast('.')
    val close = { active = null }

    when (active) {
        null -> ModalBottomSheet(
            onDismissRequest = onDismiss,
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 28.dp),
            ) {
                Text("More tools", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(
                    "Works on your phone. Your original PDF is never changed.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Groups.forEach { (label, tools) ->
                    Text(
                        label,
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 18.dp, bottom = 8.dp),
                    )
                    tools.chunked(2).forEach { row ->
                        Row(
                            Modifier.fillMaxWidth().padding(bottom = 10.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            row.forEach { t -> ToolCard(t, Modifier.weight(1f)) { active = t } }
                            if (row.size == 1 && tools.size > 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
        }
        Tool.ANNOTATE -> AnnotateDialog(name, uri, session, onClose = close, onOpenPdf = onOpenPdf)
        Tool.SIGN -> LaunchedEffect(Unit) {
            onSign(uri)
            onDismiss()
        }
        Tool.FORM -> FormFillDialog(name, uri, onClose = close, onOpenPdf = onOpenPdf)
        Tool.PROPS -> PropertiesDialog(name, uri, onClose = close, onOpenPdf = onOpenPdf)
        Tool.EDIT -> PdfEditorDialog(name, uri, session, onClose = close, onOpenPdf = onOpenPdf)
        Tool.ORGANIZE -> PageEditorDialog(name, uri, session, onClose = close, onOpenPdf = onOpenPdf)
        Tool.COMPRESS -> CompressPage(name, uri, onClose = close, onOpenPdf = { u, _ -> onOpenPdf(u) })
        Tool.PASSWORD -> SetPasswordPage(name, uri, onClose = close, onOpenPdf = { u, _ -> onOpenPdf(u) })
        Tool.EXPORT -> ExportPage(name, uri, onClose = close)
        Tool.CROP -> CropTool(base, uri, close, onOpenPdf)
        Tool.NUMBERS -> NumbersTool(base, uri, close, onOpenPdf)
        Tool.WATERMARK -> WatermarkTool(base, uri, close, onOpenPdf)
        Tool.COMBINE -> CombineTool(name, uri, close, onOpenPdf)
        Tool.SPLIT -> SplitTool(base, uri, session.pageCount, close)
        Tool.IMAGES -> ImagesTool(close, onOpenPdf)
        Tool.INSERT -> InsertTool(base, uri, session.pageCount, close, onOpenPdf)
        Tool.COMPARE -> CompareTool(name, uri, close)
    }
}

@Composable
private fun ToolCard(t: Tool, modifier: Modifier, onClick: () -> Unit) {
    Surface(
        modifier = modifier.clip(RoundedCornerShape(18.dp)).clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
    ) {
        Column(Modifier.padding(14.dp)) {
            Box(
                Modifier.size(42.dp).background(t.tint.copy(alpha = 0.16f), RoundedCornerShape(13.dp)),
                contentAlignment = Alignment.Center,
            ) { Icon(t.icon, null, tint = t.tint) }
            Spacer(Modifier.height(10.dp))
            Text(t.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Text(t.desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ---------------------------------------------------------------- shared pieces

internal class Outcome(val result: ToolResult, val out: Uri?)

@Composable
private fun FormDialog(
    title: String,
    confirm: String,
    busy: Boolean,
    canConfirm: Boolean,
    onClose: () -> Unit,
    onConfirm: () -> Unit,
    content: @Composable ColumnScope.() -> Unit,
) {
    AlertDialog(
        onDismissRequest = { if (!busy) onClose() },
        title = { Text(title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                content()
            }
        },
        confirmButton = {
            if (busy) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
            else TextButton(onClick = onConfirm, enabled = canConfirm) { Text(confirm) }
        },
        dismissButton = { TextButton(onClick = onClose, enabled = !busy) { Text("Cancel") } },
    )
}

@Composable
internal fun ResultDialog(o: Outcome, onOpen: (Uri) -> Unit, onClose: () -> Unit) {
    val ok = o.result is ToolResult.Done
    val msg = when (val r = o.result) {
        is ToolResult.Done -> r.message
        is ToolResult.Failed -> r.message
    }
    val out = o.out
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (ok) "Done" else "Could not finish") },
        text = { Text(msg) },
        confirmButton = {
            if (ok && out != null) TextButton(onClick = { onOpen(out) }) { Text("Open") }
            else TextButton(onClick = onClose) { Text("OK") }
        },
        dismissButton = {
            if (ok && out != null) TextButton(onClick = onClose) { Text("Close") }
        },
    )
}

/** A form, then "save as" (new file), then the tool runs and the result is shown. */
@Composable
private fun SaveTool(
    title: String,
    confirm: String,
    suggested: String,
    canConfirm: Boolean,
    onClose: () -> Unit,
    onOpenPdf: (Uri) -> Unit,
    work: suspend (Uri) -> ToolResult,
    content: @Composable ColumnScope.() -> Unit,
) {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var outcome by remember { mutableStateOf<Outcome?>(null) }
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { out ->
        if (out != null) {
            busy = true
            scope.launch {
                val r = work(out)
                busy = false
                outcome = Outcome(r, out)
            }
        }
    }
    val o = outcome
    if (o != null) {
        ResultDialog(o, onOpen = onOpenPdf, onClose = onClose)
    } else {
        FormDialog(title, confirm, busy, canConfirm, onClose, onConfirm = { save.launch(suggested) }, content = content)
    }
}

// ---------------------------------------------------------------- tools

@Composable
private fun CropTool(base: String, uri: Uri, onClose: () -> Unit, onOpenPdf: (Uri) -> Unit) {
    val ctx = LocalContext.current
    var left by remember { mutableFloatStateOf(0f) }
    var top by remember { mutableFloatStateOf(0f) }
    var right by remember { mutableFloatStateOf(0f) }
    var bottom by remember { mutableFloatStateOf(0f) }
    SaveTool(
        title = "Crop pages",
        confirm = "Choose where to save",
        suggested = "${base}_cropped.pdf",
        canConfirm = left + top + right + bottom > 0f && left + right < 80f && top + bottom < 80f,
        onClose = onClose,
        onOpenPdf = onOpenPdf,
        work = { out -> PdfTools.cropPages(ctx, uri, null, left, top, right, bottom, out) },
    ) {
        Text("Trim the same margins from every page.", style = MaterialTheme.typography.bodySmall)
        CropSlider("Left", left) { left = it }
        CropSlider("Top", top) { top = it }
        CropSlider("Right", right) { right = it }
        CropSlider("Bottom", bottom) { bottom = it }
    }
}

@Composable
private fun CropSlider(label: String, value: Float, onChange: (Float) -> Unit) {
    Column {
        Text("$label  ${value.toInt()}%", style = MaterialTheme.typography.labelLarge)
        Slider(value = value, onValueChange = { onChange(it) }, valueRange = 0f..40f)
    }
}

@Composable
private fun NumbersTool(base: String, uri: Uri, onClose: () -> Unit, onOpenPdf: (Uri) -> Unit) {
    val ctx = LocalContext.current
    var pos by remember { mutableIntStateOf(0) }
    SaveTool(
        title = "Page numbers",
        confirm = "Choose where to save",
        suggested = "${base}_numbered.pdf",
        canConfirm = true,
        onClose = onClose,
        onOpenPdf = onOpenPdf,
        work = { out -> PdfTools.addPageNumbers(ctx, uri, pos, out) },
    ) {
        Text("Where should the numbers go?", style = MaterialTheme.typography.bodySmall)
        listOf("Bottom centre", "Bottom right", "Bottom left").forEachIndexed { i, label ->
            Row(
                Modifier.fillMaxWidth().clickable { pos = i }.padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RadioButton(selected = pos == i, onClick = { pos = i })
                Text(label)
            }
        }
    }
}

@Composable
private fun WatermarkTool(base: String, uri: Uri, onClose: () -> Unit, onOpenPdf: (Uri) -> Unit) {
    val ctx = LocalContext.current
    var text by remember { mutableStateOf("CONFIDENTIAL") }
    var usePicture by remember { mutableStateOf(false) }
    var picture by remember { mutableStateOf<Uri?>(null) }
    val pickPicture = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { picked ->
        if (picked != null) picture = picked
    }
    SaveTool(
        title = "Watermark",
        confirm = "Choose where to save",
        suggested = "${base}_watermarked.pdf",
        canConfirm = if (usePicture) picture != null else text.isNotBlank(),
        onClose = onClose,
        onOpenPdf = onOpenPdf,
        work = { out ->
            val pic = picture
            if (usePicture && pic != null) PdfTools.addImageWatermark(ctx, uri, pic, out)
            else PdfTools.addWatermark(ctx, uri, text, out)
        },
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            RadioButton(selected = !usePicture, onClick = { usePicture = false })
            Text("Text", Modifier.clickable { usePicture = false })
            Spacer(Modifier.width(16.dp))
            RadioButton(selected = usePicture, onClick = { usePicture = true })
            Text("Picture", Modifier.clickable { usePicture = true })
        }
        if (usePicture) {
            Text("A faint copy of your picture is placed in the middle of every page.", style = MaterialTheme.typography.bodySmall)
            TextButton(onClick = { pickPicture.launch("image/*") }) {
                Icon(Icons.Rounded.AddPhotoAlternate, null)
                Text(if (picture == null) "  Choose picture" else "  Picture chosen. Tap to change")
            }
        } else {
            Text("Light grey text is stamped diagonally on every page.", style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.take(40) },
                singleLine = true,
                label = { Text("Watermark text (English)") },
            )
        }
    }
}

@Composable
private fun InsertTool(base: String, uri: Uri, pages: Int, onClose: () -> Unit, onOpenPdf: (Uri) -> Unit) {
    val ctx = LocalContext.current
    var other by remember { mutableStateOf<Uri?>(null) }
    var otherName by remember { mutableStateOf("") }
    var spec by remember { mutableStateOf("") }
    var after by remember { mutableStateOf(pages.toString()) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { picked ->
        if (picked != null) {
            runCatching { ctx.contentResolver.takePersistableUriPermission(picked, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            other = picked
            otherName = FileUtils.displayName(ctx, picked)
        }
    }
    val position = after.toIntOrNull()
    SaveTool(
        title = "Insert pages",
        confirm = "Choose where to save",
        suggested = "${base}_inserted.pdf",
        canConfirm = other != null && position != null && position in 0..pages,
        onClose = onClose,
        onOpenPdf = onOpenPdf,
        work = { out -> PdfTools.insertPages(ctx, uri, other!!, spec, position ?: pages, out) },
    ) {
        Text("Pages of another PDF are put into this one. This PDF has $pages page(s).", style = MaterialTheme.typography.bodySmall)
        TextButton(onClick = { pick.launch(arrayOf("application/pdf")) }) {
            Icon(Icons.Rounded.Add, null)
            Text(if (other == null) "  Choose the PDF to take pages from" else "  $otherName", maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        OutlinedTextField(
            value = spec,
            onValueChange = { spec = it.filter { c -> c.isDigit() || c == ',' || c == '-' || c == ' ' }.take(60) },
            singleLine = true,
            label = { Text("Pages to take (empty = all)") },
            placeholder = { Text("1-3, 5") },
        )
        OutlinedTextField(
            value = after,
            onValueChange = { after = it.filter(Char::isDigit).take(6) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            label = { Text("Insert after page (0 = at the start)") },
            isError = position == null || position !in 0..pages,
        )
    }
}

@Composable
private fun CompareTool(name: String, uri: Uri, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var report by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { picked ->
        if (picked != null) {
            runCatching { ctx.contentResolver.takePersistableUriPermission(picked, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            val otherName = FileUtils.displayName(ctx, picked)
            busy = true
            scope.launch {
                report = try {
                    val a = PdfTools.pageTexts(ctx, uri)
                    val b = PdfTools.pageTexts(ctx, picked)
                    com.doxsy.app.pdf.PdfCompare.report(name, otherName, com.doxsy.app.pdf.PdfCompare.compare(a, b))
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    "Could not compare these files. A password-protected or damaged PDF cannot be read."
                }
                busy = false
            }
        }
    }
    val r = report
    if (r != null) {
        AlertDialog(
            onDismissRequest = onClose,
            title = { Text("Comparison") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text(r, style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = { TextButton(onClick = onClose) { Text("Close") } },
            dismissButton = {
                TextButton(onClick = {
                    com.doxsy.app.ui.viewer.copyText(ctx, r)
                    FileUtils.toast(ctx, "Report copied")
                }) { Text("Copy") }
            },
        )
    } else {
        AlertDialog(
            onDismissRequest = { if (!busy) onClose() },
            title = { Text("Compare PDFs") },
            text = {
                if (busy) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(14.dp))
                        Text("Comparing…")
                    }
                } else {
                    Text("Choose a second PDF. Doxsy compares the text of both files page by page and lists what is different from \"$name\".")
                }
            },
            confirmButton = {
                TextButton(onClick = { pick.launch(arrayOf("application/pdf")) }, enabled = !busy) { Text("Choose PDF") }
            },
            dismissButton = { TextButton(onClick = onClose, enabled = !busy) { Text("Cancel") } },
        )
    }
}

private class Item(val uri: Uri, val name: String)

@Composable
private fun CombineTool(name: String, uri: Uri, onClose: () -> Unit, onOpenPdf: (Uri) -> Unit) {
    val ctx = LocalContext.current
    val base = name.substringBeforeLast('.')
    val items = remember { mutableStateListOf(Item(uri, name)) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { list ->
        list.forEach { u ->
            runCatching { ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            items.add(Item(u, FileUtils.displayName(ctx, u)))
        }
    }
    SaveTool(
        title = "Combine files",
        confirm = "Choose where to save",
        suggested = "${base}_combined.pdf",
        canConfirm = items.size >= 2,
        onClose = onClose,
        onOpenPdf = onOpenPdf,
        work = { out -> PdfTools.merge(ctx, items.map { it.uri }, out) },
    ) {
        Text("Files are joined in this order. Add at least one more PDF.", style = MaterialTheme.typography.bodySmall)
        items.forEachIndexed { i, item ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "${i + 1}. ${item.name}",
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyMedium,
                )
                IconButton(
                    modifier = Modifier.size(34.dp),
                    enabled = i > 0,
                    onClick = { val x = items.removeAt(i); items.add(i - 1, x) },
                ) { Icon(Icons.Rounded.ArrowUpward, "Move up") }
                IconButton(
                    modifier = Modifier.size(34.dp),
                    enabled = i < items.size - 1,
                    onClick = { val x = items.removeAt(i); items.add(i + 1, x) },
                ) { Icon(Icons.Rounded.ArrowDownward, "Move down") }
                IconButton(
                    modifier = Modifier.size(34.dp),
                    onClick = { items.removeAt(i) },
                ) { Icon(Icons.Rounded.Close, "Remove") }
            }
        }
        TextButton(onClick = { pick.launch(arrayOf("application/pdf")) }) {
            Icon(Icons.Rounded.Add, null)
            Text("  Add PDFs")
        }
    }
}

@Composable
private fun SplitTool(base: String, uri: Uri, pages: Int, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var every by remember { mutableStateOf("1") }
    var busy by remember { mutableStateOf(false) }
    var outcome by remember { mutableStateOf<Outcome?>(null) }
    val n = every.toIntOrNull() ?: 0
    val o = outcome
    if (o != null) {
        ResultDialog(o, onOpen = {}, onClose = onClose)
    } else {
        FormDialog(
            title = "Split PDF",
            confirm = "Split",
            busy = busy,
            canConfirm = n in 1 until pages,
            onClose = onClose,
            onConfirm = {
                busy = true
                scope.launch {
                    val r = PdfTools.split(ctx, uri, n, base)
                    busy = false
                    outcome = Outcome(r, null)
                }
            },
        ) {
            Text("This PDF has $pages pages. How many pages in each new file?", style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(
                value = every,
                onValueChange = { every = it.filter(Char::isDigit).take(4) },
                singleLine = true,
                label = { Text("Pages per file") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            )
            Text(
                "New files are saved in ${OutputStore.label(ctx)}.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun ImagesTool(onClose: () -> Unit, onOpenPdf: (Uri) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var images by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { out ->
        if (out == null) {
            onClose()
        } else {
            busy = true
            scope.launch {
                val r = PdfTools.imagesToPdf(ctx, images, out)
                busy = false
                when (r) {
                    is ToolResult.Done -> {
                        FileUtils.toast(ctx, r.message)
                        onOpenPdf(out)
                    }
                    is ToolResult.Failed -> {
                        FileUtils.toast(ctx, r.message)
                        onClose()
                    }
                }
            }
        }
    }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { list ->
        if (list.isEmpty()) {
            onClose()
        } else {
            images = list
            save.launch("Photos.pdf")
        }
    }
    LaunchedEffect(Unit) { pick.launch(arrayOf("image/*")) }
    if (busy) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Creating PDF") },
            text = { LinearProgressIndicator(Modifier.fillMaxWidth()) },
            confirmButton = {},
        )
    }
}
