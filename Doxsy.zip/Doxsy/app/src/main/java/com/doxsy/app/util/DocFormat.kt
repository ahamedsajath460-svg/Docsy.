package com.doxsy.app.util

import android.content.Context
import android.net.Uri
import android.webkit.MimeTypeMap
import java.util.Locale
import java.util.zip.ZipInputStream

/** How well Doxsy can handle a format inside the app. */
enum class Support { FULL, EXTERNAL_ONLY }

/**
 * Every format the All Documents viewer knows about. [support] is honest: legacy binary Office
 * formats (DOC/XLS/PPT) cannot be rendered by the built-in readers and are [Support.EXTERNAL_ONLY].
 */
enum class DocFormat(val label: String, val exts: Set<String>, val support: Support) {
    PDF("PDF", setOf("pdf"), Support.FULL),
    DOCX("Word (DOCX)", setOf("docx"), Support.FULL),
    DOC("Word 97-2003 (DOC)", setOf("doc"), Support.EXTERNAL_ONLY),
    XLSX("Excel (XLSX)", setOf("xlsx"), Support.FULL),
    XLS("Excel 97-2003 (XLS)", setOf("xls"), Support.EXTERNAL_ONLY),
    PPTX("PowerPoint (PPTX)", setOf("pptx"), Support.FULL),
    PPT("PowerPoint 97-2003 (PPT)", setOf("ppt"), Support.EXTERNAL_ONLY),
    TXT("Text", setOf("txt", "log", "md"), Support.FULL),
    RTF("Rich Text", setOf("rtf"), Support.FULL),
    CSV("CSV", setOf("csv", "tsv"), Support.FULL),
    HTML("HTML", setOf("html", "htm", "xhtml"), Support.FULL),
    XML("XML", setOf("xml"), Support.FULL),
    JSON("JSON", setOf("json"), Support.FULL),
    ODF("OpenDocument (ODT, ODS, ODP)", setOf("odt", "ods", "odp"), Support.FULL),
    EPUB("EPUB book", setOf("epub"), Support.FULL),
    IMAGE("Image", setOf("jpg", "jpeg", "png", "webp", "bmp", "gif", "heic", "heif"), Support.FULL),
    UNKNOWN("Unknown", emptySet(), Support.EXTERNAL_ONLY);

    val inApp: Boolean get() = support == Support.FULL

    companion object {
        fun fromExtension(name: String): DocFormat {
            val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
            if (ext.isEmpty()) return UNKNOWN
            return entries.firstOrNull { ext in it.exts } ?: UNKNOWN
        }

        fun fromMime(mime: String?): DocFormat {
            val m = mime?.lowercase(Locale.ROOT)?.substringBefore(';')?.trim().orEmpty()
            return when {
                m == "application/pdf" -> PDF
                m == "application/vnd.openxmlformats-officedocument.wordprocessingml.document" -> DOCX
                m == "application/msword" -> DOC
                m == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" -> XLSX
                m == "application/vnd.ms-excel" -> XLS
                m == "application/vnd.openxmlformats-officedocument.presentationml.presentation" -> PPTX
                m == "application/vnd.ms-powerpoint" -> PPT
                m == "text/plain" -> TXT
                m == "application/rtf" || m == "text/rtf" -> RTF
                m == "text/csv" || m == "text/comma-separated-values" -> CSV
                m == "text/html" || m == "application/xhtml+xml" -> HTML
                m == "text/xml" || m == "application/xml" -> XML
                m == "application/json" -> JSON
                m == "text/tab-separated-values" -> CSV
                m == "text/markdown" -> TXT
                m == "application/epub+zip" -> EPUB
                m.startsWith("application/vnd.oasis.opendocument.") -> ODF
                m in setOf("image/jpeg", "image/png", "image/webp", "image/bmp", "image/gif", "image/x-ms-bmp", "image/heic", "image/heif") -> IMAGE
                else -> UNKNOWN
            }
        }

        /** Detects by file name first, then MIME type, then by sniffing the first bytes. */
        fun detect(ctx: Context, uri: Uri, nameHint: String? = null): DocFormat {
            val name = nameHint ?: FileUtils.displayName(ctx, uri)
            fromExtension(name).let { if (it != UNKNOWN) return it }
            val mime = runCatching { ctx.contentResolver.getType(uri) }.getOrNull()
                ?: MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', ""))
            fromMime(mime).let { if (it != UNKNOWN) return it }
            return sniff(ctx, uri)
        }

        private fun sniff(ctx: Context, uri: Uri): DocFormat = runCatching {
            val head = ByteArray(8)
            val n = ctx.contentResolver.openInputStream(uri)?.use { it.read(head) } ?: return UNKNOWN
            if (n < 4) return UNKNOWN
            val b = head.map { it.toInt() and 0xFF }
            when {
                b[0] == 0x25 && b[1] == 0x50 && b[2] == 0x44 && b[3] == 0x46 -> PDF
                b[0] == 0x89 && b[1] == 0x50 && b[2] == 0x4E && b[3] == 0x47 -> IMAGE
                b[0] == 0xFF && b[1] == 0xD8 -> IMAGE
                b[0] == 0x47 && b[1] == 0x49 && b[2] == 0x46 -> IMAGE
                b[0] == 0x42 && b[1] == 0x4D -> IMAGE
                b[0] == 0x52 && b[1] == 0x49 && b[2] == 0x46 && b[3] == 0x46 -> IMAGE // RIFF/WEBP
                b[0] == 0x7B && b[1] == 0x5C && b[2] == 0x72 -> RTF // {\rt
                b[0] == 0x50 && b[1] == 0x4B -> sniffZip(ctx, uri)
                else -> UNKNOWN
            }
        }.getOrDefault(UNKNOWN)

        private fun sniffZip(ctx: Context, uri: Uri): DocFormat {
            ctx.contentResolver.openInputStream(uri)?.use { raw ->
                ZipInputStream(raw).use { zip ->
                    var count = 0
                    var e = zip.nextEntry
                    while (e != null && count < 40) {
                        val n = e.name
                        when {
                            n.startsWith("word/") -> return DOCX
                            n.startsWith("xl/") -> return XLSX
                            n.startsWith("ppt/") -> return PPTX
                            n == "mimetype" -> {
                                val t = String(zip.readBytes(), Charsets.US_ASCII).trim()
                                if (t == "application/epub+zip") return EPUB
                                if (t.startsWith("application/vnd.oasis.opendocument.")) return ODF
                            }
                        }
                        count++
                        e = zip.nextEntry
                    }
                }
            }
            return UNKNOWN
        }
    }
}
