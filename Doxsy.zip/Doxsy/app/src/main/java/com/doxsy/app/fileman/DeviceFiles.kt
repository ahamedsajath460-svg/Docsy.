package com.doxsy.app.fileman

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.webkit.MimeTypeMap
import androidx.core.content.ContextCompat
import com.doxsy.app.data.DocEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.util.Locale

/** Finds the PDFs and documents that already exist on the phone (needs storage access). */
object DeviceFiles {
    private val EXTS = listOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "odt")
    private const val LIMIT = 2000

    private val _files = MutableStateFlow<List<DocEntry>>(emptyList())
    /** Result of the latest scan, newest first. Shared by Home and Search. */
    val files: StateFlow<List<DocEntry>> = _files

    private val _mail = MutableStateFlow<List<DocEntry>>(emptyList())
    /** PDFs that look like downloaded e-mail attachments (Downloads / Gmail / Attachments folders). */
    val emailFiles: StateFlow<List<DocEntry>> = _mail

    fun hasAccess(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED
        }

    /** Android 11+: the "All files access" screen for this app. */
    fun settingsIntent(ctx: Context): Intent {
        val pkg = Uri.parse("package:${ctx.packageName}")
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, pkg)
        } else {
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg)
        }
    }

    /** The MediaStore content:// URI of a file on disk, if it is indexed. */
    fun contentUriFor(ctx: Context, file: java.io.File): Uri? = runCatching {
        val base = MediaStore.Files.getContentUri("external")
        ctx.contentResolver.query(
            base,
            arrayOf(MediaStore.Files.FileColumns._ID),
            "${MediaStore.Files.FileColumns.DATA}=?",
            arrayOf(file.absolutePath),
            null,
        )?.use { c -> if (c.moveToFirst()) ContentUris.withAppendedId(base, c.getLong(0)) else null }
    }.getOrNull()

    fun mimeOf(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
    }

    suspend fun scan(ctx: Context): List<DocEntry> = withContext(Dispatchers.IO) {
        val out = ArrayList<DocEntry>()
        val mail = ArrayList<DocEntry>()
        if (hasAccess(ctx)) {
            runCatching {
                val base = MediaStore.Files.getContentUri("external")
                val nameCol = MediaStore.Files.FileColumns.DISPLAY_NAME
                val sizeCol = MediaStore.Files.FileColumns.SIZE
                val dateCol = MediaStore.Files.FileColumns.DATE_MODIFIED
                val like = EXTS.joinToString(" OR ") { "$nameCol LIKE ?" }
                val args = EXTS.map { "%.$it" }.toTypedArray()
                ctx.contentResolver.query(
                    base,
                    arrayOf(MediaStore.Files.FileColumns._ID, nameCol, dateCol, MediaStore.Files.FileColumns.DATA),
                    "$sizeCol > 0 AND ($like)",
                    args,
                    "$dateCol DESC",
                )?.use { c ->
                    while (c.moveToNext() && out.size < LIMIT) {
                        val name = c.getString(1) ?: continue
                        val uri = ContentUris.withAppendedId(base, c.getLong(0))
                        val entry = DocEntry(uri.toString(), name, c.getLong(2) * 1000L, 0)
                        out += entry
                        val path = (c.getString(3) ?: "").lowercase(Locale.ROOT)
                        if (path.endsWith(".pdf") &&
                            ("/download" in path || "gmail" in path || "mail" in path || "attachment" in path)
                        ) mail += entry
                    }
                }
            }
        }
        _files.value = out
        _mail.value = mail
        out
    }
}
