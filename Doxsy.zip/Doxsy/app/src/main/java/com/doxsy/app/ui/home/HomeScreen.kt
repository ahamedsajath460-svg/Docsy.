package com.doxsy.app.ui.home

import android.Manifest
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.doxsy.app.fileman.DeviceFiles
import androidx.compose.material3.Button
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items as rowItems
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.RemoveCircleOutline
import androidx.compose.material.icons.rounded.SelectAll
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.ViewList
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.doxsy.app.data.DocEntry
import com.doxsy.app.data.Prefs
import com.doxsy.app.ui.AvatarButton
import com.doxsy.app.ui.DoxsyLogo
import com.doxsy.app.ui.MenuAction
import com.doxsy.app.util.FileUtils
import kotlinx.coroutines.delay

private enum class PromoTarget { TOOLS, OPEN }

private data class Promo(
    val id: String,
    val title: String,
    val desc: String,
    val action: String,
    val icon: ImageVector,
    val tint: Color,
    val bg: Color,
    val target: PromoTarget,
)

private val Promos = listOf(
    Promo(
        "images", "Turn photos into PDFs", "Combine your pictures into a single PDF file.",
        "Open Tools", Icons.Rounded.Image, Color(0xFF1B8A7A), Color(0xFFE0F2EF), PromoTarget.TOOLS,
    ),
    Promo(
        "tools", "Merge, compress and more", "Combine, compress and protect your PDFs.",
        "Open Tools", Icons.Rounded.Build, Color(0xFFFFFFFF), Color(0xFF2F6BFF), PromoTarget.TOOLS,
    ),
    Promo(
        "edit", "Easily edit PDFs", "Highlight, draw and sign right inside your PDFs.",
        "Open a PDF", Icons.Rounded.Edit, Color(0xFFC2308C), Color(0xFFF7E3EF), PromoTarget.OPEN,
    ),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    prefs: Prefs,
    onPickPdf: () -> Unit,
    onOpen: (DocEntry) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenTools: () -> Unit,
) {
    val ctx = LocalContext.current
    val recents by prefs.recents.state.collectAsState()
    val favourites by prefs.favourites.state.collectAsState()
    val grid by prefs.homeGrid.state.collectAsState()
    val dismissed by prefs.dismissedPromos.state.collectAsState()
    val tipShown by prefs.tipShown.state.collectAsState()

    val device by DeviceFiles.files.collectAsState()
    var hasAccess by remember { mutableStateOf(DeviceFiles.hasAccess(ctx)) }
    var tick by remember { mutableIntStateOf(0) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    val settingsLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { tick++ }
    fun requestAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            runCatching { settingsLauncher.launch(DeviceFiles.settingsIntent(ctx)) }
        } else {
            permLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    // Come back from the permission screen / viewer: re-check access and rescan the phone.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }
    LaunchedEffect(tick) {
        hasAccess = DeviceFiles.hasAccess(ctx)
        DeviceFiles.scan(ctx)
    }
    // Ask once, right after the first start, like the video's first screen.
    LaunchedEffect(Unit) {
        if (!DeviceFiles.hasAccess(ctx) && !prefs.scanAsked.value) {
            prefs.scanAsked.value = true
            requestAccess()
        }
    }

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showSheet by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }
    val selected = remember { mutableStateListOf<String>() }
    val selecting = selected.isNotEmpty()

    // Recent = files opened in Doxsy (newest first, on top) followed by everything else on the phone.
    val recentAll = remember(recents, device) {
        val seen = recents.map { it.name.lowercase() }.toSet()
        recents + device.filter { it.name.lowercase() !in seen }
    }
    val list = if (tab == 0) recentAll else favourites
    val visiblePromos = Promos.filter { it.id !in dismissed }

    BackHandler(enabled = selecting) { selected.clear() }

    // The "Open a file to get started" bubble fades away by itself after a few seconds.
    LaunchedEffect(tipShown) {
        if (!tipShown) {
            delay(7000)
            prefs.tipShown.value = true
        }
    }

    fun removeSelected() {
        val uris = selected.toList()
        if (tab == 0) uris.forEach { prefs.removeRecent(it) }
        else favourites.filter { it.uri in uris }.forEach { prefs.toggleFavourite(it) }
        selected.clear()
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            // Fixed top bar (turns into a selection bar when files are selected)
            if (selecting) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = { selected.clear() }) { Icon(Icons.Rounded.Close, "Cancel selection") }
                    Text(
                        "${selected.size} selected",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.weight(1f),
                    )
                    IconButton(onClick = { selected.clear(); selected.addAll(list.map { it.uri }) }) {
                        Icon(Icons.Rounded.SelectAll, "Select all")
                    }
                    IconButton(onClick = ::removeSelected) {
                        Icon(Icons.Rounded.Delete, if (tab == 0) "Remove from recent" else "Remove from starred")
                    }
                }
            } else {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .padding(start = 16.dp, end = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    DoxsyLogo(30.dp)
                    Spacer(Modifier.weight(1f))
                    AvatarButton(onClick = onOpenSettings)
                }
            }

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = if (grid) 10.dp else 0.dp, bottom = 110.dp),
            ) {
                if (!selecting) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Text(
                            "Welcome",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(start = if (grid) 6.dp else 16.dp, top = 8.dp, bottom = 16.dp),
                        )
                    }
                    if (visiblePromos.isNotEmpty()) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = if (grid) 6.dp else 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                rowItems(visiblePromos, key = { it.id }) { p ->
                                    PromoCard(
                                        p,
                                        onDismiss = { prefs.dismissPromo(p.id) },
                                        onAction = {
                                            if (p.target == PromoTarget.TOOLS) onOpenTools() else onPickPdf()
                                        },
                                    )
                                }
                            }
                        }
                    }
                }

                item(span = { GridItemSpan(maxLineSpan) }) {
                    TabStrip(
                        tab = tab,
                        sidePad = if (grid) 6 else 16,
                        onTab = { tab = it; selected.clear() },
                        onMore = { showSheet = true },
                    )
                }

                if (tab == 0 && !hasAccess && !selecting) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        AccessCard(onAllow = ::requestAccess)
                    }
                }

                if (list.isEmpty()) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        EmptyList(
                            icon = if (tab == 0) Icons.Rounded.Description else Icons.Rounded.StarBorder,
                            title = if (tab == 0) "No recent files" else "No starred files",
                            message = if (tab == 0) "Any files you've worked with recently will appear here."
                            else "Star a file to easily find it here later.",
                        )
                    }
                } else {
                    items(
                        list,
                        key = { (if (tab == 0) "r" else "s") + it.uri },
                        span = { if (grid) GridItemSpan(1) else GridItemSpan(maxLineSpan) },
                    ) { e ->
                        val isStar = favourites.any { it.uri == e.uri }
                        val menu = buildList {
                            add(MenuAction(if (isStar) "Remove star" else "Add star") { prefs.toggleFavourite(e) })
                            add(MenuAction("Share") { FileUtils.share(ctx, Uri.parse(e.uri), DeviceFiles.mimeOf(e.name)) })
                            if (tab == 0 && recents.any { it.uri == e.uri }) add(MenuAction("Remove from recent") { prefs.removeRecent(e.uri) })
                        }
                        val isSel = e.uri in selected
                        val toggle = { if (isSel) selected.remove(e.uri) else selected.add(e.uri); Unit }
                        val click = { if (selecting) toggle() else onOpen(e) }
                        val long = { if (!isSel) selected.add(e.uri); Unit }
                        if (grid) DocGridCard(e, selecting, isSel, click, long, menu)
                        else DocListRow(e, selecting, isSel, click, long, menu)
                    }
                }
            }
        }

        // Floating "+" button with the first-run hint bubble
        AnimatedVisibility(
            visible = !tipShown,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 92.dp, bottom = 34.dp),
        ) {
            Box(
                Modifier
                    .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(8.dp))
                    .clickable { prefs.tipShown.value = true }
                    .padding(horizontal = 16.dp, vertical = 10.dp),
            ) {
                Text("Open a file to get started", color = MaterialTheme.colorScheme.onPrimary, fontSize = 14.sp)
            }
        }
        FloatingActionButton(
            onClick = { prefs.tipShown.value = true; onPickPdf() },
            shape = CircleShape,
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp),
        ) { Icon(Icons.Rounded.Add, "Open a file") }
    }

    if (showSheet) {
        ModalBottomSheet(
            onDismissRequest = { showSheet = false },
            sheetState = rememberModalBottomSheetState(),
        ) {
            SheetRow(Icons.Rounded.SelectAll, "Select all") {
                showSheet = false
                selected.clear()
                selected.addAll(list.map { it.uri })
            }
            SheetRow(
                if (grid) Icons.Rounded.ViewList else Icons.Rounded.GridView,
                if (grid) "List view" else "Grid view",
            ) {
                showSheet = false
                prefs.homeGrid.value = !grid
            }
            if (tab == 0) {
                SheetRow(Icons.Rounded.RemoveCircleOutline, "Clear recent") {
                    showSheet = false
                    confirmClear = true
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear recent") },
            text = { Text("Are you sure you want to clear the list of recent files?") },
            confirmButton = {
                TextButton(onClick = { confirmClear = false; selected.clear(); prefs.clearRecents() }) {
                    Text("Clear", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun PromoCard(p: Promo, onDismiss: () -> Unit, onAction: () -> Unit) {
    Card(
        modifier = Modifier
            .width(300.dp)
            .height(108.dp),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Row(Modifier.fillMaxSize()) {
            Box(
                Modifier
                    .width(64.dp)
                    .fillMaxHeight()
                    .background(p.bg),
                contentAlignment = Alignment.Center,
            ) { Icon(p.icon, null, tint = p.tint, modifier = Modifier.size(30.dp)) }
            Column(
                Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .padding(start = 12.dp, end = 8.dp, top = 10.dp, bottom = 8.dp),
            ) {
                Row(verticalAlignment = Alignment.Top) {
                    Text(
                        p.title,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    Icon(
                        Icons.Rounded.Close,
                        "Dismiss",
                        modifier = Modifier
                            .size(18.dp)
                            .clickable(onClick = onDismiss),
                    )
                }
                Text(
                    p.desc,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 2.dp),
                )
                Spacer(Modifier.weight(1f))
                Text(
                    p.action,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .align(Alignment.End)
                        .clickable(onClick = onAction),
                )
            }
        }
    }
}

@Composable
private fun TabStrip(tab: Int, sidePad: Int, onTab: (Int) -> Unit, onMore: () -> Unit) {
    Column(Modifier.padding(top = 20.dp)) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = sidePad.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TabLabel("Recent", tab == 0) { onTab(0) }
            Spacer(Modifier.width(20.dp))
            TabLabel("Starred", tab == 1) { onTab(1) }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onMore) { Icon(Icons.Rounded.MoreVert, "More options") }
        }
        Box(
            Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(MaterialTheme.colorScheme.outlineVariant),
        )
    }
}

@Composable
private fun TabLabel(text: String, selected: Boolean, onClick: () -> Unit) {
    Column(
        Modifier
            .clickable(onClick = onClick)
            .padding(top = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            color = if (selected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(10.dp))
        Box(
            Modifier
                .width(if (selected) 40.dp else 0.dp)
                .height(2.dp)
                .background(if (selected) MaterialTheme.colorScheme.onSurface else Color.Transparent),
        )
    }
}

@Composable
private fun SheetRow(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(18.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
fun EmptyList(icon: ImageVector, title: String, message: String) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 40.dp, vertical = 48.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(96.dp))
        Spacer(Modifier.height(20.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        Text(
            message,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun AccessCard(onAllow: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.FolderOpen, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(12.dp))
                Text(
                    "Show all documents on this phone",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(
                "Allow access so your PDFs and documents appear here automatically. Files stay on your phone.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
            )
            Spacer(Modifier.height(10.dp))
            Button(onClick = onAllow, modifier = Modifier.align(Alignment.End)) { Text("Allow access") }
        }
    }
}
