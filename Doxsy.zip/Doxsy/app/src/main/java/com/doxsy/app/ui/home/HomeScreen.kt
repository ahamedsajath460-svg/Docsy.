package com.doxsy.app.ui.home

import android.Manifest
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.doxsy.app.fileman.DeviceFiles
import androidx.compose.material3.Button
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandIn
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items as rowItems
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.material3.pulltorefresh.PullToRefreshContainer
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Compress
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.AddPhotoAlternate
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.RemoveCircleOutline
import androidx.compose.material.icons.rounded.SelectAll
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.ViewList
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.doxsy.app.cloud.Accounts
import com.doxsy.app.data.DocEntry
import com.doxsy.app.data.PROMO_RETURN_MS
import com.doxsy.app.data.Prefs
import com.doxsy.app.ui.AvatarButton
import com.doxsy.app.ui.ConfirmDialog
import com.doxsy.app.ui.DoxsyLogo
import com.doxsy.app.ui.MenuAction
import com.doxsy.app.util.FileUtils
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private enum class PromoTarget { OPEN, LOGIN, AI }

private data class Promo(
    val id: String,
    val title: String,
    val desc: String,
    val action: String,
    val icon: ImageVector,
    val tint: Color,
    val bg: Color,
    val target: PromoTarget,
)

private val Promos = listOf(
    Promo(
        "login", "Sign in to do more", "Access saved files and your account features from any device.",
        "Sign In", Icons.Rounded.AccountCircle, Color(0xFF6B6F80), Color(0xFFECEEF3), PromoTarget.LOGIN,
    ),
    Promo(
        "edit", "Easily edit PDFs", "Highlight, draw and sign right inside your PDFs.",
        "Open a PDF", Icons.Rounded.Edit, Color(0xFFC2308C), Color(0xFFF7E3EF), PromoTarget.OPEN,
    ),
    Promo(
        "ai", "Ask Doxsy AI", "Summarise, translate or ask questions about any of your documents.",
        "Ask AI", Icons.Rounded.AutoAwesome, Color(0xFF6C4DD8), Color(0xFFEBE5FA), PromoTarget.AI,
    ),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    prefs: Prefs,
    onPickPdf: () -> Unit,
    onOpen: (DocEntry) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenAi: () -> Unit = {},
    onPickDocuments: () -> Unit = {},
    onNewText: () -> Unit = {},
) {
    val ctx = LocalContext.current
    val fabScope = androidx.compose.runtime.rememberCoroutineScope()

    // "Create PDF": choose pictures, choose where to save, make one PDF (one picture per page), open it.
    var pdfPhotos by remember { mutableStateOf<List<android.net.Uri>>(emptyList()) }
    var pdfBusy by remember { mutableStateOf(false) }
    val savePdf = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { out ->
        val photos = pdfPhotos
        pdfPhotos = emptyList()
        if (out != null && photos.isNotEmpty()) {
            pdfBusy = true
            fabScope.launch {
                val r = com.doxsy.app.pdf.PdfTools.imagesToPdf(ctx, photos, out)
                pdfBusy = false
                when (r) {
                    is com.doxsy.app.pdf.ToolResult.Done -> {
                        FileUtils.toast(ctx, r.message)
                        onOpen(DocEntry(out.toString(), FileUtils.displayName(ctx, out)))
                    }
                    is com.doxsy.app.pdf.ToolResult.Failed -> FileUtils.toast(ctx, r.message)
                }
            }
        }
    }
    var showCreate by remember { mutableStateOf(false) }
    val newPdf = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { out ->
        if (out != null) {
            fabScope.launch {
                if (com.doxsy.app.util.NewFiles.blankPdf(ctx, out)) {
                    onOpen(DocEntry(out.toString(), FileUtils.displayName(ctx, out)))
                } else {
                    FileUtils.toast(ctx, "Could not create the PDF")
                }
            }
        }
    }
    val newDocx = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument(com.doxsy.app.util.NewFiles.DOCX_MIME),
    ) { out ->
        if (out != null) {
            fabScope.launch {
                if (com.doxsy.app.util.NewFiles.blankDocx(ctx, out)) {
                    prefs.addRecent(out.toString(), FileUtils.displayName(ctx, out), 0)
                    com.doxsy.app.util.NewFiles.editExternal(ctx, out, com.doxsy.app.util.NewFiles.DOCX_MIME)
                } else {
                    FileUtils.toast(ctx, "Could not create the document")
                }
            }
        }
    }
    val newXlsx = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument(com.doxsy.app.util.NewFiles.XLSX_MIME),
    ) { out ->
        if (out != null) {
            fabScope.launch {
                if (com.doxsy.app.util.NewFiles.blankXlsx(ctx, out)) {
                    prefs.addRecent(out.toString(), FileUtils.displayName(ctx, out), 0)
                    com.doxsy.app.util.NewFiles.editExternal(ctx, out, com.doxsy.app.util.NewFiles.XLSX_MIME)
                } else {
                    FileUtils.toast(ctx, "Could not create the spreadsheet")
                }
            }
        }
    }
    val pickPhotos = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { list ->
        if (list.isNotEmpty()) {
            pdfPhotos = list
            savePdf.launch("Photos.pdf")
        }
    }
    val recents by prefs.recents.state.collectAsState()
    val favourites by prefs.favourites.state.collectAsState()
    val grid by prefs.homeGrid.state.collectAsState()
    val dismissed by prefs.dismissedPromos.state.collectAsState()
    val user by Accounts.user.collectAsState()
    // Closed cards come back 2 hours later; re-check every minute and when the app is reopened.
    var nowMs by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(60_000)
            nowMs = System.currentTimeMillis()
        }
    }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { nowMs = System.currentTimeMillis() }
    val tipShown by prefs.tipShown.state.collectAsState()

    val device by DeviceFiles.files.collectAsState()
    var hasAccess by remember { mutableStateOf(DeviceFiles.hasAccess(ctx)) }
    var tick by remember { mutableIntStateOf(0) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    val settingsLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { tick++ }
    fun requestAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            runCatching { settingsLauncher.launch(DeviceFiles.settingsIntent(ctx)) }
        } else {
            permLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    // Come back from the permission screen / viewer: re-check access and rescan the phone.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }
    LaunchedEffect(tick) {
        hasAccess = DeviceFiles.hasAccess(ctx)
        DeviceFiles.scan(ctx)
    }
    // Ask once, right after the first start, like the video's first screen.
    LaunchedEffect(Unit) {
        if (!DeviceFiles.hasAccess(ctx) && !prefs.scanAsked.value) {
            prefs.scanAsked.value = true
            requestAccess()
        }
    }

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showSheet by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }
    var confirmRemoveSel by remember { mutableStateOf(false) }
    var fabOpen by remember { mutableStateOf(false) }
    val compress = rememberCompressState()
    val selected = remember { mutableStateListOf<String>() }
    val selecting = selected.isNotEmpty()

    // Recent = files opened in Doxsy (newest first, on top) followed by everything else on the phone.
    val recentAll = remember(recents, device) {
        val seen = recents.map { it.name.lowercase() }.toSet()
        recents + device.filter { it.name.lowercase() !in seen }
    }
    val list = if (tab == 0) recentAll else favourites
    val categories = remember(list, device, recents, tab) {
        val withF = withFolders(list, device)
        if (tab == 0) {
            val recentUris = recents.map { it.uri }.toSet()
            groupByFolder(withF, withF.filter { it.uri in recentUris })
        } else groupByFolder(withF)
    }
    val fileMenu = rememberFileMenuState()
    val visiblePromos = Promos.filter { p ->
        val closedAt = dismissed[p.id]
        val hidden = closedAt != null && nowMs - closedAt in 0 until PROMO_RETURN_MS
        // The sign-in card is only for people who are not signed in.
        !hidden && (p.target != PromoTarget.LOGIN || user == null)
    }

    BackHandler(enabled = selecting) { selected.clear() }
    BackHandler(enabled = fabOpen) { fabOpen = false }

    // The "Open a file to get started" bubble fades away by itself after a few seconds.
    LaunchedEffect(tipShown) {
        if (!tipShown) {
            delay(7000)
            prefs.tipShown.value = true
        }
    }

    fun removeSelected() {
        val uris = selected.toList()
        if (tab == 0) uris.forEach { prefs.removeRecent(it) }
        else favourites.filter { it.uri in uris }.forEach { prefs.toggleFavourite(it) }
        selected.clear()
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            // Fixed top bar (turns into a selection bar when files are selected)
            if (selecting) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = { selected.clear() }) { Icon(Icons.Rounded.Close, "Cancel selection") }
                    Text(
                        "${selected.size} selected",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.weight(1f),
                    )
                    IconButton(onClick = { selected.clear(); selected.addAll(list.map { it.uri }) }) {
                        Icon(Icons.Rounded.SelectAll, "Select all")
                    }
                    IconButton(onClick = { confirmRemoveSel = true }) {
                        Icon(Icons.Rounded.Delete, if (tab == 0) "Remove from recent" else "Remove from starred")
                    }
                }
            } else {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .padding(start = 16.dp, end = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    DoxsyLogo(30.dp)
                    Spacer(Modifier.weight(1f))
                    AvatarButton(onClick = onOpenSettings)
                }
            }

            val pullState = rememberPullToRefreshState()
            if (pullState.isRefreshing) {
                LaunchedEffect(true) {
                    hasAccess = DeviceFiles.hasAccess(ctx)
                    DeviceFiles.scan(ctx)
                    nowMs = System.currentTimeMillis()
                    pullState.endRefresh()
                }
            }
            Box(Modifier.weight(1f).nestedScroll(pullState.nestedScrollConnection)) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(
                    start = if (grid) 10.dp else 0.dp,
                    end = if (grid) 10.dp else 0.dp,
                    bottom = 110.dp,
                ),
            ) {
                if (!selecting) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Text(
                            "Welcome",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(start = if (grid) 6.dp else 16.dp, top = 8.dp, bottom = 16.dp),
                        )
                    }
                    if (visiblePromos.isNotEmpty()) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = if (grid) 6.dp else 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                rowItems(visiblePromos, key = { it.id }) { p ->
                                    PromoCard(
                                        p,
                                        onDismiss = { prefs.dismissPromo(p.id) },
                                        onAction = {
                                            when (p.target) {
                                                PromoTarget.OPEN -> onPickPdf()
                                                PromoTarget.LOGIN -> onOpenSettings()
                                                PromoTarget.AI -> onOpenAi()
                                            }
                                        },
                                    )
                                }
                            }
                        }
                    }
                }

                item(span = { GridItemSpan(maxLineSpan) }) {
                    TabStrip(
                        tab = tab,
                        sidePad = if (grid) 6 else 16,
                        onTab = { tab = it; selected.clear() },
                        onMore = { showSheet = true },
                    )
                }

                if (tab == 0 && !hasAccess && !selecting) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        AccessCard(onAllow = ::requestAccess)
                    }
                }

                if (list.isEmpty()) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        EmptyList(
                            icon = if (tab == 0) Icons.Rounded.Description else Icons.Rounded.StarBorder,
                            title = if (tab == 0) "No recent files" else "No starred files",
                            message = if (tab == 0) "Any files you've worked with recently will appear here."
                            else "Star a file to easily find it here later.",
                        )
                    }
                } else {
                    categories.forEach { cat ->
                        item(key = "h_" + tab + cat.title, span = { GridItemSpan(maxLineSpan) }) {
                            CategoryHeader(cat.title, sidePad = if (grid) 6 else 16)
                        }
                        items(
                            cat.files,
                            key = { (if (tab == 0) "r" else "s") + cat.title + it.uri },
                            span = { if (grid) GridItemSpan(1) else GridItemSpan(maxLineSpan) },
                        ) { e ->
                            val isSel = e.uri in selected
                            val toggle = { if (isSel) selected.remove(e.uri) else selected.add(e.uri); Unit }
                            val click = { if (selecting) toggle() else onOpen(e) }
                            val long = { if (!isSel) selected.add(e.uri); Unit }
                            val more = { fileMenu.show(e) }
                            if (grid) DocGridCard(e, selecting, isSel, click, long, emptyList(), more)
                            else DocListRow(e, selecting, isSel, click, long, emptyList(), more)
                        }
                    }
                }
            }
                if (pullState.progress > 0f || pullState.isRefreshing) {
                    PullToRefreshContainer(state = pullState, modifier = Modifier.align(Alignment.TopCenter))
                }
            }
        }

        // Floating "+" button with the first-run hint bubble
        AnimatedVisibility(
            visible = !tipShown,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 92.dp, bottom = 34.dp),
        ) {
            Box(
                Modifier
                    .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(8.dp))
                    .clickable { prefs.tipShown.value = true }
                    .padding(horizontal = 16.dp, vertical = 10.dp),
            ) {
                Text("Open a file to get started", color = MaterialTheme.colorScheme.onPrimary, fontSize = 14.sp)
            }
        }
        // Tap outside the little menu to close it
        if (fabOpen) {
            Box(
                Modifier
                    .fillMaxSize()
                                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { fabOpen = false },
            )
        }
        // The "+" button and its menu are ONE coloured pill: the menu icons sit right above the
        // + / x button and are joined to it, so it looks like a single piece that grows upward.
        Surface(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp),
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            shadowElevation = 8.dp,
        ) {
            Column(
                Modifier
                    .width(if (fabOpen) 76.dp else 56.dp)
                    .animateContentSize(tween(160)),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                if (fabOpen) {
                    FabMenuItem(Icons.Rounded.AutoAwesome, "Doxsy AI") { fabOpen = false; onOpenAi() }
                    FabMenuItem(Icons.Rounded.FolderOpen, "Open file") { fabOpen = false; onPickPdf() }
                    FabMenuItem(Icons.Rounded.Add, "Create new") { fabOpen = false; showCreate = true }
                }
                Box(
                    Modifier
                        .size(56.dp)
                        .clickable { prefs.tipShown.value = true; fabOpen = !fabOpen },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        if (fabOpen) Icons.Rounded.Close else Icons.Rounded.Add,
                        if (fabOpen) "Close menu" else "Add",
                        tint = MaterialTheme.colorScheme.onPrimary,
                    )
                }
            }
        }

        if (pdfBusy) {
            androidx.compose.material3.AlertDialog(
                onDismissRequest = {},
                title = { Text("Creating PDF") },
                text = { androidx.compose.material3.LinearProgressIndicator(Modifier.fillMaxWidth()) },
                confirmButton = {},
            )
        }

        CompressHost(compress, onOpenPdf = { uri, name -> onOpen(DocEntry(uri.toString(), name)) })
        FileMenuHost(fileMenu, prefs, onOpen = onOpen)
    }

    if (showCreate) {
        ModalBottomSheet(onDismissRequest = { showCreate = false }) {
            Text(
                "Create new",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
            )
            SheetRow(Icons.Rounded.PictureAsPdf, "PDF  ·  blank page") {
                showCreate = false
                newPdf.launch("Untitled.pdf")
            }
            SheetRow(Icons.Rounded.Description, "Word document  ·  blank") {
                showCreate = false
                newDocx.launch("Untitled.docx")
            }
            SheetRow(Icons.Rounded.GridView, "Excel sheet  ·  blank") {
                showCreate = false
                newXlsx.launch("Untitled.xlsx")
            }
            SheetRow(Icons.Rounded.Edit, "Text file  ·  blank") {
                showCreate = false
                onNewText()
            }
            SheetRow(Icons.Rounded.AddPhotoAlternate, "PDF from photos") {
                showCreate = false
                pickPhotos.launch(arrayOf("image/*"))
            }
            SheetRow(Icons.Rounded.Compress, "Compress PDFs  ·  one or many") {
                showCreate = false
                compress.begin()
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (showSheet) {
        ModalBottomSheet(
            onDismissRequest = { showSheet = false },
            sheetState = rememberModalBottomSheetState(),
        ) {
            SheetRow(Icons.Rounded.SelectAll, "Select all") {
                showSheet = false
                selected.clear()
                selected.addAll(list.map { it.uri })
            }
            SheetRow(
                if (grid) Icons.Rounded.ViewList else Icons.Rounded.GridView,
                if (grid) "List view" else "Grid view",
            ) {
                showSheet = false
                prefs.homeGrid.value = !grid
            }
            if (tab == 0) {
                SheetRow(Icons.Rounded.RemoveCircleOutline, "Clear recent") {
                    showSheet = false
                    confirmClear = true
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (confirmRemoveSel) {
        val n = selected.size
        ConfirmDialog(
            title = if (tab == 0) "Remove from recent" else "Remove star",
            message = if (tab == 0) "$n file(s) will be removed from the recent list. The files stay on your phone."
            else "$n file(s) will be removed from your starred files.",
            confirmLabel = "Remove",
            onDismiss = { confirmRemoveSel = false },
            onConfirm = { confirmRemoveSel = false; removeSelected() },
        )
    }

    if (confirmClear) {
        ConfirmDialog(
            title = "Clear recent",
            message = "Are you sure you want to clear the list of recent files?",
            confirmLabel = "Clear",
            onDismiss = { confirmClear = false },
            onConfirm = { confirmClear = false; selected.clear(); prefs.clearRecents() },
        )
    }
}

@Composable
private fun PromoCard(p: Promo, onDismiss: () -> Unit, onAction: () -> Unit) {
    Card(
        modifier = Modifier
            .width(340.dp)
            .height(136.dp),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Row(Modifier.fillMaxSize()) {
            Box(
                Modifier
                    .width(84.dp)
                    .fillMaxHeight()
                    .background(p.bg),
                contentAlignment = Alignment.Center,
            ) { Icon(p.icon, null, tint = p.tint, modifier = Modifier.size(38.dp)) }
            Column(
                Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .padding(start = 14.dp, end = 10.dp, top = 12.dp, bottom = 10.dp),
            ) {
                Row(verticalAlignment = Alignment.Top) {
                    Text(
                        p.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    Icon(
                        Icons.Rounded.Close,
                        "Dismiss",
                        modifier = Modifier
                            .size(22.dp)
                            .clickable(onClick = onDismiss),
                    )
                }
                Text(
                    p.desc,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 2.dp),
                )
                Spacer(Modifier.weight(1f))
                Text(
                    p.action,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .align(Alignment.End)
                        .clickable(onClick = onAction),
                )
            }
        }
    }
}

@Composable
private fun TabStrip(tab: Int, sidePad: Int, onTab: (Int) -> Unit, onMore: () -> Unit) {
    Column(Modifier.padding(top = 20.dp)) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = sidePad.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TabLabel("Recent", tab == 0) { onTab(0) }
            Spacer(Modifier.width(20.dp))
            TabLabel("Starred", tab == 1) { onTab(1) }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onMore) { Icon(Icons.Rounded.MoreVert, "More options") }
        }
        Box(
            Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(MaterialTheme.colorScheme.outlineVariant),
        )
    }
}

@Composable
private fun TabLabel(text: String, selected: Boolean, onClick: () -> Unit) {
    Column(
        Modifier
            .clickable(onClick = onClick)
            .padding(top = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            color = if (selected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(10.dp))
        Box(
            Modifier
                .width(if (selected) 40.dp else 0.dp)
                .height(2.dp)
                .background(if (selected) MaterialTheme.colorScheme.onSurface else Color.Transparent),
        )
    }
}

@Composable
private fun SheetRow(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(18.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
fun EmptyList(icon: ImageVector, title: String, message: String) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 40.dp, vertical = 48.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(96.dp))
        Spacer(Modifier.height(20.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        Text(
            message,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun AccessCard(onAllow: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.FolderOpen, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(12.dp))
                Text(
                    "Show all documents on this phone",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(
                "Allow access so your PDFs and documents appear here automatically. Files stay on your phone.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
            )
            Spacer(Modifier.height(10.dp))
            Button(onClick = onAllow, modifier = Modifier.align(Alignment.End)) { Text("Allow access") }
        }
    }
}

@Composable
private fun FabMenuItem(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .height(64.dp)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.onPrimary)
        Text(
            label,
            fontSize = 10.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            color = MaterialTheme.colorScheme.onPrimary,
        )
    }
}
