package com.doxsy.app.ui.docview

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material.icons.rounded.ZoomIn
import androidx.compose.material.icons.rounded.ZoomOut
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.doxsy.app.util.DocFormat
import com.doxsy.app.util.FileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private sealed interface LoadState {
    data object Loading : LoadState
    class Failed(val message: String) : LoadState
    class Ready(val loaded: Loaded) : LoadState
}

/**
 * Opens one non-PDF document (Word, Excel, PowerPoint, text, CSV, HTML, XML, JSON, RTF, images)
 * inside Doxsy, with zoom and find. Formats that cannot be drawn here are offered to another app.
 */
@Composable
internal fun DocViewerScreen(
    uri: Uri,
    format: DocFormat,
    name: String,
    onBack: () -> Unit,
) {
    val ctx = LocalContext.current
    var state by remember(uri) { mutableStateOf<LoadState>(LoadState.Loading) }
    var zoom by remember(uri) { mutableFloatStateOf(1f) }
    var searching by remember(uri) { mutableStateOf(false) }
    var query by remember(uri) { mutableStateOf("") }
    var current by remember(uri) { mutableIntStateOf(0) }
    var sheetIdx by remember(uri) { mutableIntStateOf(0) }
    val find = remember(uri) { WebFind() }
    val mime = remember(uri) { mimeOf(ctx, uri, name) }

    LaunchedEffect(uri) {
        state = LoadState.Loading
        state = withContext(Dispatchers.IO) {
            runCatching { loadDocument(ctx, uri, format, name) }
                .fold(
                    onSuccess = { LoadState.Ready(it) },
                    onFailure = { LoadState.Failed(describeLoadError(it)) },
                )
        }
    }

    BackHandler {
        if (searching) {
            searching = false
            query = ""
            find.query = ""
        } else {
            onBack()
        }
    }

    val loaded = (state as? LoadState.Ready)?.loaded
    val searchable = loaded != null && loaded !is Loaded.Picture && loaded !is Loaded.Unsupported
    val listState = key(sheetIdx) { rememberLazyListState() }

    // Search hits (WebView documents search inside the WebView itself).
    val units = remember(loaded, sheetIdx) { if (loaded != null) buildUnits(loaded, sheetIdx) else emptyList() }
    val hits = remember(units, query) { findHits(units, query) }
    LaunchedEffect(query) { current = 0 }
    val hl = remember(hits, current) {
        if (hits.isEmpty()) Highlights.NONE else Highlights(hits, hits.getOrNull(current.coerceIn(0, hits.size - 1)))
    }
    LaunchedEffect(hits, current) {
        val hit = hits.getOrNull(current.coerceIn(0, (hits.size - 1).coerceAtLeast(0))) ?: return@LaunchedEffect
        runCatching { listState.animateScrollToItem(hit.item) }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding(),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") }
            Text(
                name,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            if (searchable) {
                IconButton(onClick = { searching = !searching; if (!searching) { query = ""; find.query = "" } }) {
                    Icon(Icons.Rounded.Search, "Find in document")
                }
            }
            if (loaded != null && loaded !is Loaded.Unsupported) {
                IconButton(onClick = { zoom = (zoom - 0.25f).coerceAtLeast(MIN_ZOOM) }) { Icon(Icons.Rounded.ZoomOut, "Zoom out") }
                IconButton(onClick = { zoom = (zoom + 0.25f).coerceAtMost(MAX_ZOOM) }) { Icon(Icons.Rounded.ZoomIn, "Zoom in") }
            }
            if (loaded != null && loaded !is Loaded.Unsupported) {
                Text(
                    "${(zoom * 100).toInt()}%",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            var menuOpen by remember { mutableStateOf(false) }
            Box {
                IconButton(onClick = { menuOpen = true }) { Icon(Icons.Rounded.MoreVert, "More") }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(text = { Text("Share file") }, onClick = {
                        menuOpen = false
                        FileUtils.share(ctx, uri, mime)
                    })
                    DropdownMenuItem(text = { Text("Open in another app") }, onClick = {
                        menuOpen = false
                        FileUtils.viewExternal(ctx, uri, mime)
                    })
                    if (loaded != null && loaded !is Loaded.Unsupported) {
                        DropdownMenuItem(text = { Text("Reset zoom (100%)") }, onClick = {
                            menuOpen = false
                            zoom = 1f
                        })
                    }
                }
            }
        }

        if (searching && searchable) {
            val isWeb = loaded is Loaded.Web
            val total = if (isWeb) find.total else hits.size
            val position = if (isWeb) find.active else if (hits.isEmpty()) 0 else current.coerceIn(0, hits.size - 1) + 1
            DocSearchBar(
                query = query,
                onQuery = { query = it; if (isWeb) find.query = it },
                countText = if (query.isBlank()) "" else "$position/$total",
                onPrev = {
                    if (isWeb) find.view?.findNext(false)
                    else if (hits.isNotEmpty()) current = (current - 1 + hits.size) % hits.size
                },
                onNext = {
                    if (isWeb) find.view?.findNext(true)
                    else if (hits.isNotEmpty()) current = (current + 1) % hits.size
                },
                onClose = { searching = false; query = ""; find.query = "" },
            )
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (val s = state) {
                LoadState.Loading -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                is LoadState.Failed -> Fallback(s.message, "Open in another app") { FileUtils.viewExternal(ctx, uri, mime) }
                is LoadState.Ready -> when (val l = s.loaded) {
                    is Loaded.Word -> WordView(l.doc, zoom, listState, hl)
                    is Loaded.Sheets -> {
                        val sheets = l.book.sheets
                        if (sheets.isEmpty()) {
                            Notice("This workbook has no sheets.")
                        } else {
                            Column(Modifier.fillMaxSize()) {
                                if (sheets.size > 1) {
                                    SheetTabs(sheets.map { it.name }, sheetIdx) { sheetIdx = it }
                                }
                                SheetGridView(
                                    sheets[sheetIdx.coerceIn(0, sheets.size - 1)],
                                    zoom, listState, hl, Modifier.weight(1f),
                                )
                            }
                        }
                    }
                    is Loaded.Slides -> SlidesView(l.deck, zoom, listState, hl)
                    is Loaded.Lines -> LinesView(l.lines, l.truncated, zoom, listState, hl)
                    is Loaded.Web -> WebDocView(l.html, zoom, find, Modifier.fillMaxSize())
                    is Loaded.Picture -> ImageViewer(l, zoom, { zoom = it.coerceIn(MIN_ZOOM, MAX_ZOOM) }, name)
                    Loaded.Unsupported -> Fallback(
                        "Doxsy cannot show this kind of file yet.",
                        "Open in another app",
                    ) { FileUtils.viewExternal(ctx, uri, mime) }
                }
            }
        }
    }
}

@Composable
private fun Fallback(message: String, action: String, onAction: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(message, textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyLarge)
        Button(onClick = onAction, modifier = Modifier.padding(top = 16.dp)) { Text(action) }
    }
}
