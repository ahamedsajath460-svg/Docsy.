package com.doxsy.app.convert

import android.content.Context
import android.net.Uri
import com.doxsy.app.docview.DocReadException
import com.doxsy.app.util.AppFiles
import com.doxsy.app.util.FileUtils
import kotlinx.coroutines.CancellationException
import java.io.FileNotFoundException
import java.io.IOException

/** Runs one conversion. Everything happens on this device; nothing is uploaded. */
object ConvertEngine {

    private val KNOWN_EXT = Regex("(?i)\\.(pdf|jpe?g|png|webp|txt|html?|zip)$")

    /** File name (no extension) for the result: the user's choice, else the first source's name. */
    fun baseName(ctx: Context, sources: List<Uri>, s: ConvertSettings): String {
        // Only a known output extension is dropped, so "Trip v1.2" keeps its full name.
        val typed = s.outName.trim().replace(KNOWN_EXT, "").trim()
        if (typed.isNotBlank()) return AppFiles.safeName(typed)
        val first = sources.firstOrNull() ?: return "Doxsy"
        val n = FileUtils.displayName(ctx, first)
        return AppFiles.safeName(n.substringBeforeLast('.', n))
    }

    /**
     * Blocking; call from a background thread. [ensure] must throw [CancellationException] when the user
     * cancelled. Never throws except for cancellation: problems come back as [ConvertOutcome.Failure].
     */
    fun run(
        ctx: Context,
        conv: Conversion,
        sources: List<Uri>,
        s: ConvertSettings,
        ensure: () -> Unit,
        progress: (done: Int, total: Int) -> Unit,
    ): ConvertOutcome {
        if (sources.isEmpty()) return ConvertOutcome.Failure("Pick a file first.")
        val name = baseName(ctx, sources, s)
        val src = sources[0]
        return try {
            when (conv) {
                Conversion.PDF_TO_JPG -> PdfConverters.pdfToImages(ctx, src, ImageFormat.JPG, s, name, ensure, progress)
                Conversion.PDF_TO_PNG -> PdfConverters.pdfToImages(ctx, src, ImageFormat.PNG, s, name, ensure, progress)
                Conversion.PDF_TO_WEBP -> PdfConverters.pdfToImages(ctx, src, ImageFormat.WEBP, s, name, ensure, progress)
                Conversion.PDF_TO_TXT -> PdfConverters.pdfToText(ctx, src, s, name, ensure, progress)
                Conversion.PDF_TO_HTML -> PdfConverters.pdfToHtml(ctx, src, s, name, ensure, progress)
                Conversion.IMAGES_TO_PDF -> ToPdfWriters.imagesToPdf(ctx, sources, s, name, ensure, progress)
                Conversion.DOCX_TO_PDF -> ToPdfWriters.docxToPdf(ctx, src, s, name, ensure, progress)
                Conversion.XLSX_TO_PDF -> ToPdfWriters.xlsxToPdf(ctx, src, s, name, ensure, progress)
                Conversion.PPTX_TO_PDF -> ToPdfWriters.pptxToPdf(ctx, src, s, name, ensure, progress)
                Conversion.TXT_TO_PDF -> ToPdfWriters.txtToPdf(ctx, src, s, name, ensure, progress)
                Conversion.CSV_TO_PDF -> ToPdfWriters.csvToPdf(ctx, src, s, name, ensure, progress)
                Conversion.HTML_TO_PDF -> ToPdfWriters.htmlToPdf(ctx, src, s, name, ensure, progress)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: ConvertException) {
            ConvertOutcome.Failure(e.message ?: "The conversion failed.")
        } catch (e: DocReadException) {
            ConvertOutcome.Failure(e.message ?: "This document could not be read.")
        } catch (e: OutOfMemoryError) {
            ConvertOutcome.Failure("Not enough memory for this file. Try fewer pages, a lower quality or a smaller file.")
        } catch (e: FileNotFoundException) {
            ConvertOutcome.Failure("The file was not found, or permission to it was lost. Pick it again.")
        } catch (e: SecurityException) {
            ConvertOutcome.Failure("Permission to a file or to the output folder was lost. Pick it again or choose another output folder.")
        } catch (e: IOException) {
            ConvertOutcome.Failure("Could not read or write a file: ${e.message ?: "unknown input/output error"}")
        } catch (e: Exception) {
            ConvertOutcome.Failure("The conversion failed: ${e.message ?: e.javaClass.simpleName}")
        }
    }
}
