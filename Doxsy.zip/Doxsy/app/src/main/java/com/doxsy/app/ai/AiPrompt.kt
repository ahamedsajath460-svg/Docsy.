package com.doxsy.app.ai

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * The instructions that make the chat answer well (ported from Zen AI's prompt: date, language rule, reasoning
 * rule) plus a short memory of the older part of a long chat, so nothing is forgotten just because only the last
 * messages are sent in full.
 */
object AiPrompt {
    private val TAMIL = Regex("[\\u0B80-\\u0BFF]")
    private val SINHALA = Regex("[\\u0D80-\\u0DFF]")

    /** Which language rule the latest message needs. Pure, so it can be tested. */
    fun languageRule(latest: String): String {
        val t = latest.trim()
        val how = when {
            t.isEmpty() -> "use the language of the earlier messages"
            TAMIL.containsMatchIn(t) -> "Tamil script"
            SINHALA.containsMatchIn(t) -> "Sinhala script"
            else -> "use the same language and writing style the user used, for example English, or Tamil typed in English letters"
        }
        return "Language rule: reply ONLY in the language and script of the user's latest message ($how). " +
            "Never add translations or versions in other languages unless the user asks for them."
    }

    fun system(latestUserText: String, think: Boolean, now: Date = Date()): String {
        val date = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale.ENGLISH).apply { timeZone = TimeZone.getDefault() }
            .format(now) + " (" + TimeZone.getDefault().id + ")"
        val parts = ArrayList<String>()
        parts += "You are Doxsy AI, the assistant inside the Doxsy PDF and documents app. " +
            "Be clear, accurate and helpful, and treat the user as a capable adult."
        parts += "Current date and time: $date."
        parts += languageRule(latestUserText)
        parts += "How to answer:\n" +
            "- Answer the question first, then add only the detail that helps. Be concise unless detail is asked for.\n" +
            "- Be accurate. Never invent facts, numbers, names, quotes or page numbers. If you are not sure, say so.\n" +
            "- For maths, dates, totals and comparisons, work it out carefully, check the result, and show the short working.\n" +
            "- If a question is unclear, state the assumption you made and answer; ask a question only when you cannot answer without it.\n" +
            "- When the user asks for writing (an email, a summary, a rewrite), give the finished text, ready to use.\n" +
            "- Questions about a file: answer from the file and say which part it came from; if the file does not contain " +
            "the answer, say that clearly instead of guessing."
        parts += "Formatting: the chat shows only simple Markdown: **bold**, `code`, # headings and - bullet lists. " +
            "Do not use tables, HTML, LaTeX or nested lists. Use short paragraphs."
        if (think) {
            parts += "Reasoning mode: think the problem through step by step, check your work, " +
                "then give a clear final answer. Keep the final answer short and do not repeat your scratch work."
        }
        return parts.joinToString("\n\n")
    }

    /**
     * A short digest of the messages that no longer fit in the full history (one line per message, newest first
     * until the room is used), or "" when nothing was cut.
     */
    fun earlier(older: List<AiMessage>, room: Int = 1_800): String {
        if (older.isEmpty()) return ""
        val lines = ArrayList<String>()
        var used = 0
        for (m in older.asReversed()) {
            val body = m.content.replace(Regex("\\s+"), " ").trim()
            if (body.isEmpty()) continue
            val who = if (m.role == "user") "User" else "AI"
            val line = "- $who: " + if (body.length > 200) body.take(200) + "…" else body
            if (used + line.length > room) break
            lines += line
            used += line.length + 1
        }
        if (lines.isEmpty()) return ""
        return "Earlier in this conversation (older messages, shortened; use them if the user refers back):\n" +
            lines.asReversed().joinToString("\n")
    }
}
