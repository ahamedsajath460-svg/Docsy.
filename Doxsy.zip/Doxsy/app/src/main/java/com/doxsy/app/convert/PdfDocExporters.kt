package com.doxsy.app.convert

import android.content.Context
import android.net.Uri
import com.doxsy.app.util.FileUtils
import com.doxsy.app.util.OutputStore
import java.io.IOException
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Document formats the Export PDF page can write. */
enum class DocTarget(val label: String, val ext: String, val mime: String) {
    DOCX("Microsoft Word (docx)", "docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
    DOC("Microsoft Word 97 - 2003 (doc)", "doc", "application/msword"),
    RTF("Rich Text Format (rtf)", "rtf", "application/rtf"),
    XLSX("Microsoft Excel (xlsx)", "xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
    PPTX("Microsoft PowerPoint (pptx)", "pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation"),
}

/** Language written into the exported document (spell-check / proofing language). [lcid] is the Windows language id used by RTF. */
class ExportLanguage(val label: String, val tag: String, val lcid: Int)

val EXPORT_LANGUAGES = listOf(
    ExportLanguage("English (United States)", "en-US", 1033),
    ExportLanguage("English (United Kingdom)", "en-GB", 2057),
    ExportLanguage("Tamil", "ta-IN", 1097),
    ExportLanguage("Sinhala", "si-LK", 1115),
    ExportLanguage("Hindi", "hi-IN", 1081),
    ExportLanguage("Arabic", "ar-SA", 1025),
    ExportLanguage("French", "fr-FR", 1036),
    ExportLanguage("German", "de-DE", 1031),
    ExportLanguage("Spanish", "es-ES", 3082),
    ExportLanguage("Portuguese (Brazil)", "pt-BR", 1046),
    ExportLanguage("Indonesian", "id-ID", 1057),
    ExportLanguage("Malay", "ms-MY", 1086),
)

/**
 * PDF to Word / RTF / Excel / PowerPoint. The TEXT of every page is written (read from the PDF's text layer);
 * fonts, columns, pictures and exact layout are not kept, and scanned PDFs have no text to export.
 * Everything happens on the phone.
 */
object PdfDocExporters {

    private const val NO_TEXT =
        "No text found. This PDF probably contains scanned images, which have no text layer to export (OCR is not part of Doxsy yet)."

    fun run(ctx: Context, uri: Uri, target: DocTarget, lang: ExportLanguage): ConvertOutcome {
        return try {
            val pages = ArrayList<String>()
            val (count, withText) = PdfConverters.extractPages(ctx, uri, "", {}, { _, _ -> }) { _, t -> pages.add(clean(t)) }
            if (withText == 0) return ConvertOutcome.Failure(NO_TEXT)
            val base = ConvertEngine.baseName(ctx, listOf(uri), ConvertSettings())
            val out = OutputStore.write(ctx, "$base.${target.ext}", target.mime) { os ->
                when (target) {
                    DocTarget.DOCX -> writeDocx(os, pages, lang)
                    DocTarget.RTF, DocTarget.DOC -> os.write(rtf(pages, lang).toByteArray(Charsets.US_ASCII))
                    DocTarget.XLSX -> writeXlsx(os, pages)
                    DocTarget.PPTX -> writePptx(os, pages, lang)
                }
            }
            val note = if (withText < count) " ${count - withText} page(s) had no text." else ""
            val extra = if (target == DocTarget.DOC) " Saved as a Word-compatible .doc file." else ""
            ConvertOutcome.Success(
                listOf(out), target.mime,
                "Exported the text of $withText of $count page(s) to ${target.ext.uppercase()} " +
                    "(${FileUtils.formatSize(com.doxsy.app.pdf.PdfTools.querySize(ctx, out))}).$note$extra",
            )
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: ConvertException) {
            ConvertOutcome.Failure(e.message ?: "The export failed.")
        } catch (e: OutOfMemoryError) {
            ConvertOutcome.Failure("Not enough memory for this file. Try a smaller PDF.")
        } catch (e: IOException) {
            ConvertOutcome.Failure("Could not read or write a file: ${e.message ?: "unknown input/output error"}")
        } catch (e: SecurityException) {
            ConvertOutcome.Failure("Permission to a file or to the output folder was lost. Pick it again.")
        } catch (e: Exception) {
            ConvertOutcome.Failure("The export failed: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    // ---------------- helpers ----------------

    /** Removes characters that are not allowed in XML / documents. */
    private fun clean(t: String): String = buildString(t.length) {
        for (c in t) if (c == '\t' || c == '\n' || (c >= ' ' && c != '\uFFFE' && c != '\uFFFF')) append(c)
    }

    private fun esc(t: String): String = t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    private const val HDR = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"
    private const val NS_A = "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\""
    private const val NS_R = "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\""
    private const val NS_P = "xmlns:p=\"http://schemas.openxmlformats.org/presentationml/2006/main\""
    private const val NS_W = "xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\""
    private const val NS_X = "xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\""
    private const val RELS = "xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\""
    private const val CT_NS = "xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\""
    private const val REL_TYPE = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"

    private fun ZipOutputStream.put(name: String, text: String) {
        putNextEntry(ZipEntry(name))
        write(text.toByteArray(Charsets.UTF_8))
        closeEntry()
    }

    private val PARA_SPLIT = Regex("\\n\\s*\\n")

    // ---------------- DOCX ----------------

    private fun writeDocx(os: OutputStream, pages: List<String>, lang: ExportLanguage) {
        val tag = lang.tag
        val langAttr = "<w:lang w:val=\"$tag\" w:eastAsia=\"$tag\" w:bidi=\"$tag\"/>"
        val body = StringBuilder()
        pages.forEachIndexed { pi, text ->
            text.split(PARA_SPLIT).map { it.trim() }.filter { it.isNotEmpty() }.forEach { para ->
                body.append("<w:p>")
                para.split('\n').forEachIndexed { k, line ->
                    if (k > 0) body.append("<w:r><w:br/></w:r>")
                    body.append("<w:r><w:rPr>").append(langAttr).append("</w:rPr><w:t xml:space=\"preserve\">")
                        .append(esc(line)).append("</w:t></w:r>")
                }
                body.append("</w:p>")
            }
            if (pi < pages.size - 1) body.append("<w:p><w:r><w:br w:type=\"page\"/></w:r></w:p>")
        }
        val document = HDR + "<w:document $NS_W><w:body>" + body +
            "<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/><w:pgMar w:top=\"1440\" w:right=\"1440\" w:bottom=\"1440\" " +
            "w:left=\"1440\" w:header=\"708\" w:footer=\"708\" w:gutter=\"0\"/></w:sectPr></w:body></w:document>"
        val styles = HDR + "<w:styles $NS_W><w:docDefaults><w:rPrDefault><w:rPr>" +
            "<w:rFonts w:ascii=\"Arial\" w:hAnsi=\"Arial\" w:eastAsia=\"Arial\" w:cs=\"Arial\"/><w:sz w:val=\"22\"/><w:szCs w:val=\"22\"/>" +
            langAttr + "</w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after=\"120\" w:line=\"276\" w:lineRule=\"auto\"/>" +
            "</w:pPr></w:pPrDefault></w:docDefaults><w:style w:type=\"paragraph\" w:default=\"1\" w:styleId=\"Normal\">" +
            "<w:name w:val=\"Normal\"/><w:qFormat/></w:style></w:styles>"
        ZipOutputStream(os).use { z ->
            z.put("[Content_Types].xml", ExportXml.DOCX_CT)
            z.put("_rels/.rels", ExportXml.DOCX_ROOT_RELS)
            z.put("word/document.xml", document)
            z.put("word/_rels/document.xml.rels", ExportXml.DOCX_DOC_RELS)
            z.put("word/styles.xml", styles)
        }
    }

    // ---------------- RTF (also used for .doc) ----------------

    private fun rtfEscape(t: String): String = buildString {
        for (c in t) {
            when {
                c == '\\' -> append("\\\\")
                c == '{' -> append("\\{")
                c == '}' -> append("\\}")
                c == '\t' -> append("\\tab ")
                c.code in 32..126 -> append(c)
                c.code > 126 -> append("\\u").append(c.code.toShort().toInt()).append('?')
            }
        }
    }

    private fun rtf(pages: List<String>, lang: ExportLanguage): String {
        val sb = StringBuilder()
        sb.append("{\\rtf1\\ansi\\ansicpg1252\\deff0\\uc1\\deflang${lang.lcid}{\\fonttbl{\\f0\\fnil Arial;}}\\viewkind4\\lang${lang.lcid}\\f0\\fs22 ")
        pages.forEachIndexed { pi, text ->
            text.split(PARA_SPLIT).map { it.trim() }.filter { it.isNotEmpty() }.forEach { para ->
                sb.append(para.split('\n').joinToString("\\line ") { rtfEscape(it) }).append("\\par\n")
            }
            if (pi < pages.size - 1) sb.append("\\page\n")
        }
        sb.append("}")
        return sb.toString()
    }

    // ---------------- XLSX ----------------

    private fun colName(index: Int): String {
        var i = index + 1
        val s = StringBuilder()
        while (i > 0) {
            val r = (i - 1) % 26
            s.insert(0, ('A'.code + r).toChar())
            i = (i - 1) / 26
        }
        return s.toString()
    }

    private val CELL_SPLIT = Regex("\\t|\\s{2,}")

    private fun sheetXml(text: String): String {
        val rows = StringBuilder()
        text.split('\n').forEachIndexed { idx, line ->
            if (line.isBlank()) return@forEachIndexed
            val r = idx + 1
            val cells = line.trim().split(CELL_SPLIT).filter { it.isNotEmpty() }.take(200)
            rows.append("<row r=\"$r\">")
            cells.forEachIndexed { ci, c ->
                rows.append("<c r=\"${colName(ci)}$r\" t=\"inlineStr\"><is><t xml:space=\"preserve\">").append(esc(c)).append("</t></is></c>")
            }
            rows.append("</row>")
        }
        return HDR + "<worksheet $NS_X><sheetData>" + rows + "</sheetData></worksheet>"
    }

    /** One sheet per PDF page; each text line is a row, and words separated by wide gaps go to separate cells. */
    private fun writeXlsx(os: OutputStream, pages: List<String>) {
        val n = pages.size
        val ct = StringBuilder(HDR + "<Types $CT_NS><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" " +
            "ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>")
        val sheets = StringBuilder()
        val rels = StringBuilder(HDR + "<Relationships $RELS>")
        for (i in 1..n) {
            ct.append("<Override PartName=\"/xl/worksheets/sheet$i.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>")
            sheets.append("<sheet name=\"Page $i\" sheetId=\"$i\" r:id=\"rId$i\"/>")
            rels.append("<Relationship Id=\"rId$i\" Type=\"$REL_TYPE/worksheet\" Target=\"worksheets/sheet$i.xml\"/>")
        }
        ct.append("</Types>")
        rels.append("</Relationships>")
        ZipOutputStream(os).use { z ->
            z.put("[Content_Types].xml", ct.toString())
            z.put("_rels/.rels", ExportXml.XLSX_ROOT_RELS)
            z.put("xl/workbook.xml", HDR + "<workbook $NS_X $NS_R><sheets>$sheets</sheets></workbook>")
            z.put("xl/_rels/workbook.xml.rels", rels.toString())
            pages.forEachIndexed { i, t -> z.put("xl/worksheets/sheet${i + 1}.xml", sheetXml(t)) }
        }
    }

    // ---------------- PPTX ----------------

    private fun slideXml(n: Int, text: String, lang: String): String {
        val size = when {
            text.length < 700 -> 1800
            text.length < 1400 -> 1400
            text.length < 2400 -> 1100
            else -> 900
        }
        val paras = StringBuilder()
        text.split('\n').forEach { l ->
            if (l.isBlank()) paras.append("<a:p><a:endParaRPr lang=\"$lang\" sz=\"$size\"/></a:p>")
            else paras.append("<a:p><a:r><a:rPr lang=\"$lang\" sz=\"$size\" dirty=\"0\"/><a:t>").append(esc(l)).append("</a:t></a:r></a:p>")
        }
        return HDR + "<p:sld $NS_A $NS_R $NS_P><p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id=\"1\" name=\"\"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>" +
            "<p:grpSpPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"0\" cy=\"0\"/><a:chOff x=\"0\" y=\"0\"/><a:chExt cx=\"0\" cy=\"0\"/></a:xfrm></p:grpSpPr>" +
            "<p:sp><p:nvSpPr><p:cNvPr id=\"2\" name=\"Page number\"/><p:cNvSpPr txBox=\"1\"/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x=\"457200\" y=\"228600\"/>" +
            "<a:ext cx=\"11277600\" cy=\"457200\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></p:spPr><p:txBody><a:bodyPr wrap=\"square\"/><a:lstStyle/>" +
            "<a:p><a:r><a:rPr lang=\"$lang\" sz=\"2000\" b=\"1\" dirty=\"0\"/><a:t>Page $n</a:t></a:r></a:p></p:txBody></p:sp>" +
            "<p:sp><p:nvSpPr><p:cNvPr id=\"3\" name=\"Text\"/><p:cNvSpPr txBox=\"1\"/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x=\"457200\" y=\"822960\"/>" +
            "<a:ext cx=\"11277600\" cy=\"5806440\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></p:spPr><p:txBody><a:bodyPr wrap=\"square\"><a:normAutofit/></a:bodyPr>" +
            "<a:lstStyle/>" + paras + "</p:txBody></p:sp></p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>"
    }

    /** One slide per PDF page with the page's text. */
    private fun writePptx(os: OutputStream, pages: List<String>, lang: ExportLanguage) {
        val n = pages.size
        val ct = StringBuilder(HDR + "<Types $CT_NS><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Override PartName=\"/ppt/presentation.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml\"/>" +
            "<Override PartName=\"/ppt/slideMasters/slideMaster1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml\"/>" +
            "<Override PartName=\"/ppt/slideLayouts/slideLayout1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml\"/>" +
            "<Override PartName=\"/ppt/theme/theme1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.theme+xml\"/>")
        val ids = StringBuilder()
        val rels = StringBuilder(HDR + "<Relationships $RELS><Relationship Id=\"rId1\" Type=\"$REL_TYPE/slideMaster\" Target=\"slideMasters/slideMaster1.xml\"/>")
        for (i in 1..n) {
            ct.append("<Override PartName=\"/ppt/slides/slide$i.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slide+xml\"/>")
            ids.append("<p:sldId id=\"${255 + i}\" r:id=\"rId${i + 1}\"/>")
            rels.append("<Relationship Id=\"rId${i + 1}\" Type=\"$REL_TYPE/slide\" Target=\"slides/slide$i.xml\"/>")
        }
        ct.append("</Types>")
        rels.append("<Relationship Id=\"rId${n + 2}\" Type=\"$REL_TYPE/theme\" Target=\"theme/theme1.xml\"/></Relationships>")
        val pres = HDR + "<p:presentation $NS_A $NS_R $NS_P><p:sldMasterIdLst><p:sldMasterId id=\"2147483648\" r:id=\"rId1\"/></p:sldMasterIdLst>" +
            "<p:sldIdLst>$ids</p:sldIdLst><p:sldSz cx=\"12192000\" cy=\"6858000\"/><p:notesSz cx=\"6858000\" cy=\"9144000\"/></p:presentation>"
        ZipOutputStream(os).use { z ->
            z.put("[Content_Types].xml", ct.toString())
            z.put("_rels/.rels", ExportXml.PPTX_ROOT_RELS)
            z.put("ppt/presentation.xml", pres)
            z.put("ppt/_rels/presentation.xml.rels", rels.toString())
            z.put("ppt/slideMasters/slideMaster1.xml", ExportXml.PPTX_MASTER)
            z.put("ppt/slideMasters/_rels/slideMaster1.xml.rels", ExportXml.PPTX_MASTER_RELS)
            z.put("ppt/slideLayouts/slideLayout1.xml", ExportXml.PPTX_LAYOUT)
            z.put("ppt/slideLayouts/_rels/slideLayout1.xml.rels", ExportXml.PPTX_LAYOUT_RELS)
            z.put("ppt/theme/theme1.xml", ExportXml.PPTX_THEME)
            pages.forEachIndexed { i, t ->
                z.put("ppt/slides/slide${i + 1}.xml", slideXml(i + 1, t, lang.tag))
                z.put("ppt/slides/_rels/slide${i + 1}.xml.rels", ExportXml.PPTX_SLIDE_RELS)
            }
        }
    }
}
