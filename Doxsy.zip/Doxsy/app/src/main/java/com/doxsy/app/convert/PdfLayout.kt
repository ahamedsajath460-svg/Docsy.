package com.doxsy.app.convert

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.StaticLayout
import android.text.TextPaint
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StrikethroughSpan
import android.text.style.StyleSpan
import android.text.style.UnderlineSpan
import com.doxsy.app.docview.Align
import com.doxsy.app.docview.Block
import com.doxsy.app.docview.Para
import com.doxsy.app.docview.TableBlock
import kotlin.math.abs

/** Paper size / orientation / margin choice of the user. Sizes are PDF points (1/72 inch). */
internal class PageSetup(val paper: PaperSize, val orientation: OrientationPref, val margin: Int) {
    fun dims(autoLandscape: Boolean): Pair<Int, Int> {
        val land = when (orientation) {
            OrientationPref.PORTRAIT -> false
            OrientationPref.LANDSCAPE -> true
            OrientationPref.AUTO -> autoLandscape
        }
        return if (land) Pair(paper.h, paper.w) else Pair(paper.w, paper.h)
    }
}

internal fun newTextPaint(sizePt: Float, typeface: Typeface? = null): TextPaint =
    TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = sizePt
        color = Color.BLACK
        linkColor = 0xFF1A56DB.toInt()
        if (typeface != null) this.typeface = typeface
    }

internal fun buildLayout(
    text: CharSequence,
    paint: TextPaint,
    width: Int,
    align: Layout.Alignment = Layout.Alignment.ALIGN_NORMAL,
    justify: Boolean = false,
): StaticLayout {
    val b = StaticLayout.Builder.obtain(text, 0, text.length, paint, width.coerceAtLeast(10))
        .setAlignment(align)
        .setLineSpacing(0f, 1.12f)
        .setIncludePad(false)
    if (justify) b.setJustificationMode(Layout.JUSTIFICATION_MODE_INTER_WORD)
    return b.build()
}

internal fun headingSize(level: Int, body: Float): Float = when (level) {
    1 -> body * 1.9f
    2 -> body * 1.5f
    3 -> body * 1.3f
    4 -> body * 1.15f
    else -> body * 1.05f
}

/** Converts a paragraph's runs into styled text. Sizes in the spans are relative to [base]. */
internal fun paraText(p: Para, base: Float): SpannableStringBuilder {
    val sb = SpannableStringBuilder()
    for (r in p.runs) {
        if (r.text.isEmpty()) continue
        val start = sb.length
        sb.append(r.text)
        val end = sb.length
        val style = when {
            r.bold && r.italic -> Typeface.BOLD_ITALIC
            r.bold -> Typeface.BOLD
            r.italic -> Typeface.ITALIC
            else -> Typeface.NORMAL
        }
        if (style != Typeface.NORMAL) sb.setSpan(StyleSpan(style), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (r.underline || r.link != null) sb.setSpan(UnderlineSpan(), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (r.strike) sb.setSpan(StrikethroughSpan(), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (r.sizePt > 0f && abs(r.sizePt - base) > 0.1f) {
            sb.setSpan(RelativeSizeSpan(r.sizePt / base), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        if (r.color != 0) {
            sb.setSpan(ForegroundColorSpan(r.color or 0xFF000000.toInt()), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
    }
    if (p.heading > 0 && sb.isNotEmpty()) sb.setSpan(StyleSpan(Typeface.BOLD), 0, sb.length, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
    return sb
}

/** Text of table-cell content (paragraphs joined by new lines; nested tables flattened). */
internal fun cellText(blocks: List<Block>, base: Float): SpannableStringBuilder {
    val sb = SpannableStringBuilder()
    for (b in blocks) {
        when (b) {
            is Para -> {
                if (sb.isNotEmpty()) sb.append('\n')
                sb.append(paraText(b, base))
            }
            is TableBlock -> b.rows.forEach { row ->
                if (sb.isNotEmpty()) sb.append('\n')
                row.forEachIndexed { i, cell ->
                    if (i > 0) sb.append("  |  ")
                    sb.append(cellText(cell, base).toString().replace('\n', ' '))
                }
            }
            else -> Unit
        }
    }
    return sb
}

internal fun alignOf(a: Align): Layout.Alignment = when (a) {
    Align.CENTER -> Layout.Alignment.ALIGN_CENTER
    Align.END -> Layout.Alignment.ALIGN_OPPOSITE
    else -> Layout.Alignment.ALIGN_NORMAL
}

/**
 * Lays content out top-to-bottom on pages of a [PdfDocument], starting a new page when the current one is
 * full. Long paragraphs are split between pages line by line.
 */
internal class FlowWriter(
    private val pdf: PdfDocument,
    val pageW: Int,
    val pageH: Int,
    margin: Int,
    private val ensure: () -> Unit,
) {
    val left: Float = margin.toFloat()
    val contentW: Float = (pageW - 2 * margin).toFloat().coerceAtLeast(100f)
    private val top: Float = margin.toFloat()
    private val bottom: Float = (pageH - margin).toFloat().coerceAtLeast(top + 100f)
    val contentH: Float get() = bottom - top

    private var page: PdfDocument.Page? = null
    private var pageCount = 0
    var y: Float = top

    val canvas: Canvas get() {
        if (page == null) newPage()
        return page!!.canvas
    }

    val atTop: Boolean get() = page == null || y <= top + 1f

    val pages: Int get() = pageCount

    fun newPage() {
        page?.let { pdf.finishPage(it) }
        pageCount++
        page = pdf.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageCount).create())
        y = top
    }

    fun breakPage() {
        if (!atTop) newPage()
    }

    fun finish() {
        page?.let { pdf.finishPage(it) }
        page = null
    }

    fun space(h: Float) {
        y += h
    }

    fun ensureRoom(h: Float) {
        if (page == null) newPage() else if (y + h > bottom && y > top + 1f) newPage()
    }

    /** Draws [layout] with its left edge at [x], splitting it across pages when needed. */
    fun drawLayout(layout: StaticLayout, x: Float = left) {
        if (page == null) newPage()
        val n = layout.lineCount
        var line = 0
        while (line < n) {
            ensure()
            val startTop = layout.getLineTop(line)
            val avail = bottom - y
            var end = line
            while (end < n && layout.getLineBottom(end) - startTop <= avail) end++
            if (end == line) {
                if (y > top + 1f) {
                    newPage()
                    continue
                }
                end = line + 1
            }
            val endBottom = layout.getLineBottom(end - 1)
            val c = page!!.canvas
            c.save()
            c.translate(x, y - startTop)
            c.clipRect(0f, startTop.toFloat(), layout.width.toFloat(), endBottom.toFloat())
            layout.draw(c)
            c.restore()
            y += (endBottom - startTop).toFloat()
            line = end
            if (line < n) newPage()
        }
    }
}
