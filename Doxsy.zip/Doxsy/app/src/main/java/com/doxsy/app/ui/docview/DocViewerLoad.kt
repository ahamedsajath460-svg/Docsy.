package com.doxsy.app.ui.docview

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import com.doxsy.app.docview.Deck
import com.doxsy.app.docview.DocReadException
import com.doxsy.app.docview.DocxReader
import com.doxsy.app.docview.LegacyOffice
import com.doxsy.app.docview.OdfReader
import com.doxsy.app.docview.PptxReader
import com.doxsy.app.docview.RtfReader
import com.doxsy.app.docview.Sheet
import com.doxsy.app.docview.WordDoc
import com.doxsy.app.docview.Workbook
import com.doxsy.app.docview.XlsxReader
import com.doxsy.app.docview.legacy.Ole2
import com.doxsy.app.util.DocFormat
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.ByteArrayOutputStream

/** Everything the viewer can show, produced off the main thread by [loadDocument]. */
internal sealed interface Loaded {
    class Word(val doc: WordDoc) : Loaded
    class Sheets(val book: Workbook) : Loaded
    class Lines(val lines: List<String>, val truncated: Boolean) : Loaded
    /** HTML, XML and JSON: always shown in a script-free WebView as a complete HTML document. */
    class Web(val html: String, val truncated: Boolean) : Loaded
    class Slides(val deck: Deck) : Loaded
    class Picture(val bitmap: Bitmap, val gif: Boolean) : Loaded
    data object Unsupported : Loaded
}

private const val MAX_TEXT_BYTES = 8 * 1024 * 1024
private const val MAX_IMAGE_BYTES = 40 * 1024 * 1024
private const val MAX_ROWS = 20_000
private const val MAX_DIM = 2048

/** Reads the whole document. Call on a background dispatcher. Throws on failure. */
internal fun loadDocument(ctx: Context, uri: Uri, format: DocFormat, name: String): Loaded = when (format) {
    DocFormat.DOCX, DocFormat.DOC, DocFormat.XLSX, DocFormat.XLS, DocFormat.PPTX, DocFormat.PPT ->
        loadOffice(ctx, uri, format)
    DocFormat.TXT -> {
        val c = readCapped(ctx, uri, MAX_TEXT_BYTES)
        Loaded.Lines(toLines(decodeText(c.bytes)), c.truncated)
    }
    DocFormat.RTF -> Loaded.Lines(toLines(RtfReader.readText(ctx, uri)), false)
    DocFormat.CSV -> {
        val c = readCapped(ctx, uri, MAX_TEXT_BYTES)
        val sep = if (name.endsWith(".tsv", ignoreCase = true)) '\t' else ','
        val rows = parseDelimited(decodeText(c.bytes), sep, MAX_ROWS)
        val sheet = Sheet(name, rows, widthsFor(rows), c.truncated)
        Loaded.Sheets(Workbook(listOf(sheet)))
    }
    DocFormat.HTML -> {
        val c = readCapped(ctx, uri, MAX_TEXT_BYTES)
        Loaded.Web(decodeText(c.bytes), c.truncated)
    }
    DocFormat.XML -> {
        val c = readCapped(ctx, uri, MAX_TEXT_BYTES)
        Loaded.Web(preAsHtml(decodeText(c.bytes)), c.truncated)
    }
    DocFormat.JSON -> {
        val c = readCapped(ctx, uri, MAX_TEXT_BYTES)
        Loaded.Web(preAsHtml(prettyJson(decodeText(c.bytes))), c.truncated)
    }
    DocFormat.ODF -> Loaded.Lines(OdfReader.readLines(ctx, uri), false)
    DocFormat.EPUB -> Loaded.Web(OdfReader.epubHtml(ctx, uri), false)
    DocFormat.IMAGE -> decodePicture(ctx, uri, name)
    else -> Loaded.Unsupported
}

/**
 * Word / Excel / PowerPoint, old or new. The file is opened by what it really contains, so an old
 * binary file saved with a new extension ("report.xlsx" that is really .xls) still opens.
 */
private fun loadOffice(ctx: Context, uri: Uri, format: DocFormat): Loaded {
    LegacyOffice.open(ctx, uri)?.let { o ->
        return when (o.kind) {
            Ole2.KIND_XLS -> Loaded.Sheets(LegacyOffice.workbook(o, MAX_ROWS))
            Ole2.KIND_DOC -> Loaded.Word(LegacyOffice.word(o))
            Ole2.KIND_PPT -> Loaded.Slides(LegacyOffice.deck(o))
            Ole2.KIND_ENCRYPTED_OOXML -> throw DocReadException(
                "This file is password-protected, so Doxsy cannot read it. Remove the password, then open it again.",
            )
            else -> throw DocReadException("This is not a valid Office document. The file may be corrupted.")
        }
    }
    val head = readCapped(ctx, uri, 4096).bytes
    val isZip = head.size >= 2 && head[0] == 'P'.code.toByte() && head[1] == 'K'.code.toByte()
    if (!isZip) looseText(ctx, uri, format, head)?.let { return it }
    return when (format) {
        DocFormat.DOCX, DocFormat.DOC -> Loaded.Word(DocxReader.read(ctx, uri))
        DocFormat.XLSX, DocFormat.XLS -> Loaded.Sheets(XlsxReader.read(ctx, uri, MAX_ROWS))
        else -> Loaded.Slides(PptxReader.read(ctx, uri))
    }
}

/** Text in a UTF-8 / UTF-16 encoding, chosen by byte-order mark. */
private fun decodeLoose(bytes: ByteArray): String = when {
    bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte() ->
        String(bytes, 2, bytes.size - 2, Charsets.UTF_16LE)
    bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte() ->
        String(bytes, 2, bytes.size - 2, Charsets.UTF_16BE)
    else -> decodeText(bytes)
}

/**
 * Many "Office" files are really something else under an Office extension: a web page saved as .xls,
 * a tab-separated export named .xlsx, RTF named .doc ... Shows those instead of failing.
 * Returns null for binary data (the real reader then explains what is wrong).
 */
private fun looseText(ctx: Context, uri: Uri, format: DocFormat, head: ByteArray): Loaded? {
    if (head.isEmpty()) throw DocReadException("This file is empty.")
    val utf16 = head.size >= 2 &&
        ((head[0] == 0xFF.toByte() && head[1] == 0xFE.toByte()) || (head[0] == 0xFE.toByte() && head[1] == 0xFF.toByte()))
    if (!utf16 && head.any { it.toInt() == 0 }) return null
    val peek = decodeLoose(head).trimStart().lowercase()
    if (peek.startsWith("{\\rtf")) return Loaded.Lines(toLines(RtfReader.readText(ctx, uri)), false)

    val c = readCapped(ctx, uri, MAX_TEXT_BYTES)
    val text = decodeLoose(c.bytes)
    val looksHtml = peek.startsWith("<html") || peek.startsWith("<!doctype html") || peek.startsWith("<table") ||
        peek.startsWith("<head") || peek.startsWith("<body") || peek.startsWith("<meta") ||
        (peek.startsWith("<?xml") && peek.contains("<html"))
    if (looksHtml) return Loaded.Web(text, c.truncated)
    if (peek.startsWith("<?xml") || peek.startsWith("<")) return Loaded.Web(preAsHtml(text), c.truncated)

    return when (format) {
        DocFormat.XLSX, DocFormat.XLS -> {
            val firstLine = text.lineSequence().firstOrNull { it.isNotBlank() } ?: ""
            val sep = listOf('\t', ';', ',').maxByOrNull { ch -> firstLine.count { it == ch } }
                ?.takeIf { ch -> firstLine.contains(ch) } ?: ','
            val rows = parseDelimited(text, sep, MAX_ROWS)
            Loaded.Sheets(Workbook(listOf(Sheet("Sheet1", rows, widthsFor(rows), c.truncated))))
        }
        else -> Loaded.Lines(toLines(text), c.truncated)
    }
}

/** Short user-facing reason for a failed load. */
internal fun describeLoadError(t: Throwable): String = when (t) {
    is DocReadException -> t.message ?: "This file could not be opened."
    is OutOfMemoryError -> "Not enough memory to open this file."
    else -> "This file could not be opened. It may be damaged."
}

internal class Capped(val bytes: ByteArray, val truncated: Boolean)

/** Reads at most [maxBytes] from the Uri. [Capped.truncated] is true when the file was longer. */
internal fun readCapped(ctx: Context, uri: Uri, maxBytes: Int): Capped {
    val input = ctx.contentResolver.openInputStream(uri)
        ?: throw DocReadException("Could not open this file.")
    input.use { s ->
        val out = ByteArrayOutputStream()
        val buf = ByteArray(64 * 1024)
        while (out.size() < maxBytes) {
            val n = s.read(buf)
            if (n < 0) return Capped(out.toByteArray(), false)
            out.write(buf, 0, minOf(n, maxBytes - out.size()))
        }
        return Capped(out.toByteArray(), true)
    }
}

internal fun decodeText(bytes: ByteArray): String =
    String(bytes, Charsets.UTF_8).removePrefix("﻿")

internal fun toLines(text: String): List<String> =
    text.replace("\r\n", "\n").split('\n')

/** RFC 4180-style splitter: quoted fields, doubled quotes, CR/LF rows. Stops after [maxRows]. */
internal fun parseDelimited(text: String, sep: Char, maxRows: Int): List<List<String>> {
    val rows = ArrayList<List<String>>()
    var row = ArrayList<String>()
    val cell = StringBuilder()
    var inQuotes = false
    var i = 0
    while (i < text.length && rows.size < maxRows) {
        val c = text[i]
        if (inQuotes) {
            if (c == '"') {
                if (i + 1 < text.length && text[i + 1] == '"') {
                    cell.append('"')
                    i++
                } else {
                    inQuotes = false
                }
            } else {
                cell.append(c)
            }
        } else {
            when (c) {
                '"' -> inQuotes = true
                sep -> {
                    row.add(cell.toString())
                    cell.setLength(0)
                }
                '\n' -> {
                    row.add(cell.toString())
                    cell.setLength(0)
                    rows.add(row)
                    row = ArrayList()
                }
                '\r' -> Unit
                else -> cell.append(c)
            }
        }
        i++
    }
    if (rows.size < maxRows && (cell.isNotEmpty() || row.isNotEmpty())) {
        row.add(cell.toString())
        rows.add(row)
    }
    return rows
}

/** Column widths in characters for a grid, from the longest cell in each column. */
internal fun widthsFor(rows: List<List<String>>): List<Float> {
    val cols = rows.maxOfOrNull { it.size } ?: 0
    return List(cols) { c ->
        val longest = rows.maxOf { r -> r.getOrNull(c)?.length ?: 0 }
        (longest.coerceIn(4, 28) + 2).toFloat()
    }
}

internal fun escapeHtml(s: String): String = buildString(s.length + 16) {
    for (c in s) {
        when (c) {
            '&' -> append("&amp;")
            '<' -> append("&lt;")
            '>' -> append("&gt;")
            '"' -> append("&quot;")
            '\'' -> append("&#39;")
            else -> append(c)
        }
    }
}

private const val PRE_CSS =
    "body{margin:12px;font-family:monospace;font-size:13px;white-space:pre-wrap;word-wrap:break-word;" +
        "color:#1b1f33;background:#ffffff}" +
        "@media (prefers-color-scheme: dark){body{color:#e8ebfa;background:#080d24}}"

/** Shows plain text (XML, JSON) as escaped text inside a pre element. */
internal fun preAsHtml(text: String): String =
    "<!doctype html><html><head><meta charset=\"utf-8\">" +
        "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">" +
        "<style>$PRE_CSS</style></head><body><pre>${escapeHtml(text)}</pre></body></html>"

/** Pretty-prints JSON with org.json. Invalid JSON is returned unchanged so the user still sees it. */
internal fun prettyJson(text: String): String = runCatching {
    when (val v = JSONTokener(text).nextValue()) {
        is JSONObject -> v.toString(2)
        is JSONArray -> v.toString(2)
        else -> v.toString()
    }
}.getOrDefault(text)

/** Decodes a raster image, downscaled to [MAX_DIM] and rotated per its EXIF orientation. */
internal fun decodePicture(ctx: Context, uri: Uri, name: String): Loaded.Picture {
    val c = readCapped(ctx, uri, MAX_IMAGE_BYTES)
    if (c.truncated) throw DocReadException("This image is too large to preview.")
    val bytes = c.bytes
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
        throw DocReadException("This image could not be decoded.")
    }
    val largest = maxOf(bounds.outWidth, bounds.outHeight)
    var sample = 1
    while (largest / sample > MAX_DIM) sample *= 2
    val bmp = BitmapFactory.decodeByteArray(
        bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample },
    ) ?: throw DocReadException("This image could not be decoded.")

    val orientation = runCatching {
        ctx.contentResolver.openInputStream(uri)?.use { s ->
            ExifInterface(s).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        } ?: ExifInterface.ORIENTATION_NORMAL
    }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)

    val matrix = Matrix()
    when (orientation) {
        ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
        ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
        ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
        ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.preScale(-1f, 1f)
        ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.preScale(1f, -1f)
    }
    val out = if (matrix.isIdentity) {
        bmp
    } else {
        Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, matrix, true).also { bmp.recycle() }
    }
    val gif = name.endsWith(".gif", ignoreCase = true) ||
        (bytes.size > 3 && bytes[0] == 'G'.code.toByte() && bytes[1] == 'I'.code.toByte() && bytes[2] == 'F'.code.toByte())
    return Loaded.Picture(out, gif)
}
