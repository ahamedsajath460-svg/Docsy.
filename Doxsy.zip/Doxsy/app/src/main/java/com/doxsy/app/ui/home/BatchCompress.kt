package com.doxsy.app.ui.home

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.doxsy.app.pdf.BatchResult
import com.doxsy.app.pdf.CompressLevel
import com.doxsy.app.pdf.PdfTools
import com.doxsy.app.util.FileUtils
import com.doxsy.app.util.OutputStore
import kotlinx.coroutines.launch

private class BatchFile(val uri: Uri, val name: String, val size: Long)

private val BATCH_LEVELS = listOf(
    Triple("High compression", "Smallest size, lower quality", CompressLevel.STRONG),
    Triple("Medium compression", "Medium size, good quality", CompressLevel.BALANCED),
    Triple("Low compression", "Larger size, best quality", CompressLevel.LIGHT),
)

/**
 * Compress many PDFs in one go. Each result is saved as "<name>_compressed.pdf" in Doxsy's output folder and the
 * size before and after is listed for every file and in total. Originals are never changed.
 */
@Composable
fun BatchCompressPage(initial: List<Uri>, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val files = remember { mutableStateListOf<BatchFile>() }
    val results = remember { mutableStateListOf<Pair<String, BatchResult>>() }
    var choice by remember { mutableStateOf(1) }
    var strip by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf("") }
    var finished by remember { mutableStateOf(false) }

    fun add(list: List<Uri>) {
        list.forEach { u ->
            runCatching { ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            if (files.none { it.uri == u }) files.add(BatchFile(u, FileUtils.displayName(ctx, u), PdfTools.querySize(ctx, u)))
        }
    }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { list ->
        if (list.isNotEmpty()) add(list)
    }
    LaunchedEffect(Unit) { if (initial.isNotEmpty()) add(initial) }

    fun run() {
        busy = true
        finished = false
        results.clear()
        val level = BATCH_LEVELS[choice].third
        val todo = files.toList()
        scope.launch {
            todo.forEachIndexed { i, f ->
                progress = "Compressing ${i + 1} of ${todo.size}: ${f.name}"
                val r = PdfTools.compressToStore(ctx, f.uri, level, strip, f.name.substringBeforeLast('.') + "_compressed.pdf")
                results.add(f.name to r)
            }
            busy = false
            finished = true
        }
    }

    Dialog(
        onDismissRequest = { if (!busy) onClose() },
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false),
    ) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                IconButton(onClick = { if (!busy) onClose() }, modifier = Modifier.padding(start = 8.dp, top = 8.dp)) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back")
                }
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 24.dp)) {
                    Text("Compress many PDFs", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(16.dp))

                    if (finished) {
                        val ok = results.filter { it.second.ok }
                        val before = ok.sumOf { it.second.before }
                        val after = ok.sumOf { it.second.after }
                        Text("Done: ${ok.size} of ${results.size} files", style = MaterialTheme.typography.titleMedium)
                        if (before > 0 && after > 0) {
                            val pct = if (after < before) ((before - after) * 100 / before).toInt() else 0
                            Text(
                                "Total ${FileUtils.formatSize(before)} → ${FileUtils.formatSize(after)}" + if (pct > 0) " (−$pct%)" else "",
                                style = MaterialTheme.typography.bodyLarge,
                            )
                        }
                        Text(
                            "Saved in ${OutputStore.label(ctx)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Spacer(Modifier.height(12.dp))
                        results.forEach { (name, r) ->
                            Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                                Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
                                val line = if (r.ok) {
                                    val pct = if (r.after in 1 until r.before) ((r.before - r.after) * 100 / r.before).toInt() else 0
                                    "${FileUtils.formatSize(r.before)} → ${FileUtils.formatSize(r.after)}" +
                                        if (pct > 0) " (−$pct%)" else " (could not be made smaller)"
                                } else r.error
                                Text(
                                    line,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (r.ok) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.error,
                                )
                            }
                        }
                    } else {
                        Text("Files", style = MaterialTheme.typography.titleMedium)
                        files.forEachIndexed { i, f ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f).padding(vertical = 4.dp)) {
                                    Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
                                    Text(
                                        if (f.size > 0) FileUtils.formatSize(f.size) else "",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                IconButton(onClick = { files.removeAt(i) }, enabled = !busy) { Icon(Icons.Rounded.Close, "Remove") }
                            }
                        }
                        TextButton(onClick = { pick.launch(arrayOf("application/pdf")) }, enabled = !busy) {
                            Icon(Icons.Rounded.Add, null)
                            Text("  Add PDFs")
                        }
                        Spacer(Modifier.height(16.dp))
                        Text("Set compression level:", style = MaterialTheme.typography.titleMedium)
                        BATCH_LEVELS.forEachIndexed { i, (title, desc, _) ->
                            Row(
                                Modifier.fillMaxWidth().clickable(enabled = !busy) { choice = i }.padding(vertical = 8.dp),
                                verticalAlignment = Alignment.Top,
                            ) {
                                RadioButton(selected = choice == i, onClick = { if (!busy) choice = i })
                                Spacer(Modifier.width(8.dp))
                                Column(Modifier.padding(top = 2.dp)) {
                                    Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                    Text(desc, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Remove hidden info", Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                            Switch(checked = strip, onCheckedChange = { strip = it }, enabled = !busy)
                        }
                        Spacer(Modifier.height(12.dp))
                        Text(
                            "Each file is saved as a new copy named \"…_compressed.pdf\" in ${OutputStore.label(ctx)}. Your originals stay as they are.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (busy) {
                        CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp)
                        Spacer(Modifier.width(12.dp))
                        Text(progress, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                    } else if (finished) {
                        Button(onClick = onClose) { Text("Close") }
                    } else {
                        Button(onClick = { run() }, enabled = files.isNotEmpty()) { Text("Compress ${files.size} file(s)") }
                    }
                }
            }
        }
    }
}
