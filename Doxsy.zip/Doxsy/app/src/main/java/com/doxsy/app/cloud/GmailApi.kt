package com.doxsy.app.cloud

import android.util.Base64
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.json.JSONObject
import java.io.OutputStream

data class MailPdf(
    val messageId: String,
    val attachmentId: String,
    val filename: String,
    val from: String,
    val date: Long,
    val size: Long,
)

object GmailApi {
    private const val BASE = "https://gmail.googleapis.com/gmail/v1/users/me"
    private const val PART = "filename,mimeType,body(attachmentId,size)"
    private val FIELDS =
        "id,internalDate,payload(headers(name,value),parts($PART,parts($PART,parts($PART))))"

    suspend fun listPdfs(token: String, max: Int = 40): List<MailPdf> = coroutineScope {
        val q = enc("has:attachment filename:pdf")
        val list = JSONObject(String(Net.request("$BASE/messages?q=$q&maxResults=$max", token)))
        val arr = list.optJSONArray("messages") ?: return@coroutineScope emptyList()
        val gate = Semaphore(6)
        val errors = java.util.Collections.synchronizedList(ArrayList<Exception>())
        val found = (0 until arr.length()).map { i ->
            val id = arr.getJSONObject(i).getString("id")
            async {
                gate.withPermit {
                    try {
                        readMessage(token, id)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        errors += e
                        emptyList()
                    }
                }
            }
        }.awaitAll().flatten().sortedByDescending { it.date }
        // every message failed (expired token, API off...): show the real error instead of "no PDFs"
        if (found.isEmpty() && errors.isNotEmpty()) throw errors.first()
        found
    }

    private fun readMessage(token: String, id: String): List<MailPdf> {
        val msg = JSONObject(String(Net.request("$BASE/messages/$id?format=full&fields=${enc(FIELDS)}", token)))
        val payload = msg.optJSONObject("payload") ?: return emptyList()
        var from = ""
        val headers = payload.optJSONArray("headers")
        if (headers != null) {
            for (i in 0 until headers.length()) {
                val h = headers.getJSONObject(i)
                if (h.optString("name").equals("From", true)) from = h.optString("value")
            }
        }
        val sender = from.substringBefore('<').trim().trim('"').ifEmpty { from }
        val date = msg.optString("internalDate").toLongOrNull() ?: 0L
        val found = ArrayList<MailPdf>()
        collect(payload, id, sender, date, found)
        return found
    }

    private fun collect(part: JSONObject, msgId: String, from: String, date: Long, out: MutableList<MailPdf>) {
        val name = part.optString("filename")
        val body = part.optJSONObject("body")
        val attId = body?.optString("attachmentId").orEmpty()
        val isPdf = name.endsWith(".pdf", true) ||
            (name.isNotBlank() && part.optString("mimeType").equals("application/pdf", true))
        if (isPdf && attId.isNotEmpty()) {
            val fileName = if (name.endsWith(".pdf", true)) name else "$name.pdf"
            out += MailPdf(msgId, attId, fileName, from, date, body?.optLong("size") ?: 0L)
        }
        val kids = part.optJSONArray("parts") ?: return
        for (i in 0 until kids.length()) collect(kids.getJSONObject(i), msgId, from, date, out)
    }

    fun downloadTo(token: String, pdf: MailPdf, out: OutputStream) {
        val json = JSONObject(String(Net.request("$BASE/messages/${pdf.messageId}/attachments/${pdf.attachmentId}", token)))
        out.write(Base64.decode(json.getString("data"), Base64.URL_SAFE))
    }
}
