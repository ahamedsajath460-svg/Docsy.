package com.doxsy.app.ui.convert

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.doxsy.app.convert.Conversion
import com.doxsy.app.convert.ConversionHistory
import com.doxsy.app.convert.ConvertEngine
import com.doxsy.app.convert.ConvertOutcome
import com.doxsy.app.convert.ConvertSettings
import com.doxsy.app.convert.HistoryItem
import com.doxsy.app.convert.MarginPref
import com.doxsy.app.convert.OrientationPref
import com.doxsy.app.convert.PaperSize
import com.doxsy.app.convert.SourceKind
import com.doxsy.app.pdf.PdfTools
import com.doxsy.app.ui.KindBadge
import com.doxsy.app.util.FileKind
import com.doxsy.app.util.FileUtils
import com.doxsy.app.util.OutputStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

private data class SourceFile(val uri: Uri, val name: String, val size: Long)

private val DPI_CHOICES = listOf(96, 150, 200, 300)

private fun unitFor(conv: Conversion): String = when {
    conv.fromPdf -> "pages"
    conv.source == SourceKind.IMAGES -> "images"
    else -> "parts"
}

private fun pagesLabel(pc: Int?): String = when {
    pc == null -> "Reading…"
    pc == PdfTools.PAGES_ENCRYPTED -> "Password-protected"
    pc <= 0 -> "Can't read this file"
    else -> "$pc pages"
}

/** One conversion: pick the input, choose settings and an output folder, run, then open or share the result. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun ConvertPane(
    conv: Conversion,
    history: ConversionHistory,
    onBack: () -> Unit,
    onOpenPdf: (Uri) -> Unit,
    onOpenDocument: (Uri) -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    // ---- Input ----
    var sources by remember { mutableStateOf<List<SourceFile>>(emptyList()) }
    var defaultName by remember { mutableStateOf("") }
    var pageCount by remember { mutableStateOf<Int?>(null) }

    // ---- Settings ----
    var quality by remember { mutableFloatStateOf(90f) }
    var dpi by remember { mutableIntStateOf(150) }
    var pageSpec by remember { mutableStateOf("") }
    var orientation by remember { mutableStateOf(OrientationPref.AUTO) }
    var paper by remember { mutableStateOf(PaperSize.A4) }
    var margin by remember { mutableStateOf(MarginPref.NORMAL) }
    var outName by remember { mutableStateOf("") }

    // ---- Output folder ----
    var outLabel by remember { mutableStateOf(OutputStore.label(ctx)) }
    var customFolder by remember { mutableStateOf(OutputStore.outputTree(ctx) != null) }

    // ---- Run ----
    var busy by remember { mutableStateOf(false) }
    var done by remember { mutableIntStateOf(0) }
    var total by remember { mutableIntStateOf(0) }
    var runJob by remember { mutableStateOf<Job?>(null) }
    var outcome by remember { mutableStateOf<ConvertOutcome?>(null) }
    var notice by remember { mutableStateOf<String?>(null) }

    fun addSources(uris: List<Uri>, replace: Boolean) {
        uris.forEach { u ->
            runCatching { ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        }
        scope.launch {
            val files = withContext(Dispatchers.IO) {
                uris.map { SourceFile(it, FileUtils.displayName(ctx, it), PdfTools.querySize(ctx, it)) }
            }
            val name = withContext(Dispatchers.IO) { ConvertEngine.baseName(ctx, uris, ConvertSettings()) }
            sources = if (replace) files else sources + files
            defaultName = name
            outcome = null
            notice = null
            if (replace) pageCount = null
            if (conv.fromPdf) pageCount = PdfTools.inspect(ctx, uris.first())
        }
    }

    val pickOne = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) addSources(listOf(uri), replace = true)
    }
    val pickMany = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { list ->
        if (list.isNotEmpty()) addSources(list, replace = false)
    }
    val pickFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { tree ->
        if (tree != null) {
            runCatching {
                ctx.contentResolver.takePersistableUriPermission(
                    tree,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
                )
            }
            OutputStore.setOutputTree(ctx, tree)
            outLabel = OutputStore.label(ctx)
            customFolder = true
        }
    }

    fun pick() {
        if (conv.source.multi) pickMany.launch(conv.source.mimes) else pickOne.launch(conv.source.mimes)
    }

    fun move(i: Int, d: Int) {
        val j = i + d
        if (j !in sources.indices) return
        val m = sources.toMutableList()
        val tmp = m[i]
        m[i] = m[j]
        m[j] = tmp
        sources = m
    }

    // ---- Validation ----
    val pageCountNow = pageCount
    val pdfError: String? = when {
        !conv.fromPdf || pageCountNow == null -> null
        pageCountNow == PdfTools.PAGES_ENCRYPTED ->
            "This PDF is password-protected. Remove the password first."
        pageCountNow <= 0 -> "This file can't be read as a PDF."
        else -> null
    }
    val pages: Int? = pageCountNow?.takeIf { conv.fromPdf && it > 0 }
    val pageError: String? = when {
        !conv.usesPages || pages == null -> null
        pageSpec.isBlank() || pageSpec.trim().equals("all", ignoreCase = true) -> null
        PdfTools.parsePages(pageSpec, pages) == null ->
            "Use All, or a list such as 1-3, 5 (this PDF has $pages pages)."
        else -> null
    }
    val blocker: String? = pdfError ?: pageError
    val canRun = !busy && sources.isNotEmpty() && blocker == null && (!conv.fromPdf || pages != null)

    fun startConversion() {
        val srcs = sources.map { it.uri }
        if (srcs.isEmpty() || busy) return
        val label = if (sources.size == 1) sources[0].name else "${sources[0].name} +${sources.size - 1}"
        val settings = ConvertSettings(
            quality = quality.roundToInt(),
            dpi = dpi,
            pages = pageSpec.trim(),
            orientation = orientation,
            paper = paper,
            margin = margin,
            outName = outName.trim(),
        )
        busy = true
        done = 0
        total = 0
        outcome = null
        notice = null
        runJob = scope.launch {
            val self = coroutineContext.job
            val result: ConvertOutcome? = try {
                withContext(Dispatchers.IO) {
                    ConvertEngine.run(
                        ctx,
                        conv,
                        srcs,
                        settings,
                        ensure = { self.ensureActive() },
                        progress = { d, t ->
                            done = d
                            total = t
                        },
                    )
                }
            } catch (e: CancellationException) {
                notice = "Conversion cancelled. Nothing was saved."
                null
            } catch (e: Exception) {
                ConvertOutcome.Failure(e.message ?: "The conversion failed.")
            }
            busy = false
            runJob = null
            if (result == null) return@launch
            outcome = result
            val ok = result as? ConvertOutcome.Success
            val message = when (result) {
                is ConvertOutcome.Success -> result.message
                is ConvertOutcome.Failure -> result.message
            }
            history.add(
                HistoryItem(
                    time = System.currentTimeMillis(),
                    source = label,
                    target = conv.title,
                    outputUri = ok?.outputs?.firstOrNull()?.toString(),
                    mime = ok?.mime ?: conv.outMime,
                    ok = ok != null,
                    message = message,
                ),
            )
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 24.dp),
    ) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") }
            Text(conv.title, style = MaterialTheme.typography.titleLarge)
        }
        Text(
            conv.desc,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 20.dp),
        )
        conv.note?.let {
            Text(
                it,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
            )
        }
        Spacer(Modifier.height(12.dp))

        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            // ---- Input ----
            SectionLabel("Input")
            sources.forEachIndexed { i, f ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                ) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        KindBadge(FileKind.of(f.name), size = 40)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
                            val detail = if (conv.fromPdf && i == 0) {
                                "${FileUtils.formatSize(f.size)} · ${pagesLabel(pageCount)}"
                            } else {
                                FileUtils.formatSize(f.size)
                            }
                            Text(
                                detail,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        if (conv.source.multi && sources.size > 1) {
                            IconButton(onClick = { move(i, -1) }, enabled = !busy && i > 0) {
                                Icon(Icons.Rounded.KeyboardArrowUp, "Move up")
                            }
                            IconButton(onClick = { move(i, 1) }, enabled = !busy && i < sources.lastIndex) {
                                Icon(Icons.Rounded.KeyboardArrowDown, "Move down")
                            }
                        }
                        IconButton(
                            onClick = { sources = sources.filterIndexed { j, _ -> j != i } },
                            enabled = !busy,
                        ) { Icon(Icons.Rounded.Close, "Remove") }
                    }
                }
            }
            val pickLabel = when {
                sources.isEmpty() -> "Choose ${conv.source.label}"
                conv.source.multi -> "Add more ${conv.source.label}"
                else -> "Choose a different file"
            }
            OutlinedButton(onClick = { pick() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                Text(pickLabel)
            }

            if (sources.isNotEmpty()) {
                // ---- Settings ----
                SectionLabel("Settings")
                if (conv.usesPages) {
                    OutlinedTextField(
                        value = pageSpec,
                        onValueChange = { pageSpec = it.take(120) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        enabled = !busy,
                        label = { Text("Pages") },
                        placeholder = { Text("All") },
                        isError = pageError != null,
                        supportingText = {
                            Text(
                                pageError ?: if (pages != null) "This PDF has $pages pages. Examples: All, 1-3, 5, 8-" else "",
                            )
                        },
                    )
                }
                if (conv.usesQuality) {
                    Text(
                        "Quality ${quality.roundToInt()}%",
                        style = MaterialTheme.typography.bodyLarge,
                    )
                    Slider(
                        value = quality,
                        onValueChange = { quality = it },
                        valueRange = 30f..100f,
                        steps = 13,
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Text(
                        "Higher quality keeps more detail and makes a bigger file.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (conv.usesDpi) {
                    Text("Resolution", style = MaterialTheme.typography.bodyLarge)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        DPI_CHOICES.forEach { d ->
                            FilterChip(
                                selected = dpi == d,
                                onClick = { dpi = d },
                                enabled = !busy,
                                label = { Text("$d DPI") },
                            )
                        }
                    }
                }
                if (conv.usesPaper) {
                    Text("Page orientation", style = MaterialTheme.typography.bodyLarge)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OrientationPref.entries.forEach { o ->
                            FilterChip(
                                selected = orientation == o,
                                onClick = { orientation = o },
                                enabled = !busy,
                                label = { Text(o.label) },
                            )
                        }
                    }
                    Text("Paper size", style = MaterialTheme.typography.bodyLarge)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PaperSize.entries.forEach { p ->
                            FilterChip(
                                selected = paper == p,
                                onClick = { paper = p },
                                enabled = !busy,
                                label = { Text(p.label) },
                            )
                        }
                    }
                    Text("Margins", style = MaterialTheme.typography.bodyLarge)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MarginPref.entries.forEach { m ->
                            FilterChip(
                                selected = margin == m,
                                onClick = { margin = m },
                                enabled = !busy,
                                label = { Text(m.label) },
                            )
                        }
                    }
                }
                OutlinedTextField(
                    value = outName,
                    onValueChange = { outName = it.take(100) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    enabled = !busy,
                    label = { Text("File name") },
                    placeholder = { Text(defaultName.ifBlank { "Same as the original" }) },
                    supportingText = {
                        val shown = outName.trim().ifBlank { defaultName }.ifBlank { "Doxsy" }
                        Text("Saved as $shown.${conv.outExt}")
                    },
                )

                // ---- Output folder ----
                SectionLabel("Save to")
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.FolderOpen, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(outLabel, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                "A new file is created. Originals are never changed.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { pickFolder.launch(null) }, enabled = !busy) { Text("Choose folder") }
                    if (customFolder) {
                        TextButton(
                            onClick = {
                                OutputStore.setOutputTree(ctx, null)
                                outLabel = OutputStore.label(ctx)
                                customFolder = false
                            },
                            enabled = !busy,
                        ) { Text("Use default") }
                    }
                }

                // ---- Run ----
                blocker?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                }
                if (busy) {
                    val fraction = if (total > 0) done / total.toFloat() else 0f
                    LinearProgressIndicator(
                        progress = fraction,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Text(
                        if (total > 0) "$done of $total ${unitFor(conv)} done" else "Starting…",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    OutlinedButton(onClick = { runJob?.cancel() }, modifier = Modifier.fillMaxWidth()) {
                        Text("Cancel")
                    }
                } else {
                    Button(onClick = { startConversion() }, enabled = canRun, modifier = Modifier.fillMaxWidth()) {
                        Text("Convert")
                    }
                }
            }

            notice?.let {
                Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            // ---- Result ----
            when (val r = outcome) {
                is ConvertOutcome.Success -> Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Done", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Text(r.message, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        r.outputs.firstOrNull()?.let { out ->
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { openOutput(ctx, out, r.mime, onOpenPdf, onOpenDocument) }) { Text("Open") }
                                OutlinedButton(onClick = { FileUtils.share(ctx, out, r.mime) }) { Text("Share") }
                            }
                        }
                    }
                }
                is ConvertOutcome.Failure -> Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Couldn't finish", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onErrorContainer)
                        Text(r.message, color = MaterialTheme.colorScheme.onErrorContainer)
                    }
                }
                null -> Unit
            }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
}
