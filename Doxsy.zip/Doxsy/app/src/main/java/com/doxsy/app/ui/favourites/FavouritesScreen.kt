package com.doxsy.app.ui.favourites

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.doxsy.app.data.DocEntry
import com.doxsy.app.data.Prefs
import com.doxsy.app.ui.DocRow
import com.doxsy.app.ui.EmptyState
import com.doxsy.app.util.FileUtils

@Composable
fun FavouritesScreen(prefs: Prefs, onOpen: (DocEntry) -> Unit) {
    val favourites by prefs.favourites.state.collectAsState()
    val positions by prefs.positions.state.collectAsState()

    Column(Modifier.fillMaxSize()) {
        Text(
            "Favourites",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(start = 20.dp, top = 16.dp, bottom = 8.dp),
        )
        if (favourites.isEmpty()) {
            EmptyState(
                Icons.Rounded.StarBorder,
                "No favourites yet",
                "Tap the star on any document to keep it here for quick access.",
            )
        } else {
            LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
                items(favourites, key = { it.uri }) { e ->
                    val page = positions[e.uri] ?: 0
                    val sub = buildList {
                        if (e.pageCount > 0) add("${e.pageCount} pages")
                        if (page > 0) add("page ${page + 1}")
                        if (e.lastOpened > 0) add(FileUtils.formatDate(e.lastOpened))
                    }.joinToString(" · ").ifBlank { "PDF" }
                    DocRow(
                        name = e.name,
                        subtitle = sub,
                        favourite = true,
                        onClick = { onOpen(e) },
                        onToggleFavourite = { prefs.toggleFavourite(e) },
                    )
                }
            }
        }
    }
}
