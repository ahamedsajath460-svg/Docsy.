package com.doxsy.app.ui.docview

import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.doxsy.app.docview.Deck
import com.doxsy.app.docview.Slide
import com.doxsy.app.docview.SlideRenderer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/** Zoom limits shared by every viewer (1f = 100%). */
internal const val MIN_ZOOM = 0.5f
internal const val MAX_ZOOM = 3f

/**
 * Slides: each slide is drawn by [SlideRenderer] at the current width, then its text and speaker
 * notes are listed under it (so they can be selected and searched). Drawn bitmaps are kept in a
 * small LRU cache so scrolling back is instant without holding every slide in memory.
 */
@Composable
internal fun SlidesView(
    deck: Deck,
    zoom: Float,
    listState: LazyListState,
    hl: Highlights,
    modifier: Modifier = Modifier,
) {
    if (deck.slides.isEmpty()) {
        Notice("This presentation has no slides.")
        return
    }
    val density = LocalDensity.current.density
    val screenDp = LocalConfiguration.current.screenWidthDp
    val widthPx = ((screenDp - 48) * density * zoom).roundToInt().coerceIn(320, 2560)
    val cache = remember(widthPx) { LruCache<String, ImageBitmap>(6) }
    val total = deck.slides.size

    LazyColumn(
        modifier.fillMaxSize(),
        state = listState,
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        itemsIndexed(deck.slides) { s, slide ->
            SlideCard(slide, s, total, widthPx, cache, hl)
        }
    }
}

@Composable
private fun SlideCard(
    slide: Slide,
    position: Int,
    total: Int,
    widthPx: Int,
    cache: LruCache<String, ImageBitmap>,
    hl: Highlights,
) {
    val ink = MaterialTheme.colorScheme.onSurface
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val cacheKey = "$position@$widthPx"
    val rendered by produceState<Result<ImageBitmap>?>(null, cacheKey) {
        value = withContext(Dispatchers.Default) {
            runCatching {
                cache.get(cacheKey) ?: SlideRenderer.render(slide, widthPx).asImageBitmap().also { cache.put(cacheKey, it) }
            }
        }
    }
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Column(Modifier.padding(10.dp)) {
            Text("Slide ${position + 1} of $total", style = MaterialTheme.typography.labelMedium, color = muted)
            Spacer8()
            val frame = Modifier
                .fillMaxWidth()
                .aspectRatio(slide.aspect.takeIf { it > 0f } ?: (16f / 9f))
                .clip(RoundedCornerShape(6.dp))
            when (val r = rendered) {
                null -> Box(frame.background(MaterialTheme.colorScheme.surfaceVariant))
                else -> r.fold(
                    onSuccess = { bmp ->
                        Image(
                            bitmap = bmp,
                            contentDescription = "Slide ${position + 1}",
                            contentScale = ContentScale.FillBounds,
                            modifier = frame,
                        )
                    },
                    onFailure = {
                        Box(frame.background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
                            Text("This slide could not be drawn.", color = muted)
                        }
                    },
                )
            }
            val texts = slideParas(slide)
            if (texts.isNotEmpty()) {
                Spacer8()
                texts.forEachIndexed { p, para ->
                    val key = "t/$position/$p"
                    val shown = AnnotatedString(para.plain).withHighlights(hl.ranges(key), hl.currentIn(key))
                    Text(shown, color = ink, fontSize = 13.sp)
                }
            }
            val notes = slide.notes?.takeIf { it.isNotBlank() }
            if (notes != null) {
                Spacer8()
                Text("Speaker notes", style = MaterialTheme.typography.labelMedium, color = muted)
                val key = "n/$position"
                val shown = AnnotatedString(notes).withHighlights(hl.ranges(key), hl.currentIn(key))
                Text(shown, color = ink, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun Spacer8() {
    Spacer(Modifier.height(8.dp))
}

/**
 * A single picture with pinch-zoom and pan. [zoom] is shared with the zoom buttons. Pinching
 * reports the new value through [onZoomChange].
 */
@Composable
internal fun ImageViewer(
    pic: Loaded.Picture,
    zoom: Float,
    onZoomChange: (Float) -> Unit,
    name: String,
    modifier: Modifier = Modifier,
) {
    val ib = remember(pic) { pic.bitmap.asImageBitmap() }
    val currentZoom by rememberUpdatedState(zoom)
    val currentOnZoom by rememberUpdatedState(onZoomChange)
    var offset by remember { mutableStateOf(Offset.Zero) }
    LaunchedEffect(zoom) {
        if (zoom <= 1f) offset = Offset.Zero
    }
    Box(
        modifier
            .fillMaxSize()
            .clipToBounds()
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, gestureZoom, _ ->
                    currentOnZoom((currentZoom * gestureZoom).coerceIn(MIN_ZOOM, MAX_ZOOM))
                    if (currentZoom > 1f) offset += pan
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Image(
            bitmap = ib,
            contentDescription = name,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = zoom
                    scaleY = zoom
                    translationX = offset.x
                    translationY = offset.y
                },
        )
    }
}
