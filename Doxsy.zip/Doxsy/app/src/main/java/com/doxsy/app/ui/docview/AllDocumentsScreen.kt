package com.doxsy.app.ui.docview

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.doxsy.app.data.Prefs
import com.doxsy.app.docview.DocRecent
import com.doxsy.app.docview.DocRecents
import com.doxsy.app.ui.EmptyState
import com.doxsy.app.ui.KindBadge
import com.doxsy.app.util.DocFormat
import com.doxsy.app.util.FileKind
import com.doxsy.app.util.FileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * All Documents: opens any supported non-PDF document (Word, Excel, PowerPoint, text, CSV, web, images)
 * in Doxsy's own viewer and keeps a list of recently opened ones. Formats Doxsy cannot render are
 * handed to another app.
 */
@Composable
fun AllDocumentsScreen(
    prefs: Prefs,
    onBack: () -> Unit,
    onOpenDocument: (Uri) -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var recents by remember { mutableStateOf(DocRecents.list(ctx)) }
    var confirmClear by remember { mutableStateOf(false) }

    /** Opens [uri] in the in-app viewer, or hands it to another app. [known] skips detection. */
    fun openEntry(uri: Uri, name: String, known: DocFormat?) {
        scope.launch {
            val fmt = known ?: withContext(Dispatchers.IO) {
                runCatching { DocFormat.detect(ctx, uri, name) }.getOrDefault(DocFormat.UNKNOWN)
            }
            if (fmt.inApp) {
                if (fmt != DocFormat.PDF) DocRecents.add(ctx, uri, name, fmt)
                onOpenDocument(uri)
            } else {
                FileUtils.viewExternal(ctx, uri, mimeOf(ctx, uri, name))
            }
            recents = DocRecents.list(ctx)
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            openEntry(uri, FileUtils.displayName(ctx, uri), null)
        }
    }

    BackHandler { onBack() }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding(),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") }
            Text(
                "All Documents",
                style = MaterialTheme.typography.titleLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
        }

        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Button(
                    onClick = { picker.launch(arrayOf("*/*")) },
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Icon(Icons.Rounded.FolderOpen, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Open a document")
                }
            }

            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Supported formats", style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.size(10.dp))
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            DocFormat.entries.filter { it.inApp }.forEach { FormatChip(it.label) }
                        }
                        Spacer(Modifier.size(10.dp))
                        Text(
                            "Other formats (DOC, XLS, PPT) open in another app.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Recent documents", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    if (recents.isNotEmpty()) {
                        TextButton(onClick = { confirmClear = true }) { Text("Clear all") }
                    }
                }
            }

            if (recents.isEmpty()) {
                item {
                    EmptyState(
                        Icons.Rounded.Description,
                        "No recent documents",
                        "Word, Excel, PowerPoint, text and other documents you open appear here.",
                    )
                }
            } else {
                items(recents, key = { it.uri }) { r ->
                    RecentRow(
                        entry = r,
                        onOpen = { openEntry(Uri.parse(r.uri), r.name, r.format) },
                        onRemove = {
                            DocRecents.remove(ctx, r.uri)
                            recents = DocRecents.list(ctx)
                        },
                    )
                }
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear recent documents?") },
            text = { Text("The list is cleared. Your files are not deleted.") },
            confirmButton = {
                TextButton(onClick = {
                    DocRecents.clear(ctx)
                    recents = DocRecents.list(ctx)
                    confirmClear = false
                }) { Text("Clear") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun FormatChip(label: String) {
    Row(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(MaterialTheme.colorScheme.primaryContainer)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
    }
}

@Composable
private fun RecentRow(entry: DocRecent, onOpen: () -> Unit, onRemove: () -> Unit) {
    Card(
        onClick = onOpen,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Row(
            Modifier.padding(start = 12.dp, top = 10.dp, bottom = 10.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            KindBadge(FileKind.of(entry.name), size = 40)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(entry.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    "${entry.format.label} · ${FileUtils.formatDate(entry.lastOpened)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            IconButton(onClick = onRemove) { Icon(Icons.Rounded.Close, "Remove from recent documents") }
        }
    }
}

/** MIME type for handing a file to another app: the content resolver first, then the file extension. */
internal fun mimeOf(ctx: Context, uri: Uri, name: String): String {
    val fromResolver = runCatching { ctx.contentResolver.getType(uri) }.getOrNull()
    if (!fromResolver.isNullOrBlank()) return fromResolver
    val ext = name.substringAfterLast('.', "").lowercase()
    return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
}
