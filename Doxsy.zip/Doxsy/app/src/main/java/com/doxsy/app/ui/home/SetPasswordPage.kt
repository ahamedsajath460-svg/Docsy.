package com.doxsy.app.ui.home

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.doxsy.app.pdf.PdfTools
import com.doxsy.app.pdf.ToolResult
import com.doxsy.app.util.FileUtils
import kotlinx.coroutines.launch

private const val MIN_LENGTH = 4

/** Letters, numbers and standard keyboard symbols only (the same kind of rule Acrobat has: no spaces, no accented letters). */
private fun supported(p: String): Boolean = p.all { it in '!'..'~' }

private fun strength(p: String): Int {
    var s = 0
    if (p.length >= 8) s++
    if (p.length >= 12) s++
    if (p.any { it.isDigit() } && p.any { it.isLetter() }) s++
    if (p.any { !it.isLetterOrDigit() }) s++
    if (p.any { it.isUpperCase() } && p.any { it.isLowerCase() }) s++
    return s
}

/**
 * Full-screen "Set password" page (Adobe Acrobat style): back arrow, title, file card, Password and
 * Confirm password fields, a password strength bar and a Set password button.
 * A protected copy "_protected.pdf" is saved where the user chooses; the original is never changed.
 */
@Composable
fun SetPasswordPage(
    name: String,
    uri: Uri,
    onClose: () -> Unit,
    onOpenPdf: (Uri, String) -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pass1 by remember { mutableStateOf("") }
    var pass2 by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<Triple<ToolResult, Uri, String>?>(null) }
    val size = remember(uri) { PdfTools.querySize(ctx, uri) }
    val outName = name.substringBeforeLast('.') + "_protected.pdf"

    val badChars = pass1.isNotEmpty() && !supported(pass1)
    val tooShort = pass1.isNotEmpty() && pass1.length < MIN_LENGTH
    val mismatch = pass2.isNotEmpty() && pass1 != pass2
    val valid = pass1.length >= MIN_LENGTH && supported(pass1) && pass1 == pass2

    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { out ->
        if (out != null) {
            busy = true
            val pw = pass1
            scope.launch {
                val r = PdfTools.protect(ctx, uri, pw, out)
                busy = false
                result = Triple(r, out, outName)
            }
        }
    }

    val visual: VisualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation()
    val s = strength(pass1)
    val sLabel = when { s <= 1 -> "Weak"; s <= 3 -> "Medium"; else -> "Strong" }
    val sColor = when { s <= 1 -> Color(0xFFD32F2F); s <= 3 -> Color(0xFFF9A825); else -> Color(0xFF2E7D32) }

    Dialog(
        onDismissRequest = { if (!busy) onClose() },
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false),
    ) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                IconButton(onClick = { if (!busy) onClose() }, modifier = Modifier.padding(start = 8.dp, top = 8.dp)) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back")
                }
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 24.dp)) {
                    Spacer(Modifier.height(8.dp))
                    Text("Set password", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(24.dp))
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            PdfThumb(uri.toString(), name, Modifier.size(width = 40.dp, height = 52.dp))
                            Spacer(Modifier.width(16.dp))
                            Column(Modifier.weight(1f)) {
                                Text(name.substringBeforeLast('.'), style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(
                                    if (size > 0) "PDF  •  " + FileUtils.formatSize(size) else "PDF",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(28.dp))
                    Text("Anyone who opens this PDF will need the password.", style = MaterialTheme.typography.bodyLarge)
                    Spacer(Modifier.height(16.dp))
                    OutlinedTextField(
                        value = pass1,
                        onValueChange = { pass1 = it },
                        label = { Text("Password") },
                        singleLine = true,
                        enabled = !busy,
                        isError = badChars || tooShort,
                        visualTransformation = visual,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        trailingIcon = {
                            IconButton(onClick = { show = !show }) {
                                Icon(if (show) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, if (show) "Hide password" else "Show password")
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    if (pass1.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = (s.coerceIn(1, 5)) / 5f,
                            color = sColor,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.fillMaxWidth().height(4.dp),
                        )
                        Text("Password strength: $sLabel", style = MaterialTheme.typography.bodySmall, color = sColor, modifier = Modifier.padding(top = 4.dp))
                    }
                    if (badChars) {
                        Text(
                            "Use only letters, numbers and standard symbols. Spaces and accented or other-language letters are not supported.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(top = 6.dp),
                        )
                    } else if (tooShort) {
                        Text("Use at least $MIN_LENGTH characters.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 6.dp))
                    }
                    Spacer(Modifier.height(16.dp))
                    OutlinedTextField(
                        value = pass2,
                        onValueChange = { pass2 = it },
                        label = { Text("Confirm password") },
                        singleLine = true,
                        enabled = !busy,
                        isError = mismatch,
                        visualTransformation = visual,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    if (mismatch) {
                        Text("Passwords do not match.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 6.dp))
                    }
                    Spacer(Modifier.height(20.dp))
                    Text(
                        "A protected copy is saved as \"$outName\"; your original stays as it is. Keep the password somewhere safe: it cannot be recovered if you forget it.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (busy) {
                        CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp)
                        Spacer(Modifier.width(12.dp))
                        Text("Protecting…", style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.width(16.dp))
                    }
                    Button(onClick = { save.launch(outName) }, enabled = valid && !busy) { Text("Set password") }
                }
            }
        }
    }

    result?.let { (r, out, file) ->
        val ok = r is ToolResult.Done
        AlertDialog(
            onDismissRequest = { result = null },
            title = { Text(if (ok) "Password set" else "Couldn't set password") },
            text = { Text(if (r is ToolResult.Done) r.message else (r as ToolResult.Failed).message) },
            confirmButton = {
                if (ok) {
                    Row {
                        TextButton(onClick = { FileUtils.share(ctx, out, "application/pdf") }) { Text("Share") }
                        TextButton(onClick = { result = null; onClose(); onOpenPdf(out, file) }) { Text("Open") }
                    }
                } else TextButton(onClick = { result = null }) { Text("OK") }
            },
            dismissButton = { if (ok) TextButton(onClick = { result = null; onClose() }) { Text("Close") } },
        )
    }
}
