package com.doxsy.app.ui.files

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.RestoreFromTrash
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.doxsy.app.data.FolderEntry
import com.doxsy.app.fileman.FileIndexer
import com.doxsy.app.fileman.FileOps
import com.doxsy.app.fileman.IndexResult
import com.doxsy.app.fileman.IndexedFile
import com.doxsy.app.fileman.OpResult
import com.doxsy.app.fileman.Progress
import com.doxsy.app.fileman.TrashEntry
import com.doxsy.app.fileman.TrashResult
import com.doxsy.app.fileman.TrashStore
import com.doxsy.app.ui.EmptyState
import com.doxsy.app.ui.KindBadge
import com.doxsy.app.util.FileItem
import com.doxsy.app.util.FileUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ---------------------------------------------------------------------------------------------
// Shared building blocks
// ---------------------------------------------------------------------------------------------

@Composable
internal fun PanelScaffold(
    title: String,
    onBack: () -> Unit,
    actions: @Composable RowScope.() -> Unit = {},
    content: @Composable () -> Unit,
) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") }
            Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            actions()
        }
        content()
    }
}

@Composable
internal fun DetailLine(label: String, value: String) {
    Column {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
internal fun NameDialog(
    title: String,
    initial: String,
    confirm: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true) },
        confirmButton = {
            TextButton(onClick = { onConfirm(text.trim()) }, enabled = text.isNotBlank() && !text.contains('/')) { Text(confirm) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

/** Progress dialog with Cancel for long copy / move / scan jobs. */
@Composable
internal fun ProgressDialog(title: String, p: Progress, onCancel: () -> Unit) {
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(200)
            tick++
        }
    }
    tick.let { }
    val total = p.total
    AlertDialog(
        onDismissRequest = {},
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (total > 0) {
                    LinearProgressIndicator(progress = { (p.done.toFloat() / total).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                    Text("${p.done} of $total", style = MaterialTheme.typography.bodySmall)
                } else {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
                if (p.current.isNotBlank()) {
                    Text(p.current, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        },
        confirmButton = { TextButton(onClick = onCancel) { Text("Cancel") } },
    )
}

// ---------------------------------------------------------------------------------------------
// Delete flow: trash first, permanent delete only after an explicit confirmation
// ---------------------------------------------------------------------------------------------

internal class Deleter(
    private val ctx: Context,
    private val scope: CoroutineScope,
    private val onDone: (List<IndexedFile>) -> Unit,
) {
    var pending by mutableStateOf<List<IndexedFile>>(emptyList())
    var reason by mutableStateOf("")
    var busy by mutableStateOf(false)

    fun request(items: List<IndexedFile>) {
        val movable = items.filter { it.canModify }
        if (movable.isEmpty() || busy) return
        busy = true
        scope.launch {
            val trashed = ArrayList<IndexedFile>()
            val unsupported = ArrayList<IndexedFile>()
            var why = ""
            for (f in movable) {
                when (val r = FileOps.moveToTrash(ctx, f)) {
                    TrashResult.Trashed -> trashed += f
                    is TrashResult.Unsupported -> {
                        unsupported += f
                        why = r.reason
                    }
                }
            }
            busy = false
            if (trashed.isNotEmpty()) {
                FileUtils.toast(ctx, "Moved ${trashed.size} item(s) to Trash.")
                onDone(trashed)
            }
            if (unsupported.isNotEmpty()) {
                reason = why
                pending = unsupported
            }
        }
    }

    fun confirmPermanent() {
        val items = pending
        pending = emptyList()
        if (items.isEmpty()) return
        scope.launch {
            val deleted = ArrayList<IndexedFile>()
            for (f in items) if (FileOps.deletePermanently(ctx, listOf(f.item)) == 0) deleted += f
            if (deleted.size < items.size) FileUtils.toast(ctx, "${items.size - deleted.size} item(s) could not be deleted.")
            if (deleted.isNotEmpty()) onDone(deleted)
        }
    }

    fun cancelPermanent() {
        pending = emptyList()
    }
}

@Composable
internal fun rememberDeleter(onDone: (List<IndexedFile>) -> Unit): Deleter {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    // Always call the latest callback, not the one captured when the Deleter was first created.
    val latest = rememberUpdatedState(onDone)
    return remember { Deleter(ctx, scope) { deleted -> latest.value(deleted) } }
}

@Composable
internal fun DeleterDialogs(d: Deleter) {
    if (d.pending.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { d.cancelPermanent() },
            title = { Text("Trash not available") },
            text = {
                Text(
                    "${d.pending.size} item(s) cannot be moved to Trash (${d.reason}). " +
                        "Delete them permanently? This cannot be undone.",
                )
            },
            confirmButton = { TextButton(onClick = { d.confirmPermanent() }) { Text("Delete permanently") } },
            dismissButton = { TextButton(onClick = { d.cancelPermanent() }) { Text("Keep") } },
        )
    }
}

// ---------------------------------------------------------------------------------------------
// Storage information
// ---------------------------------------------------------------------------------------------

@Composable
internal fun StoragePanel(
    index: IndexResult?,
    indexing: Boolean,
    folders: List<FolderEntry>,
    onRefresh: () -> Unit,
    onBack: () -> Unit,
) {
    val device = remember { FileIndexer.deviceStorage() }
    PanelScaffold("Storage", onBack, actions = {
        IconButton(onClick = onRefresh) { Icon(Icons.Rounded.Refresh, "Refresh") }
    }) {
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Device storage", style = MaterialTheme.typography.titleMedium)
                        if (device.total > 0L) {
                            val used = device.total - device.free
                            LinearProgressIndicator(progress = { (used.toFloat() / device.total).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                            Text(
                                "${FileUtils.formatSize(used)} used of ${FileUtils.formatSize(device.total)} · ${FileUtils.formatSize(device.free)} free",
                                style = MaterialTheme.typography.bodyMedium,
                            )
                        } else {
                            Text("Device storage information is not available.", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
            item {
                Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Your folders in Doxsy", style = MaterialTheme.typography.titleMedium)
                        when {
                            folders.isEmpty() -> Text("Add a folder in Files to see its size here.", style = MaterialTheme.typography.bodyMedium)
                            index == null -> Row(verticalAlignment = Alignment.CenterVertically) {
                                if (indexing) CircularProgressIndicator(Modifier.padding(end = 12.dp).height(20.dp).width(20.dp), strokeWidth = 2.dp)
                                Text(if (indexing) "Scanning folders…" else "Not scanned yet.", style = MaterialTheme.typography.bodyMedium)
                            }
                            else -> {
                                val sizes = FileIndexer.sizeByTree(index.files)
                                folders.forEach { f ->
                                    val count = index.files.count { it.treeUri?.toString() == f.uri }
                                    Row(Modifier.fillMaxWidth()) {
                                        Text(f.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text("$count files · ${FileUtils.formatSize(sizes[f.uri] ?: 0L)}", style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                                if (index.truncated) {
                                    Text("The scan was limited for very large folders; totals may be lower than the real size.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
            if (index != null) {
                item {
                    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("By type", style = MaterialTheme.typography.titleMedium)
                            val stats = FileIndexer.breakdown(index.files)
                            val max = (stats.maxOfOrNull { it.bytes } ?: 0L).coerceAtLeast(1L)
                            stats.forEach { s ->
                                Column {
                                    Row(Modifier.fillMaxWidth()) {
                                        Text(s.kind.label, Modifier.weight(1f))
                                        Text("${s.count} · ${FileUtils.formatSize(s.bytes)}", style = MaterialTheme.typography.bodySmall)
                                    }
                                    LinearProgressIndicator(progress = { (s.bytes.toFloat() / max).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().padding(top = 4.dp), color = s.kind.color)
                                }
                            }
                            if (stats.isEmpty()) Text("No files found.", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Duplicate files
// ---------------------------------------------------------------------------------------------

@Composable
internal fun DuplicatesPanel(
    index: IndexResult?,
    onOpen: (FileItem) -> Unit,
    onChanged: () -> Unit,
    onBack: () -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var groups by remember { mutableStateOf<List<List<IndexedFile>>?>(null) }
    var running by remember { mutableStateOf(false) }
    val progress = remember { Progress() }
    val deleter = rememberDeleter { deleted ->
        val keys = deleted.map { it.key }.toSet()
        groups = groups?.map { g -> g.filterNot { it.key in keys } }?.filter { it.size > 1 }
        onChanged()
    }

    PanelScaffold("Duplicate files", onBack) {
        when {
            running -> Column(Modifier.fillMaxWidth().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Comparing files…", style = MaterialTheme.typography.titleMedium)
                ProgressInline(progress)
                OutlinedButton(onClick = { progress.cancelled = true }) { Text("Cancel") }
            }
            // Results already on screen stay visible while a rescan runs in the background.
            groups == null && index == null -> EmptyState(Icons.Rounded.FolderOpen, "Scanning folders…", "Doxsy is reading your added folders.")
            groups == null -> Column(Modifier.fillMaxWidth().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    "Doxsy compares file sizes first, then checks the contents of files that could match. Everything stays on your device.",
                    style = MaterialTheme.typography.bodyMedium,
                )
                Button(onClick = {
                    progress.cancelled = false
                    running = true
                    val files = index?.files.orEmpty()
                    scope.launch {
                        val found = FileIndexer.findDuplicates(ctx, files, progress)
                        groups = found
                        running = false
                    }
                }) { Text("Find duplicates") }
            }
            groups!!.isEmpty() -> EmptyState(Icons.Rounded.CleaningServices, "No duplicates", "No identical files were found in your folders.")
            else -> {
                val list = groups!!
                LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(list, key = { g -> g.first().key }) { g ->
                        Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                            Column(Modifier.padding(12.dp)) {
                                Text(
                                    "${g.size} identical files · ${FileUtils.formatSize(g.first().item.size)} each",
                                    style = MaterialTheme.typography.titleSmall,
                                    modifier = Modifier.padding(start = 4.dp, bottom = 4.dp),
                                )
                                g.forEach { f ->
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                        KindBadge(f.item.kind, size = 36)
                                        Spacer(Modifier.width(10.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(f.item.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Text(
                                                "${f.path} · ${FileUtils.formatDate(f.item.modified)}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                            )
                                        }
                                        TextButton(onClick = { onOpen(f.item) }) { Text("Open") }
                                        IconButton(onClick = { deleter.request(listOf(f)) }) { Icon(Icons.Rounded.Delete, "Delete this copy") }
                                    }
                                }
                                val keep = g.maxByOrNull { it.item.modified } ?: g.first()
                                TextButton(onClick = { deleter.request(g.filter { it.key != keep.key }) }) {
                                    Text("Keep newest, delete the rest")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    DeleterDialogs(deleter)
}

@Composable
private fun ProgressInline(p: Progress) {
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(200)
            tick++
        }
    }
    tick.let { }
    if (p.total > 0) {
        LinearProgressIndicator(progress = { (p.done.toFloat() / p.total).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
        Text("${p.done} of ${p.total} · ${p.current}", style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
    } else {
        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
    }
}

// ---------------------------------------------------------------------------------------------
// Empty folders
// ---------------------------------------------------------------------------------------------

@Composable
internal fun EmptyFoldersPanel(index: IndexResult?, onChanged: () -> Unit, onBack: () -> Unit) {
    var removed by remember { mutableStateOf(setOf<String>()) }
    val deleter = rememberDeleter { deleted ->
        removed = removed + deleted.map { it.key }
        onChanged()
    }
    val list = index?.emptyFolders.orEmpty().filter { it.key !in removed }
    PanelScaffold("Empty folders", onBack, actions = {
        if (list.isNotEmpty()) TextButton(onClick = { deleter.request(list) }) { Text("Delete all") }
    }) {
        when {
            index == null -> EmptyState(Icons.Rounded.FolderOpen, "Scanning folders…", "Doxsy is reading your added folders.")
            list.isEmpty() -> EmptyState(Icons.Rounded.CleaningServices, "No empty folders", "Every folder in your added folders has something in it.")
            else -> LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
                items(list, key = { it.key }) { f ->
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.FolderOpen, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(f.item.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(f.path, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        IconButton(onClick = { deleter.request(listOf(f)) }) { Icon(Icons.Rounded.Delete, "Delete folder") }
                    }
                }
            }
        }
    }
    DeleterDialogs(deleter)
}

// ---------------------------------------------------------------------------------------------
// Trash
// ---------------------------------------------------------------------------------------------

@Composable
internal fun TrashPanel(onChanged: () -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var entries by remember { mutableStateOf<List<TrashEntry>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var confirmEmpty by remember { mutableStateOf(false) }

    fun reload() {
        entries = TrashStore.list(ctx).sortedByDescending { it.deletedAt }
    }
    LaunchedEffect(Unit) {
        busy = true
        FileOps.purgeExpired(ctx)
        reload()
        busy = false
    }

    PanelScaffold("Trash", onBack, actions = {
        if (entries.isNotEmpty()) TextButton(onClick = { confirmEmpty = true }) { Text("Empty trash") }
    }) {
        Text(
            "Items stay here for 30 days, then are deleted for good.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
        )
        when {
            busy -> Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            entries.isEmpty() -> EmptyState(Icons.Rounded.RestoreFromTrash, "Trash is empty", "Deleted files will appear here so you can restore them.")
            else -> LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
                items(entries, key = { it.id }) { e ->
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(e.origName, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            val left = ((TrashStore.RETENTION_MS - (System.currentTimeMillis() - e.deletedAt)) / 86_400_000L).coerceAtLeast(0)
                            Text(
                                "${if (e.isDir) "Folder" else FileUtils.formatSize(e.size)} · deleted ${FileUtils.formatDate(e.deletedAt)} · $left days left",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        IconButton(onClick = {
                            scope.launch {
                                when (val r = FileOps.restore(ctx, e)) {
                                    is OpResult.Ok -> FileUtils.toast(ctx, r.message)
                                    is OpResult.Failed -> FileUtils.toast(ctx, r.message)
                                }
                                reload()
                                onChanged()
                            }
                        }) { Icon(Icons.Rounded.RestoreFromTrash, "Restore") }
                        IconButton(onClick = {
                            scope.launch {
                                if (!FileOps.purge(ctx, e)) FileUtils.toast(ctx, "Could not delete this item.")
                                reload()
                            }
                        }) { Icon(Icons.Rounded.DeleteForever, "Delete permanently") }
                    }
                }
            }
        }
    }
    if (confirmEmpty) {
        AlertDialog(
            onDismissRequest = { confirmEmpty = false },
            title = { Text("Empty trash?") },
            text = { Text("All ${entries.size} item(s) will be deleted permanently. This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmEmpty = false
                    scope.launch {
                        busy = true
                        entries.forEach { FileOps.purge(ctx, it) }
                        reload()
                        busy = false
                    }
                }) { Text("Empty") }
            },
            dismissButton = { TextButton(onClick = { confirmEmpty = false }) { Text("Cancel") } },
        )
    }
}
