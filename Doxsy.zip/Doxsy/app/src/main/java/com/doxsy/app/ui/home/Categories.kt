package com.doxsy.app.ui.home

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.doxsy.app.data.DocEntry
import java.util.Locale

/** A titled group of files, e.g. "CAMSCANNER" with its PDFs. */
data class Category(val title: String, val files: List<DocEntry>)

const val RECENT_TITLE = "RECENT"
const val OTHER_TITLE = "OTHER"

/** Gives every entry its folder name (looked up from the phone scan when it does not carry one). */
fun withFolders(list: List<DocEntry>, device: List<DocEntry>): List<DocEntry> {
    if (list.all { it.folder.isNotEmpty() }) return list
    val byUri = device.associateBy { it.uri }
    val byName = device.associateBy { it.name.lowercase(Locale.ROOT) }
    return list.map { e ->
        if (e.folder.isNotEmpty()) e
        else {
            val f = (byUri[e.uri] ?: byName[e.name.lowercase(Locale.ROOT)])?.folder.orEmpty()
            e.copy(folder = f)
        }
    }
}

/**
 * Groups files by the folder they live in, like Adobe Acrobat's "On this device" list.
 * Folders are sorted by name (symbols/numbers first), files inside a folder newest first.
 * [recent] (files opened in the app) are shown first under a RECENT header.
 */
fun groupByFolder(files: List<DocEntry>, recent: List<DocEntry> = emptyList()): List<Category> {
    val out = ArrayList<Category>()
    val recentUris = recent.map { it.uri }.toSet()
    if (recent.isNotEmpty()) out += Category(RECENT_TITLE, recent)
    val rest = files.filter { it.uri !in recentUris }
    val groups = rest.groupBy { it.folder.ifBlank { OTHER_TITLE }.uppercase(Locale.ROOT) }
    groups.entries
        .sortedWith(compareBy<Map.Entry<String, List<DocEntry>>>({ it.key == OTHER_TITLE }, { it.key.lowercase(Locale.ROOT) }))
        .forEach { (k, v) ->
            out += Category(k, v.sortedWith(compareByDescending<DocEntry> { it.lastOpened }.thenBy { it.name.lowercase(Locale.ROOT) }))
        }
    return out
}

/** Small grey section title above each group of files. */
@Composable
fun CategoryHeader(title: String, sidePad: Int = 16) {
    Text(
        title,
        style = MaterialTheme.typography.labelMedium,
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 0.4.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = sidePad.dp, end = 16.dp, top = 18.dp, bottom = 4.dp),
    )
}
