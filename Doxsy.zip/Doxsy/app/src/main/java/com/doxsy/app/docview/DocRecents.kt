package com.doxsy.app.docview

import android.content.Context
import android.net.Uri
import com.doxsy.app.util.DocFormat
import org.json.JSONArray
import org.json.JSONObject

/** One entry in the All Documents "Recent" list. Stored as JSON in its own SharedPreferences file. */
data class DocRecent(
    val uri: String,
    val name: String,
    val format: DocFormat,
    val lastOpened: Long,
)

/**
 * Recently opened in-app documents (DOCX, XLSX, PPTX, TXT ...). Kept separate from the PDF recents
 * in [com.doxsy.app.data.Prefs]. Every call is wrapped so a broken preferences file never crashes the UI.
 */
object DocRecents {
    private const val PREFS = "doxsy_docs"
    private const val KEY = "recent_list"
    const val MAX = 30

    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun list(ctx: Context): List<DocRecent> = runCatching {
        val raw = sp(ctx).getString(KEY, null) ?: return emptyList()
        val arr = JSONArray(raw)
        val out = ArrayList<DocRecent>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val uri = o.optString("uri").takeIf { it.isNotBlank() } ?: continue
            out += DocRecent(
                uri = uri,
                name = o.optString("name", "Document"),
                format = runCatching { DocFormat.valueOf(o.optString("format")) }.getOrDefault(DocFormat.UNKNOWN),
                lastOpened = o.optLong("lastOpened", 0L),
            )
        }
        out.sortedByDescending { it.lastOpened }
    }.getOrDefault(emptyList())

    /** Puts [uri] at the top of the list. Oldest entries beyond [MAX] are dropped. */
    fun add(ctx: Context, uri: Uri, name: String, format: DocFormat) {
        val key = uri.toString()
        val now = System.currentTimeMillis()
        val rest = list(ctx).filterNot { it.uri == key }
        write(ctx, listOf(DocRecent(key, name, format, now)) + rest)
    }

    fun remove(ctx: Context, uri: String) {
        write(ctx, list(ctx).filterNot { it.uri == uri })
    }

    fun clear(ctx: Context) {
        runCatching { sp(ctx).edit().remove(KEY).apply() }
    }

    private fun write(ctx: Context, items: List<DocRecent>) {
        runCatching {
            val arr = JSONArray()
            for (r in items.take(MAX)) {
                arr.put(
                    JSONObject()
                        .put("uri", r.uri)
                        .put("name", r.name)
                        .put("format", r.format.name)
                        .put("lastOpened", r.lastOpened),
                )
            }
            sp(ctx).edit().putString(KEY, arr.toString()).apply()
        }
    }
}
