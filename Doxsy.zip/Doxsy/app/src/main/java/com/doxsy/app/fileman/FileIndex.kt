package com.doxsy.app.fileman

import android.content.Context
import android.net.Uri
import android.os.Environment
import android.os.StatFs
import android.provider.DocumentsContract
import com.doxsy.app.data.FolderEntry
import com.doxsy.app.util.FileItem
import com.doxsy.app.util.FileKind
import com.doxsy.app.util.FileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.security.MessageDigest

/**
 * A file or folder together with where it lives. [treeUri]/[parentDocId] are null for entries that
 * only come from the recents/favourites lists (those can be opened and shared but not modified).
 * [path] is the human readable path of the containing folder, e.g. "Downloads/Reports".
 */
data class IndexedFile(
    val item: FileItem,
    val treeUri: Uri?,
    val parentDocId: String?,
    val path: String = "",
) {
    val key: String get() = item.uri.toString()
    val canModify: Boolean get() = treeUri != null && parentDocId != null
}

data class IndexResult(
    val files: List<IndexedFile>,
    val emptyFolders: List<IndexedFile>,
    val truncated: Boolean,
    /** Names of added folders Doxsy could no longer read (permission lost). */
    val lostFolders: List<String>,
    val builtAt: Long,
)

data class StorageInfo(val total: Long, val free: Long)

data class KindStat(val kind: FileKind, val count: Int, val bytes: Long)

object FileIndexer {
    const val TRASH_NAME = ".DoxsyTrash"
    private const val MAX_DEPTH = 12
    private const val MAX_ENTRIES = 40_000

    /** Recursively lists every added folder. Cancellable; bounded by depth and entry count. */
    suspend fun scan(ctx: Context, folders: List<FolderEntry>, onProgress: (Int) -> Unit): IndexResult =
        withContext(Dispatchers.IO) {
            val files = ArrayList<IndexedFile>()
            val empties = ArrayList<IndexedFile>()
            val lost = ArrayList<String>()
            var truncated = false
            var counter = 0

            /** Returns the number of children, or -1 when the folder could not be read. */
            suspend fun walk(tree: Uri, parentId: String, path: String, depth: Int, isRoot: Boolean): Int {
                currentCoroutineContext().ensureActive()
                val children: List<FileItem> = try {
                    FileUtils.queryChildren(ctx, tree, parentId)
                } catch (e: SecurityException) {
                    if (isRoot) throw e else return -1
                } catch (e: Exception) {
                    return -1
                }
                for (c in children) {
                    if (files.size >= MAX_ENTRIES) {
                        truncated = true
                        break
                    }
                    if (c.isDir) {
                        if (c.name == TRASH_NAME) continue
                        if (depth < MAX_DEPTH) {
                            val sub = if (path.isEmpty()) c.name else "$path/${c.name}"
                            val n = walk(tree, c.docId, sub, depth + 1, false)
                            if (n == 0) empties.add(IndexedFile(c, tree, parentId, path))
                        } else {
                            truncated = true
                        }
                    } else {
                        files.add(IndexedFile(c, tree, parentId, path))
                        counter++
                        if (counter % 50 == 0) onProgress(counter)
                    }
                }
                return children.size
            }

            for (f in folders) {
                currentCoroutineContext().ensureActive()
                val tree = Uri.parse(f.uri)
                val rootId = runCatching { DocumentsContract.getTreeDocumentId(tree) }.getOrNull() ?: continue
                try {
                    walk(tree, rootId, f.name, 0, true)
                } catch (e: SecurityException) {
                    lost.add(f.name)
                }
            }
            onProgress(counter)
            IndexResult(files, empties, truncated, lost, System.currentTimeMillis())
        }

    fun deviceStorage(): StorageInfo = runCatching {
        val st = StatFs(Environment.getDataDirectory().path)
        StorageInfo(st.totalBytes, st.availableBytes)
    }.getOrDefault(StorageInfo(0L, 0L))

    fun breakdown(files: List<IndexedFile>): List<KindStat> =
        FileKind.entries.map { k ->
            val l = files.filter { it.item.kind == k }
            KindStat(k, l.size, l.sumOf { f -> if (f.item.size > 0L) f.item.size else 0L })
        }.filter { it.count > 0 }

    /** Total size of indexed files per added folder (keyed by tree uri string). */
    fun sizeByTree(files: List<IndexedFile>): Map<String, Long> =
        files.groupBy { it.treeUri?.toString() ?: "" }
            .mapValues { (_, l) -> l.sumOf { f -> if (f.item.size > 0L) f.item.size else 0L } }

    /** Groups of byte-identical files: same size first, then streamed SHA-256. Cancellable via [p]. */
    suspend fun findDuplicates(ctx: Context, files: List<IndexedFile>, p: Progress): List<List<IndexedFile>> =
        withContext(Dispatchers.IO) {
            val bySize = files.filter { !it.item.isDir && it.item.size > 0L }
                .groupBy { it.item.size }
                .filter { it.value.size > 1 }
            p.total = bySize.values.sumOf { it.size }
            p.done = 0
            val out = ArrayList<List<IndexedFile>>()
            for (group in bySize.values) {
                val byHash = HashMap<String, MutableList<IndexedFile>>()
                for (f in group) {
                    currentCoroutineContext().ensureActive()
                    if (p.cancelled) return@withContext out
                    p.current = f.item.name
                    val h = hashOf(ctx, f.item.uri, p)
                    p.done++
                    if (h != null) byHash.getOrPut(h) { ArrayList() }.add(f)
                }
                byHash.values.filter { it.size > 1 }.forEach { out.add(it) }
            }
            out.sortedByDescending { it.first().item.size }
        }

    private fun hashOf(ctx: Context, uri: Uri, p: Progress): String? {
        return try {
            val md = MessageDigest.getInstance("SHA-256")
            val input = ctx.contentResolver.openInputStream(uri) ?: return null
            input.use { i ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    if (p.cancelled) return null
                    val n = i.read(buf)
                    if (n < 0) break
                    md.update(buf, 0, n)
                }
            }
            md.digest().joinToString("") { b -> "%02x".format(b) }
        } catch (e: java.util.concurrent.CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
    }
}
