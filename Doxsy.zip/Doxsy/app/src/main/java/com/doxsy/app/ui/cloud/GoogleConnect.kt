package com.doxsy.app.ui.cloud

import android.accounts.AccountManager
import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Email
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.doxsy.app.cloud.AuthOutcome
import com.doxsy.app.cloud.GoogleAuth
import com.doxsy.app.cloud.GoogleScopes
import com.doxsy.app.data.Prefs
import com.doxsy.app.ui.DoxsyLogo
import com.google.android.gms.common.AccountPicker
import kotlinx.coroutines.launch

enum class ConnectStep { NONE, INTRO, LOADING, SIGNIN, PERMS, EXTRA, DONE }

/**
 * State of the "connect Google account" flow, one page at a time with a Continue button on each:
 * intro -> account list -> sign in (email) -> choose permissions -> Google's own consent for each
 * permission separately (Drive, then Gmail as "additional access") -> success.
 */
class ConnectState {
    var step by mutableStateOf(ConnectStep.NONE)
    var error by mutableStateOf<String?>(null)
    var account by mutableStateOf("")
    /** Display name from the app sign-in (blank when unknown). */
    var name by mutableStateOf("")
    /** true when started from "PDFs from emails". */
    var forGmail by mutableStateOf(false)
    var driveSel by mutableStateOf(false)
    var gmailSel by mutableStateOf(false)
    /** Permissions still to ask for, one by one. */
    var queue by mutableStateOf<List<String>>(emptyList())
    /** Permissions Google has already allowed in this flow. */
    var granted by mutableStateOf<List<String>>(emptyList())

    val drive: Boolean get() = GoogleScopes.DRIVE in granted
    val gmail: Boolean get() = GoogleScopes.GMAIL in granted

    /** After "Sign in with Google" succeeded: share page, then the permission pages. */
    fun beginAfterLogin(email: String, displayName: String) {
        error = null
        forGmail = false
        account = email
        name = displayName
        driveSel = true
        gmailSel = true
        queue = emptyList()
        granted = emptyList()
        step = ConnectStep.SIGNIN
    }

    fun begin(forGmail: Boolean = false) {
        name = ""
        error = null
        this.forGmail = forGmail
        driveSel = !forGmail
        gmailSel = forGmail
        queue = emptyList()
        granted = emptyList()
        step = ConnectStep.INTRO
    }
}

@Composable
fun rememberConnectState(): ConnectState = remember { ConnectState() }

/** Draws the pages and runs the Google account picker + authorization for [st]. */
@Composable
fun GoogleConnectHost(st: ConnectState, prefs: Prefs, onDone: () -> Unit, onCancelSignIn: () -> Unit = {}) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    fun finish() {
        if (st.granted.isEmpty()) {
            st.step = ConnectStep.NONE
            return
        }
        prefs.saveAccount(st.account)
        prefs.googleAccount.value = st.account
        if (st.gmail) prefs.gmailOn.value = true
        st.step = ConnectStep.DONE
    }

    /** Stop asking: keep whatever was already allowed. */
    fun stopAsking() {
        if (st.granted.isNotEmpty()) finish() else st.step = ConnectStep.NONE
    }

    fun allowed() {
        val done = st.queue.firstOrNull() ?: return finish()
        st.granted = st.granted + done
        st.queue = st.queue.drop(1)
        if (st.queue.isEmpty()) finish() else st.step = ConnectStep.EXTRA
    }

    val consent = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            when (val o = GoogleAuth.tokenFromIntent(ctx, r.data)) {
                is AuthOutcome.Token -> allowed()
                is AuthOutcome.Failed -> { st.error = o.message; stopAsking() }
                is AuthOutcome.Consent -> stopAsking()
            }
        } else {
            stopAsking()
        }
    }

    fun askNext() {
        val next = st.queue.firstOrNull() ?: return finish()
        st.step = ConnectStep.LOADING
        scope.launch {
            when (val o = GoogleAuth.authorize(ctx, st.account, listOf(next))) {
                is AuthOutcome.Token -> allowed()
                is AuthOutcome.Consent -> consent.launch(IntentSenderRequest.Builder(o.sender).build())
                is AuthOutcome.Failed -> { st.error = o.message; stopAsking() }
            }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val name = r.data?.getStringExtra(AccountManager.KEY_ACCOUNT_NAME)
        if (r.resultCode == Activity.RESULT_OK && !name.isNullOrBlank()) {
            st.account = name
            st.step = ConnectStep.SIGNIN
        } else {
            st.step = ConnectStep.NONE
        }
    }

    when (st.step) {
        ConnectStep.INTRO -> Dialog(onDismissRequest = { st.step = ConnectStep.NONE }) {
            Surface(shape = RoundedCornerShape(6.dp), color = MaterialTheme.colorScheme.surface) {
                Column {
                    IntroArt(st.forGmail)
                    Column(Modifier.padding(horizontal = 20.dp, vertical = 16.dp)) {
                        Text(
                            if (st.forGmail) "Access PDF attachments from your Gmail"
                            else "Access Google Drive and PDFs from Gmail using the same email",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                        )
                        Spacer(Modifier.height(10.dp))
                        Box(Modifier.fillMaxWidth().height(1.dp).background(MaterialTheme.colorScheme.outline))
                        Spacer(Modifier.height(10.dp))
                        Text(
                            "Choose your Google account. Then you decide what Doxsy can access, one permission at a time.",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                        Spacer(Modifier.height(20.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            OutlinedButton(onClick = { st.step = ConnectStep.NONE }) { Text("Cancel") }
                            Spacer(Modifier.width(12.dp))
                            Button(onClick = {
                                val intent = AccountPicker.newChooseAccountIntent(
                                    AccountPicker.AccountChooserOptions.Builder()
                                        .setAllowableAccountsTypes(listOf("com.google"))
                                        .setTitleOverrideText("Choose account for Doxsy")
                                        .build(),
                                )
                                st.step = ConnectStep.LOADING
                                picker.launch(intent)
                            }) { Text("Continue") }
                        }
                    }
                }
            }
        }
        // Page 1: sign in with the chosen account (what is shared).
        ConnectStep.SIGNIN -> ConsentPage(
            title = "Sign in to Doxsy",
            account = st.account,
            onCancel = { st.step = ConnectStep.NONE; onCancelSignIn() },
            onContinue = { st.step = ConnectStep.PERMS },
        ) {
            Text("You'll share this info about you", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(20.dp))
            if (st.name.isNotBlank()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.AccountCircle, null, modifier = Modifier.size(28.dp))
                    Spacer(Modifier.width(20.dp))
                    Column {
                        Text(st.name, style = MaterialTheme.typography.bodyLarge)
                        Text("Name and profile picture", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(Modifier.height(20.dp))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Email, null, modifier = Modifier.size(28.dp))
                Spacer(Modifier.width(20.dp))
                Column {
                    Text(st.account, style = MaterialTheme.typography.bodyLarge)
                    Text("Email address", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            TrustNote()
        }
        // Page 2: pick what Doxsy may access (each permission on its own).
        ConnectStep.PERMS -> ConsentPage(
            title = "Doxsy wants access to your Google Account",
            account = st.account,
            continueEnabled = st.driveSel || st.gmailSel,
            onCancel = { st.step = ConnectStep.NONE },
            onContinue = {
                st.granted = emptyList()
                st.queue = listOfNotNull(
                    if (st.driveSel) GoogleScopes.DRIVE else null,
                    if (st.gmailSel) GoogleScopes.GMAIL else null,
                )
                askNext()
            },
        ) {
            Text("Select what Doxsy can access", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(12.dp))
            if (!st.forGmail) {
                PermissionRow(
                    icon = { DriveLogo(32.dp) },
                    text = "See, edit, create and delete all of your Google Drive files.",
                    checked = st.driveSel,
                    onChecked = { st.driveSel = it },
                )
            }
            PermissionRow(
                icon = { Icon(androidx.compose.ui.res.painterResource(com.doxsy.app.R.drawable.ic_gmail), null, tint = Color.Unspecified, modifier = Modifier.size(32.dp)) },
                text = "See PDF attachments in your Gmail emails (read only).",
                checked = st.gmailSel,
                onChecked = { st.gmailSel = it },
            )
            TrustNote()
        }
        // Page 3: the next permission, shown after the first one was allowed.
        ConnectStep.EXTRA -> ConsentPage(
            title = "Doxsy wants additional access to your Google Account",
            account = st.account,
            onCancel = { stopAsking() },
            onContinue = { askNext() },
        ) {
            Text("When you allow this access, Doxsy will be able to", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(16.dp))
            val nextIsGmail = st.queue.firstOrNull() == GoogleScopes.GMAIL
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (nextIsGmail) {
                    Icon(androidx.compose.ui.res.painterResource(com.doxsy.app.R.drawable.ic_gmail), null, tint = Color.Unspecified, modifier = Modifier.size(32.dp))
                } else DriveLogo(32.dp)
                Spacer(Modifier.width(16.dp))
                Text(
                    if (nextIsGmail) "See PDF attachments in your Gmail emails (read only)."
                    else "See, edit, create and delete all of your Google Drive files.",
                    style = MaterialTheme.typography.bodyLarge,
                )
            }
            Spacer(Modifier.height(20.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(16.dp))
                    .padding(16.dp),
                verticalAlignment = Alignment.Top,
            ) {
                Icon(Icons.Rounded.Info, null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Doxsy already has some access", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        if (st.drive) "Google Drive is already allowed for this account." else "Another permission is already allowed for this account.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                    )
                }
            }
            TrustNote()
        }
        ConnectStep.LOADING -> Dialog(onDismissRequest = {}) {
            Surface(shape = RoundedCornerShape(4.dp)) {
                Box(Modifier.fillMaxWidth().height(96.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
        }
        ConnectStep.DONE -> Dialog(onDismissRequest = {}) {
            Surface(shape = RoundedCornerShape(6.dp)) {
                Column(
                    Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Box(
                        Modifier.size(48.dp).background(Color(0xFF0B8A1A), CircleShape),
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(30.dp)) }
                    Spacer(Modifier.height(16.dp))
                    Text(
                        if (st.drive && st.gmail) "Your Google Drive and Gmail accounts have been added."
                        else if (st.gmail) "Your Gmail account has been added."
                        else "Your Google Drive account has been added.",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center,
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        if (st.drive && st.gmail) {
                            "Now you can access PDF attachments from your Gmail account, your Google Drive files " +
                                "and save local files directly to your Google Drive."
                        } else if (st.gmail) {
                            "Now you can access PDF attachments from your Gmail account right here."
                        } else {
                            "Now you can access your Google Drive files and save local files directly to your Google Drive."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center,
                    )
                    Spacer(Modifier.height(20.dp))
                    Button(onClick = { st.step = ConnectStep.NONE; onDone() }) { Text("OK") }
                }
            }
        }
        ConnectStep.NONE -> Unit
    }

    st.error?.let { msg ->
        AlertDialog(
            onDismissRequest = { st.error = null },
            title = { Text("Couldn't connect") },
            text = { Text(msg) },
            confirmButton = { TextButton(onClick = { st.error = null }) { Text("OK") } },
        )
    }
}

/** A full-screen page like Google's consent screens: logo, big title, account, content, Cancel / Continue. */
@Composable
private fun ConsentPage(
    title: String,
    account: String,
    onCancel: () -> Unit,
    onContinue: () -> Unit,
    continueEnabled: Boolean = true,
    body: @Composable ColumnScope.() -> Unit,
) {
    Dialog(
        onDismissRequest = onCancel,
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false),
    ) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.fillMaxSize().systemBarsPadding()) {
                Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 24.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Connect Google account", style = MaterialTheme.typography.titleMedium)
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(MaterialTheme.colorScheme.outlineVariant))
                Column(
                    Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 24.dp, vertical = 24.dp),
                ) {
                    DoxsyLogo(56.dp)
                    Spacer(Modifier.height(24.dp))
                    Text(title, style = MaterialTheme.typography.headlineMedium)
                    Spacer(Modifier.height(16.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(28.dp).background(MaterialTheme.colorScheme.primary, CircleShape),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(account.take(1).uppercase(), color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.labelLarge)
                        }
                        Spacer(Modifier.width(12.dp))
                        Text(account, style = MaterialTheme.typography.bodyLarge)
                    }
                    Spacer(Modifier.height(32.dp))
                    body()
                }
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("Cancel") }
                    OutlinedButton(onClick = onContinue, enabled = continueEnabled, modifier = Modifier.weight(1f)) { Text("Continue") }
                }
            }
        }
    }
}

@Composable
private fun PermissionRow(icon: @Composable () -> Unit, text: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        icon()
        Spacer(Modifier.width(16.dp))
        Text(text, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        Checkbox(checked = checked, onCheckedChange = onChecked)
    }
}

@Composable
private fun TrustNote() {
    Spacer(Modifier.height(32.dp))
    Text("Make sure that you trust Doxsy", style = MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(12.dp))
    Text(
        "Doxsy only uses these permissions to show your files and attachments inside the app. " +
            "You can remove access at any time in your Google Account.",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

/** Blue header with a little phone showing Drive and Gmail rows, like the intro card in the video. */
@Composable
private fun IntroArt(forGmail: Boolean) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(150.dp)
            .background(Color(0xFF0B63D6)),
        contentAlignment = Alignment.BottomCenter,
    ) {
        Column(
            Modifier
                .width(150.dp)
                .height(130.dp)
                .background(Color.White, RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(Modifier.width(30.dp).height(4.dp).background(Color(0xFFCCCCCC), RoundedCornerShape(2.dp)))
            if (!forGmail) MockRow { DriveLogo(18.dp) }
            MockRow { Icon(androidx.compose.ui.res.painterResource(com.doxsy.app.R.drawable.ic_gmail), null, tint = Color.Unspecified, modifier = Modifier.size(18.dp)) }
        }
    }
}

@Composable
private fun MockRow(icon: @Composable () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFFCCCCCC), RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        icon()
        Spacer(Modifier.width(8.dp))
        Box(Modifier.weight(1f).height(4.dp).background(Color(0xFFDDDDDD), RoundedCornerShape(2.dp)))
        Icon(Icons.Rounded.ChevronRight, null, tint = Color(0xFF999999), modifier = Modifier.size(14.dp))
    }
}

/** The official Google Drive logo (vector drawable ic_google_drive). */
@Composable
fun DriveLogo(size: Dp, modifier: Modifier = Modifier) {
    Icon(
        androidx.compose.ui.res.painterResource(com.doxsy.app.R.drawable.ic_google_drive),
        contentDescription = null,
        tint = Color.Unspecified,
        modifier = modifier.size(size),
    )
}
