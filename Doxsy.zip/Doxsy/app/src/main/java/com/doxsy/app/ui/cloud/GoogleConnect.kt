package com.doxsy.app.ui.cloud

import android.accounts.AccountManager
import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddToDrive
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Email
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.doxsy.app.cloud.AuthOutcome
import com.doxsy.app.cloud.GoogleAuth
import com.doxsy.app.cloud.GoogleScopes
import com.doxsy.app.data.Prefs
import com.google.android.gms.common.AccountPicker
import kotlinx.coroutines.launch

enum class ConnectStep { NONE, INTRO, LOADING, DONE }

/** State of the "connect Google account" flow (intro card -> account list -> consent -> success). */
class ConnectState {
    var step by mutableStateOf(ConnectStep.NONE)
    var gmail by mutableStateOf(true)
    var error by mutableStateOf<String?>(null)
    var account by mutableStateOf("")

    fun begin() {
        error = null
        step = ConnectStep.INTRO
    }
}

@Composable
fun rememberConnectState(): ConnectState = remember { ConnectState() }

/** Draws the dialogs and runs the Google account picker + authorization for [st]. */
@Composable
fun GoogleConnectHost(st: ConnectState, prefs: Prefs, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    fun finish() {
        prefs.googleAccount.value = st.account
        prefs.gmailOn.value = st.gmail
        st.step = ConnectStep.DONE
    }

    val consent = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            when (val o = GoogleAuth.tokenFromIntent(ctx, r.data)) {
                is AuthOutcome.Token -> finish()
                is AuthOutcome.Failed -> { st.step = ConnectStep.NONE; st.error = o.message }
                is AuthOutcome.Consent -> { st.step = ConnectStep.NONE }
            }
        } else {
            st.step = ConnectStep.NONE
        }
    }

    fun authorize() {
        st.step = ConnectStep.LOADING
        scope.launch {
            when (val o = GoogleAuth.authorize(ctx, st.account, GoogleScopes.forAccount(st.gmail))) {
                is AuthOutcome.Token -> finish()
                is AuthOutcome.Consent -> consent.launch(IntentSenderRequest.Builder(o.sender).build())
                is AuthOutcome.Failed -> { st.step = ConnectStep.NONE; st.error = o.message }
            }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val name = r.data?.getStringExtra(AccountManager.KEY_ACCOUNT_NAME)
        if (r.resultCode == Activity.RESULT_OK && !name.isNullOrBlank()) {
            st.account = name
            authorize()
        } else {
            st.step = ConnectStep.NONE
        }
    }

    when (st.step) {
        ConnectStep.INTRO -> Dialog(onDismissRequest = { st.step = ConnectStep.NONE }) {
            Surface(shape = RoundedCornerShape(6.dp), color = MaterialTheme.colorScheme.surface) {
                Column {
                    IntroArt()
                    Column(Modifier.padding(horizontal = 20.dp, vertical = 16.dp)) {
                        Text(
                            "Access Google Drive and PDFs from Gmail using the same email",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                        )
                        Spacer(Modifier.height(10.dp))
                        Box(Modifier.fillMaxWidth().height(1.dp).background(MaterialTheme.colorScheme.outline))
                        Spacer(Modifier.height(10.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Switch(checked = st.gmail, onCheckedChange = { st.gmail = it })
                            Spacer(Modifier.width(12.dp))
                            Text(
                                "Show PDFs from Gmail from the same account",
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.weight(1f),
                            )
                        }
                        Spacer(Modifier.height(20.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            OutlinedButton(onClick = { st.step = ConnectStep.NONE }) { Text("Cancel") }
                            Spacer(Modifier.width(12.dp))
                            Button(onClick = {
                                val intent = AccountPicker.newChooseAccountIntent(
                                    AccountPicker.AccountChooserOptions.Builder()
                                        .setAllowableAccountsTypes(listOf("com.google"))
                                        .setTitleOverrideText("Choose account for Doxsy")
                                        .build(),
                                )
                                st.step = ConnectStep.LOADING
                                picker.launch(intent)
                            }) { Text("Continue") }
                        }
                    }
                }
            }
        }
        ConnectStep.LOADING -> Dialog(onDismissRequest = {}) {
            Surface(shape = RoundedCornerShape(4.dp)) {
                Box(Modifier.fillMaxWidth().height(96.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
        }
        ConnectStep.DONE -> Dialog(onDismissRequest = {}) {
            Surface(shape = RoundedCornerShape(6.dp)) {
                Column(
                    Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Box(
                        Modifier.size(48.dp).background(Color(0xFF0B8A1A), CircleShape),
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(30.dp)) }
                    Spacer(Modifier.height(16.dp))
                    Text(
                        if (st.gmail) "Your Google Drive and Gmail accounts have been added."
                        else "Your Google Drive account has been added.",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center,
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        if (st.gmail) {
                            "Now you can access PDF attachments from your Gmail account, your Google Drive files " +
                                "and save local files directly to your Google Drive."
                        } else {
                            "Now you can access your Google Drive files and save local files directly to your Google Drive."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center,
                    )
                    Spacer(Modifier.height(20.dp))
                    Button(onClick = { st.step = ConnectStep.NONE; onDone() }) { Text("OK") }
                }
            }
        }
        ConnectStep.NONE -> Unit
    }

    st.error?.let { msg ->
        AlertDialog(
            onDismissRequest = { st.error = null },
            title = { Text("Couldn't connect") },
            text = { Text(msg) },
            confirmButton = { TextButton(onClick = { st.error = null }) { Text("OK") } },
        )
    }
}

/** Blue header with a little phone showing Drive and Gmail rows, like the intro card in the video. */
@Composable
private fun IntroArt() {
    Box(
        Modifier
            .fillMaxWidth()
            .height(150.dp)
            .background(Color(0xFF0B63D6)),
        contentAlignment = Alignment.BottomCenter,
    ) {
        Column(
            Modifier
                .width(150.dp)
                .height(130.dp)
                .background(Color.White, RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(Modifier.width(30.dp).height(4.dp).background(Color(0xFFCCCCCC), RoundedCornerShape(2.dp)))
            MockRow { DriveLogo(18.dp) }
            MockRow { Icon(Icons.Rounded.Email, null, tint = Color(0xFFEA4335), modifier = Modifier.size(18.dp)) }
        }
    }
}

@Composable
private fun MockRow(icon: @Composable () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFFCCCCCC), RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        icon()
        Spacer(Modifier.width(8.dp))
        Box(Modifier.weight(1f).height(4.dp).background(Color(0xFFDDDDDD), RoundedCornerShape(2.dp)))
        Icon(Icons.Rounded.ChevronRight, null, tint = Color(0xFF999999), modifier = Modifier.size(14.dp))
    }
}

/** The three-colour Google Drive triangle, drawn with paths (no image file needed). */
@Composable
fun DriveLogo(size: Dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        fun poly(color: Color, vararg p: Pair<Float, Float>) {
            val path = Path().apply {
                moveTo(p[0].first * w, p[0].second * h)
                for (i in 1 until p.size) lineTo(p[i].first * w, p[i].second * h)
                close()
            }
            drawPath(path, color)
        }
        poly(Color(0xFF0F9D58), 0.33f to 0.0f, 0.62f to 0.0f, 0.0f to 0.72f, 0.14f to 0.96f) // green (left)
        poly(Color(0xFFFFBA00), 0.62f to 0.0f, 1.0f to 0.66f, 0.86f to 0.96f, 0.33f to 0.0f)  // yellow (right)
        poly(Color(0xFF2684FC), 0.14f to 0.96f, 0.0f to 0.72f, 0.0f to 0.72f, 0.14f to 0.96f)
        poly(Color(0xFF2684FC), 0.14f to 0.96f, 0.86f to 0.96f, 1.0f to 0.66f, 0.14f to 0.66f) // blue (bottom)
        poly(Color(0xFFEA4335), 0.86f to 0.96f, 1.0f to 0.66f, 0.76f to 0.66f, 0.6f to 0.96f)  // red tip
    }
}
