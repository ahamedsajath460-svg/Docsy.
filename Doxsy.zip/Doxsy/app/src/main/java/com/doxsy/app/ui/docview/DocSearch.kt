package com.doxsy.app.ui.docview

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.doxsy.app.docview.Para
import com.doxsy.app.docview.Sheet
import com.doxsy.app.docview.TableBlock
import com.doxsy.app.docview.Slide
import com.doxsy.app.docview.SlideText


private const val MAX_HITS = 2000

/** One match. [item] is the LazyColumn row to scroll to; [key] names the text box holding it. */
internal data class SearchHit(val item: Int, val key: String, val start: Int, val end: Int)

/** A piece of searchable text, addressed the same way the renderer addresses it. */
internal class SearchUnit(val item: Int, val key: String, val text: String)

/** Hits grouped by text box, plus the hit the user is on. */
internal class Highlights(hits: List<SearchHit>, private val current: SearchHit?) {
    private val byKey: Map<String, List<SearchHit>> = hits.groupBy { it.key }

    fun ranges(key: String): List<IntRange> = byKey[key]?.map { it.start until it.end } ?: emptyList()

    fun currentIn(key: String): IntRange? =
        current?.takeIf { it.key == key }?.let { it.start until it.end }

    companion object {
        val NONE = Highlights(emptyList(), null)
    }
}

private val HitColor = Color(0x66FFD54F)
private val CurrentHitColor = Color(0xFFFFB300)

/** Adds highlight backgrounds to an already-styled string. */
internal fun AnnotatedString.withHighlights(ranges: List<IntRange>, current: IntRange?): AnnotatedString {
    if (ranges.isEmpty() && current == null) return this
    return buildAnnotatedString {
        append(this@withHighlights)
        for (r in ranges) addStyle(SpanStyle(background = HitColor), r.first, r.last + 1)
        if (current != null) {
            addStyle(SpanStyle(background = CurrentHitColor, color = Color(0xFF111111)), current.first, current.last + 1)
        }
    }
}

/** Paragraph text that a slide shows (in reading order), used for both rendering and search. */
internal fun slideParas(slide: Slide): List<Para> =
    slide.elements.filterIsInstance<SlideText>().flatMap { it.paras }

/** Case-insensitive search over [units]. Stops at [MAX_HITS]. */
internal fun findHits(units: List<SearchUnit>, query: String): List<SearchHit> {
    if (query.isBlank()) return emptyList()
    val out = ArrayList<SearchHit>()
    for (u in units) {
        var from = 0
        while (from <= u.text.length) {
            val at = u.text.indexOf(query, from, ignoreCase = true)
            if (at < 0) break
            out += SearchHit(u.item, u.key, at, at + query.length)
            if (out.size >= MAX_HITS) return out
            from = at + query.length
        }
    }
    return out
}

/** Builds the searchable text for the loaded document (for [sheet] when it is a workbook). */
internal fun buildUnits(loaded: Loaded, sheet: Int): List<SearchUnit> {
    val out = ArrayList<SearchUnit>()
    when (loaded) {
        is Loaded.Word -> {
            for ((b, block) in loaded.doc.blocks.withIndex()) {
                when (block) {
                    is Para -> out += SearchUnit(b, "$b", block.plain)
                    is TableBlock -> for ((r, row) in block.rows.withIndex()) {
                        for ((c, cell) in row.withIndex()) {
                            for ((p, inner) in cell.withIndex()) {
                                if (inner is Para) out += SearchUnit(b, "$b/$r/$c/$p", inner.plain)
                            }
                        }
                    }
                    else -> Unit
                }
            }
        }
        is Loaded.Sheets -> {
            val s: Sheet = loaded.book.sheets.getOrNull(sheet) ?: return out
            for ((r, row) in s.rows.withIndex()) {
                for ((c, v) in row.withIndex()) {
                    if (v.isNotEmpty()) out += SearchUnit(r, "$r/$c", v)
                }
            }
        }
        is Loaded.Lines -> for ((i, line) in loaded.lines.withIndex()) out += SearchUnit(i, "$i", line)
        is Loaded.Slides -> for ((s, slide) in loaded.deck.slides.withIndex()) {
            slide.notes?.takeIf { it.isNotBlank() }?.let { out += SearchUnit(s, "n/$s", it) }
            for ((p, para) in slideParas(slide).withIndex()) out += SearchUnit(s, "t/$s/$p", para.plain)
        }
        is Loaded.Web, is Loaded.Picture, Loaded.Unsupported -> Unit
    }
    return out
}

/** Find bar shown under the top bar. Enter and the arrows step through hits. */
@Composable
internal fun DocSearchBar(
    query: String,
    onQuery: (String) -> Unit,
    countText: String,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onClose: () -> Unit,
) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        OutlinedTextField(
            value = query,
            onValueChange = onQuery,
            singleLine = true,
            placeholder = { Text("Find in document") },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { onNext() }),
            modifier = Modifier.weight(1f).focusRequester(focus),
        )
        Spacer(Modifier.width(4.dp))
        Text(countText, style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(horizontal = 4.dp))
        IconButton(onClick = onPrev) { Icon(Icons.Rounded.KeyboardArrowUp, "Previous match") }
        IconButton(onClick = onNext) { Icon(Icons.Rounded.KeyboardArrowDown, "Next match") }
        IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, "Close search") }
    }
}
