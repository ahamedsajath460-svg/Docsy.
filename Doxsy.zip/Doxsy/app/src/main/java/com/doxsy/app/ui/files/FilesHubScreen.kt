package com.doxsy.app.ui.files

import android.content.pm.PackageManager
import android.net.Uri
import android.os.Environment
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AddToDrive
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.Email
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.doxsy.app.data.DocEntry
import com.doxsy.app.data.Prefs
import com.doxsy.app.fileman.DeviceFiles
import com.doxsy.app.pdf.PdfTools
import com.doxsy.app.pdf.ToolResult
import com.doxsy.app.ui.AvatarButton
import com.doxsy.app.ui.KindBadge
import com.doxsy.app.ui.cloud.DriveScreen
import com.doxsy.app.ui.cloud.GmailPdfsScreen
import com.doxsy.app.ui.MenuAction
import com.doxsy.app.ui.home.DocListRow
import com.doxsy.app.ui.home.EmptyList
import com.doxsy.app.util.FileKind
import com.doxsy.app.util.FileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private const val DEVICE = "device"
private const val EMAILS = "emails"
private const val DRIVE = "drive"
private const val FOLDERS = "folders"

private val DOC_MIMES = arrayOf(
    "application/pdf",
    "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/vnd.ms-excel",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.ms-powerpoint",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    "application/vnd.oasis.opendocument.text",
    "text/plain",
    "application/rtf",
)

private val DOC_EXTS = setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "odt", "txt", "rtf", "csv")

/**
 * Files tab: On this device, Photos, Google Drive, PDFs from e-mails, Browse more files
 * (plus the folders you added earlier).
 */
@Composable
fun FilesHubScreen(
    prefs: Prefs,
    state: FilesState,
    onOpenSettings: () -> Unit,
    onOpenPdf: (Uri) -> Unit,
    onOpenEntry: (DocEntry) -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var section by rememberSaveable { mutableStateOf<String?>(null) }
    val driveAccount by prefs.googleAccount.state.collectAsState()

    // --- Browse more files / Google Drive: Android's own file picker (Drive shows up in it) ---
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            onOpenEntry(DocEntry(uri.toString(), FileUtils.displayName(ctx, uri)))
        }
    }

    // --- Photos: choose pictures, turn them into one PDF ---
    var photos by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) photos = uris
    }
    val createPdf = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { out ->
        val imgs = photos
        if (out != null && imgs.isNotEmpty()) {
            busy = true
            scope.launch {
                val r = PdfTools.imagesToPdf(ctx, imgs, out)
                busy = false
                when (r) {
                    is ToolResult.Done -> {
                        photos = emptyList()
                        FileUtils.toast(ctx, r.message)
                        onOpenPdf(out)
                    }
                    is ToolResult.Failed -> FileUtils.toast(ctx, r.message)
                }
            }
        }
    }

    when (section) {
        DEVICE -> DeviceBrowser(
            onBack = { section = null },
            onOpenFile = { f ->
                val uri = DeviceFiles.contentUriFor(ctx, f) ?: Uri.fromFile(f)
                onOpenEntry(DocEntry(uri.toString(), f.name))
            },
        )
        EMAILS -> GmailPdfsScreen(prefs, onBack = { section = null }, onOpenEntry = onOpenEntry)
        DRIVE -> DriveScreen(prefs, onBack = { section = null }, onOpenEntry = onOpenEntry)
        FOLDERS -> {
            BackHandler { section = null }
            Column(Modifier.fillMaxSize()) {
                IconButton(onClick = { section = null }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") }
                Box(Modifier.weight(1f)) {
                    FilesScreen(prefs, state, onOpenPdf = onOpenPdf)
                }
            }
        }
        else -> Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .padding(end = 12.dp),
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.End,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                AvatarButton(onClick = onOpenSettings)
            }
            Text(
                "Files",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 16.dp),
            )
            HubRow(Icons.Rounded.PhoneAndroid, MaterialTheme.colorScheme.onSurface, "On this device", null, Icons.Rounded.ChevronRight) {
                section = DEVICE
            }
            HubRow(Icons.Rounded.PhotoLibrary, MaterialTheme.colorScheme.onSurface, "Photos", "Turn pictures into a PDF", Icons.Rounded.ChevronRight) {
                photoPicker.launch("image/*")
            }
            HubRow(
                Icons.Rounded.AddToDrive, Color(0xFF0F9D58), "Google Drive",
                driveAccount.ifEmpty { null },
                if (driveAccount.isEmpty()) Icons.Rounded.Add else Icons.Rounded.ChevronRight,
            ) { section = DRIVE }
            HubRow(Icons.Rounded.Email, Color(0xFFEA4335), "PDFs from emails", "Gmail", Icons.Rounded.Add) {
                section = EMAILS
            }
            HubRow(Icons.Rounded.FolderOpen, MaterialTheme.colorScheme.onSurface, "Browse more files", null, null) {
                pick.launch(arrayOf("*/*"))
            }
            HubRow(Icons.Rounded.CreateNewFolder, MaterialTheme.colorScheme.onSurface, "Added folders", "Folders you gave Doxsy access to", Icons.Rounded.ChevronRight) {
                section = FOLDERS
            }
        }
    }

    if (photos.isNotEmpty() && !busy) {
        AlertDialog(
            onDismissRequest = { photos = emptyList() },
            title = { Text("Create PDF") },
            text = { Text("${photos.size} photo(s) selected. Each photo becomes one page.") },
            confirmButton = {
                TextButton(onClick = { createPdf.launch("Photos.pdf") }) { Text("Choose where to save") }
            },
            dismissButton = { TextButton(onClick = { photos = emptyList() }) { Text("Cancel") } },
        )
    }
    if (busy) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Creating PDF") },
            text = { Row(verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(Modifier.size(28.dp)); Spacer(Modifier.width(16.dp)); Text("Please wait…") } },
            confirmButton = {},
        )
    }
}

@Composable
private fun HubRow(
    icon: ImageVector,
    tint: Color,
    title: String,
    subtitle: String?,
    trailing: ImageVector?,
    onClick: () -> Unit,
) {
    Column {
        Row(
            Modifier
                .fillMaxWidth()
                .clickable(onClick = onClick)
                .padding(horizontal = 16.dp, vertical = 18.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(24.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.bodyLarge)
                if (subtitle != null) {
                    Text(
                        subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            if (trailing != null) Icon(trailing, null, modifier = Modifier.size(22.dp))
        }
        Box(
            Modifier
                .padding(horizontal = 16.dp)
                .fillMaxWidth()
                .height(1.dp)
                .background(MaterialTheme.colorScheme.outlineVariant),
        )
    }
}

@Composable
private fun SubHeader(title: String, subtitle: String?, onBack: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(end = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") }
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (subtitle != null) {
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

private fun listDir(dir: File): List<File> {
    val all = dir.listFiles() ?: return emptyList()
    return all
        .filter { !it.name.startsWith(".") && (it.isDirectory || it.extension.lowercase() in DOC_EXTS) }
        .sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase() }))
}

/** "On this device": browse the phone's storage folder by folder. */
@Composable
private fun DeviceBrowser(onBack: () -> Unit, onOpenFile: (File) -> Unit) {
    val access = rememberDeviceAccess()
    val root = remember { Environment.getExternalStorageDirectory().absolutePath }
    var path by rememberSaveable { mutableStateOf(root) }
    var entries by remember { mutableStateOf<List<File>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    val atRoot = path == root

    LaunchedEffect(path, access.granted) {
        if (!access.granted) {
            entries = emptyList()
        } else {
            loading = true
            entries = withContext(Dispatchers.IO) { runCatching { listDir(File(path)) }.getOrDefault(emptyList()) }
            loading = false
        }
    }
    BackHandler { if (atRoot) onBack() else path = File(path).parent ?: root }

    Column(Modifier.fillMaxSize()) {
        SubHeader(
            title = if (atRoot) "On this device" else File(path).name,
            subtitle = path.removePrefix(root).ifEmpty { "Internal storage" },
            onBack = { if (atRoot) onBack() else path = File(path).parent ?: root },
        )
        when {
            !access.granted -> AccessPrompt("Allow access to browse the files on this phone.", access.request)
            !loading && entries.isEmpty() -> EmptyList(Icons.Rounded.FolderOpen, "Nothing here", "No folders or documents in this folder.")
            else -> LazyColumn {
                items(entries, key = { it.absolutePath }) { f ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { if (f.isDirectory) path = f.absolutePath else onOpenFile(f) }
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        if (f.isDirectory) {
                            Box(
                                Modifier
                                    .size(44.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center,
                            ) { Icon(Icons.Rounded.Folder, null, tint = MaterialTheme.colorScheme.primary) }
                        } else {
                            KindBadge(FileKind.of(f.name))
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(f.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (!f.isDirectory) {
                                Text(
                                    "${FileUtils.formatSize(f.length())} • ${FileUtils.formatDate(f.lastModified())}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
