package com.doxsy.app.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.util.LruCache
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.Closeable
import java.io.File
import java.io.FileNotFoundException
import java.io.IOException
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.roundToInt

sealed interface OpenResult {
    data class Success(val session: PdfSession) : OpenResult
    data object PasswordRequired : OpenResult
    data object WrongPassword : OpenResult
    data class Failure(val message: String) : OpenResult
}

/**
 * Wraps Android's native [PdfRenderer]. Only one page can be open at a time, so all access
 * goes through a single render thread. Rendered pages live in a size-bounded LRU cache so
 * that large documents never hold every page in memory.
 */
class PdfSession private constructor(
    private val pfd: ParcelFileDescriptor,
    private val renderer: PdfRenderer,
    private val tempFile: File?,
) : Closeable {

    val pageCount: Int = renderer.pageCount

    /** Private, unencrypted copy of the document on disk, if one was needed to open it. */
    val backingFile: File? get() = tempFile

    private val lock = Any()
    @Volatile private var closed = false
    private val widths = FloatArray(pageCount) { 595f }
    private val heights = FloatArray(pageCount) { 842f }

    private val executor: ExecutorService = Executors.newSingleThreadExecutor { r ->
        Thread(r, "doxsy-pdf-render").apply { isDaemon = true }
    }
    private val dispatcher: CoroutineDispatcher = executor.asCoroutineDispatcher()

    private val cache = object : LruCache<String, Bitmap>(cacheBytes()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    /** Reads the size of every page (cheap) so layouts have the right aspect ratio. */
    suspend fun loadPageSizes() = withContext(dispatcher) {
        for (i in 0 until pageCount) {
            if (!isActive) return@withContext
            synchronized(lock) {
                if (closed) return@withContext
                renderer.openPage(i).use { p ->
                    widths[i] = p.width.toFloat().coerceAtLeast(1f)
                    heights[i] = p.height.toFloat().coerceAtLeast(1f)
                }
            }
        }
    }

    /** Height / width of the page as displayed (after [rotation]). */
    fun aspect(page: Int, rotation: Int): Float {
        val w = widths[page]
        val h = heights[page]
        return if (rotation % 180 == 0) h / w else w / h
    }

    /** Renders [page] so the displayed bitmap is [targetWidth] px wide. */
    suspend fun renderAsync(page: Int, targetWidth: Int, rotation: Int): Bitmap? {
        val key = "$page:$targetWidth:$rotation"
        cache.get(key)?.let { return it }
        return withContext(dispatcher) {
            if (!isActive) return@withContext null
            cache.get(key)?.let { return@withContext it }
            val bmp = renderBlocking(page, targetWidth, rotation)
            if (bmp != null) cache.put(key, bmp)
            bmp
        }
    }

    private fun renderBlocking(page: Int, targetWidth: Int, rotation: Int): Bitmap? {
        val tw = targetWidth.coerceIn(16, 3000)
        return try {
            synchronized(lock) {
                if (closed) return null
                renderer.openPage(page).use { p ->
                    val pw = p.width.toFloat().coerceAtLeast(1f)
                    val ph = p.height.toFloat().coerceAtLeast(1f)
                    val rw: Int
                    val rh: Int
                    if (rotation % 180 == 0) {
                        rw = tw
                        rh = (tw * ph / pw).roundToInt().coerceAtLeast(1)
                    } else {
                        rh = tw
                        rw = (tw * pw / ph).roundToInt().coerceAtLeast(1)
                    }
                    val bmp = Bitmap.createBitmap(rw, rh, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(Color.WHITE)
                    p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    if (rotation % 360 == 0) {
                        bmp
                    } else {
                        val m = Matrix().apply { postRotate(rotation.toFloat()) }
                        val rotated = Bitmap.createBitmap(bmp, 0, 0, rw, rh, m, true)
                        bmp.recycle()
                        rotated
                    }
                }
            }
        } catch (e: OutOfMemoryError) {
            cache.evictAll()
            null
        } catch (e: Exception) {
            null
        }
    }

    override fun close() {
        synchronized(lock) {
            if (closed) return
            closed = true
            runCatching { renderer.close() }
            runCatching { pfd.close() }
            tempFile?.delete()
        }
        cache.evictAll()
        executor.shutdown()
    }

    companion object {
        private const val TEMP_PREFIX = "doxsy_open_"

        private fun cacheBytes(): Int =
            (Runtime.getRuntime().maxMemory() / 6).coerceAtMost(96L * 1024 * 1024).toInt()

        fun clearTempFiles(context: Context) {
            context.cacheDir.listFiles()?.forEach {
                if (it.name.startsWith(TEMP_PREFIX) || it.name.startsWith("doxsy_tmp_")) it.delete()
            }
        }

        private fun create(pfd: ParcelFileDescriptor, temp: File?): PdfSession {
            val r = PdfRenderer(pfd)
            if (r.pageCount <= 0) {
                r.close()
                throw IOException("empty document")
            }
            return PdfSession(pfd, r, temp)
        }

        suspend fun open(context: Context, uri: Uri): OpenResult = withContext(Dispatchers.IO) {
            val app = context.applicationContext
            try {
                val pfd = app.contentResolver.openFileDescriptor(uri, "r")
                    ?: return@withContext OpenResult.Failure("Could not open this file.")
                try {
                    OpenResult.Success(create(pfd, null))
                } catch (e: SecurityException) {
                    runCatching { pfd.close() }
                    OpenResult.PasswordRequired
                } catch (e: IOException) {
                    runCatching { pfd.close() }
                    // The provider may not support seeking; retry from a private cache copy.
                    openViaCopy(app, uri)
                }
            } catch (e: FileNotFoundException) {
                OpenResult.Failure("File not found, or it is no longer accessible.")
            } catch (e: SecurityException) {
                OpenResult.Failure("Permission to this file was lost. Open it again from Files.")
            } catch (e: Exception) {
                OpenResult.Failure("Could not open this file.")
            }
        }

        /**
         * Opens a password-protected PDF. PdfRenderer cannot take a password on Android 8-14, so the
         * document is decrypted into a private cache copy (deleted when the viewer closes and on the
         * next app start). The original file is never modified.
         */
        suspend fun openWithPassword(context: Context, uri: Uri, password: String): OpenResult =
            withContext(Dispatchers.IO) {
                val app = context.applicationContext
                PdfEngine.init(app)
                val src = File(app.cacheDir, TEMP_PREFIX + "src_" + System.nanoTime() + ".pdf")
                val out = File(app.cacheDir, TEMP_PREFIX + System.nanoTime() + ".pdf")
                try {
                    app.contentResolver.openInputStream(uri)?.use { i ->
                        src.outputStream().use { o -> i.copyTo(o) }
                    } ?: return@withContext OpenResult.Failure("Could not open this file.")
                    PDDocument.load(src, password).use { doc ->
                        doc.isAllSecurityToBeRemoved = true
                        doc.save(out)
                    }
                    val pfd = ParcelFileDescriptor.open(out, ParcelFileDescriptor.MODE_READ_ONLY)
                    try {
                        OpenResult.Success(create(pfd, out))
                    } catch (e: Exception) {
                        runCatching { pfd.close() }
                        throw e
                    }
                } catch (e: InvalidPasswordException) {
                    out.delete()
                    OpenResult.WrongPassword
                } catch (e: kotlinx.coroutines.CancellationException) {
                    out.delete()
                    throw e
                } catch (e: OutOfMemoryError) {
                    out.delete()
                    OpenResult.Failure("Not enough memory to open this protected file.")
                } catch (e: Exception) {
                    out.delete()
                    OpenResult.Failure("Could not open this protected file.")
                } finally {
                    src.delete()
                }
            }

        private fun openViaCopy(app: Context, uri: Uri): OpenResult {
            val temp = File(app.cacheDir, TEMP_PREFIX + System.nanoTime() + ".pdf")
            return try {
                app.contentResolver.openInputStream(uri)?.use { input ->
                    temp.outputStream().use { out -> input.copyTo(out) }
                } ?: return OpenResult.Failure("Could not open this file.")
                val pfd = ParcelFileDescriptor.open(temp, ParcelFileDescriptor.MODE_READ_ONLY)
                try {
                    OpenResult.Success(create(pfd, temp))
                } catch (e: Exception) {
                    runCatching { pfd.close() }
                    throw e
                }
            } catch (e: SecurityException) {
                temp.delete()
                OpenResult.PasswordRequired
            } catch (e: Exception) {
                temp.delete()
                OpenResult.Failure("This file looks corrupted or is not a valid PDF.")
            }
        }
    }
}
