package com.doxsy.app.ai

import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

/** How long the model may think: Low / Medium / High. [extraTokens] is the room added for the thinking itself. */
enum class ThinkDepth(val effort: String, val extraTokens: Int, val label: String) {
    LOW("low", 1_500, "Low"),
    MEDIUM("medium", 4_000, "Medium"),
    HIGH("high", 8_000, "High"),
    ;

    companion object {
        fun parse(s: String?): ThinkDepth = values().firstOrNull { it.name.equals(s, ignoreCase = true) } ?: MEDIUM
    }
}

/**
 * The user's thinking settings (same three controls as Zen AI):
 * [always] = "Think deeper" (think for every message), [auto] = think only for hard questions, [depth] = how much.
 */
data class ThinkConfig(
    val always: Boolean = false,
    val auto: Boolean = true,
    val depth: ThinkDepth = ThinkDepth.MEDIUM,
)

/**
 * Thinking for the chat, ported from Zen AI (pure Kotlin apart from the request body, so it is easy to test).
 *
 *  - [wanted]: decides per message. Greetings and small talk (English, Tamil, Tamil typed in English letters)
 *    never think, so they stay fast; real problems (maths, logic, comparing, checking, long questions) do.
 *  - [apply]: adds only the controls the provider really has (Groq gpt-oss, Groq Qwen3, OpenRouter).
 *    Nothing is invented for a model that has none.
 *  - A provider that refuses a thinking option (HTTP 400 that mentions it) is retried once without thinking and
 *    remembered for this run of the app, so the chat never breaks because of thinking.
 */
object AiThinking {
    private val HARD = Regex(
        """```|\b(solve|prove|calculate|compute|analy[sz]e|debug|algorithm|optimi[sz]e|derive|equation|puzzle|riddle|""" +
            """step by step|refactor|architecture|implement|compare|contrast|reconcile|verify|evaluate|estimate|""" +
            """inconsisten\w*|contradict\w*|pros and cons|difference between)\b|""" +
            """[0-9]\s*[-+*/^=]\s*[0-9]\s*[-+*/^=]?|\bwhat if\b|\b(kanakku|kanaku|kandupidi|oppidu)\b""",
        RegexOption.IGNORE_CASE,
    )

    private val GREET = Regex(
        """^(hi+|hello+|hey+|yo|thanks?|thank you|thx|ok(ay)?|cool|nice|great|bye|gm|gn|vanakkam|""" +
            """good (morning|night|evening|afternoon))[\s.!?]*$""",
        RegexOption.IGNORE_CASE,
    )

    private val TAMIL_ONLY = Regex("""^[\s஀-௿.,!?]{2,60}$""")
    private val TAMIL_CHIT = Regex("சுகமா|நலமா|எப்படி|வணக்கம்|நன்றி|சரி|என்ன பண்ற|இருக்க")

    /** Words that only ever appear in small talk. A short message made of nothing else is small talk. */
    private val CHIT_WORDS: Set<String> = (
        "hi hello hey thanks thank you ok okay cool nice great good morning night evening afternoon bye yes no yeah " +
            "yup sure fine lol haha hmm wow please how are u am i im fine " +
            "vanakkam nandri sari seri aama aamam illa illai ille suhama sugama sukama sugamaa suhamaa nalla nallaa " +
            "irukken irukkeen irukka irukkinga irukkingala irukkiya iruka irukeenga eppadi epdi eppidi epadi enna panra " +
            "panringa panreenga pannra pannitu saptiya saptingala saaptiya saptacha thoongitiya neenga neengal nee naan " +
            "naa unga un ungalukku ippo ippa innaiku innikku eppo ethuku yen ennada nalama nalamaa romba sandhosham " +
            "santhosham okey ooo oh ohh aha ayyo mm mmm ahh gm gn bore boring tired free busy mudinjatha mudinjuthu " +
            "sollu sollunga"
        ).split(' ').toSet()

    private val SPACES = Regex("\\s+")
    private val NOT_LATIN = Regex("[^a-z0-9\\s']")
    private val REJECT = Regex("think|reasoning|effort|budget|temperature", RegexOption.IGNORE_CASE)

    /** True for greetings and small talk ("hi", "நன்றி", "eppadi irukka"). */
    fun isChit(text: String): Boolean {
        val t = text.trim().lowercase()
        if (t.isEmpty() || t.length > 60) return false
        if (GREET.matches(t)) return true
        if (TAMIL_ONLY.matches(t) && TAMIL_CHIT.containsMatchIn(t) && t.split(SPACES).size <= 5) return true
        val words = t.replace(NOT_LATIN, " ").split(SPACES).filter { it.isNotEmpty() }
        return words.isNotEmpty() && words.size <= 6 && words.all { it in CHIT_WORDS }
    }

    /** True for messages that look like a real problem: maths, logic, comparing, checking, long questions. */
    fun needsThinking(text: String): Boolean = text.length > 700 || HARD.containsMatchIn(text)

    /** Should this message be answered with thinking? A greeting never is, unless a file is attached. */
    fun wanted(cfg: ThinkConfig, text: String, hasAttachment: Boolean): Boolean {
        if (!hasAttachment && isChit(text)) return false
        return cfg.always || (cfg.auto && needsThinking(text))
    }

    // ---- provider controls ------------------------------------------------------------------------------------

    private val refused = ConcurrentHashMap<String, Boolean>()

    private fun key(p: AiConfig.Provider) = p.name + "|" + p.model

    /** False once this model has refused our thinking options (learned for this run of the app). */
    fun usable(p: AiConfig.Provider): Boolean = refused[key(p)] != true

    fun markRefused(p: AiConfig.Provider) {
        refused[key(p)] = true
    }

    /** Did the provider reject the request because of a thinking option? Other errors (bad key, too big) are not. */
    fun isOptionError(code: Int, message: String): Boolean =
        (code == 400 || code == 422) && REJECT.containsMatchIn(message)

    /**
     * Writes the provider's own thinking controls into [body] and returns true when something was sent.
     *  - Groq gpt-oss: reasoning_effort + include_reasoning (reasoning_format is not supported there).
     *  - Groq Qwen3: reasoning_format "parsed" + reasoning_effort ("none" when not thinking, so quick questions stay quick).
     *  - OpenRouter: reasoning {effort} + include_reasoning.
     * With [think] false only the cheap "low" / "none" settings are sent. More room for the answer is added when thinking.
     */
    fun apply(body: JSONObject, p: AiConfig.Provider, think: Boolean, depth: ThinkDepth): Boolean {
        if (!usable(p)) return false
        val m = p.model.lowercase()
        val effort = depth.effort
        val sent = when {
            p.groq && m.contains("gpt-oss") -> {
                body.put("reasoning_effort", if (think) effort else (p.reasoning ?: "low"))
                body.put("include_reasoning", think)
                true
            }
            p.groq && m.contains("qwen3") -> {
                body.put("reasoning_format", "parsed")
                body.put("reasoning_effort", if (think) effort else "none")
                true
            }
            !p.groq && think -> {
                body.put("reasoning", JSONObject().put("effort", effort))
                body.put("include_reasoning", true)
                true
            }
            else -> false
        }
        if (sent && think) body.put("max_tokens", p.maxTokens + depth.extraTokens)
        return sent
    }

    /** Thinking text of a reply: the provider's reasoning field, or the <think> block some models put in the answer. */
    fun reasoningOf(message: JSONObject?): String {
        if (message == null) return ""
        for (k in arrayOf("reasoning", "reasoning_content")) {
            if (!message.isNull(k)) {
                val s = message.optString(k).trim()
                if (s.isNotEmpty()) return s
            }
        }
        val content = if (message.isNull("content")) "" else message.optString("content")
        return THINK_BLOCK.findAll(content).joinToString("\n\n") { it.groupValues[1].trim() }.trim()
    }

    private val THINK_BLOCK = Regex("(?is)<think>(.*?)</think>")

    /** The answer without any <think> block (also an unfinished one at the end). */
    fun answerOf(message: JSONObject?): String {
        if (message == null || message.isNull("content")) return ""
        return message.optString("content")
            .replace(THINK_BLOCK, "")
            .replace(Regex("(?is)<think>.*$"), "")
            .trim()
    }
}
