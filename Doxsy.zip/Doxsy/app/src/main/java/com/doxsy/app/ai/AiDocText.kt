package com.doxsy.app.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.util.Base64
import com.doxsy.app.docview.Block
import com.doxsy.app.docview.Para
import com.doxsy.app.docview.SlideText
import com.doxsy.app.docview.TableBlock
import com.doxsy.app.pdf.PdfEngine
import com.doxsy.app.ui.docview.Loaded
import com.doxsy.app.ui.docview.decodePicture
import com.doxsy.app.ui.docview.decodeText
import com.doxsy.app.ui.docview.describeLoadError
import com.doxsy.app.ui.docview.loadDocument
import com.doxsy.app.ui.docview.readCapped
import com.doxsy.app.util.DocFormat
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * Prepares any file Doxsy can open for the AI:
 *  - PDF: the original file (plus its full text), or the first pages as pictures when it is a scan
 *  - pictures: the picture itself
 *  - Word, Excel, PowerPoint (old and new), OpenDocument, RTF, CSV, HTML, XML, JSON, EPUB, text and
 *    code files: the complete text of the file
 */
object AiDocText {
    private const val MAX_TEXT_CHARS = 600_000
    private const val MAX_PDF_PAGES = 400
    private const val MAX_PDF_FILE = 8 * 1024 * 1024
    private const val MAX_PLAIN_BYTES = 8 * 1024 * 1024
    private const val MAX_ROWS_PER_SHEET = 20_000
    private const val SCAN_PAGES = 3
    private const val IMAGE_SIDE = 1400

    suspend fun load(ctx: Context, uri: Uri, name: String): AiAttachment = withContext(Dispatchers.IO) {
        val fmt = DocFormat.detect(ctx, uri, name)
        when (fmt) {
            DocFormat.PDF -> pdf(ctx, uri, name)
            DocFormat.IMAGE -> image(ctx, uri, name)
            else -> textFile(ctx, uri, name, fmt)
        }
    }

    // ---- Pictures ---------------------------------------------------------------------------------

    private fun image(ctx: Context, uri: Uri, name: String): AiAttachment {
        val pic = try {
            decodePicture(ctx, uri, name)
        } catch (e: Throwable) {
            if (e is CancellationException) throw e
            throw AiException(describeLoadError(e))
        }
        val url = jpegDataUrl(pic.bitmap)
        pic.bitmap.recycle()
        return AiAttachment(name, "", listOf(url), null, null)
    }

    // ---- PDF --------------------------------------------------------------------------------------

    private fun pdf(ctx: Context, uri: Uri, name: String): AiAttachment {
        PdfEngine.init(ctx)
        // Copy to a temp file first: PDFBox and the page renderer then read from disk, not from memory.
        val tmp = File(ctx.cacheDir, "ai_" + System.nanoTime() + ".pdf")
        try {
            val input = ctx.contentResolver.openInputStream(uri) ?: throw AiException("Could not open this file.")
            input.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }

            var text = ""
            var pages = 0
            try {
                PDDocument.load(tmp).use { doc ->
                    if (doc.isEncrypted) throw AiException("This PDF is password protected.")
                    pages = doc.numberOfPages
                    val st = PDFTextStripper()
                    st.startPage = 1
                    st.endPage = minOf(pages, MAX_PDF_PAGES)
                    text = tidy(st.getText(doc)).take(MAX_TEXT_CHARS)
                }
            } catch (e: AiException) {
                throw e
            } catch (e: Throwable) {
                if (e is CancellationException) throw e
                if (e is OutOfMemoryError) throw AiException("Not enough memory to read this PDF.")
                // Damaged text layer: still try the pictures of the pages below.
            }

            val hasText = text.count { !it.isWhitespace() } >= 40
            if (hasText) {
                val pdfUrl = if (tmp.length() <= MAX_PDF_FILE) {
                    "data:application/pdf;base64," + Base64.encodeToString(tmp.readBytes(), Base64.NO_WRAP)
                } else {
                    null
                }
                val note = if (pages > MAX_PDF_PAGES) "Very long PDF: the first $MAX_PDF_PAGES pages are read" else null
                return AiAttachment(name, text, emptyList(), pdfUrl, note)
            }

            // No text layer: a scan or a photo saved as PDF. Give the AI the first pages as pictures.
            val shots = renderPages(tmp, SCAN_PAGES)
            if (shots.isEmpty()) throw AiException("This PDF has no selectable text and could not be read as pictures.")
            val total = if (pages > 0) pages else shots.size
            val note = if (total > shots.size) {
                "Scanned PDF: the AI sees the first ${shots.size} pages as pictures"
            } else {
                "Scanned PDF: the AI reads it as pictures"
            }
            return AiAttachment(name, "", shots, null, note)
        } finally {
            tmp.delete()
        }
    }

    private fun renderPages(file: File, max: Int): List<String> {
        val out = ArrayList<String>()
        val pfd = try {
            ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
        } catch (e: Exception) {
            return out
        }
        try {
            val renderer = PdfRenderer(pfd)
            try {
                val n = minOf(renderer.pageCount, max)
                for (i in 0 until n) {
                    val page = renderer.openPage(i)
                    try {
                        val w = 1200
                        val h = maxOf(1, (w.toFloat() * page.height / page.width).toInt())
                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        out.add(jpegDataUrl(bmp))
                        bmp.recycle()
                    } finally {
                        page.close()
                    }
                }
            } finally {
                renderer.close()
            }
        } catch (e: Exception) {
            // Password protected or damaged: return what was rendered so far.
        } finally {
            runCatching { pfd.close() }
        }
        return out
    }

    // ---- Everything else: Word, Excel, PowerPoint, text, code ... ---------------------------------

    private fun textFile(ctx: Context, uri: Uri, name: String, fmt: DocFormat): AiAttachment {
        val raw = try {
            if (fmt == DocFormat.UNKNOWN) plainText(ctx, uri) else loadedText(loadDocument(ctx, uri, fmt, name))
        } catch (e: AiException) {
            throw e
        } catch (e: Throwable) {
            if (e is CancellationException) throw e
            throw AiException(describeLoadError(e))
        }
        val clean = tidy(raw)
        if (clean.isBlank()) throw AiException("No text found in this file.")
        val cut = clean.length > MAX_TEXT_CHARS
        val note = if (cut) "Very long file: the AI reads the first part only" else null
        return AiAttachment(name, if (cut) clean.take(MAX_TEXT_CHARS) else clean, emptyList(), null, note)
    }

    /** Files Doxsy has no viewer for (source code, config, notes...): used when they are plain text. */
    private fun plainText(ctx: Context, uri: Uri): String {
        val c = readCapped(ctx, uri, MAX_PLAIN_BYTES)
        val probe = minOf(c.bytes.size, 4096)
        for (i in 0 until probe) {
            if (c.bytes[i].toInt() == 0) throw AiException("The AI cannot read this kind of file yet.")
        }
        return decodeText(c.bytes)
    }

    private fun loadedText(l: Loaded): String = when (l) {
        is Loaded.Word -> l.doc.blocks.joinToString("\n") { blockText(it) }
        is Loaded.Sheets -> l.book.sheets.joinToString("\n\n") { sh ->
            "[${sh.name}]\n" + sh.rows.asSequence()
                .filter { r -> r.any { cell -> cell.isNotBlank() } }
                .take(MAX_ROWS_PER_SHEET)
                .joinToString("\n") { r -> r.joinToString(" | ") }
        }
        is Loaded.Slides -> l.deck.slides.joinToString("\n\n") { sl ->
            "Slide ${sl.index + 1}:\n" + sl.elements.filterIsInstance<SlideText>()
                .joinToString("\n") { t -> t.paras.joinToString("\n") { it.plain } } +
                (sl.notes?.let { "\nNotes: $it" } ?: "")
        }
        is Loaded.Lines -> l.lines.joinToString("\n")
        is Loaded.Web -> l.html
            .replace(Regex("(?is)<(script|style)[^>]*>.*?</\\1>"), " ")
            .replace(Regex("(?i)<br\\s*/?>|</p>|</div>|</tr>|</li>|</h[1-6]>"), "\n")
            .replace(Regex("(?i)</t[dh]>"), " | ")
            .replace(Regex("<[^>]+>"), " ")
            .replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
            .replace("&quot;", "\"").replace("&#39;", "'")
        is Loaded.Picture, Loaded.Unsupported -> throw AiException("The AI cannot read this kind of file yet.")
    }

    private fun blockText(b: Block): String = when (b) {
        is Para -> b.plain
        is TableBlock -> b.rows.joinToString("\n") { row -> row.joinToString(" | ") { cell -> cell.joinToString(" ") { blockText(it) } } }
        else -> ""
    }

    // ---- Helpers ----------------------------------------------------------------------------------

    private fun tidy(raw: String): String =
        raw.replace(Regex("[ \\t]+"), " ").replace(Regex("\\n{3,}"), "\n\n").trim()

    /** A picture as a JPEG data URL, at most [IMAGE_SIDE] pixels on the long side, on a white background. */
    private fun jpegDataUrl(bmp: Bitmap): String {
        val scale = minOf(1f, IMAGE_SIDE.toFloat() / maxOf(bmp.width, bmp.height))
        val w = maxOf(1, (bmp.width * scale).toInt())
        val h = maxOf(1, (bmp.height * scale).toInt())
        val flat = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(flat)
        canvas.drawColor(Color.WHITE)
        canvas.drawBitmap(bmp, null, Rect(0, 0, w, h), Paint(Paint.FILTER_BITMAP_FLAG))
        val bos = ByteArrayOutputStream()
        flat.compress(Bitmap.CompressFormat.JPEG, 82, bos)
        flat.recycle()
        return "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
    }
}
