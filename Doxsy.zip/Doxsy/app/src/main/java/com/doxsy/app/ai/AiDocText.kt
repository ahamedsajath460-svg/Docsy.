package com.doxsy.app.ai

import android.content.Context
import android.net.Uri
import com.doxsy.app.docview.Block
import com.doxsy.app.docview.Para
import com.doxsy.app.docview.SlideText
import com.doxsy.app.docview.TableBlock
import com.doxsy.app.pdf.PdfEngine
import com.doxsy.app.ui.docview.Loaded
import com.doxsy.app.ui.docview.loadDocument
import com.doxsy.app.util.DocFormat
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Text of a document for the AI: PDF, Word, Excel, PowerPoint, text files, OpenDocument, EPUB... */
object AiDocText {
    class Result(val text: String, val truncated: Boolean)

    suspend fun extract(ctx: Context, uri: Uri, name: String): Result = withContext(Dispatchers.IO) {
        val fmt = DocFormat.detect(ctx, uri, name)
        val raw = if (fmt == DocFormat.PDF) pdfText(ctx, uri) else loadedText(loadDocument(ctx, uri, fmt, name))
        val clean = raw.replace(Regex("[ \\t]+"), " ").replace(Regex("\\n{3,}"), "\n\n").trim()
        if (clean.isBlank()) {
            throw AiException(
                if (fmt == DocFormat.PDF) "This PDF has no selectable text (it may be a scan)."
                else "No text found in this file.",
            )
        }
        val cut = clean.length > AiConfig.MAX_DOC_CHARS
        Result(if (cut) clean.take(AiConfig.MAX_DOC_CHARS) else clean, cut)
    }

    private fun pdfText(ctx: Context, uri: Uri): String {
        PdfEngine.init(ctx)
        // Copy to a temp file first: PDFBox then reads from disk instead of holding the whole PDF in memory.
        val tmp = File(ctx.cacheDir, "ai_" + System.nanoTime() + ".pdf")
        try {
            val input = ctx.contentResolver.openInputStream(uri) ?: throw AiException("Could not open this file.")
            input.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            PDDocument.load(tmp).use { doc ->
                if (doc.isEncrypted) throw AiException("This PDF is password protected.")
                val st = PDFTextStripper()
                st.startPage = 1
                st.endPage = minOf(doc.numberOfPages, 40)
                return st.getText(doc)
            }
        } finally {
            tmp.delete()
        }
    }

    private fun loadedText(l: Loaded): String = when (l) {
        is Loaded.Word -> l.doc.blocks.joinToString("\n") { blockText(it) }
        is Loaded.Sheets -> l.book.sheets.joinToString("\n\n") { sh ->
            "[${sh.name}]\n" + sh.rows.take(400).joinToString("\n") { r -> r.joinToString(" | ") }
        }
        is Loaded.Slides -> l.deck.slides.joinToString("\n\n") { sl ->
            "Slide ${sl.index + 1}:\n" + sl.elements.filterIsInstance<SlideText>()
                .joinToString("\n") { t -> t.paras.joinToString("\n") { it.plain } } +
                (sl.notes?.let { "\nNotes: $it" } ?: "")
        }
        is Loaded.Lines -> l.lines.joinToString("\n")
        is Loaded.Web -> l.html
            .replace(Regex("(?is)<(script|style)[^>]*>.*?</\\1>"), " ")
            .replace(Regex("<[^>]+>"), " ")
            .replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
        is Loaded.Picture, Loaded.Unsupported -> throw AiException("The AI cannot read this kind of file yet.")
    }

    private fun blockText(b: Block): String = when (b) {
        is Para -> b.plain
        is TableBlock -> b.rows.joinToString("\n") { row -> row.joinToString(" | ") { cell -> cell.joinToString(" ") { blockText(it) } } }
        else -> ""
    }
}
