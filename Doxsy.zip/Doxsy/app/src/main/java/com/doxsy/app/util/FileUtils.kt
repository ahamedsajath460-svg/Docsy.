package com.doxsy.app.util

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.InsertDriveFile
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Slideshow
import androidx.compose.material.icons.rounded.TableChart
import androidx.compose.material.icons.rounded.TextSnippet
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.biometric.BiometricManager
import com.doxsy.app.data.SortOrder
import java.io.FileOutputStream
import java.text.DateFormat
import java.util.Date
import java.util.Locale

enum class FileKind(val label: String, val color: Color, val icon: ImageVector, val exts: Set<String>) {
    PDF("PDF", Color(0xFFE5484D), Icons.Rounded.PictureAsPdf, setOf("pdf")),
    WORD("Word", Color(0xFF2F6BFF), Icons.Rounded.Description, setOf("doc", "docx", "rtf", "odt")),
    EXCEL("Excel", Color(0xFF1FA463), Icons.Rounded.TableChart, setOf("xls", "xlsx", "csv", "ods")),
    POWERPOINT("Slides", Color(0xFFF76808), Icons.Rounded.Slideshow, setOf("ppt", "pptx", "odp")),
    IMAGE("Images", Color(0xFF7C4DFF), Icons.Rounded.Image, setOf("jpg", "jpeg", "png", "webp", "bmp", "gif", "tif", "tiff")),
    TEXT("Text", Color(0xFF5A6280), Icons.Rounded.TextSnippet, setOf("txt", "json", "xml", "html", "htm", "epub", "md")),
    OTHER("Other", Color(0xFF8A90A6), Icons.Rounded.InsertDriveFile, emptySet());

    companion object {
        fun of(name: String): FileKind {
            val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
            return entries.firstOrNull { ext in it.exts } ?: OTHER
        }
    }
}

data class FileItem(
    val uri: Uri,
    val docId: String,
    val name: String,
    val mime: String,
    val size: Long,
    val modified: Long,
    val isDir: Boolean,
) {
    val kind: FileKind get() = FileKind.of(name)
    val isPdf: Boolean get() = !isDir && (mime == "application/pdf" || name.endsWith(".pdf", ignoreCase = true))
}

object FileUtils {

    fun displayName(ctx: Context, uri: Uri): String {
        if (uri.scheme == "content") {
            runCatching {
                ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val n = c.getString(0)
                        if (!n.isNullOrBlank()) return n
                    }
                }
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "Document"
    }

    fun documentName(ctx: Context, docUri: Uri): String? = runCatching {
        ctx.contentResolver.query(docUri, arrayOf(Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull()

    fun formatSize(bytes: Long): String {
        if (bytes < 0) return "—"
        val units = arrayOf("B", "KB", "MB", "GB")
        var v = bytes.toDouble()
        var i = 0
        while (v >= 1024 && i < units.lastIndex) {
            v /= 1024
            i++
        }
        return if (i == 0) "$bytes B" else String.format(Locale.getDefault(), "%.1f %s", v, units[i])
    }

    fun formatDate(ms: Long): String =
        if (ms <= 0) "—" else DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(ms))

    fun queryChildren(ctx: Context, treeUri: Uri, parentDocId: String): List<FileItem> {
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocId)
        val projection = arrayOf(
            Document.COLUMN_DOCUMENT_ID,
            Document.COLUMN_DISPLAY_NAME,
            Document.COLUMN_MIME_TYPE,
            Document.COLUMN_SIZE,
            Document.COLUMN_LAST_MODIFIED,
        )
        val out = ArrayList<FileItem>()
        ctx.contentResolver.query(childrenUri, projection, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0)
                val mime = c.getString(2) ?: ""
                out += FileItem(
                    uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, id),
                    docId = id,
                    name = c.getString(1) ?: id,
                    mime = mime,
                    size = if (c.isNull(3)) -1L else c.getLong(3),
                    modified = if (c.isNull(4)) 0L else c.getLong(4),
                    isDir = mime == Document.MIME_TYPE_DIR,
                )
            }
        }
        return out
    }

    fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

    fun share(ctx: Context, uri: Uri, mime: String) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = mime.ifBlank { "*/*" }
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        launchChooser(ctx, send)
    }

    fun shareMany(ctx: Context, items: List<FileItem>) {
        val files = items.filter { !it.isDir }
        if (files.isEmpty()) return
        if (files.size == 1) return share(ctx, files[0].uri, files[0].mime)
        val send = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "*/*"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(files.map { it.uri }))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        launchChooser(ctx, send)
    }

    private fun launchChooser(ctx: Context, intent: Intent) {
        try {
            val chooser = Intent.createChooser(intent, null).apply {
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                if (ctx !is android.app.Activity) addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            ctx.startActivity(chooser)
        } catch (e: Exception) {
            toast(ctx, "Nothing to share with.")
        }
    }

    fun viewExternal(ctx: Context, uri: Uri, mime: String) {
        val view = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mime.ifBlank { "*/*" })
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            if (ctx !is android.app.Activity) addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            ctx.startActivity(view)
        } catch (e: ActivityNotFoundException) {
            toast(ctx, "No app installed to open this file type.")
        } catch (e: Exception) {
            toast(ctx, "Could not open this file.")
        }
    }

    fun printPdf(ctx: Context, uri: Uri, name: String) {
        val pm = ctx.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
        val appCtx = ctx.applicationContext
        val adapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes?,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback,
                extras: Bundle?,
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback.onLayoutCancelled()
                    return
                }
                val info = PrintDocumentInfo.Builder(name)
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN)
                    .build()
                callback.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>?,
                destination: ParcelFileDescriptor,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback,
            ) {
                Thread {
                    try {
                        appCtx.contentResolver.openInputStream(uri)?.use { input ->
                            FileOutputStream(destination.fileDescriptor).use { out -> input.copyTo(out) }
                        } ?: throw IllegalStateException("no stream")
                        callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                    } catch (e: Exception) {
                        callback.onWriteFailed(e.message)
                    }
                }.start()
            }
        }
        pm.print(name, adapter, null)
    }

    private val appLockAuthenticators =
        BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL

    fun canUseAppLock(ctx: Context): Boolean =
        BiometricManager.from(ctx).canAuthenticate(appLockAuthenticators) == BiometricManager.BIOMETRIC_SUCCESS

    fun appLockAuthenticators(): Int = appLockAuthenticators

    // ---- File manager helpers (appended) ----

    /**
     * Sort comparator for the file list. Folders are always kept first by the caller.
     * [reversed] flips the natural direction of [order]: Name/Type A-Z, Date and Size newest/largest first.
     */
    fun sortComparator(order: SortOrder, reversed: Boolean): Comparator<FileItem> {
        val base: Comparator<FileItem> = when (order) {
            SortOrder.NAME -> compareBy { it.name.lowercase(Locale.ROOT) }
            SortOrder.DATE -> compareByDescending { it.modified }
            SortOrder.SIZE -> compareByDescending { it.size }
            SortOrder.TYPE -> compareBy<FileItem> { it.name.substringAfterLast('.', "").lowercase(Locale.ROOT) }
                .thenBy { it.name.lowercase(Locale.ROOT) }
        }
        return if (reversed) base.reversed() else base
    }

    /** Whether the sort order sorts in its natural direction (used to label Ascending / Descending). */
    fun naturallyDescending(order: SortOrder): Boolean = order == SortOrder.DATE || order == SortOrder.SIZE

    /** Builds a read-only item for a recents / favourites entry (no tree, so it cannot be modified). */
    fun recentItem(uri: Uri, name: String, at: Long): FileItem = FileItem(
        uri = uri,
        docId = uri.toString(),
        name = name.ifBlank { "Document" },
        mime = "",
        size = -1L,
        modified = at,
        isDir = false,
    )

    /** Created date is not exposed by every provider, so it is shown as not available. */
    const val CREATED_NOT_AVAILABLE = "Not available"
}

fun Context.findActivity(): ComponentActivity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is ComponentActivity) return c
        c = c.baseContext
    }
    return null
}
