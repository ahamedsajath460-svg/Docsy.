package com.doxsy.app.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.Shapes
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.core.view.WindowCompat
import com.doxsy.app.data.ThemeMode
import com.doxsy.app.util.findActivity

val DoxsyNavy = Color(0xFF0B1230)
val DoxsyBlue = Color(0xFF2F6BFF)
val DoxsyPurple = Color(0xFF7C4DFF)

val AccentColors = listOf(DoxsyBlue, DoxsyPurple, Color(0xFF00A3A3), Color(0xFFFF7A1A))
val AccentNames = listOf("Blue", "Purple", "Teal", "Orange")

private val DoxsyShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

@Composable
fun DoxsyTheme(
    themeMode: ThemeMode,
    accentIndex: Int,
    fontScale: Float,
    content: @Composable () -> Unit,
) {
    val dark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val accent = AccentColors[accentIndex.coerceIn(0, AccentColors.lastIndex)]

    val scheme = if (dark) {
        darkColorScheme(
            primary = lerp(accent, Color.White, 0.25f),
            onPrimary = DoxsyNavy,
            primaryContainer = lerp(accent, DoxsyNavy, 0.6f),
            onPrimaryContainer = Color.White,
            secondary = lerp(DoxsyPurple, Color.White, 0.25f),
            background = Color(0xFF080D24),
            onBackground = Color(0xFFE8EBFA),
            surface = Color(0xFF0F1736),
            onSurface = Color(0xFFE8EBFA),
            surfaceVariant = Color(0xFF1A2347),
            onSurfaceVariant = Color(0xFFA3ABCB),
            outline = Color(0xFF3A4570),
            outlineVariant = Color(0xFF273157),
        )
    } else {
        lightColorScheme(
            primary = accent,
            onPrimary = Color.White,
            primaryContainer = lerp(accent, Color.White, 0.86f),
            onPrimaryContainer = DoxsyNavy,
            secondary = DoxsyPurple,
            background = Color(0xFFF5F6FB),
            onBackground = DoxsyNavy,
            surface = Color.White,
            onSurface = DoxsyNavy,
            surfaceVariant = Color(0xFFE8EBF5),
            onSurfaceVariant = Color(0xFF5A6280),
            outline = Color(0xFFC3C8DA),
            outlineVariant = Color(0xFFDDE1EE),
        )
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context.findActivity() as? Activity)?.window
            if (window != null) {
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = !dark
                controller.isAppearanceLightNavigationBars = !dark
            }
        }
    }

    val base = LocalDensity.current
    CompositionLocalProvider(LocalDensity provides Density(base.density, base.fontScale * fontScale)) {
        MaterialTheme(colorScheme = scheme, shapes = DoxsyShapes, content = content)
    }
}
