package com.doxsy.app.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.Shapes
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.core.view.WindowCompat
import com.doxsy.app.data.ThemeMode
import com.doxsy.app.util.findActivity

val DoxsyNavy = Color(0xFF0B1230)
val DoxsyBlue = Color(0xFF2F6BFF)
val DoxsyPurple = Color(0xFF7C4DFF)

// The first four keep their old positions so a saved accent choice still points at the same colour.
val AccentColors = listOf(
    DoxsyBlue, DoxsyPurple, Color(0xFF00A3A3), Color(0xFFFF7A1A),
    Color(0xFF3949AB), Color(0xFF1E8E5A), Color(0xFFD32F2F), Color(0xFF455A64),
)
val AccentNames = listOf("Blue", "Purple", "Teal", "Orange", "Indigo", "Emerald", "Crimson", "Slate")

private val DoxsyShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

@Composable
fun DoxsyTheme(
    themeMode: ThemeMode,
    accentIndex: Int,
    fontScale: Float,
    amoled: Boolean = false,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val dark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val accent = AccentColors[accentIndex.coerceIn(0, AccentColors.lastIndex)]

    val ctx = LocalContext.current
    val useDynamic = dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    val onAccent = if (accent.luminance() > 0.6f) DoxsyNavy else Color.White

    val scheme = when {
        useDynamic && dark -> dynamicDarkColorScheme(ctx).let {
            if (amoled) it.copy(background = Color.Black, surface = Color(0xFF0A0A0A), surfaceVariant = Color(0xFF161616)) else it
        }
        useDynamic -> dynamicLightColorScheme(ctx)
        dark -> darkColorScheme(
            primary = lerp(accent, Color.White, 0.25f),
            onPrimary = DoxsyNavy,
            primaryContainer = lerp(accent, DoxsyNavy, 0.6f),
            onPrimaryContainer = Color.White,
            secondary = lerp(DoxsyPurple, Color.White, 0.25f),
            background = if (amoled) Color.Black else Color(0xFF080D24),
            onBackground = Color(0xFFE8EBFA),
            surface = if (amoled) Color(0xFF0A0A0A) else Color(0xFF0F1736),
            onSurface = Color(0xFFE8EBFA),
            surfaceVariant = if (amoled) Color(0xFF161616) else Color(0xFF1A2347),
            onSurfaceVariant = Color(0xFFA3ABCB),
            outline = if (amoled) Color(0xFF3A3A3A) else Color(0xFF3A4570),
            outlineVariant = if (amoled) Color(0xFF262626) else Color(0xFF273157),
        )
        else -> lightColorScheme(
            primary = accent,
            onPrimary = onAccent,
            primaryContainer = lerp(accent, Color.White, 0.86f),
            onPrimaryContainer = DoxsyNavy,
            secondary = DoxsyPurple,
            background = Color(0xFFF5F6FB),
            onBackground = DoxsyNavy,
            surface = Color.White,
            onSurface = DoxsyNavy,
            surfaceVariant = Color(0xFFE8EBF5),
            onSurfaceVariant = Color(0xFF5A6280),
            outline = Color(0xFFC3C8DA),
            outlineVariant = Color(0xFFDDE1EE),
        )
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context.findActivity() as? Activity)?.window
            if (window != null) {
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = !dark
                controller.isAppearanceLightNavigationBars = !dark
            }
        }
    }

    val base = LocalDensity.current
    CompositionLocalProvider(LocalDensity provides Density(base.density, base.fontScale * fontScale)) {
        MaterialTheme(colorScheme = scheme, shapes = DoxsyShapes, content = content)
    }
}
