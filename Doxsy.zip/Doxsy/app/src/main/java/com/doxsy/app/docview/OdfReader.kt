package com.doxsy.app.docview

import android.content.Context
import android.net.Uri
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream

/**
 * Text reader for OpenDocument files (ODT text, ODS spreadsheets, ODP presentations) and EPUB books.
 * Both are zip files, so one small reader serves them: it shows the text (not the page layout).
 */
object OdfReader {
    private const val MAX_ENTRY_BYTES = 40 * 1024 * 1024
    private const val MAX_LINES = 200_000

    /** One text line per paragraph; spreadsheet rows are joined with tabs; slides get a divider line. */
    fun readLines(ctx: Context, uri: Uri): List<String> {
        val xml = readEntry(ctx, uri) { it == "content.xml" }.firstOrNull()
            ?: throw DocReadException("This is not a valid OpenDocument file.")
        val p = Xml.newPullParser()
        p.setInput(ByteArrayInputStream(xml), "UTF-8")

        val lines = ArrayList<String>()
        val cur = StringBuilder()
        val cell = StringBuilder()
        val row = ArrayList<String>()
        var inPara = 0
        var inCell = false
        var slide = 0

        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT && lines.size < MAX_LINES) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "text:p", "text:h" -> inPara++
                    "text:tab" -> if (inPara > 0) cur.append('\t')
                    "text:s" -> if (inPara > 0) {
                        val n = p.getAttributeValue(null, "text:c")?.toIntOrNull() ?: 1
                        repeat(n.coerceIn(1, 200)) { cur.append(' ') }
                    }
                    "text:line-break" -> if (inPara > 0) cur.append(' ')
                    "draw:page" -> {
                        slide++
                        if (lines.isNotEmpty()) lines += ""
                        lines += "--- Slide $slide ---"
                    }
                    "table:table" -> {
                        val n = p.getAttributeValue(null, "table:name")
                        if (!n.isNullOrBlank()) {
                            if (lines.isNotEmpty()) lines += ""
                            lines += "[$n]"
                        }
                    }
                    "table:table-cell", "table:covered-table-cell" -> {
                        inCell = true
                        cell.setLength(0)
                    }
                }
                XmlPullParser.TEXT -> if (inPara > 0) cur.append(p.text)
                XmlPullParser.END_TAG -> when (p.name) {
                    "text:p", "text:h" -> {
                        if (inPara > 0) inPara--
                        if (inPara == 0) {
                            val t = cur.toString()
                            cur.setLength(0)
                            if (inCell) {
                                if (cell.isNotEmpty()) cell.append(' ')
                                cell.append(t.trim())
                            } else {
                                lines += t
                            }
                        }
                    }
                    "table:table-cell", "table:covered-table-cell" -> {
                        row += cell.toString()
                        cell.setLength(0)
                        inCell = false
                    }
                    "table:table-row" -> {
                        val line = row.joinToString("\t").trimEnd()
                        if (line.isNotBlank()) lines += line
                        row.clear()
                    }
                }
            }
            ev = p.next()
        }
        if (lines.none { it.isNotBlank() }) lines += "(This document has no text.)"
        return lines
    }

    /** All chapters of an EPUB as one HTML page (text and basic formatting; pictures are left out). */
    fun epubHtml(ctx: Context, uri: Uri): String {
        val parts = readEntry(ctx, uri) { n ->
            val l = n.lowercase()
            (l.endsWith(".xhtml") || l.endsWith(".html") || l.endsWith(".htm")) && !l.startsWith("meta-inf/")
        }
        if (parts.isEmpty()) throw DocReadException("This is not a valid EPUB file.")
        val body = StringBuilder()
        val bodyRx = Regex("<body[^>]*>(.*?)</body>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
        val dropRx = Regex("<(script|style|img|svg|image)[^>]*?(/>|>.*?</\\1>)", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
        for (bytes in parts) {
            val s = String(bytes, Charsets.UTF_8)
            val inner = bodyRx.find(s)?.groupValues?.get(1) ?: continue
            body.append(dropRx.replace(inner, "")).append("<hr>")
        }
        return "<!DOCTYPE html><html><head><meta charset=\"utf-8\">" +
            "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">" +
            "<style>body{font-family:sans-serif;line-height:1.6;padding:16px;word-wrap:break-word}" +
            "hr{border:0;border-top:1px solid #ccc;margin:28px 0}</style></head><body>$body</body></html>"
    }

    /** Entries whose name matches [want], in the order they appear in the zip. */
    private fun readEntry(ctx: Context, uri: Uri, want: (String) -> Boolean): List<ByteArray> {
        val input = ctx.contentResolver.openInputStream(uri) ?: throw DocReadException("Could not open this file.")
        val out = ArrayList<ByteArray>()
        input.use { raw ->
            ZipInputStream(raw).use { zip ->
                var e = zip.nextEntry
                while (e != null) {
                    if (!e.isDirectory && want(e.name)) {
                        val buf = java.io.ByteArrayOutputStream()
                        val chunk = ByteArray(64 * 1024)
                        while (true) {
                            val n = zip.read(chunk)
                            if (n < 0) break
                            buf.write(chunk, 0, n)
                            if (buf.size() > MAX_ENTRY_BYTES) throw DocReadException("This file is too large to open.")
                        }
                        out += buf.toByteArray()
                    }
                    e = zip.nextEntry
                }
            }
        }
        return out
    }
}
