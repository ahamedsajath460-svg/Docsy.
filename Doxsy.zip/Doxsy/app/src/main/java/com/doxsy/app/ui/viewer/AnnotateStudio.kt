package com.doxsy.app.ui.viewer

import android.graphics.Paint
import android.graphics.PointF
import android.graphics.RectF
import android.net.Uri
import android.provider.DocumentsContract
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Redo
import androidx.compose.material.icons.automirrored.rounded.Undo
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.doxsy.app.annot.Annot
import com.doxsy.app.annot.AnnotStore
import com.doxsy.app.annot.AnnotType
import com.doxsy.app.annot.PageTextLayer
import com.doxsy.app.annot.PdfAnnotExporter
import com.doxsy.app.annot.TextChar
import com.doxsy.app.annot.hitTest
import com.doxsy.app.annot.movedBy
import com.doxsy.app.data.ReadingMode
import com.doxsy.app.pdf.PdfSession
import com.doxsy.app.pdf.ToolResult
import com.doxsy.app.ui.annot.AnnotEditorState
import com.doxsy.app.ui.annot.AnnotPalette
import com.doxsy.app.ui.annot.AnnotTool
import com.doxsy.app.ui.annot.drawAnnot
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import java.util.UUID

/** What the text / note dialog is editing. */
private class AnnotTextTarget(val page: Int, val u: Float, val v: Float, val existing: Annot?, val note: Boolean)

/**
 * Annotate: highlight / underline / strike real text, draw with pen or marker, shapes, arrows, text
 * boxes and sticky notes. Markups are autosaved inside Doxsy and written into a NEW PDF on Save.
 */
@Composable
internal fun AnnotateDialog(
    name: String,
    uri: Uri,
    session: PdfSession,
    onClose: () -> Unit,
    onOpenPdf: (Uri) -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val n = session.pageCount
    val base = name.substringBeforeLast('.')
    val st = remember { AnnotEditorState() }
    val store = remember { AnnotStore(ctx.applicationContext) }
    val key = remember(uri) { AnnotStore.keyFor(uri.toString()) }
    val layer = remember(uri) { PageTextLayer(ctx.applicationContext, uri) }
    val listState = rememberLazyListState()
    var loaded by remember { mutableStateOf(false) }

    DisposableEffect(layer) { onDispose { layer.close() } }
    LaunchedEffect(key) {
        val saved = withContext(Dispatchers.IO) { runCatching { store.load(key) }.getOrNull() }
        if (saved != null) st.load(saved.annots)
        loaded = true
    }
    LaunchedEffect(st.revision) {
        if (loaded && st.revision > 0) {
            delay(700)
            withContext(Dispatchers.IO) { runCatching { store.save(key, uri.toString(), name, n, st.annots) } }
        }
    }
    DisposableEffect(Unit) {
        onDispose { if (loaded) runCatching { store.save(key, uri.toString(), name, n, st.annots) } }
    }

    var textTarget by remember { mutableStateOf<AnnotTextTarget?>(null) }
    var busy by remember { mutableStateOf(false) }
    var outcome by remember { mutableStateOf<Outcome?>(null) }

    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { out ->
        if (out != null) {
            busy = true
            val list = st.annots
            scope.launch {
                val r = withContext(Dispatchers.IO) {
                    try {
                        val os = ctx.contentResolver.openOutputStream(out, "wt") ?: throw IOException("Could not write the file.")
                        os.use { PdfAnnotExporter.export(ctx, uri, "", list, it) }
                        ToolResult.Done("Saved with ${list.size} markup(s). Original unchanged.")
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Throwable) {
                        runCatching { DocumentsContract.deleteDocument(ctx.contentResolver, out) }
                        ToolResult.Failed(PdfAnnotExporter.describe(e))
                    }
                }
                busy = false
                outcome = Outcome(r, out)
            }
        }
    }

    fun selectTool(t: AnnotTool) {
        st.tool = t
        st.selectedId = null
        st.draft = null
        st.selection = null
        if (t == AnnotTool.HIGHLIGHT) st.color = AnnotPalette[0]
        if (t == AnnotTool.UNDERLINE || t == AnnotTool.STRIKE) st.color = AnnotPalette[2]
    }

    fun onTapPage(page: Int, u: Float, v: Float, tool: AnnotTool) {
        textTarget = AnnotTextTarget(page, u, v, null, tool == AnnotTool.NOTE)
    }

    fun applyText(t: AnnotTextTarget, text: String) {
        val ex = t.existing
        if (ex != null) {
            if (text.isBlank()) {
                st.remove(ex.id)
            } else if (t.note) {
                st.update(ex.copy(comment = text))
            } else {
                st.update(ex.copy(text = text))
            }
            return
        }
        if (text.isBlank()) return
        if (t.note) {
            st.add(Annot(type = AnnotType.NOTE, page = t.page, color = 0xFFFFD83A.toInt(), points = listOf(PointF(t.u, t.v)), comment = text))
        } else {
            st.add(
                Annot(
                    type = AnnotType.TEXT, page = t.page, color = st.color, sizeFrac = st.textSizeFrac,
                    points = listOf(PointF(t.u, t.v)), text = text,
                ),
            )
        }
    }

    Dialog(
        onDismissRequest = { if (!busy) onClose() },
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false),
    ) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                // ---- top bar ----
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { if (!busy) onClose() }) { Icon(Icons.Rounded.Close, "Close") }
                    Column(Modifier.weight(1f)) {
                        Text("Annotate", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                        Text(
                            "Page ${listState.firstVisibleItemIndex + 1} of $n · ${st.annots.size} markup(s) · autosaved",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                        )
                    }
                    IconButton(onClick = { scope.launch { listState.animateScrollToItem((listState.firstVisibleItemIndex - 1).coerceAtLeast(0)) } }) {
                        Icon(Icons.Rounded.KeyboardArrowUp, "Previous page")
                    }
                    IconButton(onClick = { scope.launch { listState.animateScrollToItem((listState.firstVisibleItemIndex + 1).coerceAtMost(n - 1)) } }) {
                        Icon(Icons.Rounded.KeyboardArrowDown, "Next page")
                    }
                    IconButton(onClick = { st.undo() }, enabled = st.canUndo) { Icon(Icons.AutoMirrored.Rounded.Undo, "Undo") }
                    IconButton(onClick = { st.redo() }, enabled = st.canRedo) { Icon(Icons.AutoMirrored.Rounded.Redo, "Redo") }
                    if (busy) {
                        CircularProgressIndicator(Modifier.padding(horizontal = 12.dp).size(22.dp), strokeWidth = 2.dp)
                    } else {
                        TextButton(onClick = { save.launch("${base}_annotated.pdf") }, enabled = st.annots.isNotEmpty()) { Text("Save") }
                    }
                }

                // ---- pages ----
                LazyColumn(
                    state = listState,
                    modifier = Modifier.weight(1f).fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant),
                    contentPadding = PaddingValues(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(n, key = { it }) { i ->
                        AnnotPage(i, session, st, layer, ::onTapPage)
                    }
                }

                // ---- options + tools ----
                Surface(tonalElevation = 3.dp, shadowElevation = 6.dp) {
                    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        val sel = st.selected
                        if (sel != null && st.tool == AnnotTool.HAND) {
                            Row(
                                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                if (sel.type == AnnotType.TEXT || sel.type == AnnotType.NOTE) {
                                    TextButton(onClick = {
                                        val p = sel.points.firstOrNull() ?: PointF(0.1f, 0.1f)
                                        textTarget = AnnotTextTarget(sel.page, p.x, p.y, sel, sel.type == AnnotType.NOTE)
                                    }) {
                                        Icon(Icons.Rounded.Edit, null, Modifier.size(18.dp))
                                        Text("  Edit")
                                    }
                                }
                                if (sel.type != AnnotType.NOTE) {
                                    AnnotPalette.forEach { c ->
                                        ColorDot(c, sel.color == c) { st.update(sel.copy(color = c)) }
                                    }
                                }
                                TextButton(onClick = { st.remove(sel.id) }) {
                                    Icon(Icons.Rounded.Delete, null, Modifier.size(18.dp))
                                    Text("  Delete")
                                }
                            }
                        } else {
                            Row(
                                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                if (st.tool != AnnotTool.HAND && st.tool != AnnotTool.ERASER && st.tool != AnnotTool.NOTE) {
                                    AnnotPalette.forEach { c -> ColorDot(c, st.color == c) { st.color = c } }
                                }
                                if (st.tool.usesThickness) {
                                    Text("Thickness", style = MaterialTheme.typography.labelMedium)
                                    Slider(st.thicknessLevel, { st.thicknessLevel = it }, Modifier.size(width = 150.dp, height = 32.dp))
                                }
                                if (st.tool == AnnotTool.TEXT) {
                                    Text("Text size", style = MaterialTheme.typography.labelMedium)
                                    Slider(st.textLevel, { st.textLevel = it }, Modifier.size(width = 150.dp, height = 32.dp))
                                }
                                if (st.tool == AnnotTool.HAND) {
                                    Text(
                                        "Tap a markup to select it. Scroll normally.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                if (st.tool == AnnotTool.ERASER) {
                                    Text("Drag over a markup to erase it.", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                        Row(
                            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp, vertical = 2.dp),
                            horizontalArrangement = Arrangement.spacedBy(2.dp),
                        ) {
                            AnnotTool.values().forEach { t -> ToolButton(t.icon, t.label, st.tool == t) { selectTool(t) } }
                        }
                    }
                }
            }

            textTarget?.let { t ->
                AnnotTextDialog(t, onDone = { text ->
                    textTarget = null
                    if (text != null) applyText(t, text)
                })
            }
            outcome?.let { o -> ResultDialog(o, onOpen = onOpenPdf, onClose = { outcome = null }) }
        }
    }
}

@Composable
private fun ColorDot(color: Int, active: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(30.dp)
            .clip(CircleShape)
            .background(Color(color))
            .border(if (active) 3.dp else 1.dp, if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline, CircleShape)
            .clickable(onClick = onClick),
    )
}

@Composable
private fun ToolButton(icon: ImageVector, label: String, active: Boolean, onClick: () -> Unit) {
    val tint = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
    Column(
        Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (active) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, label, tint = tint)
        Text(label, style = MaterialTheme.typography.labelSmall, color = tint, maxLines = 1)
    }
}

@Composable
private fun AnnotTextDialog(t: AnnotTextTarget, onDone: (String?) -> Unit) {
    var text by remember(t) { mutableStateOf(t.existing?.let { if (t.note) it.comment else it.text } ?: "") }
    val focus = remember { FocusRequester() }
    LaunchedEffect(t) { runCatching { focus.requestFocus() } }
    val nonLatin = text.any { it.code > 255 }
    AlertDialog(
        onDismissRequest = { onDone(null) },
        title = { Text(if (t.note) "Sticky note" else "Text") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    modifier = Modifier.fillMaxWidth().focusRequester(focus),
                    minLines = 2,
                    maxLines = 6,
                    label = { Text(if (t.note) "Note" else "Text") },
                )
                if (nonLatin && !t.note) {
                    Text(
                        "Tamil / Sinhala letters cannot be written by this tool. Use Edit PDF > Add text for those.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
                if (t.existing != null) {
                    Text("Leave it empty to delete.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        },
        confirmButton = { TextButton(onClick = { onDone(text) }) { Text("Done") } },
        dismissButton = { TextButton(onClick = { onDone(null) }) { Text("Cancel") } },
    )
}

/** One page: the PDF underneath, the markups painted on top, and the touch handling for the current tool. */
@Composable
private fun AnnotPage(
    page: Int,
    session: PdfSession,
    st: AnnotEditorState,
    layer: PageTextLayer,
    onTapPage: (Int, Float, Float, AnnotTool) -> Unit,
) {
    val primary = MaterialTheme.colorScheme.primary
    val paint = remember { Paint(Paint.ANTI_ALIAS_FLAG) }
    var chars by remember(page) { mutableStateOf<List<TextChar>>(emptyList()) }
    val wantsText = st.tool.isTextMarkup
    LaunchedEffect(page, wantsText) {
        if (wantsText && chars.isEmpty()) chars = runCatching { layer.chars(page) }.getOrDefault(emptyList())
    }

    Box(Modifier.fillMaxWidth().aspectRatio(1f / session.aspect(page, 0)).background(Color.White)) {
        PageImage(session, page, 1000, 0, ReadingMode.LIGHT, Modifier.fillMaxSize())
        Canvas(
            Modifier.fillMaxSize().pointerInput(page) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val w = size.width.toFloat()
                    val h = size.height.toFloat()
                    val aspect = h / w
                    val tool = st.tool
                    val start = down.position
                    var moved = false
                    var grabbed = false
                    var hitId: String? = null
                    var begun = false
                    val pts = ArrayList<PointF>()
                    val draftId = UUID.randomUUID().toString()

                    fun nu(x: Float) = (x / w).coerceIn(0f, 1f)
                    fun nv(y: Float) = (y / h).coerceIn(0f, 1f)

                    fun eraseAt(x: Float, y: Float) {
                        val u = nu(x)
                        val v = nv(y)
                        val hit = st.annots.filter { it.page == page && it.hitTest(u, v, 0.015f, aspect) }
                        if (hit.isNotEmpty()) {
                            if (!begun) {
                                st.beginGesture()
                                begun = true
                            }
                            val ids = hit.map { it.id }.toSet()
                            st.setSilently(st.annots.filterNot { it.id in ids })
                        }
                    }

                    if (tool == AnnotTool.HAND) {
                        val hit = st.annots.lastOrNull { it.page == page && it.hitTest(nu(start.x), nv(start.y), 0.02f, aspect) }
                        st.selectedId = hit?.id
                        if (hit != null) {
                            grabbed = true
                            hitId = hit.id
                        }
                    } else if (tool.isTextMarkup || tool.isStroke || tool.isShape || tool == AnnotTool.ERASER) {
                        grabbed = true
                    }
                    if (tool.isStroke) pts.add(PointF(nu(start.x), nv(start.y)))
                    if (tool == AnnotTool.ERASER) eraseAt(start.x, start.y)

                    var last = start
                    while (true) {
                        val ev = awaitPointerEvent()
                        val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                        if (!ch.pressed) {
                            when {
                                (tool == AnnotTool.TEXT || tool == AnnotTool.NOTE) && !moved ->
                                    onTapPage(page, nu(start.x), nv(start.y), tool)
                                tool.isStroke -> {
                                    if (pts.isNotEmpty()) {
                                        st.add(
                                            Annot(
                                                type = tool.type ?: AnnotType.INK, page = page, color = st.color,
                                                strokeFrac = st.strokeFrac, points = pts.toList(),
                                            ),
                                        )
                                    }
                                    st.draft = null
                                }
                                tool.isShape -> {
                                    val d = st.draft
                                    st.draft = null
                                    if (d != null && d.points.size >= 2) {
                                        val dx = (d.points[1].x - d.points[0].x) * w
                                        val dy = (d.points[1].y - d.points[0].y) * h
                                        if (dx * dx + dy * dy > 64f) st.add(d)
                                    }
                                }
                                tool.isTextMarkup -> {
                                    val sel = st.selection
                                    st.selection = null
                                    if (sel != null && sel.first == page && sel.second.isNotEmpty()) {
                                        st.add(
                                            Annot(
                                                type = tool.type ?: AnnotType.HIGHLIGHT, page = page, color = st.color,
                                                rects = sel.second.map { RectF(it) },
                                            ),
                                        )
                                    }
                                }
                                tool == AnnotTool.HAND && hitId != null && begun -> st.finishGesture()
                                tool == AnnotTool.ERASER && begun -> st.finishGesture()
                            }
                            break
                        }
                        if (!moved && (ch.position - start).getDistance() > viewConfiguration.touchSlop) moved = true
                        if (moved && grabbed) {
                            ch.consume()
                            val x = ch.position.x
                            val y = ch.position.y
                            when {
                                tool == AnnotTool.HAND -> {
                                    val id = hitId
                                    if (id != null) {
                                        if (!begun) {
                                            st.beginGesture()
                                            begun = true
                                        }
                                        val du = (x - last.x) / w
                                        val dv = (y - last.y) / h
                                        st.setSilently(st.annots.map { if (it.id == id) it.movedBy(du, dv) else it })
                                    }
                                }
                                tool == AnnotTool.ERASER -> eraseAt(x, y)
                                tool.isStroke -> {
                                    pts.add(PointF(nu(x), nv(y)))
                                    st.draft = Annot(
                                        id = draftId, type = tool.type ?: AnnotType.INK, page = page, color = st.color,
                                        strokeFrac = st.strokeFrac, points = pts.toList(),
                                    )
                                }
                                tool.isShape -> {
                                    st.draft = Annot(
                                        id = draftId, type = tool.type ?: AnnotType.RECT, page = page, color = st.color,
                                        strokeFrac = st.strokeFrac,
                                        points = listOf(PointF(nu(start.x), nv(start.y)), PointF(nu(x), nv(y))),
                                    )
                                }
                                tool.isTextMarkup -> {
                                    val picked = layer.selectionBetween(chars, PointF(nu(start.x), nv(start.y)), PointF(nu(x), nv(y)), aspect)
                                    st.selection = Pair(page, layer.rectsOf(picked))
                                }
                            }
                        }
                        last = ch.position
                    }
                    if (st.draft != null) st.draft = null
                    if (st.selection != null) st.selection = null
                }
            },
        ) {
            val w = size.width
            val h = size.height
            st.annots.forEach { a ->
                if (a.page == page) drawAnnot(a, if (a.id == st.selectedId) primary else null, paint)
            }
            val d = st.draft
            if (d != null && d.page == page) drawAnnot(d, null, paint)
            val sel = st.selection
            if (sel != null && sel.first == page) {
                sel.second.forEach {
                    drawRect(Color(0x552F6BFF), Offset(it.left * w, it.top * h), Size((it.right - it.left) * w, (it.bottom - it.top) * h))
                }
            }
        }
    }
}
