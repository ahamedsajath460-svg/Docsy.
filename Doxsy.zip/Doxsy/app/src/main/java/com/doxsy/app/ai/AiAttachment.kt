package com.doxsy.app.ai

/**
 * A file prepared for the AI. Whatever the user picks, the AI gets the file itself where it can read it:
 * the original PDF, the picture, or the complete text of Word / Excel / PowerPoint / text files.
 */
class AiAttachment(
    val name: String,
    /** Complete text of the file (empty for pictures and scanned PDFs). */
    val text: String,
    /** Pictures as data URLs: the picture itself, or the first pages of a scanned PDF. */
    val images: List<String>,
    /** The original PDF as a data URL, for AI models that read PDF files themselves. */
    val pdf: String?,
    /** Short note shown under the file name, e.g. that only the first pages are read. */
    val note: String?,
) {
    val hasText: Boolean get() = text.isNotBlank()

    /** True when the file is only a picture (a photo, a screenshot, a scanned page). */
    val isPicture: Boolean get() = images.isNotEmpty() && !hasText
}
