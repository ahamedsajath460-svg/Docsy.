package com.doxsy.app.docview

import android.content.Context
import android.net.Uri
import org.xmlpull.v1.XmlPullParser
import java.math.BigDecimal
import java.math.MathContext
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.floor

/** Streaming reader for .xlsx. Shows cached cell values (formulas are NOT recalculated). */
object XlsxReader {
    private const val MAX_COLS = 1000

    fun read(ctx: Context, uri: Uri, maxRows: Int = 20000): Workbook {
        try {
            // Old binary .xls (or an .xlsx that is really one) is read by the legacy reader.
            LegacyOffice.open(ctx, uri)?.let { return LegacyOffice.workbook(it, maxRows) }
            OoxmlPackage.open(ctx, uri, "Excel").use { pkg ->
                if (!pkg.has("xl/workbook.xml")) {
                    throw DocReadException("This is not a valid Excel workbook (xl/workbook.xml is missing).")
                }
                val rels = pkg.rels("xl/workbook.xml")
                val shared = readSharedStrings(pkg)
                val (xfs, codes) = readStyles(pkg)
                val fmts = xfs.map { fmtFor(it, codes) }
                val date1904 = readDate1904(pkg)

                val sheets = ArrayList<Sheet>()
                val wb = pkg.open("xl/workbook.xml")
                    ?: throw DocReadException("This workbook has no readable content.")
                wb.use { input ->
                    val p = newParser(input)
                    while (true) {
                        val ev = p.next()
                        if (ev == XmlPullParser.END_DOCUMENT) break
                        if (ev == XmlPullParser.START_TAG && p.ln() == "sheet") {
                            if (p.attr("state") == "veryHidden") continue
                            val name = p.attr("name") ?: "Sheet ${sheets.size + 1}"
                            val rid = p.attr("id") ?: continue
                            val target = rels[rid]?.target ?: continue
                            if (!pkg.has(target)) continue
                            sheets.add(readSheet(pkg, target, name, shared, fmts, date1904, maxRows))
                        }
                    }
                }
                if (sheets.isEmpty()) throw DocReadException("This workbook contains no readable sheets.")
                return Workbook(sheets)
            }
        } catch (e: DocReadException) {
            throw e
        } catch (e: OutOfMemoryError) {
            throw DocReadException("Not enough memory to open this workbook.", e)
        } catch (e: Exception) {
            throw DocReadException("This Excel workbook could not be read. It may be corrupted.", e)
        }
    }

    private fun readDate1904(pkg: OoxmlPackage): Boolean {
        val s = pkg.open("xl/workbook.xml") ?: return false
        return runCatching {
            s.use { input ->
                val p = newParser(input)
                var res = false
                while (true) {
                    val ev = p.next()
                    if (ev == XmlPullParser.END_DOCUMENT) break
                    if (ev == XmlPullParser.START_TAG && p.ln() == "workbookPr") {
                        res = p.attr("date1904").let { it == "1" || it == "true" }
                        break
                    }
                }
                res
            }
        }.getOrDefault(false)
    }

    private fun readSharedStrings(pkg: OoxmlPackage): List<String> {
        val out = ArrayList<String>()
        val s = pkg.open("xl/sharedStrings.xml") ?: return out
        s.use { input ->
            val p = newParser(input)
            var sb: StringBuilder? = null
            while (true) {
                val ev = p.next()
                if (ev == XmlPullParser.END_DOCUMENT) break
                if (ev == XmlPullParser.START_TAG) {
                    when (p.ln()) {
                        "si" -> sb = StringBuilder()
                        "t" -> sb?.append(p.nextText())
                        "rPh" -> p.skipTree()
                    }
                } else if (ev == XmlPullParser.END_TAG && p.ln() == "si") {
                    out.add(sb?.toString() ?: "")
                    sb = null
                }
            }
        }
        return out
    }

    private fun readStyles(pkg: OoxmlPackage): Pair<List<Int>, Map<Int, String>> {
        val xfs = ArrayList<Int>()
        val codes = HashMap<Int, String>()
        val s = pkg.open("xl/styles.xml") ?: return Pair(xfs, codes)
        s.use { input ->
            val p = newParser(input)
            var inXfs = false
            while (true) {
                val ev = p.next()
                if (ev == XmlPullParser.END_DOCUMENT) break
                if (ev == XmlPullParser.START_TAG) {
                    when (p.ln()) {
                        "numFmt" -> {
                            val id = p.attr("numFmtId")?.toIntOrNull()
                            val code = p.attr("formatCode")
                            if (id != null && code != null) codes[id] = code
                        }
                        "cellXfs" -> inXfs = true
                        "xf" -> if (inXfs) xfs.add(p.attr("numFmtId")?.toIntOrNull() ?: 0)
                    }
                } else if (ev == XmlPullParser.END_TAG && p.ln() == "cellXfs") {
                    inXfs = false
                }
            }
        }
        return Pair(xfs, codes)
    }

    // ---------- number formats ----------

    internal class Fmt(
        val kind: Int, // 0 general, 1 number, 2 percent, 3 date/time, 4 text
        val decimals: Int = 0,
        val thousands: Boolean = false,
        val hasDate: Boolean = false,
        val hasTime: Boolean = false,
    )

    private val GENERAL = Fmt(0)

    /** Formats numeric cell values of legacy (.xls) workbooks the same way as .xlsx cells. */
    internal class NumFormatter(private val codes: Map<Int, String>, private val date1904: Boolean) {
        private val cache = HashMap<Int, Fmt>()
        fun format(value: Double, fmtId: Int): String {
            val f = cache.getOrPut(fmtId) { fmtFor(fmtId, codes) }
            return formatNumber(java.lang.Double.toString(value), f, date1904)
        }
    }

    private fun fmtFor(id: Int, codes: Map<Int, String>): Fmt {
        when (id) {
            0 -> return GENERAL
            1 -> return Fmt(1, 0)
            2 -> return Fmt(1, 2)
            3 -> return Fmt(1, 0, true)
            4 -> return Fmt(1, 2, true)
            5, 6, 37, 38 -> return Fmt(1, 0, true)
            7, 8, 39, 40 -> return Fmt(1, 2, true)
            9 -> return Fmt(2, 0)
            10 -> return Fmt(2, 2)
            14, 15, 16, 17 -> return Fmt(3, hasDate = true)
            18, 19, 20, 21 -> return Fmt(3, hasTime = true)
            22 -> return Fmt(3, hasDate = true, hasTime = true)
            45, 46, 47 -> return Fmt(3, hasTime = true)
            49 -> return Fmt(4)
        }
        val raw = codes[id] ?: return GENERAL
        val code = cleanCode(raw.substringBefore(';'))
        if (code.equals("general", ignoreCase = true) || code.isBlank()) return GENERAL
        val lower = code.lowercase(Locale.ROOT)
        if ('%' in lower) return Fmt(2, decimalsOf(lower))
        val hasDate = lower.any { it == 'y' || it == 'd' } || (lower.contains('m') && !lower.contains('0') && !lower.contains('#') && !lower.contains('h') && !lower.contains('s'))
        val hasTime = lower.contains('h') || lower.contains('s')
        if ((hasDate || hasTime) && !lower.contains('0') && !lower.contains('#')) return Fmt(3, hasDate = hasDate, hasTime = hasTime)
        if (lower.contains('e') && lower.contains("e+")) return GENERAL
        if (lower.contains('0') || lower.contains('#')) return Fmt(1, decimalsOf(lower), thousands = ',' in lower)
        if (lower == "@") return Fmt(4)
        return GENERAL
    }

    private fun cleanCode(code: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < code.length) {
            val c = code[i]
            when {
                c == '"' -> {
                    i++
                    while (i < code.length && code[i] != '"') i++
                }
                c == '[' -> {
                    i++
                    while (i < code.length && code[i] != ']') i++
                }
                c == '\\' || c == '_' || c == '*' -> i++ // skip the escaped / padding character too
                else -> sb.append(c)
            }
            i++
        }
        return sb.toString()
    }

    private fun decimalsOf(code: String): Int {
        val dot = code.indexOf('.')
        if (dot < 0) return 0
        var n = 0
        var i = dot + 1
        while (i < code.length && (code[i] == '0' || code[i] == '#')) {
            n++
            i++
        }
        return n.coerceAtMost(10)
    }

    private fun general(raw: String): String {
        val d = raw.toDoubleOrNull() ?: return raw
        if (d.isNaN() || d.isInfinite()) return raw
        if (d == floor(d) && abs(d) < 1e15) return d.toLong().toString()
        return raw.toBigDecimalOrNull()?.round(MathContext(12))?.stripTrailingZeros()?.toPlainString() ?: raw
    }

    private fun formatNumber(raw: String, f: Fmt, date1904: Boolean): String {
        val d = raw.toDoubleOrNull() ?: return raw
        if (d.isNaN() || d.isInfinite()) return raw
        return when (f.kind) {
            1 -> {
                val pattern = (if (f.thousands) "#,##0" else "0") + (if (f.decimals > 0) "." + "0".repeat(f.decimals) else "")
                DecimalFormat(pattern, DecimalFormatSymbols(Locale.getDefault())).format(BigDecimal(raw).setScale(f.decimals, java.math.RoundingMode.HALF_UP))
            }
            2 -> {
                val pattern = "0" + (if (f.decimals > 0) "." + "0".repeat(f.decimals) else "") + "%"
                DecimalFormat(pattern, DecimalFormatSymbols(Locale.getDefault())).format(d)
            }
            3 -> formatDate(d, f, date1904)
            4 -> raw
            else -> general(raw)
        }
    }

    private fun formatDate(serial: Double, f: Fmt, date1904: Boolean): String {
        if (serial < 0 || serial > 2_958_465) return general(serial.toString())
        val days = floor(serial)
        val frac = serial - days
        val offset = if (date1904) 24107.0 else 25569.0 // days between 1900/1904 epochs and 1970
        val adj = if (!date1904 && serial < 61) 1.0 else 0.0 // Excel's 1900 leap-year bug
        val ms = ((days - offset + adj) * 86_400_000.0 + Math.round(frac * 86_400_000.0)).toLong()
        val pattern = when {
            f.hasDate && f.hasTime -> "yyyy-MM-dd HH:mm"
            f.hasTime && !f.hasDate -> "HH:mm:ss"
            else -> "yyyy-MM-dd"
        }
        val fmt = SimpleDateFormat(pattern, Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
        return if (f.hasTime && !f.hasDate && serial >= 1) {
            SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(Date(ms))
        } else {
            fmt.format(Date(ms))
        }
    }

    // ---------- sheets ----------

    private fun colIndex(ref: String?): Int {
        if (ref == null) return -1
        var idx = 0
        var n = 0
        for (ch in ref) {
            if (ch in 'A'..'Z') idx = idx * 26 + (ch - 'A' + 1)
            else if (ch in 'a'..'z') idx = idx * 26 + (ch - 'a' + 1)
            else break
            n++
        }
        return if (n == 0) -1 else idx - 1
    }

    private fun readSheet(
        pkg: OoxmlPackage,
        path: String,
        name: String,
        shared: List<String>,
        fmts: List<Fmt>,
        date1904: Boolean,
        maxRows: Int,
    ): Sheet {
        val rows = ArrayList<ArrayList<String>>()
        val widths = ArrayList<Float>()
        var truncated = false
        val stream = pkg.open(path) ?: return Sheet(name, emptyList())
        stream.use { input ->
            val p = newParser(input)
            var rowNum = 0
            var nextCol = 0
            loop@ while (true) {
                val ev = p.next()
                if (ev == XmlPullParser.END_DOCUMENT) break
                if (ev != XmlPullParser.START_TAG) continue
                when (p.ln()) {
                    "col" -> {
                        val min = p.attr("min")?.toIntOrNull() ?: continue@loop
                        val max = (p.attr("max")?.toIntOrNull() ?: min).coerceAtMost(200)
                        val w = p.attr("width")?.toFloatOrNull() ?: continue@loop
                        for (c in min..max) {
                            while (widths.size < c) widths.add(8.43f)
                            widths[c - 1] = w
                        }
                    }
                    "row" -> {
                        rowNum = p.attr("r")?.toIntOrNull() ?: (rowNum + 1)
                        nextCol = 0
                        if (rowNum > maxRows) {
                            truncated = true
                            break@loop
                        }
                        while (rows.size < rowNum) rows.add(ArrayList())
                    }
                    "c" -> {
                        if (rowNum <= 0) continue@loop
                        val col = colIndex(p.attr("r")).let { if (it >= 0) it else nextCol }
                        nextCol = col + 1
                        val t = p.attr("t")
                        val style = p.attr("s")?.toIntOrNull() ?: 0
                        var v: String? = null
                        val inline = StringBuilder()
                        var hasInline = false
                        cell@ while (true) {
                            val e2 = p.next()
                            if (e2 == XmlPullParser.END_DOCUMENT) break@cell
                            if (e2 == XmlPullParser.END_TAG) {
                                if (p.ln() == "c") break@cell
                                continue
                            }
                            if (e2 != XmlPullParser.START_TAG) continue
                            when (p.ln()) {
                                "v" -> v = p.nextText()
                                "is" -> hasInline = true
                                "t" -> if (hasInline) inline.append(p.nextText())
                                "rPh" -> p.skipTree()
                            }
                        }
                        if (col in 0 until MAX_COLS) {
                            val text = when (t) {
                                "s" -> v?.trim()?.toIntOrNull()?.let { shared.getOrNull(it) } ?: ""
                                "inlineStr" -> inline.toString()
                                "str", "e", "d" -> v ?: ""
                                "b" -> if (v?.trim() == "1") "TRUE" else "FALSE"
                                else -> {
                                    val raw = v?.trim()
                                    if (raw.isNullOrEmpty()) "" else formatNumber(raw, fmts.getOrNull(style) ?: GENERAL, date1904)
                                }
                            }
                            if (text.isNotEmpty()) {
                                val row = rows[rowNum - 1]
                                while (row.size <= col) row.add("")
                                row[col] = text
                            }
                        }
                    }
                }
            }
        }
        while (rows.isNotEmpty() && rows.last().isEmpty()) rows.removeAt(rows.lastIndex)
        return Sheet(name, rows, widths, truncated)
    }
}
