package com.doxsy.app.ui.settings

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.imePadding
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Button
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.window.Dialog
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.HeadsetMic
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.PrivacyTip
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Smartphone
import androidx.compose.material.icons.rounded.ThumbUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import android.content.Intent
import android.net.Uri
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.doxsy.app.BuildConfig
import com.doxsy.app.data.PageMode
import com.doxsy.app.data.Prefs
import com.doxsy.app.data.ReadingMode
import com.doxsy.app.data.SortOrder
import com.doxsy.app.data.ThemeMode
import com.doxsy.app.ui.theme.AccentColors
import com.doxsy.app.ui.theme.AccentNames
import com.doxsy.app.util.FileUtils

private enum class InfoDialog { PRIVACY, TERMS, ABOUT }

@Composable
fun SettingsScreen(prefs: Prefs) {
    val ctx = LocalContext.current
    val theme by prefs.themeMode.state.collectAsState()
    val accent by prefs.accent.state.collectAsState()
    val fontScale by prefs.fontScale.state.collectAsState()
    val pageMode by prefs.pageMode.state.collectAsState()
    val readingMode by prefs.readingMode.state.collectAsState()
    val defaultZoom by prefs.defaultZoom.state.collectAsState()
    val rememberPage by prefs.rememberLastPage.state.collectAsState()
    val autoRotate by prefs.autoRotate.state.collectAsState()
    val recentLimit by prefs.recentLimit.state.collectAsState()
    val sort by prefs.sortOrder.state.collectAsState()
    val grid by prefs.gridView.state.collectAsState()
    val appLock by prefs.appLock.state.collectAsState()
    val secure by prefs.secureScreen.state.collectAsState()
    val hideRecents by prefs.hideRecents.state.collectAsState()
    val keepOn by prefs.keepScreenOn.state.collectAsState()
    val systemDark = isSystemInDarkTheme()
    val darkOn = theme == ThemeMode.DARK || (theme == ThemeMode.SYSTEM && systemDark)

    var info by remember { mutableStateOf<InfoDialog?>(null) }
    var confirmClear by remember { mutableStateOf(false) }
    var showSupport by rememberSaveable { mutableStateOf(false) }
    var showRate by remember { mutableStateOf(false) }

    fun openStore() {
        val pkg = ctx.packageName
        runCatching {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }.onFailure {
            runCatching {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
    }

    fun sendSupport(message: String) {
        runCatching {
            ctx.startActivity(
                Intent.createChooser(
                    Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
                        .putExtra(Intent.EXTRA_EMAIL, arrayOf(SUPPORT_EMAIL))
                        .putExtra(Intent.EXTRA_SUBJECT, "Doxsy feedback (" + BuildConfig.VERSION_NAME + ")")
                        .putExtra(Intent.EXTRA_TEXT, message),
                    "Send feedback",
                ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
            showSupport = false
        }.onFailure { FileUtils.toast(ctx, "No email app found") }
    }

    if (showSupport) SupportPage(onBack = { showSupport = false }, onSend = { sendSupport(it) })
    else LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 32.dp)) {
        item {
            Column {
                Text(
                    "Settings",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 20.dp, top = 8.dp, bottom = 12.dp),
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            }
        }

        item {
            Column(Modifier.padding(vertical = 8.dp)) {
                SwitchRow("Dark Mode", null, darkOn, icon = Icons.Rounded.DarkMode) {
                    prefs.themeMode.value = if (it) ThemeMode.DARK else ThemeMode.LIGHT
                }
                SwitchRow("Keep Screen On", null, keepOn, icon = Icons.Rounded.Smartphone) {
                    prefs.keepScreenOn.value = it
                }
            }
        }

        item { SectionBand() }

        item {
            Column(Modifier.padding(vertical = 8.dp)) {
                ActionRow(
                    "Customer Support",
                    "Tell us what changes you'd like to see, or bugs you've discovered.",
                    Icons.Rounded.HeadsetMic,
                ) { showSupport = true }
                ActionRow("Rate Us", "Do you like this app? Please support it with 5 stars.", Icons.Rounded.ThumbUp) { showRate = true }
                ActionRow("Share", "Do you want to share this app with your friends?", Icons.Rounded.Share) {
                    val send = Intent(Intent.ACTION_SEND)
                        .setType("text/plain")
                        .putExtra(Intent.EXTRA_TEXT, "Doxsy - a fast, private PDF reader: https://play.google.com/store/apps/details?id=" + ctx.packageName)
                    runCatching { ctx.startActivity(Intent.createChooser(send, "Share Doxsy").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                }
                ActionRow("Privacy Policy", "Read the Privacy Policy.", Icons.Rounded.PrivacyTip) { info = InfoDialog.PRIVACY }
                ActionRow("Terms Of Service", "Read the Terms and Conditions.", Icons.Rounded.Description) { info = InfoDialog.TERMS }
                ActionRow("Doxsy", "Version: " + BuildConfig.VERSION_NAME, Icons.Rounded.Info) { info = InfoDialog.ABOUT }
            }
        }

        item {
            Group("Privacy & security") {
                SwitchRow("App lock", "Require fingerprint, face or screen lock to open Doxsy", appLock) { on ->
                    if (!on) {
                        prefs.appLock.value = false
                    } else if (FileUtils.canUseAppLock(ctx)) {
                        prefs.appLock.value = true
                    } else {
                        FileUtils.toast(ctx, "Set up a screen lock or biometrics on your device first.")
                    }
                }
                Divider()
                SwitchRow("Block screenshots", "Also hides Doxsy in the recent apps view", secure) {
                    prefs.secureScreen.value = it
                }
                Divider()
                SwitchRow("Hide recent documents", "Stop recording newly opened documents", hideRecents) {
                    prefs.hideRecents.value = it
                    if (it) prefs.recents.value = emptyList()
                }
                Divider()
                ActionRow("Clear recent history", "Removes recents and saved reading positions") { confirmClear = true }
            }
        }

    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear recent history?") },
            text = { Text("Recent documents and remembered reading positions will be removed. Your files, favourites and bookmarks are not affected.") },
            confirmButton = {
                TextButton(onClick = {
                    prefs.clearHistory()
                    confirmClear = false
                }) { Text("Clear") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } },
        )
    }

    if (showRate) {
        RateDialog(
            onClose = { showRate = false },
            onRate = { stars ->
                showRate = false
                if (stars >= 4) openStore() else showSupport = true
            },
        )
    }

    info?.let { which ->
        val (title, body) = when (which) {
            InfoDialog.ABOUT -> "Doxsy ${BuildConfig.VERSION_NAME}" to
                "Read. View. Manage.\n\nDoxsy is a fast, private PDF reader. Everything happens on your device."
            InfoDialog.PRIVACY -> "Privacy policy" to
                "Doxsy works fully offline and does not collect, upload or share your documents or personal data.\n\n" +
                    "• Files are opened through Android's file picker or folders you choose; Doxsy never asks for broad storage access.\n" +
                    "• Recent files, favourites, bookmarks and settings are stored only on this device. Clear them any time in Settings.\n" +
                    "• Temporary copies, if ever needed to open a file, are kept in private app storage and removed on the next launch."
            InfoDialog.TERMS -> "Terms of service" to
                "Doxsy is provided \"as is\", without warranty of any kind. You are responsible for the documents you open, " +
                    "edit or delete with it, and for keeping backups of important files."
        }
        AlertDialog(
            onDismissRequest = { info = null },
            title = { Text(title) },
            text = { Text(body) },
            confirmButton = { TextButton(onClick = { info = null }) { Text("Close") } },
        )
    }
}

/** Support address for "Customer Support". Never shown inside Doxsy; it is only filled into the e-mail app's "To" field. */
private const val SUPPORT_EMAIL = "ahamedsajath460@gmail.com"

@Composable
internal fun SectionBand() {
    Box(
        Modifier
            .fillMaxWidth()
            .height(8.dp)
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
    )
}

@Composable
internal fun Group(title: String, content: @Composable () -> Unit) {
    SectionBand()
    Column(Modifier.padding(vertical = 8.dp)) {
        Text(
            title,
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 6.dp),
        )
        Column { content() }
    }
}

@Composable
internal fun Divider() {
    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant, modifier = Modifier.padding(horizontal = 16.dp))
}

@Composable
internal fun <T> Choice(title: String, options: List<Pair<String, T>>, selected: T, onSelect: (T) -> Unit) {
    Column(Modifier.padding(16.dp)) {
        Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { (label, value) ->
                FilterChip(selected = value == selected, onClick = { onSelect(value) }, label = { Text(label) })
            }
        }
    }
}

@Composable
private fun RowIcon(icon: ImageVector?) {
    if (icon != null) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(26.dp))
        Spacer(Modifier.width(22.dp))
    }
}

@Composable
internal fun SwitchRow(
    title: String,
    subtitle: String?,
    checked: Boolean,
    enabled: Boolean = true,
    icon: ImageVector? = null,
    onChange: (Boolean) -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .alpha(if (enabled) 1f else 0.45f)
            .clickable(enabled = enabled) { onChange(!checked) }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RowIcon(icon)
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
            if (subtitle != null) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}

@Composable
internal fun ActionRow(title: String, subtitle: String?, icon: ImageVector? = null, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RowIcon(icon)
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
            if (subtitle != null) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

/** Full page: write the problem (at least 50 characters), then Send opens the e-mail app. */
@Composable
private fun SupportPage(onBack: () -> Unit, onSend: (String) -> Unit) {
    var text by rememberSaveable { mutableStateOf("") }
    val count = text.trim().length
    BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize().imePadding()) {
        Row(Modifier.fillMaxWidth().height(64.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") }
            Text(
                "Customer Support",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(start = 16.dp),
            )
        }
        TextField(
            value = text,
            onValueChange = { text = it },
            placeholder = { Text("Describe the issue (at least 50 characters)") },
            textStyle = MaterialTheme.typography.bodyLarge,
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.Transparent,
                unfocusedContainerColor = Color.Transparent,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
            ),
            modifier = Modifier.weight(1f).fillMaxWidth(),
        )
        Text(
            "$count / 50",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.End,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 4.dp),
        )
        Button(
            onClick = { onSend(text.trim()) },
            enabled = count >= 50,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 16.dp).height(52.dp),
            shape = RoundedCornerShape(8.dp),
        ) { Text("Send") }
    }
}

/** "Do you like Doxsy?" with 5 stars; 4-5 stars goes to the store, fewer opens Customer Support. */
@Composable
private fun RateDialog(onClose: () -> Unit, onRate: (Int) -> Unit) {
    var stars by remember { mutableStateOf(0) }
    Dialog(onDismissRequest = onClose) {
        Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(Modifier.fillMaxWidth()) {
                    IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, "Close") }
                }
                Text(
                    "Do you like\nDoxsy?",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(16.dp))
                Text(
                    "We are working hard for a better user experience.\nWe'd greatly appreciate if you can rate us",
                    style = MaterialTheme.typography.bodyLarge,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 8.dp),
                )
                Spacer(Modifier.height(24.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    for (i in 1..5) {
                        Icon(
                            Icons.Rounded.Star,
                            contentDescription = "$i stars",
                            tint = if (i <= stars) Color(0xFFFFB400) else Color(0xFFBDBDBD),
                            modifier = Modifier.size(44.dp).clickable { stars = i },
                        )
                    }
                }
                Row(
                    Modifier.fillMaxWidth().padding(top = 8.dp, end = 8.dp),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("The best we can get", style = MaterialTheme.typography.bodyLarge)
                    Spacer(Modifier.width(8.dp))
                    Icon(Icons.Rounded.ArrowUpward, null, modifier = Modifier.size(22.dp))
                }
                Spacer(Modifier.height(24.dp))
                Button(
                    onClick = { onRate(stars) },
                    enabled = stars > 0,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                ) { Text("Rate") }
            }
        }
    }
}
