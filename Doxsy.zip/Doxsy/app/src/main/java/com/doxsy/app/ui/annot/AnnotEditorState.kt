package com.doxsy.app.ui.annot

import android.graphics.RectF
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Backspace
import androidx.compose.material.icons.rounded.Brush
import androidx.compose.material.icons.rounded.CropSquare
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.FormatUnderlined
import androidx.compose.material.icons.rounded.Highlight
import androidx.compose.material.icons.rounded.PanTool
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.StickyNote2
import androidx.compose.material.icons.rounded.StrikethroughS
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.vector.ImageVector
import com.doxsy.app.annot.Annot
import com.doxsy.app.annot.AnnotType

enum class AnnotTool(val label: String, val icon: ImageVector, val type: AnnotType?) {
    HAND("Select", Icons.Rounded.PanTool, null),
    HIGHLIGHT("Highlight", Icons.Rounded.Highlight, AnnotType.HIGHLIGHT),
    UNDERLINE("Underline", Icons.Rounded.FormatUnderlined, AnnotType.UNDERLINE),
    STRIKE("Strikethrough", Icons.Rounded.StrikethroughS, AnnotType.STRIKE),
    PEN("Pen", Icons.Rounded.Edit, AnnotType.INK),
    MARKER("Marker", Icons.Rounded.Brush, AnnotType.MARKER),
    ERASER("Eraser", Icons.Rounded.Backspace, null),
    TEXT("Text", Icons.Rounded.TextFields, AnnotType.TEXT),
    RECT("Rectangle", Icons.Rounded.CropSquare, AnnotType.RECT),
    CIRCLE("Circle", Icons.Rounded.RadioButtonUnchecked, AnnotType.CIRCLE),
    ARROW("Arrow", Icons.AutoMirrored.Rounded.ArrowForward, AnnotType.ARROW),
    LINE("Line", Icons.Rounded.Remove, AnnotType.LINE),
    NOTE("Sticky note", Icons.Rounded.StickyNote2, AnnotType.NOTE);

    val isTextMarkup: Boolean get() = this == HIGHLIGHT || this == UNDERLINE || this == STRIKE
    val isStroke: Boolean get() = this == PEN || this == MARKER
    val isShape: Boolean get() = this == RECT || this == CIRCLE || this == ARROW || this == LINE
    val usesThickness: Boolean get() = isStroke || isShape
}

val AnnotPalette: List<Int> = listOf(
    0xFFFFD60A.toInt(), 0xFFF76808.toInt(), 0xFFE5484D.toInt(), 0xFF1FA463.toInt(),
    0xFF2F6BFF.toInt(), 0xFF7C4DFF.toInt(), 0xFF000000.toInt(), 0xFFFFFFFF.toInt(),
)

/** Editing state for one open document: annotations, undo/redo history, tool options and live drafts. */
@Stable
class AnnotEditorState {
    var annots by mutableStateOf<List<Annot>>(emptyList())
        private set
    var canUndo by mutableStateOf(false)
        private set
    var canRedo by mutableStateOf(false)
        private set
    /** Bumped after every committed change; drives autosave. */
    var revision by mutableIntStateOf(0)
        private set

    var tool by mutableStateOf(AnnotTool.HAND)
    var color by mutableIntStateOf(0xFF2F6BFF.toInt())
    /** 0..1 slider values. */
    var thicknessLevel by mutableFloatStateOf(0.35f)
    var textLevel by mutableFloatStateOf(0.4f)
    var selectedId by mutableStateOf<String?>(null)

    /** In-progress drawing and text selection preview. */
    var draft by mutableStateOf<Annot?>(null)
    var selection by mutableStateOf<Pair<Int, List<RectF>>?>(null)

    val strokeFrac: Float get() = 0.0015f + thicknessLevel * 0.012f
    val textSizeFrac: Float get() = 0.018f + textLevel * 0.05f

    private val undoStack = ArrayList<List<Annot>>()
    private val redoStack = ArrayList<List<Annot>>()

    val selected: Annot? get() = selectedId?.let { id -> annots.firstOrNull { it.id == id } }

    private fun flags() {
        canUndo = undoStack.isNotEmpty()
        canRedo = redoStack.isNotEmpty()
    }

    fun load(list: List<Annot>) {
        annots = list
        undoStack.clear()
        redoStack.clear()
        selectedId = null
        flags()
    }

    private fun commit(newList: List<Annot>) {
        undoStack.add(annots)
        if (undoStack.size > 100) undoStack.removeAt(0)
        redoStack.clear()
        annots = newList
        revision++
        flags()
    }

    fun add(a: Annot) {
        commit(annots + a)
        selectedId = null
    }

    fun update(a: Annot) {
        commit(annots.map { if (it.id == a.id) a else it })
    }

    fun remove(id: String) {
        commit(annots.filterNot { it.id == id })
        if (selectedId == id) selectedId = null
    }

    fun clearPage(page: Int) {
        if (annots.none { it.page == page }) return
        commit(annots.filterNot { it.page == page })
        selectedId = null
    }

    /** Multi-step gestures (move, erase): one undo entry for the whole gesture. */
    fun beginGesture() {
        undoStack.add(annots)
        if (undoStack.size > 100) undoStack.removeAt(0)
        redoStack.clear()
        flags()
    }

    fun setSilently(list: List<Annot>) {
        annots = list
    }

    fun finishGesture() {
        revision++
    }

    fun undo() {
        val prev = undoStack.removeLastOrNull() ?: return
        redoStack.add(annots)
        annots = prev
        if (selectedId != null && selected == null) selectedId = null
        revision++
        flags()
    }

    fun redo() {
        val next = redoStack.removeLastOrNull() ?: return
        undoStack.add(annots)
        annots = next
        if (selectedId != null && selected == null) selectedId = null
        revision++
        flags()
    }
}
