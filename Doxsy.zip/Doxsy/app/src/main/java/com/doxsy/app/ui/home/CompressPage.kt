package com.doxsy.app.ui.home

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.doxsy.app.pdf.CompressLevel
import com.doxsy.app.pdf.PdfTools
import com.doxsy.app.pdf.ToolResult
import com.doxsy.app.util.FileUtils
import kotlinx.coroutines.launch

private class LevelChoice(val title: String, val desc: String, val level: CompressLevel)

private val LEVELS = listOf(
    LevelChoice("High compression", "Smallest size, lower quality", CompressLevel.STRONG),
    LevelChoice("Medium compression", "Medium size, good quality", CompressLevel.BALANCED),
    LevelChoice("Low compression", "Larger size, best quality", CompressLevel.LIGHT),
    LevelChoice("Custom", "Pick the picture quality and size yourself", CompressLevel.BALANCED),
)

/**
 * Full-screen "Compress PDF" page (Adobe style): back arrow, title, file card,
 * "Set compression level" with three choices, and a Compress button at the bottom.
 * The original PDF is never changed; a new "_compressed" copy is saved where the user chooses.
 */
@Composable
fun CompressPage(
    name: String,
    uri: Uri,
    onClose: () -> Unit,
    onOpenPdf: (Uri, String) -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var choice by remember { mutableStateOf(1) } // Medium
    var strip by remember { mutableStateOf(false) }
    var customQuality by remember { mutableStateOf(0.6f) }
    var customDim by remember { mutableStateOf(1400f) }
    var busy by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<Triple<ToolResult, Uri, String>?>(null) }
    val size = remember(uri) { PdfTools.querySize(ctx, uri) }
    val outName = name.substringBeforeLast('.') + "_compressed.pdf"

    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { out ->
        if (out != null) {
            busy = true
            val level = LEVELS[choice].level
            scope.launch {
                val r = if (choice == 3) {
                    PdfTools.compress(ctx, uri, level, strip, out, customQuality, customDim.toInt())
                } else {
                    PdfTools.compress(ctx, uri, level, strip, out)
                }
                busy = false
                result = Triple(r, out, outName)
            }
        }
    }

    Dialog(
        onDismissRequest = { if (!busy) onClose() },
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false),
    ) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                IconButton(onClick = { if (!busy) onClose() }, modifier = Modifier.padding(start = 8.dp, top = 8.dp)) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back")
                }
                Column(
                    Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 24.dp),
                ) {
                    Spacer(Modifier.height(8.dp))
                    Text("Compress PDF", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(24.dp))
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            PdfThumb(uri.toString(), name, Modifier.size(width = 40.dp, height = 52.dp))
                            Spacer(Modifier.width(16.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    name.substringBeforeLast('.'),
                                    style = MaterialTheme.typography.titleMedium,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                Text(
                                    if (size > 0) "PDF  •  " + FileUtils.formatSize(size) else "PDF",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(28.dp))
                    Text("Set compression level:", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    LEVELS.forEachIndexed { i, l ->
                        Row(
                            Modifier.fillMaxWidth().clickable(enabled = !busy) { choice = i }.padding(vertical = 10.dp),
                            verticalAlignment = Alignment.Top,
                        ) {
                            RadioButton(selected = choice == i, onClick = { if (!busy) choice = i })
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.padding(top = 2.dp)) {
                                Text(l.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                Text(l.desc, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    if (choice == 3) {
                        Text("Picture quality: ${(customQuality * 100).toInt()}%", style = MaterialTheme.typography.bodyMedium)
                        androidx.compose.material3.Slider(
                            value = customQuality,
                            onValueChange = { customQuality = it },
                            valueRange = 0.3f..0.95f,
                            enabled = !busy,
                        )
                        Text("Biggest picture side: ${customDim.toInt()} px", style = MaterialTheme.typography.bodyMedium)
                        androidx.compose.material3.Slider(
                            value = customDim,
                            onValueChange = { customDim = it },
                            valueRange = 600f..3000f,
                            enabled = !busy,
                        )
                        Text(
                            "Smaller pictures make a smaller file but look softer when you zoom in.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Remove hidden info", style = MaterialTheme.typography.titleSmall)
                            Text(
                                "Title, author and other details stored in the file",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        androidx.compose.material3.Switch(checked = strip, onCheckedChange = { strip = it }, enabled = !busy)
                    }
                    Spacer(Modifier.height(16.dp))
                    Text(
                        "Only photos inside the PDF are made smaller. A new copy is saved; your original stays as it is.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (busy) {
                        CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp)
                        Spacer(Modifier.width(12.dp))
                        Text("Compressing…", style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.width(16.dp))
                    }
                    Button(onClick = { save.launch(outName) }, enabled = !busy) { Text("Compress") }
                }
            }
        }
    }

    result?.let { (r, out, file) ->
        val ok = r is ToolResult.Done
        AlertDialog(
            onDismissRequest = { result = null },
            title = { Text(if (ok) "Compressed" else "Couldn't compress") },
            text = { Text(if (r is ToolResult.Done) r.message else (r as ToolResult.Failed).message) },
            confirmButton = {
                if (ok) TextButton(onClick = { result = null; onClose(); onOpenPdf(out, file) }) { Text("Open") }
                else TextButton(onClick = { result = null }) { Text("OK") }
            },
            dismissButton = { if (ok) TextButton(onClick = { result = null; onClose() }) { Text("Close") } },
        )
    }
}
