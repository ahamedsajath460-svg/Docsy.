package com.doxsy.app.ui.files

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.doxsy.app.fileman.DeviceFiles

class DeviceAccess(val granted: Boolean, val request: () -> Unit)

/** Tracks storage access and knows how to ask for it (re-checks when the app is resumed). */
@Composable
fun rememberDeviceAccess(): DeviceAccess {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(DeviceFiles.hasAccess(ctx)) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        granted = DeviceFiles.hasAccess(ctx)
    }
    val settings = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        granted = DeviceFiles.hasAccess(ctx)
    }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { granted = DeviceFiles.hasAccess(ctx) }
    return DeviceAccess(granted) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            runCatching { settings.launch(DeviceFiles.settingsIntent(ctx)) }
        } else {
            perm.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }
}

@Composable
fun AccessPrompt(message: String, onAllow: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 32.dp, vertical = 48.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            message,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(16.dp))
        Button(onClick = onAllow) { Text("Allow access") }
    }
}
