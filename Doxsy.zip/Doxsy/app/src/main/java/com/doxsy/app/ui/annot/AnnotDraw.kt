package com.doxsy.app.ui.annot

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import com.doxsy.app.annot.Annot
import com.doxsy.app.annot.AnnotType
import com.doxsy.app.annot.NOTE_SIZE_FRAC
import com.doxsy.app.annot.bounds
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Draws one annotation on a page-sized canvas. Mirrors what PdfAnnotExporter writes into the PDF. */
fun DrawScope.drawAnnot(a: Annot, selectionColor: Color?, paint: android.graphics.Paint) {
    val w = size.width
    val h = size.height
    if (w <= 0f || h <= 0f) return
    val col = Color(a.color)
    val sw = max(a.strokeFrac * w, 1f)
    when (a.type) {
        AnnotType.HIGHLIGHT -> a.rects.forEach {
            drawRect(col.copy(alpha = 0.4f), Offset(it.left * w, it.top * h), Size((it.right - it.left) * w, (it.bottom - it.top) * h))
        }
        AnnotType.UNDERLINE -> a.rects.forEach {
            val lw = max(1f, (it.bottom - it.top) * h * 0.07f)
            drawLine(col, Offset(it.left * w, it.bottom * h), Offset(it.right * w, it.bottom * h), lw)
        }
        AnnotType.STRIKE -> a.rects.forEach {
            val lw = max(1f, (it.bottom - it.top) * h * 0.07f)
            val y = (it.top + it.bottom) / 2f * h
            drawLine(col, Offset(it.left * w, y), Offset(it.right * w, y), lw)
        }
        AnnotType.INK, AnnotType.MARKER -> {
            val marker = a.type == AnnotType.MARKER
            val c = if (marker) col.copy(alpha = 0.4f) else col
            if (a.points.size == 1) {
                drawCircle(c, radius = (if (marker) sw * 3f else sw) / 2f, center = Offset(a.points[0].x * w, a.points[0].y * h))
            } else if (a.points.size > 1) {
                val path = Path()
                a.points.forEachIndexed { i, p ->
                    if (i == 0) path.moveTo(p.x * w, p.y * h) else path.lineTo(p.x * w, p.y * h)
                }
                drawPath(
                    path,
                    c,
                    style = Stroke(
                        width = if (marker) sw * 3f else sw,
                        cap = if (marker) StrokeCap.Butt else StrokeCap.Round,
                        join = StrokeJoin.Round,
                    ),
                )
            }
        }
        AnnotType.RECT, AnnotType.CIRCLE -> if (a.points.size >= 2) {
            val l = min(a.points[0].x, a.points[1].x) * w
            val r = max(a.points[0].x, a.points[1].x) * w
            val t = min(a.points[0].y, a.points[1].y) * h
            val b = max(a.points[0].y, a.points[1].y) * h
            if (a.type == AnnotType.RECT) drawRect(col, Offset(l, t), Size(r - l, b - t), style = Stroke(sw))
            else drawOval(col, Offset(l, t), Size(r - l, b - t), style = Stroke(sw))
        }
        AnnotType.LINE, AnnotType.ARROW -> if (a.points.size >= 2) {
            val x1 = a.points[0].x * w
            val y1 = a.points[0].y * h
            val x2 = a.points[1].x * w
            val y2 = a.points[1].y * h
            drawLine(col, Offset(x1, y1), Offset(x2, y2), sw, cap = StrokeCap.Round)
            if (a.type == AnnotType.ARROW) {
                val ang = atan2(y2 - y1, x2 - x1)
                val head = max(sw * 5f, w * 0.02f)
                for (s in intArrayOf(-1, 1)) {
                    val th = ang + Math.PI.toFloat() + s * 0.5f
                    drawLine(col, Offset(x2, y2), Offset(x2 + head * cos(th), y2 + head * sin(th)), sw, cap = StrokeCap.Round)
                }
            }
        }
        AnnotType.TEXT -> a.points.firstOrNull()?.let { p ->
            val fs = max(a.sizeFrac * w, 2f)
            paint.color = a.color
            paint.textSize = fs
            a.text.split('\n').forEachIndexed { i, line ->
                drawContext.canvas.nativeCanvas.drawText(line, p.x * w, p.y * h + i * fs * 1.2f + fs * 0.9f, paint)
            }
        }
        AnnotType.NOTE -> a.points.firstOrNull()?.let { p ->
            val s = NOTE_SIZE_FRAC * w
            val tl = Offset(p.x * w - s / 2f, p.y * h - s / 2f)
            drawRoundRect(Color(0xFFFFD83A), tl, Size(s, s), CornerRadius(s * 0.15f))
            drawRoundRect(Color(0xFF735900), tl, Size(s, s), CornerRadius(s * 0.15f), style = Stroke(max(1f, s * 0.04f)))
            for (k in 0..2) {
                val y = tl.y + s * (0.3f + k * 0.2f)
                drawLine(Color(0xFF735900), Offset(tl.x + s * 0.2f, y), Offset(tl.x + s * 0.8f, y), max(1f, s * 0.04f))
            }
        }
    }
    if (selectionColor != null) {
        val bb = a.bounds(h / w)
        val pad = 6f
        drawRect(
            selectionColor,
            Offset(bb.left * w - pad, bb.top * h - pad),
            Size((bb.right - bb.left) * w + 2 * pad, (bb.bottom - bb.top) * h + 2 * pad),
            style = Stroke(2.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f))),
        )
    }
}
