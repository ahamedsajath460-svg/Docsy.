package com.doxsy.app.docview.legacy;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

/** Extracts slide text from PowerPoint 97-2003 (.ppt) files. Layout and pictures are not reproduced. */
public final class PptParser {
    public static final class Text {
        /** PowerPoint text type: 0 title, 1 body, 4 other, 5 centre body, 6 centre title, ... */
        public int type;
        public String text;
    }

    public static final class SlideData {
        public final ArrayList<Text> texts = new ArrayList<>();
    }

    public static final class Result {
        public final ArrayList<SlideData> slides = new ArrayList<>();
        public float aspect = 4f / 3f;
        public float widthPt = 720f;
    }

    private static final Charset CP1252 = Charset.forName("windows-1252");
    private static final int MAX_SLIDES = 400;

    private final byte[] d;
    private final int fileEnd;

    private PptParser(byte[] d) {
        this.d = d;
        this.fileEnd = d.length;
    }

    private int u16(int o) {
        return (d[o] & 0xFF) | ((d[o + 1] & 0xFF) << 8);
    }

    private int i32(int o) {
        return (d[o] & 0xFF) | ((d[o + 1] & 0xFF) << 8) | ((d[o + 2] & 0xFF) << 16) | ((d[o + 3] & 0xFF) << 24);
    }

    public static Result parse(Ole2 ole) throws LegacyException {
        byte[] ppt = ole.stream("PowerPoint Document");
        if (ppt == null || ppt.length < 8) throw new LegacyException("This PowerPoint file has no readable content.");
        byte[] cu = ole.stream("Current User");
        if (cu != null && cu.length >= 12) {
            int token = (cu[4] & 0xFF) | ((cu[5] & 0xFF) << 8) | ((cu[6] & 0xFF) << 16) | ((cu[7] & 0xFF) << 24);
            if (token == 0xF3D1C4DF) {
                throw new LegacyException(
                        "This PowerPoint file is password-protected, so Doxsy cannot read it. Remove the password, then open it again.",
                        true, null);
            }
        }
        try {
            return new PptParser(ppt).run(cu);
        } catch (LegacyException e) {
            throw e;
        } catch (RuntimeException e) {
            throw new LegacyException("This PowerPoint presentation could not be read. It may be corrupted.", false, e);
        }
    }

    // record header: ver/instance(2) type(2) len(4)
    private int type(int o) {
        return u16(o + 2);
    }

    private int len(int o) {
        return i32(o + 4);
    }

    private int instance(int o) {
        return (u16(o) >> 4) & 0x0FFF;
    }

    private boolean isContainer(int o) {
        return (u16(o) & 0x0F) == 0x0F;
    }

    private boolean valid(int o) {
        if (o < 0 || o + 8 > fileEnd) return false;
        int l = len(o);
        return l >= 0 && (long) o + 8 + l <= fileEnd;
    }

    private Result run(byte[] currentUser) throws LegacyException {
        Result res = new Result();
        HashMap<Integer, Integer> persist = new HashMap<>();
        int docPersist = -1;

        // ---- follow the chain of edits: UserEditAtom -> PersistDirectoryAtom
        try {
            if (currentUser != null && currentUser.length >= 12) {
                int editOff = (currentUser[8] & 0xFF) | ((currentUser[9] & 0xFF) << 8)
                        | ((currentUser[10] & 0xFF) << 16) | ((currentUser[11] & 0xFF) << 24);
                HashSet<Integer> seen = new HashSet<>();
                while (editOff > 0 && valid(editOff) && type(editOff) == 4085 && seen.add(editOff)) {
                    int b = editOff + 8;
                    int offLastEdit = i32(b + 8);
                    int offPersistDir = i32(b + 12);
                    int docRef = i32(b + 16);
                    if (docPersist < 0) docPersist = docRef;
                    if (valid(offPersistDir) && type(offPersistDir) == 6002) {
                        int p = offPersistDir + 8;
                        int end = p + len(offPersistDir);
                        while (p + 4 <= end) {
                            int info = i32(p);
                            p += 4;
                            int id = info & 0xFFFFF;
                            int count = (info >>> 20) & 0xFFF;
                            for (int i = 0; i < count && p + 4 <= end; i++, p += 4) {
                                persist.putIfAbsent(id + i, i32(p));
                            }
                        }
                    }
                    editOff = offLastEdit;
                }
            }
        } catch (RuntimeException e) {
            persist.clear();
        }

        ArrayList<Integer> slideOffsets = new ArrayList<>();
        ArrayList<ArrayList<Text>> slwtTexts = new ArrayList<>();
        int docOff = docPersist >= 0 && persist.containsKey(docPersist) ? persist.get(docPersist) : -1;
        if (docOff >= 0 && valid(docOff) && type(docOff) == 1000) {
            readDocument(docOff, persist, res, slideOffsets, slwtTexts);
        }

        if (slideOffsets.isEmpty()) {
            // Fallback: no usable persist directory - take every slide container in stream order.
            int p = 0;
            while (valid(p)) {
                if (type(p) == 1006 && isContainer(p)) slideOffsets.add(p);
                p += 8 + len(p);
            }
            slwtTexts.clear();
        }
        if (slideOffsets.isEmpty()) throw new LegacyException("This presentation has no readable slides.");

        for (int i = 0; i < slideOffsets.size() && i < MAX_SLIDES; i++) {
            SlideData sd = new SlideData();
            if (i < slwtTexts.size()) sd.texts.addAll(slwtTexts.get(i));
            int off = slideOffsets.get(i);
            if (off >= 0 && valid(off) && type(off) == 1006) collectDrawingText(off, sd);
            res.slides.add(sd);
        }
        return res;
    }

    private void readDocument(int docOff, HashMap<Integer, Integer> persist, Result res,
                              ArrayList<Integer> slideOffsets, ArrayList<ArrayList<Text>> slwtTexts) {
        int p = docOff + 8;
        int end = docOff + 8 + len(docOff);
        while (p + 8 <= end && valid(p)) {
            int t = type(p);
            if (t == 1001 && len(p) >= 8) { // DocumentAtom: slide size in master units (1/576 in)
                int sx = i32(p + 8);
                int sy = i32(p + 12);
                if (sx > 0 && sy > 0) {
                    res.aspect = (float) sx / (float) sy;
                    res.widthPt = sx / 8f;
                }
            } else if (t == 4080 && instance(p) == 0) { // SlideListWithText for slides
                int q = p + 8;
                int qEnd = p + 8 + len(p);
                ArrayList<Text> cur = null;
                int curType = 4;
                while (q + 8 <= qEnd && valid(q)) {
                    int qt = type(q);
                    if (qt == 1011) { // SlidePersistAtom starts the next slide
                        int ref = i32(q + 8);
                        Integer off = persist.get(ref);
                        slideOffsets.add(off == null ? -1 : off);
                        cur = new ArrayList<>();
                        slwtTexts.add(cur);
                    } else if (qt == 3999 && len(q) >= 4) {
                        curType = i32(q + 8);
                    } else if ((qt == 4000 || qt == 4008) && cur != null) {
                        Text tx = new Text();
                        tx.type = curType;
                        tx.text = decodeText(q, qt == 4000);
                        if (!tx.text.trim().isEmpty()) cur.add(tx);
                        curType = 4;
                    }
                    q += 8 + len(q);
                }
            }
            p += 8 + len(p);
        }
    }

    /** Text boxes drawn directly on the slide (not referenced from the slide list). */
    private void collectDrawingText(int off, SlideData sd) {
        int end = off + 8 + len(off);
        walk(off + 8, end, sd, false, 0);
    }

    private void walk(int p, int end, SlideData sd, boolean inTextbox, int depth) {
        if (depth > 24) return;
        int curType = 4;
        boolean hasOutlineRef = false;
        ArrayList<Text> pending = new ArrayList<>();
        while (p + 8 <= end && valid(p)) {
            int t = type(p);
            int l = len(p);
            if (isContainer(p)) {
                walk(p + 8, Math.min(end, p + 8 + l), sd, t == 0xF00D, depth + 1);
            } else if (inTextbox) {
                if (t == 3999 && l >= 4) {
                    curType = i32(p + 8);
                } else if (t == 3998) {
                    hasOutlineRef = true;
                } else if (t == 4000 || t == 4008) {
                    Text tx = new Text();
                    tx.type = curType;
                    tx.text = decodeText(p, t == 4000);
                    if (!tx.text.trim().isEmpty()) pending.add(tx);
                }
            }
            p += 8 + l;
        }
        if (inTextbox && !hasOutlineRef) sd.texts.addAll(pending);
    }

    private String decodeText(int rec, boolean unicode) {
        int l = len(rec);
        int o = rec + 8;
        String s = unicode ? new String(d, o, l & ~1, StandardCharsets.UTF_16LE) : new String(d, o, l, CP1252);
        return s.replace("\r\n", "\n").replace('\r', '\n').replace('\u000B', '\n');
    }
}
