package com.doxsy.app.docview.legacy;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;

/** Reads Excel 5.0 / 95 / 97-2003 (BIFF5 and BIFF8) workbooks: cell values, sheet names, column widths. */
public final class XlsParser {
    public static final int NUM = 1, STR = 2, BOOL = 3, ERR = 4;

    public static final class Cell {
        public int kind;
        public double num;
        public String str;
        public int xf;
    }

    public static final class SheetData {
        public String name = "";
        public boolean hidden;
        public final ArrayList<Cell[]> rows = new ArrayList<>();
        public final ArrayList<Float> widths = new ArrayList<>();
        public boolean truncated;
    }

    public static final class Book {
        public final ArrayList<SheetData> sheets = new ArrayList<>();
        /** numFmtId for each XF record, in order. */
        public final ArrayList<Integer> xfFormat = new ArrayList<>();
        public final HashMap<Integer, String> formatCodes = new HashMap<>();
        public boolean date1904;
    }

    private static final int MAX_COLS = 1000;
    private static final Charset CP1252 = Charset.forName("windows-1252");

    private final byte[] d;
    private final int maxRows;
    private boolean biff8 = true;
    private final ArrayList<String> sst = new ArrayList<>();

    private XlsParser(byte[] d, int maxRows) {
        this.d = d;
        this.maxRows = maxRows;
    }

    public static Book parse(Ole2 ole, int maxRows) throws LegacyException {
        byte[] wb = ole.stream("Workbook");
        if (wb == null) wb = ole.stream("Book");
        if (wb == null) throw new LegacyException("This Excel file has no readable workbook data.");
        try {
            return new XlsParser(wb, maxRows).run();
        } catch (LegacyException e) {
            throw e;
        } catch (RuntimeException e) {
            throw new LegacyException("This Excel workbook could not be read. It may be corrupted.", false, e);
        }
    }

    // ------------------------------------------------------------------ record helpers

    private int u8(int o) {
        return d[o] & 0xFF;
    }

    private int u16(int o) {
        return (d[o] & 0xFF) | ((d[o + 1] & 0xFF) << 8);
    }

    private int i32(int o) {
        return (d[o] & 0xFF) | ((d[o + 1] & 0xFF) << 8) | ((d[o + 2] & 0xFF) << 16) | ((d[o + 3] & 0xFF) << 24);
    }

    private double f64(int o) {
        long lo = i32(o) & 0xFFFFFFFFL;
        long hi = i32(o + 4) & 0xFFFFFFFFL;
        return Double.longBitsToDouble((hi << 32) | lo);
    }

    private static final class Sheet {
        String name;
        int pos;
        int type;
        int state;
    }

    private Book run() throws LegacyException {
        Book book = new Book();
        ArrayList<Sheet> sheetRefs = new ArrayList<>();
        int pos = 0;
        boolean sawBof = false;
        // ---- globals substream
        while (pos + 4 <= d.length) {
            int type = u16(pos);
            int len = u16(pos + 2);
            int body = pos + 4;
            if (body + len > d.length) break;
            if (!sawBof) {
                if (type != 0x0809 && type != 0x0009 && type != 0x0209 && type != 0x0409) {
                    throw new LegacyException("This Excel file has no readable workbook data.");
                }
                sawBof = true;
                if (type == 0x0809) biff8 = len >= 2 && u16(body) >= 0x0600;
                else biff8 = false;
                pos = body + len;
                continue;
            }
            if (type == 0x000A) break; // EOF
            switch (type) {
                case 0x002F: // FILEPASS
                    throw new LegacyException(
                            "This Excel file is password-protected, so Doxsy cannot read it. Remove the password, then open it again.",
                            true, null);
                case 0x0022:
                    book.date1904 = len >= 2 && u16(body) == 1;
                    break;
                case 0x0085: { // BOUNDSHEET
                    Sheet s = new Sheet();
                    s.pos = i32(body);
                    s.state = u8(body + 4) & 3;
                    s.type = u8(body + 5);
                    int cch = u8(body + 6);
                    if (biff8) {
                        int flags = u8(body + 7);
                        s.name = readStr(body + 8, cch, (flags & 1) != 0);
                    } else {
                        s.name = new String(d, body + 7, Math.min(cch, Math.max(0, d.length - body - 7)), CP1252);
                    }
                    sheetRefs.add(s);
                    break;
                }
                case 0x00FC: { // SST (+ CONTINUE)
                    ArrayList<int[]> chunks = new ArrayList<>();
                    chunks.add(new int[]{body, body + len});
                    int p2 = body + len;
                    while (p2 + 4 <= d.length && u16(p2) == 0x003C) {
                        int l2 = u16(p2 + 2);
                        if (p2 + 4 + l2 > d.length) break;
                        chunks.add(new int[]{p2 + 4, p2 + 4 + l2});
                        p2 += 4 + l2;
                    }
                    readSst(chunks);
                    pos = p2;
                    continue;
                }
                case 0x041E: { // FORMAT
                    int id = u16(body);
                    String code;
                    if (biff8) {
                        int cch = u16(body + 2);
                        int flags = u8(body + 4);
                        code = readStr(body + 5, cch, (flags & 1) != 0);
                    } else {
                        int cch = u8(body + 2);
                        code = new String(d, body + 3, Math.min(cch, Math.max(0, d.length - body - 3)), CP1252);
                    }
                    book.formatCodes.put(id, code);
                    break;
                }
                case 0x00E0: // XF
                    book.xfFormat.add(len >= 4 ? u16(body + 2) : 0);
                    break;
                default:
                    break;
            }
            pos = body + len;
        }
        if (sheetRefs.isEmpty()) throw new LegacyException("This workbook contains no readable sheets.");
        for (Sheet ref : sheetRefs) {
            if (ref.type != 0) continue; // charts, macro sheets, VB modules
            if (ref.state == 2) continue; // very hidden
            SheetData sd = new SheetData();
            sd.name = ref.name;
            sd.hidden = ref.state == 1;
            if (ref.pos >= 0 && ref.pos + 4 <= d.length) {
                try {
                    readSheet(ref.pos, sd);
                } catch (RuntimeException e) {
                    // keep whatever was read before the damaged record
                }
            }
            book.sheets.add(sd);
        }
        return book;
    }

    // ------------------------------------------------------------------ strings

    private String readStr(int off, int cch, boolean high) {
        int bytes = high ? cch * 2 : cch;
        if (off < 0 || off + bytes > d.length) bytes = Math.max(0, d.length - off);
        if (high) return new String(d, off, bytes & ~1, java.nio.charset.StandardCharsets.UTF_16LE);
        return decodeLatin(d, off, bytes);
    }

    /** Compressed ("high byte = 0") strings hold only the low byte, i.e. ISO-8859-1 code points. */
    private static String decodeLatin(byte[] b, int off, int n) {
        char[] c = new char[n];
        for (int i = 0; i < n; i++) c[i] = (char) (b[off + i] & 0xFF);
        return new String(c);
    }

    private final class Chunked {
        final ArrayList<int[]> chunks;
        int ci = 0;
        int pos;
        int end;

        Chunked(ArrayList<int[]> chunks) {
            this.chunks = chunks;
            pos = chunks.get(0)[0];
            end = chunks.get(0)[1];
        }

        boolean more() {
            while (pos >= end) {
                if (ci + 1 >= chunks.size()) return false;
                ci++;
                pos = chunks.get(ci)[0];
                end = chunks.get(ci)[1];
            }
            return true;
        }

        int u8() {
            if (!more()) throw new IllegalStateException("eof");
            return d[pos++] & 0xFF;
        }

        int u16() {
            int a = u8();
            return a | (u8() << 8);
        }

        int i32() {
            int a = u16();
            return a | (u16() << 16);
        }

        void skip(int n) {
            while (n > 0) {
                if (!more()) return;
                int k = Math.min(n, end - pos);
                pos += k;
                n -= k;
            }
        }
    }

    private void readSst(ArrayList<int[]> chunks) {
        Chunked r = new Chunked(chunks);
        try {
            r.i32(); // total
            int unique = r.i32();
            for (int i = 0; i < unique; i++) {
                if (!r.more()) break;
                int cch = r.u16();
                int flags = r.u8();
                boolean high = (flags & 1) != 0;
                int runs = 0;
                int ext = 0;
                if ((flags & 8) != 0) runs = r.u16();
                if ((flags & 4) != 0) ext = r.i32();
                StringBuilder sb = new StringBuilder(cch);
                int left = cch;
                while (left > 0) {
                    if (r.pos >= r.end) {
                        // chunk exhausted inside the characters: the next CONTINUE starts with a flag byte
                        if (r.ci + 1 >= r.chunks.size()) break;
                        r.ci++;
                        r.pos = r.chunks.get(r.ci)[0];
                        r.end = r.chunks.get(r.ci)[1];
                        if (r.pos >= r.end) continue;
                        high = (d[r.pos++] & 1) != 0;
                        if (r.pos >= r.end) continue;
                    }
                    int avail = r.end - r.pos;
                    int take = Math.min(left, high ? avail / 2 : avail);
                    if (take <= 0) {
                        // odd byte left at the end of a chunk: skip it
                        r.pos = r.end;
                        continue;
                    }
                    if (high) {
                        sb.append(new String(d, r.pos, take * 2, java.nio.charset.StandardCharsets.UTF_16LE));
                        r.pos += take * 2;
                    } else {
                        sb.append(decodeLatin(d, r.pos, take));
                        r.pos += take;
                    }
                    left -= take;
                }
                r.skip(runs * 4);
                r.skip(ext);
                sst.add(sb.toString());
            }
        } catch (IllegalStateException e) {
            // truncated table: keep the strings read so far
        }
    }

    // ------------------------------------------------------------------ sheets

    private static double rk(int v) {
        double r;
        if ((v & 2) != 0) {
            r = v >> 2;
        } else {
            r = Double.longBitsToDouble(((long) (v & 0xFFFFFFFC)) << 32);
        }
        return (v & 1) != 0 ? r / 100.0 : r;
    }

    private static String errText(int code) {
        switch (code) {
            case 0x00: return "#NULL!";
            case 0x07: return "#DIV/0!";
            case 0x0F: return "#VALUE!";
            case 0x17: return "#REF!";
            case 0x1D: return "#NAME?";
            case 0x24: return "#NUM!";
            case 0x2A: return "#N/A";
            default: return "#ERR";
        }
    }

    private void put(SheetData sd, int row, int col, Cell c) {
        if (col < 0 || col >= MAX_COLS) return;
        while (sd.rows.size() <= row) sd.rows.add(null);
        Cell[] r = sd.rows.get(row);
        if (r == null || r.length <= col) {
            Cell[] n = new Cell[Math.max(col + 1, r == null ? 8 : r.length * 2)];
            if (r != null) System.arraycopy(r, 0, n, 0, r.length);
            sd.rows.set(row, n);
            r = n;
        }
        r[col] = c;
    }

    private Cell num(double v, int xf) {
        Cell c = new Cell();
        c.kind = NUM;
        c.num = v;
        c.xf = xf;
        return c;
    }

    private Cell str(String s, int xf) {
        Cell c = new Cell();
        c.kind = STR;
        c.str = s;
        c.xf = xf;
        return c;
    }

    private void readSheet(int start, SheetData sd) {
        int pos = start;
        boolean first = true;
        int pendingRow = -1;
        int pendingCol = -1;
        int pendingXf = 0;
        while (pos + 4 <= d.length) {
            int type = u16(pos);
            int len = u16(pos + 2);
            int b = pos + 4;
            if (b + len > d.length) break;
            pos = b + len;
            if (first) {
                first = false;
                if (type != 0x0809 && type != 0x0009 && type != 0x0209 && type != 0x0409) return;
                continue;
            }
            if (type == 0x000A) break;
            if (type == 0x0809) { // nested substream (e.g. embedded chart) - skip to its EOF
                int depth = 1;
                while (pos + 4 <= d.length && depth > 0) {
                    int t2 = u16(pos);
                    int l2 = u16(pos + 2);
                    if (t2 == 0x0809) depth++;
                    else if (t2 == 0x000A) depth--;
                    pos += 4 + l2;
                }
                continue;
            }
            switch (type) {
                case 0x007D: { // COLINFO
                    if (len < 6) break;
                    int c1 = u16(b), c2 = Math.min(u16(b + 2), 255);
                    float w = u16(b + 4) / 256f;
                    for (int c = c1; c <= c2; c++) {
                        while (sd.widths.size() <= c) sd.widths.add(8.43f);
                        sd.widths.set(c, w);
                    }
                    break;
                }
                case 0x00FD: { // LABELSST
                    int row = u16(b), col = u16(b + 2), xf = u16(b + 4);
                    int idx = i32(b + 6);
                    if (row >= maxRows) { sd.truncated = true; break; }
                    if (idx >= 0 && idx < sst.size()) put(sd, row, col, str(sst.get(idx), xf));
                    break;
                }
                case 0x0203: { // NUMBER
                    int row = u16(b), col = u16(b + 2), xf = u16(b + 4);
                    if (row >= maxRows) { sd.truncated = true; break; }
                    put(sd, row, col, num(f64(b + 6), xf));
                    break;
                }
                case 0x027E: { // RK
                    int row = u16(b), col = u16(b + 2), xf = u16(b + 4);
                    if (row >= maxRows) { sd.truncated = true; break; }
                    put(sd, row, col, num(rk(i32(b + 6)), xf));
                    break;
                }
                case 0x00BD: { // MULRK
                    int row = u16(b), first2 = u16(b + 2);
                    if (row >= maxRows) { sd.truncated = true; break; }
                    int n = (len - 6) / 6;
                    for (int i = 0; i < n; i++) {
                        int o = b + 4 + i * 6;
                        put(sd, row, first2 + i, num(rk(i32(o + 2)), u16(o)));
                    }
                    break;
                }
                case 0x0204: // LABEL
                case 0x00D6: { // RSTRING
                    int row = u16(b), col = u16(b + 2), xf = u16(b + 4);
                    if (row >= maxRows) { sd.truncated = true; break; }
                    int cch = u16(b + 6);
                    String s;
                    if (biff8) {
                        int flags = u8(b + 8);
                        s = readStr(b + 9, Math.min(cch, len), (flags & 1) != 0);
                    } else {
                        s = new String(d, b + 8, Math.min(cch, Math.max(0, Math.min(len - 8, d.length - b - 8))), CP1252);
                    }
                    put(sd, row, col, str(s, xf));
                    break;
                }
                case 0x0205: { // BOOLERR
                    int row = u16(b), col = u16(b + 2), xf = u16(b + 4);
                    if (row >= maxRows) { sd.truncated = true; break; }
                    Cell c = new Cell();
                    c.xf = xf;
                    if (u8(b + 7) == 0) {
                        c.kind = BOOL;
                        c.num = u8(b + 6);
                    } else {
                        c.kind = ERR;
                        c.str = errText(u8(b + 6));
                    }
                    put(sd, row, col, c);
                    break;
                }
                case 0x0006: { // FORMULA (cached result)
                    int row = u16(b), col = u16(b + 2), xf = u16(b + 4);
                    pendingRow = -1;
                    if (row >= maxRows) { sd.truncated = true; break; }
                    if (u8(b + 12) == 0xFF && u8(b + 13) == 0xFF) {
                        int t = u8(b + 6);
                        if (t == 0) { // string result follows in a STRING record
                            pendingRow = row;
                            pendingCol = col;
                            pendingXf = xf;
                        } else if (t == 1) {
                            Cell c = new Cell();
                            c.kind = BOOL;
                            c.num = u8(b + 8);
                            c.xf = xf;
                            put(sd, row, col, c);
                        } else if (t == 2) {
                            Cell c = new Cell();
                            c.kind = ERR;
                            c.str = errText(u8(b + 8));
                            c.xf = xf;
                            put(sd, row, col, c);
                        }
                    } else {
                        put(sd, row, col, num(f64(b + 6), xf));
                    }
                    break;
                }
                case 0x0207: { // STRING (result of the preceding formula)
                    if (pendingRow >= 0) {
                        String s;
                        if (biff8) {
                            int cch = u16(b);
                            int flags = u8(b + 2);
                            s = readStr(b + 3, Math.min(cch, len), (flags & 1) != 0);
                        } else {
                            int cch = u16(b);
                            s = new String(d, b + 2, Math.min(cch, Math.max(0, Math.min(len - 2, d.length - b - 2))), CP1252);
                        }
                        put(sd, pendingRow, pendingCol, str(s, pendingXf));
                        pendingRow = -1;
                    }
                    break;
                }
                default:
                    break;
            }
        }
    }
}
