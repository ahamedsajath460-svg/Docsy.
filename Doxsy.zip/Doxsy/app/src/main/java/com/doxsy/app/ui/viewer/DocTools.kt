package com.doxsy.app.ui.viewer

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.doxsy.app.pdf.PdfTools
import com.doxsy.app.util.FileUtils
import kotlinx.coroutines.launch

/** Fill form: lists the real form fields (AcroForm) of the PDF so you can type into them. */
@Composable
internal fun FormFillDialog(name: String, uri: Uri, onClose: () -> Unit, onOpenPdf: (Uri) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val base = name.substringBeforeLast('.')
    var loading by remember { mutableStateOf(true) }
    var fields by remember { mutableStateOf<List<PdfTools.FormField>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    val values = remember { mutableStateMapOf<String, String>() }
    var flatten by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var outcome by remember { mutableStateOf<Outcome?>(null) }

    LaunchedEffect(uri) {
        val res = PdfTools.readFormFields(ctx, uri)
        fields = res.first
        error = res.second
        res.first.forEach { values[it.name] = it.value }
        loading = false
    }

    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { out ->
        if (out != null) {
            busy = true
            val snapshot = values.toMap()
            scope.launch {
                val r = PdfTools.fillForm(ctx, uri, snapshot, flatten, out)
                busy = false
                outcome = Outcome(r, out)
            }
        }
    }

    Dialog(
        onDismissRequest = { if (!busy) onClose() },
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false),
    ) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { if (!busy) onClose() }) { Icon(Icons.Rounded.Close, "Close") }
                    Column(Modifier.weight(1f)) {
                        Text("Fill form", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                        Text(
                            if (loading) "Reading the form…" else "${fields.size} field(s)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    if (busy) {
                        CircularProgressIndicator(Modifier.padding(horizontal = 12.dp).size(22.dp), strokeWidth = 2.dp)
                    } else {
                        TextButton(onClick = { save.launch("${base}_filled.pdf") }, enabled = fields.isNotEmpty()) { Text("Save") }
                    }
                }
                when {
                    loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                    error != null -> Message(error ?: "")
                    fields.isEmpty() -> Message(
                        "This PDF has no fillable form fields.\n\nTo type on any PDF, use Edit PDF > Add text, or Fill and sign.",
                    )
                    else -> LazyColumn(
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        items(fields, key = { it.name }) { f ->
                            when (f.kind) {
                                1 -> Row(
                                    Modifier.fillMaxWidth().clickable(enabled = !f.readOnly) {
                                        values[f.name] = if (values[f.name] == "true") "false" else "true"
                                    },
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Checkbox(checked = values[f.name] == "true", onCheckedChange = null, enabled = !f.readOnly)
                                    Text("  ${f.name}")
                                }
                                2, 3 -> Column {
                                    Text(f.name, style = MaterialTheme.typography.labelLarge)
                                    f.options.forEach { opt ->
                                        Row(
                                            Modifier.fillMaxWidth().clickable(enabled = !f.readOnly) { values[f.name] = opt },
                                            verticalAlignment = Alignment.CenterVertically,
                                        ) {
                                            RadioButton(selected = values[f.name] == opt, onClick = null, enabled = !f.readOnly)
                                            Text("  $opt")
                                        }
                                    }
                                }
                                else -> OutlinedTextField(
                                    value = values[f.name] ?: "",
                                    onValueChange = { values[f.name] = it },
                                    modifier = Modifier.fillMaxWidth(),
                                    enabled = !f.readOnly,
                                    label = { Text(f.name) },
                                )
                            }
                        }
                        item {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("Make the answers permanent", style = MaterialTheme.typography.bodyMedium)
                                    Text(
                                        "Fields can no longer be changed after saving.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                Switch(checked = flatten, onCheckedChange = { flatten = it })
                            }
                        }
                    }
                }
            }
            outcome?.let { o -> ResultDialog(o, onOpen = onOpenPdf, onClose = { outcome = null }) }
        }
    }
}

@Composable
private fun Message(text: String) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Text(text, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Document properties: see and change title / author / subject / keywords, or strip all hidden information. */
@Composable
internal fun PropertiesDialog(name: String, uri: Uri, onClose: () -> Unit, onOpenPdf: (Uri) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val base = name.substringBeforeLast('.')
    var info by remember { mutableStateOf<PdfTools.DocInfo?>(null) }
    var loading by remember { mutableStateOf(true) }
    var title by remember { mutableStateOf("") }
    var author by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf("") }
    var keywords by remember { mutableStateOf("") }
    var strip by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var outcome by remember { mutableStateOf<Outcome?>(null) }

    LaunchedEffect(uri) {
        val i = PdfTools.readInfo(ctx, uri)
        info = i
        if (i != null) {
            title = i.title
            author = i.author
            subject = i.subject
            keywords = i.keywords
        }
        loading = false
    }

    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { out ->
        if (out != null) {
            busy = true
            scope.launch {
                val r = PdfTools.writeInfo(ctx, uri, title, author, subject, keywords, strip, out)
                busy = false
                outcome = Outcome(r, out)
            }
        }
    }

    Dialog(
        onDismissRequest = { if (!busy) onClose() },
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false),
    ) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { if (!busy) onClose() }) { Icon(Icons.Rounded.Close, "Close") }
                    Text(
                        "Properties",
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.SemiBold,
                    )
                    if (busy) {
                        CircularProgressIndicator(Modifier.padding(horizontal = 12.dp).size(22.dp), strokeWidth = 2.dp)
                    } else {
                        TextButton(onClick = { save.launch("${base}_info.pdf") }, enabled = info != null) { Text("Save") }
                    }
                }
                val i = info
                when {
                    loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                    i == null -> Message("Could not read this PDF's properties. If it has a password, remove the password first.")
                    else -> Column(
                        Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Text(
                            "${i.pages} pages · ${FileUtils.formatSize(i.size)} · PDF ${i.version}" + (if (i.encrypted) " · protected" else ""),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), enabled = !strip, label = { Text("Title") })
                        OutlinedTextField(author, { author = it }, Modifier.fillMaxWidth(), enabled = !strip, label = { Text("Author") })
                        OutlinedTextField(subject, { subject = it }, Modifier.fillMaxWidth(), enabled = !strip, label = { Text("Subject") })
                        OutlinedTextField(keywords, { keywords = it }, Modifier.fillMaxWidth(), enabled = !strip, label = { Text("Keywords") })
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Remove all hidden information", style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    "Clears title, author, subject, keywords and the extra metadata before you share the file.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            Switch(checked = strip, onCheckedChange = { strip = it })
                        }
                    }
                }
            }
            outcome?.let { o -> ResultDialog(o, onOpen = onOpenPdf, onClose = { outcome = null }) }
        }
    }
}
