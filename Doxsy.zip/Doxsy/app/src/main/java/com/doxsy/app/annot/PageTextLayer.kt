package com.doxsy.app.annot

import android.content.Context
import android.graphics.PointF
import android.graphics.RectF
import android.net.Uri
import com.doxsy.app.pdf.PdfEngine
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.Closeable
import java.io.File
import java.io.IOException
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * One character of a page's text layer. [rect] is normalised (0..1, origin top-left) in the page as
 * DISPLAYED (rotation applied). [lineIndex] groups characters on the same visual line.
 */
data class TextChar(val ch: Char, val rect: RectF, val lineIndex: Int)

/**
 * Text layer access for real text selection (used by Annotation Studio and reusable by the viewer).
 * Backed by PDFBox. Pass [file] when a readable, already-decrypted copy exists (e.g. PdfSession.backingFile);
 * otherwise the Uri is copied once into the cache and deleted on [close].
 */
class PageTextLayer(
    private val app: Context,
    private val uri: Uri,
    private val file: File? = null,
    private val password: String = "",
) : Closeable {

    private val mutex = Mutex()
    private var doc: PDDocument? = null
    private var ownedFile: File? = null
    private val cache = HashMap<Int, List<TextChar>>()
    @Volatile private var closed = false

    private fun docLocked(): PDDocument {
        if (closed) throw IOException("closed")
        doc?.let { return it }
        PdfEngine.init(app)
        val src = file ?: File(app.cacheDir, "doxsy_tmp_ptl_${System.nanoTime()}.pdf").also { target ->
            ownedFile = target
            app.contentResolver.openInputStream(uri)?.use { i -> target.outputStream().use { o -> i.copyTo(o) } }
                ?: throw IOException("unreadable")
        }
        return PDDocument.load(src, password).also { doc = it }
    }

    suspend fun chars(page: Int): List<TextChar> = mutex.withLock {
        cache[page]?.let { return@withLock it }
        withContext(Dispatchers.IO) {
            val d = docLocked()
            if (page < 0 || page >= d.numberOfPages) return@withContext emptyList<TextChar>()
            val out = extract(d, page)
            if (cache.size > 24) cache.clear()
            cache[page] = out
            out
        }
    }

    private fun extract(d: PDDocument, page: Int): List<TextChar> {
        val pg = d.getPage(page)
        val box = pg.cropBox ?: pg.mediaBox
        val rot = ((pg.rotation % 360) + 360) % 360
        val pw = if (rot == 90 || rot == 270) box.height else box.width
        val ph = if (rot == 90 || rot == 270) box.width else box.height
        if (pw <= 0f || ph <= 0f) return emptyList()

        val out = ArrayList<TextChar>()
        var line = 0
        var lastY = Float.NaN
        var lastH = 1f

        val stripper = object : PDFTextStripper() {
            override fun writeString(text: String, textPositions: MutableList<TextPosition>) {
                if (textPositions.isEmpty()) return
                // Word separator between pieces on the same line.
                for (i in text.indices) {
                    val t = textPositions[min(i, textPositions.size - 1)]
                    val h = max(t.heightDir, 1f)
                    val yb = t.yDirAdj
                    if (!lastY.isNaN() && abs(yb - lastY) > lastH * 0.6f) line++
                    lastY = yb
                    lastH = h
                    val l = (t.xDirAdj / pw).coerceIn(0f, 1f)
                    val r = ((t.xDirAdj + t.widthDirAdj) / pw).coerceIn(0f, 1f)
                    val top = ((yb - h) / ph).coerceIn(0f, 1f)
                    val bot = (yb / ph).coerceIn(0f, 1f)
                    out += TextChar(text[i], RectF(l, top, max(r, l), max(bot, top)), line)
                }
                // add an explicit space after each string so copied text keeps word breaks
                val last = out.lastOrNull()
                if (last != null) {
                    out += TextChar(' ', RectF(last.rect.right, last.rect.top, last.rect.right, last.rect.bottom), last.lineIndex)
                }
            }
        }
        stripper.sortByPosition = true
        stripper.startPage = page + 1
        stripper.endPage = page + 1
        try {
            stripper.getText(d)
        } catch (e: Exception) {
            return emptyList()
        }
        return out
    }

    /**
     * Characters between the one nearest to [from] and the one nearest to [to] (reading order).
     * [aspect] = page height / width, used to compare distances in a uniform space.
     */
    fun selectionBetween(chars: List<TextChar>, from: PointF, to: PointF, aspect: Float = 1.414f): List<TextChar> {
        if (chars.isEmpty()) return emptyList()
        val a = nearest(chars, from, aspect)
        val b = nearest(chars, to, aspect)
        if (a < 0 || b < 0) return emptyList()
        val lo = min(a, b)
        val hi = max(a, b)
        return chars.subList(lo, hi + 1)
    }

    private fun nearest(chars: List<TextChar>, p: PointF, aspect: Float): Int {
        var best = -1
        var bestD = Float.MAX_VALUE
        for (i in chars.indices) {
            val c = chars[i]
            if (c.ch == ' ' && c.rect.width() <= 0f) continue
            val r = c.rect
            val dx = max(max(r.left - p.x, p.x - r.right), 0f)
            val dy = max(max(r.top - p.y, p.y - r.bottom), 0f) * aspect
            val d = hypot(dx, dy)
            if (d < bestD) {
                bestD = d
                best = i
            }
        }
        return best
    }

    fun textOf(sel: List<TextChar>): String {
        val sb = StringBuilder()
        var line = Int.MIN_VALUE
        for (c in sel) {
            if (line != Int.MIN_VALUE && c.lineIndex != line && sb.isNotEmpty() && sb.last() != '\n') {
                if (sb.last() == ' ') sb.setLength(sb.length - 1)
                sb.append('\n')
            }
            line = c.lineIndex
            sb.append(c.ch)
        }
        return sb.toString().trim()
    }

    /** One merged rectangle per text line of the selection (normalised, displayed space). */
    fun rectsOf(sel: List<TextChar>): List<RectF> {
        val out = ArrayList<RectF>()
        var cur: RectF? = null
        var curLine = Int.MIN_VALUE
        for (c in sel) {
            if (c.ch == ' ' && c.rect.width() <= 0f) continue
            val r = c.rect
            val cc = cur
            if (cc != null && c.lineIndex == curLine) {
                cc.left = min(cc.left, r.left)
                cc.right = max(cc.right, r.right)
                cc.top = min(cc.top, r.top)
                cc.bottom = max(cc.bottom, r.bottom)
            } else {
                if (cc != null) out += cc
                cur = RectF(r)
                curLine = c.lineIndex
            }
        }
        cur?.let { out += it }
        return out
    }

    override fun close() {
        closed = true
        runCatching { doc?.close() }
        doc = null
        cache.clear()
        ownedFile?.delete()
    }
}
