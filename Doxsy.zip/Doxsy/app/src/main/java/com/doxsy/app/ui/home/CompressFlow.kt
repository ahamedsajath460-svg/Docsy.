package com.doxsy.app.ui.home

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.doxsy.app.util.FileUtils

/** Tells [CompressHost] to start: pick a PDF, then show the Compress PDF page. */
class CompressState {
    var requestPick by mutableStateOf(false)
    fun begin() { requestPick = true }
}

@Composable
fun rememberCompressState(): CompressState = remember { CompressState() }

private class Picked(val uri: Uri, val name: String)

/** "Compress file" from the + menu: pick a PDF, then the full-screen [CompressPage]. */
@Composable
fun CompressHost(state: CompressState, onOpenPdf: (Uri, String) -> Unit) {
    val ctx = LocalContext.current
    var picked by remember { mutableStateOf<Picked?>(null) }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            picked = Picked(uri, FileUtils.displayName(ctx, uri))
        }
    }
    LaunchedEffect(state.requestPick) {
        if (state.requestPick) {
            state.requestPick = false
            pick.launch(arrayOf("application/pdf"))
        }
    }

    picked?.let { p ->
        CompressPage(p.name, p.uri, onClose = { picked = null }, onOpenPdf = onOpenPdf)
    }
}
