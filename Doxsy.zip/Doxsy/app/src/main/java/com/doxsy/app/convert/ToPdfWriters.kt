package com.doxsy.app.convert

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.text.Html
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import androidx.exifinterface.media.ExifInterface
import com.doxsy.app.docview.DocxReader
import com.doxsy.app.docview.ImageBlock
import com.doxsy.app.docview.PageBreak
import com.doxsy.app.docview.Para
import com.doxsy.app.docview.PptxReader
import com.doxsy.app.docview.SlideRenderer
import com.doxsy.app.docview.TableBlock
import com.doxsy.app.docview.XlsxReader
import com.doxsy.app.pdf.PdfEngine
import com.doxsy.app.pdf.PdfTools
import com.doxsy.app.util.FileUtils
import com.doxsy.app.util.OutputStore
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private const val BODY_PT = 11f
private const val MAX_TEXT_BYTES = 60L * 1024 * 1024

/** Converters whose result is a PDF. Each call is blocking: run it on a background thread. */
object ToPdfWriters {

    private fun pdfResult(ctx: Context, out: Uri, pages: Int, what: String): ConvertOutcome {
        val size = PdfTools.querySize(ctx, out)
        return ConvertOutcome.Success(listOf(out), "application/pdf", "$what ($pages page(s), ${FileUtils.formatSize(size)}).")
    }

    /** Writes an Android [PdfDocument] to the output location and frees it and the [bitmaps] kept for drawing. */
    private fun savePdfDocument(ctx: Context, name: String, pdf: PdfDocument, pages: Int, bitmaps: List<Bitmap>): Uri {
        try {
            if (pages <= 0) throw ConvertException("The file has nothing to convert.")
            return OutputStore.write(ctx, "$name.pdf", "application/pdf") { os -> pdf.writeTo(os) }
        } finally {
            runCatching { pdf.close() }
            bitmaps.forEach { runCatching { it.recycle() } }
        }
    }

    private fun savePdfBox(ctx: Context, name: String, doc: PDDocument): Uri =
        OutputStore.write(ctx, "$name.pdf", "application/pdf") { os -> doc.save(os) }

    private fun setupOf(s: ConvertSettings) = PageSetup(s.paper, s.orientation, s.margin.pt)

    // ---------------------------------------------------------------- Images -> PDF

    fun imagesToPdf(
        ctx: Context, images: List<Uri>, s: ConvertSettings, name: String,
        ensure: () -> Unit, progress: (Int, Int) -> Unit,
    ): ConvertOutcome {
        if (images.isEmpty()) return ConvertOutcome.Failure("Pick at least one image.")
        PdfEngine.init(ctx)
        val setup = setupOf(s)
        val q = (s.quality.coerceIn(30, 100)) / 100f
        // Longest side in pixels kept for each picture; higher quality keeps more detail.
        val maxSide = (1400 + (s.quality.coerceIn(30, 100) - 30) * 25).coerceAtMost(3200)
        val doc = PDDocument()
        try {
            progress(0, images.size)
            images.forEachIndexed { i, u ->
                ensure()
                val bmp = decodeUri(ctx, u, maxSide)
                    ?: throw ConvertException("Could not read image ${i + 1}. It may be damaged or in an unsupported format.")
                try {
                    val (pw, ph) = setup.dims(bmp.width > bmp.height)
                    val page = PDPage(PDRectangle(pw.toFloat(), ph.toFloat()))
                    doc.addPage(page)
                    val m = s.margin.pt.toFloat()
                    val availW = (pw - 2 * m).coerceAtLeast(20f)
                    val availH = (ph - 2 * m).coerceAtLeast(20f)
                    val scale = min(availW / bmp.width, availH / bmp.height)
                    val dw = bmp.width * scale
                    val dh = bmp.height * scale
                    val img = JPEGFactory.createFromImage(doc, bmp, q)
                    PDPageContentStream(doc, page).use { cs ->
                        cs.drawImage(img, (pw - dw) / 2f, (ph - dh) / 2f, dw, dh)
                    }
                } finally {
                    bmp.recycle()
                }
                progress(i + 1, images.size)
            }
            ensure()
            val out = savePdfBox(ctx, name, doc)
            return pdfResult(ctx, out, images.size, "Combined ${images.size} image(s) into one PDF")
        } finally {
            runCatching { doc.close() }
        }
    }

    // ---------------------------------------------------------------- DOCX -> PDF

    fun docxToPdf(
        ctx: Context, uri: Uri, s: ConvertSettings, name: String,
        ensure: () -> Unit, progress: (Int, Int) -> Unit,
    ): ConvertOutcome {
        progress(0, 1)
        val word = DocxReader.read(ctx, uri)
        ensure()
        val setup = setupOf(s)
        val (pw, ph) = setup.dims(false)
        val pdf = PdfDocument()
        val kept = ArrayList<Bitmap>()
        var pages = 0
        try {
            val w = FlowWriter(pdf, pw, ph, s.margin.pt, ensure)
            val total = word.blocks.size.coerceAtLeast(1)
            word.blocks.forEachIndexed { bi, b ->
                ensure()
                when (b) {
                    is Para -> drawPara(w, b)
                    is ImageBlock -> drawImageBlock(w, b, kept)
                    is TableBlock -> drawWordTable(w, b, ensure)
                    is PageBreak -> w.breakPage()
                }
                if (bi % 20 == 0) progress(bi, total)
            }
            w.finish()
            pages = w.pages
            progress(total, total)
            val out = savePdfDocument(ctx, name, pdf, pages, kept)
            val tail = if (word.truncated) " The document was very large, so only the first part was converted." else ""
            val r = pdfResult(ctx, out, pages, "Converted the Word document")
            return if (word.truncated && r is ConvertOutcome.Success) r.copy(message = r.message + tail) else r
        } catch (e: Throwable) {
            runCatching { pdf.close() }
            kept.forEach { runCatching { it.recycle() } }
            throw e
        }
    }

    private fun drawPara(w: FlowWriter, p: Para) {
        val size = if (p.heading > 0) headingSize(p.heading, BODY_PT) else BODY_PT
        val text = paraText(p, size)
        val indent = (p.indentLevel * 18 + if (p.bullet != null) 18 else 0).toFloat().coerceAtMost(w.contentW / 2f)
        if (text.isEmpty() && p.bullet == null) {
            w.space(size * 0.8f)
            return
        }
        val paint = newTextPaint(size)
        val layout = buildLayout(
            if (text.isEmpty()) " " else text, paint, (w.contentW - indent).toInt(),
            alignOf(p.align), justify = p.align == com.doxsy.app.docview.Align.JUSTIFY,
        )
        if (p.heading > 0) w.space(size * 0.5f)
        w.ensureRoom(layout.getLineBottom(0).toFloat())
        p.bullet?.let { label ->
            w.canvas.drawText(label, w.left + indent - 16f, w.y + layout.getLineBaseline(0), paint)
        }
        w.drawLayout(layout, w.left + indent)
        w.space(if (p.heading > 0) size * 0.35f else 5f)
    }

    private fun drawImageBlock(w: FlowWriter, b: ImageBlock, kept: MutableList<Bitmap>) {
        val bmp = decodeBytes(b.bytes, 1800) ?: return
        kept += bmp
        var dw = if (b.widthPt > 1f) b.widthPt else bmp.width.toFloat()
        var dh = if (b.heightPt > 1f) b.heightPt else bmp.height.toFloat()
        val f = min(1f, min(w.contentW / dw, w.contentH / dh))
        dw *= f
        dh *= f
        w.ensureRoom(dh)
        w.canvas.drawBitmap(bmp, null, RectF(w.left, w.y, w.left + dw, w.y + dh), Paint(Paint.FILTER_BITMAP_FLAG))
        w.space(dh + 6f)
    }

    private fun drawWordTable(w: FlowWriter, t: TableBlock, ensure: () -> Unit) {
        val cols = t.rows.maxOfOrNull { it.size } ?: return
        if (cols == 0) return
        val cw = w.contentW / cols
        val paint = newTextPaint(BODY_PT - 1f)
        val line = Paint().apply { style = Paint.Style.STROKE; color = Color.GRAY; strokeWidth = 0.6f }
        for (row in t.rows) {
            ensure()
            val layouts = row.map { cell ->
                val txt = cellText(cell, BODY_PT - 1f)
                buildCellLayout(if (txt.isEmpty()) " " else txt, paint, (cw - 8f).toInt(), 40)
            }
            val h = min((layouts.maxOfOrNull { it.height } ?: 14) + 8f, w.contentH)
            w.ensureRoom(h)
            val c = w.canvas
            layouts.forEachIndexed { i, l ->
                val x = w.left + i * cw
                c.drawRect(x, w.y, x + cw, w.y + h, line)
                c.save()
                c.translate(x + 4f, w.y + 4f)
                c.clipRect(0f, 0f, cw - 8f, h - 8f)
                l.draw(c)
                c.restore()
            }
            w.space(h)
        }
        w.space(8f)
    }

    private fun buildCellLayout(text: CharSequence, paint: TextPaint, width: Int, maxLines: Int): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, paint, width.coerceAtLeast(10))
            .setMaxLines(maxLines)
            .setEllipsize(TextUtils.TruncateAt.END)
            .setIncludePad(false)
            .build()

    // ---------------------------------------------------------------- Grids (XLSX / CSV)

    /**
     * Prints [rows] as a bordered table. Columns that do not fit the page width continue in "bands" on
     * following pages; the first row is repeated on every new page.
     */
    private fun drawGrid(
        w: FlowWriter, rows: List<List<String>>, hintChars: List<Float>, ensure: () -> Unit,
    ) {
        if (rows.isEmpty()) return
        val fontPt = 9f
        val colCount = min(rows.maxOf { it.size }, 200)
        if (colCount == 0) return
        val widths = FloatArray(colCount) { c ->
            val chars = hintChars.getOrNull(c) ?: rows.take(200).maxOf { (it.getOrNull(c) ?: "").length.coerceAtMost(40) }.toFloat()
            (chars * fontPt * 0.55f + 10f).coerceIn(32f, min(280f, w.contentW))
        }
        val paint = newTextPaint(fontPt)
        val bold = newTextPaint(fontPt, Typeface.DEFAULT_BOLD)
        val line = Paint().apply { style = Paint.Style.STROKE; color = Color.GRAY; strokeWidth = 0.5f }
        val headFill = Paint().apply { style = Paint.Style.FILL; color = 0xFFEDEFF5.toInt() }

        var start = 0
        var firstBand = true
        while (start < colCount) {
            var end = start
            var used = 0f
            while (end < colCount && (end == start || used + widths[end] <= w.contentW)) {
                used += widths[end]
                end++
            }
            if (!firstBand) w.breakPage()
            firstBand = false

            fun layoutsFor(r: Int, head: Boolean): List<StaticLayout> = (start until end).map { c ->
                val t = rows[r].getOrNull(c).orEmpty()
                buildCellLayout(if (t.isEmpty()) " " else t, if (head) bold else paint, (widths[c] - 8f).toInt(), 6)
            }

            fun drawRow(layouts: List<StaticLayout>, h: Float, head: Boolean) {
                val cv = w.canvas
                var x = w.left
                layouts.forEachIndexed { i, l ->
                    val cwid = widths[start + i]
                    if (head) cv.drawRect(x, w.y, x + cwid, w.y + h, headFill)
                    cv.drawRect(x, w.y, x + cwid, w.y + h, line)
                    cv.save()
                    cv.translate(x + 4f, w.y + 3f)
                    cv.clipRect(0f, 0f, cwid - 8f, h - 6f)
                    l.draw(cv)
                    cv.restore()
                    x += cwid
                }
                w.space(h)
            }

            for (r in rows.indices) {
                ensure()
                val head = r == 0
                val ls = layoutsFor(r, head)
                val h = max(15f, (ls.maxOfOrNull { it.height } ?: 10) + 6f)
                val before = w.pages
                w.ensureRoom(h)
                if (w.pages != before && r > 0) {
                    val hl = layoutsFor(0, true)
                    drawRow(hl, max(15f, (hl.maxOfOrNull { it.height } ?: 10) + 6f), true)
                    w.ensureRoom(h)
                }
                drawRow(ls, h, head)
            }
            start = end
        }
    }

    fun xlsxToPdf(
        ctx: Context, uri: Uri, s: ConvertSettings, name: String,
        ensure: () -> Unit, progress: (Int, Int) -> Unit,
    ): ConvertOutcome {
        progress(0, 1)
        val book = XlsxReader.read(ctx, uri)
        if (book.sheets.isEmpty()) return ConvertOutcome.Failure("This workbook has no sheets.")
        ensure()
        val (pw, ph) = setupOf(s).dims(false)
        val pdf = PdfDocument()
        try {
            val w = FlowWriter(pdf, pw, ph, s.margin.pt, ensure)
            val title = newTextPaint(13f, Typeface.DEFAULT_BOLD)
            var truncated = false
            book.sheets.forEachIndexed { i, sheet ->
                ensure()
                if (i > 0) w.breakPage()
                w.drawLayout(buildLayout(sheet.name.ifBlank { "Sheet ${i + 1}" }, title, w.contentW.toInt()))
                w.space(6f)
                if (sheet.rows.isEmpty()) {
                    w.drawLayout(buildLayout("(empty sheet)", newTextPaint(10f), w.contentW.toInt()))
                } else {
                    drawGrid(w, sheet.rows, sheet.colWidthsChars, ensure)
                }
                if (sheet.truncated) truncated = true
                progress(i + 1, book.sheets.size)
            }
            w.finish()
            val pages = w.pages
            val out = savePdfDocument(ctx, name, pdf, pages, emptyList())
            val r = pdfResult(ctx, out, pages, "Converted ${book.sheets.size} sheet(s)")
            return if (truncated && r is ConvertOutcome.Success)
                r.copy(message = r.message + " Very large sheets were cut after the first rows.") else r
        } catch (e: Throwable) {
            runCatching { pdf.close() }
            throw e
        }
    }

    // ---------------------------------------------------------------- PPTX -> PDF

    fun pptxToPdf(
        ctx: Context, uri: Uri, s: ConvertSettings, name: String,
        ensure: () -> Unit, progress: (Int, Int) -> Unit,
    ): ConvertOutcome {
        progress(0, 1)
        val deck = PptxReader.read(ctx, uri)
        if (deck.slides.isEmpty()) return ConvertOutcome.Failure("This presentation has no slides.")
        PdfEngine.init(ctx)
        val setup = setupOf(s)
        val doc = PDDocument()
        try {
            val total = deck.slides.size
            progress(0, total)
            deck.slides.forEachIndexed { i, slide ->
                ensure()
                val (pw, ph) = setup.dims(slide.aspect >= 1f)
                val page = PDPage(PDRectangle(pw.toFloat(), ph.toFloat()))
                doc.addPage(page)
                val m = s.margin.pt.toFloat()
                val availW = (pw - 2 * m).coerceAtLeast(20f)
                val availH = (ph - 2 * m).coerceAtLeast(20f)
                val dw: Float
                val dh: Float
                if (availW / availH > slide.aspect) {
                    dh = availH
                    dw = availH * slide.aspect
                } else {
                    dw = availW
                    dh = availW / slide.aspect
                }
                val px = (dw * 2.4f).roundToInt().coerceIn(600, 2000)
                val rendered = SlideRenderer.render(slide, px)
                val bmp = flattenOnWhite(rendered)
                try {
                    val img = JPEGFactory.createFromImage(doc, bmp, 0.9f)
                    PDPageContentStream(doc, page).use { cs ->
                        cs.drawImage(img, (pw - dw) / 2f, (ph - dh) / 2f, dw, dh)
                    }
                } finally {
                    if (bmp !== rendered) bmp.recycle()
                    rendered.recycle()
                }
                progress(i + 1, total)
            }
            val out = savePdfBox(ctx, name, doc)
            return pdfResult(ctx, out, total, "Converted $total slide(s), one per page")
        } finally {
            runCatching { doc.close() }
        }
    }

    // ---------------------------------------------------------------- TXT / CSV / HTML -> PDF

    fun txtToPdf(
        ctx: Context, uri: Uri, s: ConvertSettings, name: String,
        ensure: () -> Unit, progress: (Int, Int) -> Unit,
    ): ConvertOutcome {
        progress(0, 1)
        val (pw, ph) = setupOf(s).dims(false)
        val pdf = PdfDocument()
        try {
            val w = FlowWriter(pdf, pw, ph, s.margin.pt, ensure)
            val paint = newTextPaint(10f, Typeface.MONOSPACE)
            val size = querySizeOrZero(ctx, uri)
            if (size > MAX_TEXT_BYTES) throw ConvertException("This text file is too large to convert (limit ${FileUtils.formatSize(MAX_TEXT_BYTES)}).")
            openReader(ctx, uri).use { rd ->
                val chunk = StringBuilder()
                var lines = 0
                var any = false
                fun flush() {
                    if (chunk.isEmpty()) return
                    w.drawLayout(buildLayout(chunk.toString(), paint, w.contentW.toInt()))
                    chunk.setLength(0)
                    lines = 0
                }
                while (true) {
                    val raw = rd.readLine() ?: break
                    ensure()
                    // The reader does not skip a byte-order mark, so drop it from the first line.
                    val line = if (any) raw else raw.removePrefix("﻿")
                    any = true
                    chunk.append(line.replace("\t", "    ").replace("\u0000", "")).append('\n')
                    if (++lines >= 80) flush()
                }
                flush()
                if (!any) throw ConvertException("The text file is empty.")
            }
            w.finish()
            val pages = w.pages
            progress(1, 1)
            val out = savePdfDocument(ctx, name, pdf, pages, emptyList())
            return pdfResult(ctx, out, pages, "Converted the text file")
        } catch (e: Throwable) {
            runCatching { pdf.close() }
            throw e
        }
    }

    fun csvToPdf(
        ctx: Context, uri: Uri, s: ConvertSettings, name: String,
        ensure: () -> Unit, progress: (Int, Int) -> Unit,
    ): ConvertOutcome {
        progress(0, 1)
        if (querySizeOrZero(ctx, uri) > MAX_TEXT_BYTES) throw ConvertException("This CSV file is too large to convert.")
        val text = openReader(ctx, uri).use { it.readText() }
        val rows = parseCsv(text, ensure)
        if (rows.isEmpty()) throw ConvertException("The CSV file is empty.")
        val (pw, ph) = setupOf(s).dims(rows.maxOf { it.size } > 6)
        val pdf = PdfDocument()
        try {
            val w = FlowWriter(pdf, pw, ph, s.margin.pt, ensure)
            drawGrid(w, rows, emptyList(), ensure)
            w.finish()
            val pages = w.pages
            progress(1, 1)
            val out = savePdfDocument(ctx, name, pdf, pages, emptyList())
            return pdfResult(ctx, out, pages, "Converted ${rows.size} CSV row(s)")
        } catch (e: Throwable) {
            runCatching { pdf.close() }
            throw e
        }
    }

    fun htmlToPdf(
        ctx: Context, uri: Uri, s: ConvertSettings, name: String,
        ensure: () -> Unit, progress: (Int, Int) -> Unit,
    ): ConvertOutcome {
        progress(0, 1)
        if (querySizeOrZero(ctx, uri) > 10L * 1024 * 1024) throw ConvertException("This HTML file is too large to convert (limit 10 MB).")
        var html = openReader(ctx, uri).use { it.readText() }
        html = html
            .replace(Regex("(?is)<script.*?</script>"), "")
            .replace(Regex("(?is)<style.*?</style>"), "")
            .replace(Regex("(?is)<head\\b.*?</head>"), "")
            .replace(Regex("(?is)<img[^>]*>"), "")
            .replace(Regex("(?is)<(iframe|object|embed|video|audio|svg)\\b.*?(</\\1>|/>)"), "")
        ensure()
        val spanned = Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY)
        if (spanned.toString().isBlank()) throw ConvertException("The HTML file has no readable text.")
        val (pw, ph) = setupOf(s).dims(false)
        val pdf = PdfDocument()
        try {
            val w = FlowWriter(pdf, pw, ph, s.margin.pt, ensure)
            val paint = newTextPaint(BODY_PT)
            var from = 0
            val plain = spanned.toString()
            val n = spanned.length
            while (from < n) {
                ensure()
                var to = min(n, from + 3500)
                if (to < n) {
                    val nl = plain.lastIndexOf('\n', to)
                    if (nl > from) to = nl + 1
                }
                val part = spanned.subSequence(from, to)
                if (part.isNotBlank()) w.drawLayout(buildLayout(part, paint, w.contentW.toInt()))
                from = to
            }
            w.finish()
            val pages = w.pages
            progress(1, 1)
            val out = savePdfDocument(ctx, name, pdf, pages, emptyList())
            return pdfResult(ctx, out, pages, "Converted the HTML file (simple rendering)")
        } catch (e: Throwable) {
            runCatching { pdf.close() }
            throw e
        }
    }

    // ---------------------------------------------------------------- helpers

    private fun querySizeOrZero(ctx: Context, uri: Uri): Long = PdfTools.querySize(ctx, uri).coerceAtLeast(0L)

    /** Opens a text file, honouring UTF-16 byte-order marks; everything else is read as UTF-8. */
    private fun openReader(ctx: Context, uri: Uri): BufferedReader {
        val cr = ctx.contentResolver
        val bom = cr.openInputStream(uri)?.use { i ->
            val b = ByteArray(2)
            if (i.read(b) == 2) b else null
        }
        val cs = when {
            bom != null && bom[0] == 0xFE.toByte() && bom[1] == 0xFF.toByte() -> Charsets.UTF_16BE
            bom != null && bom[0] == 0xFF.toByte() && bom[1] == 0xFE.toByte() -> Charsets.UTF_16LE
            else -> Charsets.UTF_8
        }
        val stream = cr.openInputStream(uri) ?: throw ConvertException("Could not open the file.")
        return BufferedReader(InputStreamReader(stream, cs), 64 * 1024)
    }

    /** Small RFC 4180 parser; the delimiter (comma, semicolon or tab) is guessed from the first line. */
    internal fun parseCsv(text: String, ensure: () -> Unit): List<List<String>> {
        val src = text.removePrefix("﻿")
        val firstLine = src.lineSequence().firstOrNull().orEmpty()
        val delim = listOf(',', ';', '\t').maxByOrNull { d -> firstLine.count { it == d } }
            ?.takeIf { d -> firstLine.contains(d) } ?: ','
        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>()
        val cell = StringBuilder()
        var inQuotes = false
        var i = 0
        fun endCell() {
            row.add(cell.toString())
            cell.setLength(0)
        }
        fun endRow() {
            endCell()
            if (row.size > 1 || row[0].isNotEmpty()) rows.add(row)
            row = ArrayList()
        }
        while (i < src.length) {
            val ch = src[i]
            if (i % 50000 == 0) ensure()
            when {
                inQuotes -> if (ch == '"') {
                    if (i + 1 < src.length && src[i + 1] == '"') {
                        cell.append('"')
                        i++
                    } else inQuotes = false
                } else cell.append(ch)
                ch == '"' -> inQuotes = true
                ch == delim -> endCell()
                ch == '\n' -> endRow()
                ch == '\r' -> Unit
                else -> cell.append(ch)
            }
            i++
        }
        if (cell.isNotEmpty() || row.isNotEmpty()) endRow()
        return rows
    }

    private fun flattenOnWhite(src: Bitmap): Bitmap {
        if (!src.hasAlpha()) return src
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawColor(Color.WHITE)
        c.drawBitmap(src, 0f, 0f, null)
        return out
    }

    private fun sampleFor(w: Int, h: Int, maxSide: Int): Int {
        var sample = 1
        while (max(w, h) / sample > maxSide * 2) sample *= 2
        return sample
    }

    private fun finishDecode(bmp: Bitmap, maxSide: Int): Bitmap {
        val longest = max(bmp.width, bmp.height)
        val scaled = if (longest > maxSide) {
            val f = maxSide.toFloat() / longest
            Bitmap.createScaledBitmap(bmp, (bmp.width * f).roundToInt().coerceAtLeast(1), (bmp.height * f).roundToInt().coerceAtLeast(1), true)
        } else bmp
        if (scaled !== bmp) bmp.recycle()
        return flattenOnWhite(scaled).also { if (it !== scaled) scaled.recycle() }
    }

    internal fun decodeBytes(bytes: ByteArray, maxSide: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        val opts = BitmapFactory.Options().apply { inSampleSize = sampleFor(bounds.outWidth, bounds.outHeight, maxSide) }
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return null
        return finishDecode(bmp, maxSide)
    }

    /** Decodes an image (memory-safe, EXIF rotation applied, transparency flattened onto white). */
    internal fun decodeUri(ctx: Context, uri: Uri, maxSide: Int): Bitmap? {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        try {
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        } catch (e: IOException) {
            return null
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        val opts = BitmapFactory.Options().apply { inSampleSize = sampleFor(bounds.outWidth, bounds.outHeight, maxSide) }
        val raw = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
        val orientation = runCatching {
            cr.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            }
        }.getOrNull() ?: ExifInterface.ORIENTATION_NORMAL
        val m = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> {
                m.postRotate(90f)
                m.postScale(-1f, 1f)
            }
            ExifInterface.ORIENTATION_TRANSVERSE -> {
                m.postRotate(270f)
                m.postScale(-1f, 1f)
            }
        }
        val oriented = if (m.isIdentity) raw else {
            Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true).also { if (it !== raw) raw.recycle() }
        }
        return finishDecode(oriented, maxSide)
    }
}
