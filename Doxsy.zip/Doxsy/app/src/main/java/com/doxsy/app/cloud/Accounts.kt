package com.doxsy.app.cloud

import android.content.Context
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.tasks.await

data class AccountInfo(val name: String, val email: String)

/** Firebase Authentication with "Sign in with Google". Off (but harmless) without google-services.json. */
object Accounts {
    private val _user = MutableStateFlow<AccountInfo?>(null)
    val user: StateFlow<AccountInfo?> = _user

    fun configured(ctx: Context): Boolean = FirebaseApp.getApps(ctx).isNotEmpty()

    fun init(ctx: Context) {
        if (!configured(ctx)) return
        val auth = FirebaseAuth.getInstance()
        auth.addAuthStateListener { _user.value = it.currentUser.toInfo() }
        _user.value = auth.currentUser.toInfo()
    }

    private fun FirebaseUser?.toInfo(): AccountInfo? =
        this?.let { AccountInfo(it.displayName.orEmpty(), it.email.orEmpty()) }

    private fun webClientId(ctx: Context): String? {
        val id = ctx.resources.getIdentifier("default_web_client_id", "string", ctx.packageName)
        return if (id == 0) null else ctx.getString(id)
    }

    /** Returns null on success, otherwise a message to show. [activityCtx] must be an Activity. */
    suspend fun signIn(activityCtx: Context): String? {
        if (!configured(activityCtx)) {
            return "Firebase is not set up in this build (app/google-services.json is missing)."
        }
        val web = webClientId(activityCtx)
            ?: return "No web client ID found. In Firebase > Authentication turn on Google sign-in, then download google-services.json again."
        return try {
            val option = GetGoogleIdOption.Builder()
                .setFilterByAuthorizedAccounts(false)
                .setServerClientId(web)
                .build()
            val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
            val result = CredentialManager.create(activityCtx).getCredential(activityCtx, request)
            val cred = result.credential
            if (cred is CustomCredential && cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val idToken = GoogleIdTokenCredential.createFrom(cred.data).idToken
                FirebaseAuth.getInstance()
                    .signInWithCredential(GoogleAuthProvider.getCredential(idToken, null))
                    .await()
                null
            } else {
                "Unexpected sign-in result."
            }
        } catch (e: GetCredentialCancellationException) {
            "Sign-in cancelled."
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            e.message ?: "Sign-in failed."
        }
    }

    suspend fun signOut(ctx: Context) {
        if (!configured(ctx)) return
        FirebaseAuth.getInstance().signOut()
        runCatching { CredentialManager.create(ctx).clearCredentialState(ClearCredentialStateRequest()) }
    }
}
