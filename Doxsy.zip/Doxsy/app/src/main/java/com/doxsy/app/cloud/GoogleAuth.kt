package com.doxsy.app.cloud

import android.accounts.Account
import android.content.Context
import android.content.Intent
import android.content.IntentSender
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.tasks.await

object GoogleScopes {
    const val DRIVE = "https://www.googleapis.com/auth/drive"
    const val GMAIL = "https://www.googleapis.com/auth/gmail.readonly"

    fun forAccount(gmail: Boolean): List<String> = if (gmail) listOf(DRIVE, GMAIL) else listOf(DRIVE)
}

sealed interface AuthOutcome {
    data class Token(val value: String) : AuthOutcome
    data class Consent(val sender: IntentSender) : AuthOutcome
    data class Failed(val message: String) : AuthOutcome
}

/** Google's Authorization API: asks the user once, then hands out short-lived access tokens. */
object GoogleAuth {
    private fun friendly(e: Exception): String {
        val m = e.message.orEmpty()
        return if ("10" in m || "DEVELOPER_ERROR" in m.uppercase()) {
            "Google rejected this app (developer error). Register the package name com.doxsy.app and the " +
                "signing SHA-1 in Firebase / Google Cloud, then try again. ($m)"
        } else {
            m.ifBlank { "Google authorization failed." }
        }
    }

    suspend fun authorize(ctx: Context, accountName: String, scopes: List<String>): AuthOutcome = try {
        val request = AuthorizationRequest.builder()
            .setRequestedScopes(scopes.map { Scope(it) })
            .setAccount(Account(accountName, "com.google"))
            .build()
        val result = Identity.getAuthorizationClient(ctx).authorize(request).await()
        val pending = result.pendingIntent
        if (result.hasResolution() && pending != null) {
            AuthOutcome.Consent(pending.intentSender)
        } else {
            val token = result.accessToken
            if (token != null) AuthOutcome.Token(token) else AuthOutcome.Failed("Google did not return an access token.")
        }
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        AuthOutcome.Failed(friendly(e))
    }

    fun tokenFromIntent(ctx: Context, data: Intent?): AuthOutcome = try {
        val result = Identity.getAuthorizationClient(ctx).getAuthorizationResultFromIntent(data)
        val token = result.accessToken
        if (token != null) AuthOutcome.Token(token) else AuthOutcome.Failed("Google did not return an access token.")
    } catch (e: Exception) {
        AuthOutcome.Failed(friendly(e))
    }

    /** A usable access token, or null when the user has to connect again. */
    suspend fun freshToken(ctx: Context, accountName: String, gmail: Boolean): String? =
        (authorize(ctx, accountName, GoogleScopes.forAccount(gmail)) as? AuthOutcome.Token)?.value
}
