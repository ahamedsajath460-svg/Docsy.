package com.doxsy.app.ui.docview

import android.graphics.BitmapFactory
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.item
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.doxsy.app.docview.Align
import com.doxsy.app.docview.Block
import com.doxsy.app.docview.ImageBlock
import com.doxsy.app.docview.PageBreak
import com.doxsy.app.docview.Para
import com.doxsy.app.docview.TableBlock
import com.doxsy.app.docview.TextRun
import com.doxsy.app.docview.WordDoc
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/** Word document: paragraphs, lists, tables, pictures and page breaks. [zoom] scales all text. */
@Composable
internal fun WordView(
    doc: WordDoc,
    zoom: Float,
    listState: LazyListState,
    hl: Highlights,
    modifier: Modifier = Modifier,
) {
    LazyColumn(
        modifier.fillMaxSize(),
        state = listState,
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        itemsIndexed(doc.blocks) { b, block ->
            BlockItem(block, "$b", b, zoom, hl)
        }
        if (doc.truncated) {
            item { Notice("This document is very large, so only the first part is shown.") }
        }
    }
}

@Composable
private fun BlockItem(block: Block, key: String, index: Int, zoom: Float, hl: Highlights) {
    when (block) {
        is Para -> ParagraphView(block, key, zoom, hl)
        is ImageBlock -> PictureView(block, zoom)
        is TableBlock -> TableView(block, index, zoom, hl)
        PageBreak -> HorizontalDivider(Modifier.padding(vertical = 12.dp))
    }
}

@Composable
private fun ParagraphView(p: Para, key: String, zoom: Float, hl: Highlights, modifier: Modifier = Modifier) {
    val ink = MaterialTheme.colorScheme.onBackground
    val size = when (p.heading) {
        1 -> 26f
        2 -> 22f
        3 -> 19f
        0 -> 15f
        else -> 16f
    } * zoom
    val base = remember(p, zoom) { runsToText(p.runs, zoom) }
    val shown = remember(base, hl, key) { base.withHighlights(hl.ranges(key), hl.currentIn(key)) }
    Row(
        modifier
            .fillMaxWidth()
            .padding(start = (p.indentLevel * 16).dp),
    ) {
        if (p.bullet != null) {
            Text(
                p.bullet + " ",
                fontSize = size.sp,
                color = ink,
                modifier = Modifier.padding(end = 4.dp),
            )
        }
        Text(
            shown,
            modifier = Modifier.weight(1f),
            color = ink,
            fontSize = size.sp,
            lineHeight = (size * 1.35f).sp,
            fontWeight = if (p.heading > 0) FontWeight.Bold else null,
            textAlign = alignOf(p.align),
        )
    }
}

/** Styled runs as one AnnotatedString. Colour 0 and size 0 mean "use the default". */
internal fun runsToText(runs: List<TextRun>, zoom: Float): AnnotatedString = buildAnnotatedString {
    for (r in runs) {
        val style = SpanStyle(
            fontWeight = if (r.bold) FontWeight.Bold else null,
            fontStyle = if (r.italic) FontStyle.Italic else null,
            textDecoration = decorationOf(r),
            color = if (r.color != 0) Color(r.color) else Color.Unspecified,
            fontSize = if (r.sizePt > 0f) (r.sizePt * zoom).sp else TextUnit.Unspecified,
        )
        withStyle(style) { append(r.text) }
    }
}

private fun decorationOf(r: TextRun): TextDecoration? {
    val list = buildList {
        if (r.underline || r.link != null) add(TextDecoration.Underline)
        if (r.strike) add(TextDecoration.LineThrough)
    }
    return if (list.isEmpty()) null else TextDecoration.combine(list)
}

private fun alignOf(a: Align): TextAlign = when (a) {
    Align.START -> TextAlign.Start
    Align.CENTER -> TextAlign.Center
    Align.END -> TextAlign.End
    Align.JUSTIFY -> TextAlign.Justify
}

@Composable
private fun PictureView(img: ImageBlock, zoom: Float) {
    val bmp by produceState<ImageBitmap?>(null, img) {
        value = withContext(Dispatchers.Default) {
            BitmapFactory.decodeByteArray(img.bytes, 0, img.bytes.size)?.asImageBitmap()
        }
    }
    val b = bmp ?: return
    val ratio = b.width.toFloat() / b.height.coerceAtLeast(1).toFloat()
    val fraction = ((img.widthPt * zoom) / 340f).coerceIn(0.2f, 1f)
    Image(
        bitmap = b,
        contentDescription = null,
        contentScale = ContentScale.FillWidth,
        modifier = Modifier
            .fillMaxWidth(fraction)
            .aspectRatio(ratio),
    )
}

/**
 * Tables with up to four columns fill the width. Wider tables get fixed-width columns and scroll
 * sideways. Cell paragraphs use keys "[block]/[row]/[col]/[para]" to match the search index.
 */
@Composable
private fun TableView(t: TableBlock, index: Int, zoom: Float, hl: Highlights) {
    val cols = t.rows.maxOfOrNull { it.size } ?: 0
    if (cols == 0) return
    val wide = cols > 4
    val cellWidth: Dp = 150.dp
    val border = MaterialTheme.colorScheme.outlineVariant
    val scroll = rememberScrollState()
    val tableMod = Modifier
        .then(if (wide) Modifier.width(cellWidth * cols) else Modifier.fillMaxWidth())
        .border(0.5.dp, border)
    Box(
        Modifier
            .fillMaxWidth()
            .then(if (wide) Modifier.horizontalScroll(scroll) else Modifier),
    ) {
        Column(tableMod) {
            t.rows.forEachIndexed { r, row ->
                Row(Modifier.height(IntrinsicSize.Min)) {
                    for (c in 0 until cols) {
                        val cell = row.getOrNull(c).orEmpty()
                        val cellMod = (if (wide) Modifier.width(cellWidth) else Modifier.weight(1f))
                            .fillMaxHeight()
                            .border(0.5.dp, border)
                            .padding(6.dp)
                        Column(cellMod) {
                            cell.forEachIndexed { p, inner ->
                                when (inner) {
                                    is Para -> ParagraphView(inner, "$index/$r/$c/$p", zoom, hl)
                                    is ImageBlock -> PictureView(inner, zoom * 0.6f)
                                    else -> Text("[table]", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Plain text lines (TXT, RTF). Selectable, so the user can copy text. */
@Composable
internal fun LinesView(
    lines: List<String>,
    truncated: Boolean,
    zoom: Float,
    listState: LazyListState,
    hl: Highlights,
    modifier: Modifier = Modifier,
) {
    val ink = MaterialTheme.colorScheme.onBackground
    SelectionContainer(modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        ) {
            itemsIndexed(lines) { i, line ->
                val key = "$i"
                val shown = remember(line, hl, key) {
                    AnnotatedString(line).withHighlights(hl.ranges(key), hl.currentIn(key))
                }
                Text(
                    shown,
                    color = ink,
                    fontSize = (14f * zoom).sp,
                    lineHeight = (14f * zoom * 1.4f).sp,
                )
            }
            if (truncated) {
                item { Notice("This file is very large, so only the first part is shown.") }
            }
        }
    }
}

/** Find state for the WebView viewer. Filled in by the WebView callbacks. */
internal class WebFind {
    var query by mutableStateOf("")
    var total by mutableIntStateOf(0)
    var active by mutableIntStateOf(0)
    var view: WebView? = null
}

/**
 * HTML, XML and JSON. JavaScript is off, file and content access are off, and every link
 * or network load is blocked, so a document cannot run code or reach the network.
 */
@Composable
internal fun WebDocView(
    html: String,
    zoom: Float,
    find: WebFind,
    modifier: Modifier = Modifier,
) {
    AndroidView(
        modifier = modifier,
        factory = { c ->
            WebView(c).apply {
                settings.javaScriptEnabled = false
                settings.allowFileAccess = false
                settings.allowContentAccess = false
                settings.blockNetworkLoads = true
                settings.builtInZoomControls = false
                settings.textZoom = (zoom * 100).roundToInt()
                setFindListener { active, matches, _ ->
                    find.total = matches
                    find.active = if (matches > 0) active + 1 else 0
                }
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = true

                    override fun onPageFinished(view: WebView?, url: String?) {
                        if (find.query.isNotBlank()) view?.findAllAsync(find.query)
                    }
                }
                find.view = this
            }
        },
        update = { v ->
            v.settings.textZoom = (zoom * 100).roundToInt()
            if (v.tag != html) {
                v.tag = html
                v.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
            }
        },
    )
    LaunchedEffect(find.query) {
        val v = find.view ?: return@LaunchedEffect
        if (find.query.isBlank()) {
            v.clearMatches()
            find.total = 0
            find.active = 0
        } else {
            v.findAllAsync(find.query)
        }
    }
    DisposableEffect(Unit) {
        onDispose {
            find.view?.destroy()
            find.view = null
        }
    }
}

@Composable
internal fun Notice(text: String) {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(12.dp),
    ) {
        Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
