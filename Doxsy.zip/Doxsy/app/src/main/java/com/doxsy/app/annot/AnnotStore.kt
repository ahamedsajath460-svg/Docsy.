package com.doxsy.app.annot

import android.content.Context
import com.doxsy.app.util.AppFiles
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

data class AnnotDocInfo(val key: String, val uri: String, val name: String, val count: Int, val pages: Int, val updated: Long)

data class AnnotDoc(val info: AnnotDocInfo, val annots: List<Annot>)

/**
 * Permanent annotation storage. One JSON sidecar per document (keyed by a hash of the document Uri)
 * plus a small index so previously annotated documents can be listed and reopened. The original PDF
 * is never touched.
 */
class AnnotStore(context: Context) {
    private val dir: File = AppFiles.dir(context.applicationContext, "annotations")
    private val indexFile = File(dir, "index.json")

    private fun docFile(key: String) = File(dir, "$key.json")

    @Synchronized
    fun load(key: String): AnnotDoc? = runCatching {
        val f = docFile(key)
        if (!f.exists()) return null
        val o = JSONObject(f.readText())
        val arr = o.getJSONArray("annots")
        val list = ArrayList<Annot>()
        for (i in 0 until arr.length()) annotFromJson(arr.getJSONObject(i))?.let { list += it }
        AnnotDoc(
            AnnotDocInfo(key, o.optString("uri"), o.optString("name"), list.size, o.optInt("pages"), o.optLong("updated")),
            list,
        )
    }.getOrNull()

    @Synchronized
    fun save(key: String, uri: String, name: String, pages: Int, annots: List<Annot>) {
        if (annots.isEmpty()) {
            delete(key)
            return
        }
        val now = System.currentTimeMillis()
        val arr = JSONArray()
        annots.forEach { arr.put(it.toJson()) }
        val o = JSONObject().put("v", 1).put("uri", uri).put("name", name).put("pages", pages).put("updated", now).put("annots", arr)
        writeAtomic(docFile(key), o.toString())
        val idx = readIndex().filterNot { it.key == key }.toMutableList()
        idx.add(0, AnnotDocInfo(key, uri, name, annots.size, pages, now))
        writeIndex(idx)
    }

    @Synchronized
    fun delete(key: String) {
        docFile(key).delete()
        val idx = readIndex()
        if (idx.any { it.key == key }) writeIndex(idx.filterNot { it.key == key })
    }

    @Synchronized
    fun index(): List<AnnotDocInfo> = readIndex().filter { docFile(it.key).exists() }.sortedByDescending { it.updated }

    private fun readIndex(): List<AnnotDocInfo> = runCatching {
        if (!indexFile.exists()) return emptyList()
        val arr = JSONArray(indexFile.readText())
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            AnnotDocInfo(o.getString("k"), o.getString("u"), o.getString("n"), o.optInt("c"), o.optInt("p"), o.optLong("t"))
        }
    }.getOrDefault(emptyList())

    private fun writeIndex(list: List<AnnotDocInfo>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("k", it.key).put("u", it.uri).put("n", it.name).put("c", it.count).put("p", it.pages).put("t", it.updated))
        }
        writeAtomic(indexFile, arr.toString())
    }

    private fun writeAtomic(target: File, text: String) {
        val tmp = File(target.parentFile, target.name + ".tmp")
        tmp.writeText(text)
        if (!tmp.renameTo(target)) {
            target.delete()
            if (!tmp.renameTo(target)) {
                target.writeText(text)
                tmp.delete()
            }
        }
    }

    companion object {
        /** Stable key for a document Uri. */
        fun keyFor(uri: String): String =
            MessageDigest.getInstance("SHA-1").digest(uri.toByteArray()).joinToString("") { "%02x".format(it) }
    }
}
