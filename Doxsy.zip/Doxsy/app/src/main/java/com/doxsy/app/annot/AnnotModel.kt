package com.doxsy.app.annot

import android.graphics.PointF
import android.graphics.RectF
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

enum class AnnotType { HIGHLIGHT, UNDERLINE, STRIKE, INK, MARKER, TEXT, RECT, CIRCLE, ARROW, LINE, NOTE }

/**
 * One annotation. All geometry is normalised to the page as DISPLAYED (rotation applied):
 * x / u and y / v are 0..1 with the origin at the top-left corner.
 *
 *  - HIGHLIGHT / UNDERLINE / STRIKE : [rects] (one per text line)
 *  - INK / MARKER                   : [points] polyline
 *  - RECT / CIRCLE / LINE / ARROW   : [points] = two corners / end points
 *  - TEXT                           : [points][0] = top-left, [text]
 *  - NOTE                           : [points][0] = centre, [comment] = note body
 *
 * [strokeFrac] and [sizeFrac] are fractions of the page WIDTH, so they scale with the page.
 */
data class Annot(
    val id: String = UUID.randomUUID().toString(),
    val type: AnnotType,
    val page: Int,
    val color: Int,
    val strokeFrac: Float = 0.003f,
    val sizeFrac: Float = 0.03f,
    val rects: List<RectF> = emptyList(),
    val points: List<PointF> = emptyList(),
    val text: String = "",
    val comment: String = "",
    val created: Long = System.currentTimeMillis(),
)

const val NOTE_SIZE_FRAC = 0.05f

/** Bounds in normalised page space. [aspect] = page height / page width. */
fun Annot.bounds(aspect: Float): RectF {
    val out = RectF()
    var first = true
    fun add(l: Float, t: Float, r: Float, b: Float) {
        if (first) {
            out.set(l, t, r, b)
            first = false
        } else {
            out.left = min(out.left, l)
            out.top = min(out.top, t)
            out.right = max(out.right, r)
            out.bottom = max(out.bottom, b)
        }
    }
    when (type) {
        AnnotType.HIGHLIGHT, AnnotType.UNDERLINE, AnnotType.STRIKE ->
            rects.forEach { add(it.left, it.top, it.right, it.bottom) }
        AnnotType.INK, AnnotType.MARKER, AnnotType.RECT, AnnotType.CIRCLE, AnnotType.LINE, AnnotType.ARROW -> {
            val padU = strokeFrac / 2f
            val padV = padU / aspect
            points.forEach { add(it.x - padU, it.y - padV, it.x + padU, it.y + padV) }
        }
        AnnotType.TEXT -> {
            val p = points.firstOrNull()
            if (p != null) {
                val lines = text.split('\n')
                val longest = lines.maxOfOrNull { it.length } ?: 1
                val w = max(longest, 1) * sizeFrac * 0.55f
                val h = lines.size * sizeFrac * 1.2f / aspect
                add(p.x, p.y, p.x + w, p.y + h)
            }
        }
        AnnotType.NOTE -> {
            val p = points.firstOrNull()
            if (p != null) {
                val hu = NOTE_SIZE_FRAC / 2f
                val hv = hu / aspect
                add(p.x - hu, p.y - hv, p.x + hu, p.y + hv)
            }
        }
    }
    return out
}

private fun distToSegment(px: Float, py: Float, ax: Float, ay: Float, bx: Float, by: Float): Float {
    val dx = bx - ax
    val dy = by - ay
    val len2 = dx * dx + dy * dy
    if (len2 <= 1e-12f) return hypot(px - ax, py - ay)
    val t = (((px - ax) * dx + (py - ay) * dy) / len2).coerceIn(0f, 1f)
    return hypot(px - (ax + t * dx), py - (ay + t * dy))
}

/** Hit test. (u, v) normalised, [tol] in page-width units, [aspect] = height / width. */
fun Annot.hitTest(u: Float, v: Float, tol: Float, aspect: Float): Boolean {
    val y = v * aspect
    when (type) {
        AnnotType.INK, AnnotType.MARKER, AnnotType.LINE, AnnotType.ARROW -> {
            val reach = strokeFrac / 2f + tol
            if (points.size == 1) {
                val p = points[0]
                return hypot(u - p.x, y - p.y * aspect) <= reach
            }
            for (i in 0 until points.size - 1) {
                val a = points[i]
                val b = points[i + 1]
                if (distToSegment(u, y, a.x, a.y * aspect, b.x, b.y * aspect) <= reach) return true
            }
            return false
        }
        AnnotType.CIRCLE -> {
            if (points.size < 2) return false
            val l = min(points[0].x, points[1].x)
            val r = max(points[0].x, points[1].x)
            val t = min(points[0].y, points[1].y) * aspect
            val b = max(points[0].y, points[1].y) * aspect
            val cx = (l + r) / 2f
            val cy = (t + b) / 2f
            val rx = (r - l) / 2f + tol
            val ry = (b - t) / 2f + tol
            if (rx <= 0f || ry <= 0f) return false
            val nx = (u - cx) / rx
            val ny = (y - cy) / ry
            return nx * nx + ny * ny <= 1f
        }
        else -> {
            val bb = bounds(aspect)
            val tv = tol / aspect
            return u >= bb.left - tol && u <= bb.right + tol && v >= bb.top - tv && v <= bb.bottom + tv
        }
    }
}

fun Annot.movedBy(du: Float, dv: Float): Annot = copy(
    rects = rects.map { RectF(it.left + du, it.top + dv, it.right + du, it.bottom + dv) },
    points = points.map { PointF(it.x + du, it.y + dv) },
)

// ---------------------------------------------------------------- JSON

fun Annot.toJson(): JSONObject {
    val o = JSONObject()
    o.put("id", id)
    o.put("t", type.name)
    o.put("p", page)
    o.put("c", color)
    o.put("sw", strokeFrac.toDouble())
    o.put("sz", sizeFrac.toDouble())
    o.put("tx", text)
    o.put("cm", comment)
    o.put("cr", created)
    val r = JSONArray()
    rects.forEach {
        r.put(JSONArray().put(it.left.toDouble()).put(it.top.toDouble()).put(it.right.toDouble()).put(it.bottom.toDouble()))
    }
    o.put("r", r)
    val p = JSONArray()
    points.forEach { p.put(JSONArray().put(it.x.toDouble()).put(it.y.toDouble())) }
    o.put("pt", p)
    return o
}

fun annotFromJson(o: JSONObject): Annot? = runCatching {
    val type = AnnotType.valueOf(o.getString("t"))
    val rs = ArrayList<RectF>()
    o.optJSONArray("r")?.let { a ->
        for (i in 0 until a.length()) {
            val q = a.getJSONArray(i)
            rs += RectF(q.getDouble(0).toFloat(), q.getDouble(1).toFloat(), q.getDouble(2).toFloat(), q.getDouble(3).toFloat())
        }
    }
    val ps = ArrayList<PointF>()
    o.optJSONArray("pt")?.let { a ->
        for (i in 0 until a.length()) {
            val q = a.getJSONArray(i)
            ps += PointF(q.getDouble(0).toFloat(), q.getDouble(1).toFloat())
        }
    }
    Annot(
        id = o.getString("id"),
        type = type,
        page = o.getInt("p"),
        color = o.getInt("c"),
        strokeFrac = o.optDouble("sw", 0.003).toFloat(),
        sizeFrac = o.optDouble("sz", 0.03).toFloat(),
        rects = rs,
        points = ps,
        text = o.optString("tx", ""),
        comment = o.optString("cm", ""),
        created = o.optLong("cr", 0L),
    )
}.getOrNull()
