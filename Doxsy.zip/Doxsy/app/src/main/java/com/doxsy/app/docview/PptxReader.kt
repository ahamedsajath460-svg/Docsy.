package com.doxsy.app.docview

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayOutputStream
import kotlin.math.max
import kotlin.math.roundToLong

private const val MAX_IMAGE_PX = 1600
private const val MAX_MEDIA_BYTES = 40 * 1024 * 1024

/** Position and size in EMU (914400 per inch) on the slide. */
private class Box(val x: Long, val y: Long, val cx: Long, val cy: Long)

/** Group transform: maps a child's coordinates into the group's parent space. */
private class Grp(val ox: Long, val oy: Long, val chx: Long, val chy: Long, val sx: Double, val sy: Double)

/** One parsed shape or picture, with positions already mapped through its group transforms. */
private class Rec(
    val box: Box?,
    val fill: Int?,
    val line: Int?,
    val ellipse: Boolean,
    val paras: List<Para>,
    val image: ByteArray?,
    val ph: String?,
    val phIdx: String?,
)

/**
 * Reads .pptx slides: slide order and size, text boxes, pictures, solid fills, background colour
 * and speaker notes. Layout and animation are not reproduced.
 */
object PptxReader {
    private const val MAX_SLIDES = 400

    fun read(ctx: Context, uri: Uri): Deck {
        try {
            OoxmlPackage.open(ctx, uri, "PowerPoint").use { pkg ->
                if (!pkg.has("ppt/presentation.xml")) {
                    throw DocReadException("This is not a valid PowerPoint presentation (ppt/presentation.xml is missing).")
                }
                var sw = 9144000L // 10in x 7.5in default (4:3)
                var sh = 6858000L
                val slideRids = ArrayList<String>()
                pkg.open("ppt/presentation.xml")?.use { s ->
                    val p = newParser(s)
                    while (true) {
                        val ev = p.next()
                        if (ev == XmlPullParser.END_DOCUMENT) break
                        if (ev != XmlPullParser.START_TAG) continue
                        when (p.ln()) {
                            "sldSz" -> {
                                sw = p.attr("cx")?.toLongOrNull()?.takeIf { it > 0L } ?: sw
                                sh = p.attr("cy")?.toLongOrNull()?.takeIf { it > 0L } ?: sh
                            }
                            "sldId" -> relId(p)?.let { slideRids.add(it) }
                        }
                    }
                }
                val rels = pkg.rels("ppt/presentation.xml")
                val order = slideRids.mapNotNull { rels[it]?.target }.filter { pkg.has(it) }
                if (order.isEmpty()) throw DocReadException("This presentation has no readable slides.")

                val aspect = sw.toFloat() / sh.toFloat()
                val widthPt = sw / 12700f
                val media = HashMap<String, ByteArray?>()
                val layouts = HashMap<String, Map<String, Box>>()
                val slides = ArrayList<Slide>()
                for ((i, path) in order.withIndex()) {
                    if (i >= MAX_SLIDES) break
                    slides.add(readSlide(pkg, path, i, sw.toFloat(), sh.toFloat(), aspect, widthPt, layouts, media))
                }
                return Deck(slides)
            }
        } catch (e: DocReadException) {
            throw e
        } catch (e: OutOfMemoryError) {
            throw DocReadException("Not enough memory to open this presentation.", e)
        } catch (e: Exception) {
            throw DocReadException("This PowerPoint presentation could not be read. It may be corrupted.", e)
        }
    }

    private fun readSlide(
        pkg: OoxmlPackage,
        path: String,
        index: Int,
        sw: Float,
        sh: Float,
        aspect: Float,
        widthPt: Float,
        layouts: HashMap<String, Map<String, Box>>,
        media: HashMap<String, ByteArray?>,
    ): Slide {
        val rels = pkg.rels(path)
        val stream = pkg.open(path) ?: return Slide(index, aspect, null, emptyList(), null, widthPt)
        val parser = SlideParser(pkg, rels, media)
        val (bg, recs) = stream.use { parser.parseSlide(newParser(it)) }
        val layout = rels.values.firstOrNull { it.type == "slideLayout" }
            ?.let { layoutBoxes(pkg, it.target, layouts, media) } ?: emptyMap()
        val notes = rels.values.firstOrNull { it.type == "notesSlide" }?.let { r ->
            try {
                notesText(pkg, r.target, media)
            } catch (e: Exception) {
                null
            }
        }
        return Slide(index, aspect, bg, toElements(recs, layout, sw, sh), notes, widthPt)
    }

    /** Placeholder positions from a slide layout, keyed by "i:<idx>" and "t:<type>". */
    private fun layoutBoxes(
        pkg: OoxmlPackage,
        path: String,
        cache: HashMap<String, Map<String, Box>>,
        media: HashMap<String, ByteArray?>,
    ): Map<String, Box> {
        cache[path]?.let { return it }
        val out = HashMap<String, Box>()
        val recs = pkg.open(path)?.use { SlideParser(pkg, pkg.rels(path), media).parseSlide(newParser(it)).second }
            ?: emptyList()
        for (r in recs) {
            val b = r.box ?: continue
            val ph = r.ph ?: continue
            r.phIdx?.let { out["i:$it"] = b }
            out["t:$ph"] = b
        }
        cache[path] = out
        return out
    }

    private fun notesText(pkg: OoxmlPackage, path: String, media: HashMap<String, ByteArray?>): String? {
        val recs = pkg.open(path)?.use { SlideParser(pkg, pkg.rels(path), media).parseSlide(newParser(it)).second }
            ?: return null
        val text = recs.filter { it.ph == "body" }
            .flatMap { it.paras }
            .map { it.plain.trim() }
            .filter { it.isNotEmpty() }
            .joinToString("\n")
        return text.ifEmpty { null }
    }

    private fun toElements(recs: List<Rec>, layout: Map<String, Box>, sw: Float, sh: Float): List<SlideElement> {
        val out = ArrayList<SlideElement>()
        for (r in recs) {
            val b = boxOf(r, layout) ?: continue
            val x = b.x.toFloat() / sw
            val y = b.y.toFloat() / sh
            val w = b.cx.toFloat() / sw
            val h = b.cy.toFloat() / sh
            val img = r.image
            if (img != null) {
                out.add(SlideImage(x, y, w, h, img))
                continue
            }
            if (r.fill != null || r.line != null || r.ellipse) {
                out.add(SlideShape(x, y, w, h, r.fill, r.line, r.ellipse))
            }
            if (r.paras.any { it.plain.isNotBlank() }) out.add(SlideText(x, y, w, h, r.paras))
        }
        return out
    }

    /** A shape's own position, or the layout placeholder's position when it has none. */
    private fun boxOf(r: Rec, layout: Map<String, Box>): Box? {
        r.box?.let { return it }
        val ph = r.ph ?: return null
        val idx = r.phIdx
        return (if (idx != null) layout["i:$idx"] else null) ?: layout["t:$ph"]
    }

    private fun relId(p: XmlPullParser): String? {
        for (i in 0 until p.attributeCount) {
            val n = p.getAttributeName(i)
            if (n.substringAfter(':') == "id" && (n.contains(':') || p.getAttributePrefix(i) != null)) {
                return p.getAttributeValue(i)
            }
        }
        return null
    }
}

private fun isOn(v: String?): Boolean = v == "1" || v == "true"

private fun alignOf(v: String?): Align = when (v) {
    "ctr" -> Align.CENTER
    "r" -> Align.END
    "just", "dist" -> Align.JUSTIFY
    else -> Align.START
}

/** Decodes a picture, keeps it within [MAX_IMAGE_PX] and re-encodes it as PNG. Null if undecodable. */
private fun reencodePng(bytes: ByteArray): ByteArray? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
    val w = bounds.outWidth
    val h = bounds.outHeight
    if (w <= 0 || h <= 0) return null
    var sample = 1
    while (max(w, h) / sample > MAX_IMAGE_PX) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    val bmp: Bitmap = try {
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return null
    } catch (e: OutOfMemoryError) {
        return null
    }
    try {
        val out = ByteArrayOutputStream()
        return if (bmp.compress(Bitmap.CompressFormat.PNG, 100, out)) out.toByteArray() else null
    } finally {
        bmp.recycle()
    }
}

/** Walks one slide, layout or notes part. Each method consumes the events of the element it is called for. */
private class SlideParser(
    private val pkg: OoxmlPackage,
    private val rels: Map<String, Rel>,
    private val media: HashMap<String, ByteArray?>,
) {
    private class SpPr(val box: LongArray?, val fill: Int?, val line: Int?, val ellipse: Boolean)

    /** Returns the background colour and the shapes of the slide's spTree. */
    fun parseSlide(p: XmlPullParser): Pair<Int?, List<Rec>> {
        var bg: Int? = null
        val recs = ArrayList<Rec>()
        loop@ while (true) {
            val ev = p.next()
            if (ev == XmlPullParser.END_DOCUMENT) break
            if (ev != XmlPullParser.START_TAG) continue
            when (p.ln()) {
                "bg" -> bg = colorOf(p, "bg")
                "spTree" -> {
                    tree(p, "spTree", emptyList(), recs)
                    break@loop
                }
            }
        }
        return Pair(bg, recs)
    }

    /** Children of spTree or grpSp, up to the matching [endName]. */
    private fun tree(p: XmlPullParser, endName: String, groups: List<Grp>, out: MutableList<Rec>) {
        var self: Grp? = null
        while (true) {
            val ev = p.next()
            if (ev == XmlPullParser.END_DOCUMENT) return
            if (ev == XmlPullParser.END_TAG) {
                if (p.ln() == endName) return
                continue
            }
            if (ev != XmlPullParser.START_TAG) continue
            val s = self
            val here = if (s == null) groups else groups + s
            when (p.ln()) {
                "grpSpPr" -> self = groupXf(p)
                "sp" -> out.add(shape(p, here))
                "pic" -> pic(p, here)?.let { out.add(it) }
                "grpSp" -> tree(p, "grpSp", here, out)
                "AlternateContent", "Choice" -> Unit
                else -> p.skipTree()
            }
        }
    }

    private fun groupXf(p: XmlPullParser): Grp {
        var ox = 0L
        var oy = 0L
        var cx = 0L
        var cy = 0L
        var chx = 0L
        var chy = 0L
        var chcx = 0L
        var chcy = 0L
        while (true) {
            val ev = p.next()
            if (ev == XmlPullParser.END_DOCUMENT) break
            if (ev == XmlPullParser.END_TAG) {
                if (p.ln() == "grpSpPr") break
                continue
            }
            if (ev != XmlPullParser.START_TAG) continue
            when (p.ln()) {
                "off" -> {
                    ox = p.attr("x")?.toLongOrNull() ?: ox
                    oy = p.attr("y")?.toLongOrNull() ?: oy
                }
                "ext" -> {
                    cx = p.attr("cx")?.toLongOrNull() ?: cx
                    cy = p.attr("cy")?.toLongOrNull() ?: cy
                }
                "chOff" -> {
                    chx = p.attr("x")?.toLongOrNull() ?: chx
                    chy = p.attr("y")?.toLongOrNull() ?: chy
                }
                "chExt" -> {
                    chcx = p.attr("cx")?.toLongOrNull() ?: chcx
                    chcy = p.attr("cy")?.toLongOrNull() ?: chcy
                }
            }
        }
        val sx = if (chcx > 0L && cx > 0L) cx.toDouble() / chcx else 1.0
        val sy = if (chcy > 0L && cy > 0L) cy.toDouble() / chcy else 1.0
        return Grp(ox, oy, chx, chy, sx, sy)
    }

    private fun mapBox(x: Long, y: Long, cx: Long, cy: Long, groups: List<Grp>): Box {
        var nx = x.toDouble()
        var ny = y.toDouble()
        var w = cx.toDouble()
        var h = cy.toDouble()
        for (g in groups.asReversed()) {
            nx = g.ox + (nx - g.chx) * g.sx
            ny = g.oy + (ny - g.chy) * g.sy
            w *= g.sx
            h *= g.sy
        }
        return Box(nx.roundToLong(), ny.roundToLong(), w.roundToLong(), h.roundToLong())
    }

    private fun shape(p: XmlPullParser, groups: List<Grp>): Rec {
        var sp: SpPr? = null
        var paras: List<Para> = emptyList()
        var ph: String? = null
        var phIdx: String? = null
        while (true) {
            val ev = p.next()
            if (ev == XmlPullParser.END_DOCUMENT) break
            if (ev == XmlPullParser.END_TAG) {
                if (p.ln() == "sp") break
                continue
            }
            if (ev != XmlPullParser.START_TAG) continue
            when (p.ln()) {
                "nvSpPr", "nvPr" -> Unit
                "ph" -> {
                    ph = p.attr("type") ?: "obj"
                    phIdx = p.attr("idx")
                }
                "spPr" -> sp = spPr(p)
                "txBody" -> paras = txBody(p)
                else -> p.skipTree()
            }
        }
        val s = sp
        val box = s?.box?.let { mapBox(it[0], it[1], it[2], it[3], groups) }
        return Rec(box, s?.fill, s?.line, s?.ellipse ?: false, paras, null, ph, phIdx)
    }

    private fun spPr(p: XmlPullParser): SpPr {
        var ox: Long? = null
        var oy: Long? = null
        var ex: Long? = null
        var ey: Long? = null
        var fill: Int? = null
        var line: Int? = null
        var ellipse = false
        var inLn = false
        while (true) {
            val ev = p.next()
            if (ev == XmlPullParser.END_DOCUMENT) break
            if (ev == XmlPullParser.END_TAG) {
                if (p.ln() == "spPr") break
                if (p.ln() == "ln") inLn = false
                continue
            }
            if (ev != XmlPullParser.START_TAG) continue
            when (p.ln()) {
                "off" -> {
                    ox = p.attr("x")?.toLongOrNull() ?: ox
                    oy = p.attr("y")?.toLongOrNull() ?: oy
                }
                "ext" -> {
                    ex = p.attr("cx")?.toLongOrNull() ?: ex
                    ey = p.attr("cy")?.toLongOrNull() ?: ey
                }
                "prstGeom" -> ellipse = p.attr("prst") == "ellipse"
                "ln" -> inLn = true
                "solidFill" -> {
                    val c = colorOf(p, "solidFill")
                    if (inLn) line = c else fill = c
                }
                "noFill" -> {
                    if (!inLn) fill = null
                }
                "effectLst", "custGeom", "scene3d", "sp3d", "extLst" -> p.skipTree()
            }
        }
        val a = ox
        val b = oy
        val c = ex
        val d = ey
        val box = if (a != null && b != null && c != null && d != null) longArrayOf(a, b, c, d) else null
        return SpPr(box, fill, line, ellipse)
    }

    private fun pic(p: XmlPullParser, groups: List<Grp>): Rec? {
        var embed: String? = null
        var sp: SpPr? = null
        while (true) {
            val ev = p.next()
            if (ev == XmlPullParser.END_DOCUMENT) break
            if (ev == XmlPullParser.END_TAG) {
                if (p.ln() == "pic") break
                continue
            }
            if (ev != XmlPullParser.START_TAG) continue
            when (p.ln()) {
                "nvPicPr", "blipFill" -> Unit
                "blip" -> {
                    embed = p.attr("embed")
                    p.skipTree()
                }
                "spPr" -> sp = spPr(p)
                else -> p.skipTree()
            }
        }
        val a = sp?.box ?: return null
        val target = embed?.let { rels[it]?.target } ?: return null
        val bytes = imageBytes(target) ?: return null
        val b = mapBox(a[0], a[1], a[2], a[3], groups)
        return Rec(b, null, null, false, emptyList(), bytes, null, null)
    }

    private fun imageBytes(path: String): ByteArray? {
        if (media.containsKey(path)) return media[path]
        val raw = try {
            pkg.readBytes(path, MAX_MEDIA_BYTES)
        } catch (e: Exception) {
            null
        }
        val out = raw?.let { reencodePng(it) }
        media[path] = out
        return out
    }

    private fun txBody(p: XmlPullParser): List<Para> {
        val out = ArrayList<Para>()
        while (true) {
            val ev = p.next()
            if (ev == XmlPullParser.END_DOCUMENT) break
            if (ev == XmlPullParser.END_TAG) {
                if (p.ln() == "txBody") break
                continue
            }
            if (ev != XmlPullParser.START_TAG) continue
            if (p.ln() == "p") out.add(para(p)) else p.skipTree()
        }
        return out
    }

    private fun para(p: XmlPullParser): Para {
        val runs = ArrayList<TextRun>()
        var align = Align.START
        var level = 0
        var bullet: String? = null
        while (true) {
            val ev = p.next()
            if (ev == XmlPullParser.END_DOCUMENT) break
            if (ev == XmlPullParser.END_TAG) {
                if (p.ln() == "p") break
                continue
            }
            if (ev != XmlPullParser.START_TAG) continue
            when (p.ln()) {
                "pPr" -> {
                    align = alignOf(p.attr("algn"))
                    level = (p.attr("lvl")?.toIntOrNull() ?: 0).coerceIn(0, 8)
                    bullet = pPrBullet(p)
                }
                "r", "fld" -> runs.add(textRun(p))
                "br" -> {
                    p.skipTree()
                    runs.add(TextRun("\n"))
                }
                else -> p.skipTree()
            }
        }
        return Para(runs, 0, align, bullet, level)
    }

    private fun pPrBullet(p: XmlPullParser): String? {
        var b: String? = null
        while (true) {
            val ev = p.next()
            if (ev == XmlPullParser.END_DOCUMENT) break
            if (ev == XmlPullParser.END_TAG) {
                if (p.ln() == "pPr") break
                continue
            }
            if (ev != XmlPullParser.START_TAG) continue
            when (p.ln()) {
                "buChar" -> b = p.attr("char") ?: "•"
                "buAutoNum" -> b = "•"
                "buNone" -> b = null
                else -> p.skipTree()
            }
        }
        return b
    }

    /** A text run (`a:r`) or field (`a:fld`). */
    private fun textRun(p: XmlPullParser): TextRun {
        val endName = p.ln()
        val text = StringBuilder()
        var bold = false
        var italic = false
        var underline = false
        var strike = false
        var size = 0f
        var color = 0
        while (true) {
            val ev = p.next()
            if (ev == XmlPullParser.END_DOCUMENT) break
            if (ev == XmlPullParser.END_TAG) {
                if (p.ln() == endName) break
                continue
            }
            if (ev != XmlPullParser.START_TAG) continue
            when (p.ln()) {
                "rPr" -> {
                    bold = isOn(p.attr("b"))
                    italic = isOn(p.attr("i"))
                    underline = p.attr("u").let { it != null && it != "none" }
                    strike = p.attr("strike").let { it != null && it != "noStrike" }
                    size = (p.attr("sz")?.toFloatOrNull() ?: 0f) / 100f
                    color = rPrColor(p)
                }
                "t" -> text.append(p.nextText())
                else -> p.skipTree()
            }
        }
        return TextRun(text.toString(), bold, italic, underline, strike, size, color)
    }

    /** Colour from the children of an rPr, consuming up to its end tag. 0 when none. */
    private fun rPrColor(p: XmlPullParser): Int {
        var c = 0
        while (true) {
            val ev = p.next()
            if (ev == XmlPullParser.END_DOCUMENT) break
            if (ev == XmlPullParser.END_TAG) {
                if (p.ln() == "rPr") break
                continue
            }
            if (ev != XmlPullParser.START_TAG) continue
            if (p.ln() == "solidFill") c = colorOf(p, "solidFill") ?: c else p.skipTree()
        }
        return c
    }

    /** First srgbClr value inside [endName], as ARGB. Scheme colours are not resolved (null). */
    private fun colorOf(p: XmlPullParser, endName: String): Int? {
        var res: Int? = null
        while (true) {
            val ev = p.next()
            if (ev == XmlPullParser.END_DOCUMENT) break
            if (ev == XmlPullParser.END_TAG) {
                if (p.ln() == endName) break
                continue
            }
            if (ev == XmlPullParser.START_TAG && p.ln() == "srgbClr" && res == null) {
                res = parseHexColor(p.attr("val"))
            }
        }
        return res
    }
}
