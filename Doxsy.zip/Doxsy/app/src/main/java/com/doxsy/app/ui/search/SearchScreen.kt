package com.doxsy.app.ui.search

import android.net.Uri
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.doxsy.app.data.DocEntry
import com.doxsy.app.data.Prefs
import com.doxsy.app.fileman.DeviceFiles
import com.doxsy.app.ui.MenuAction
import com.doxsy.app.ui.home.DocListRow
import com.doxsy.app.ui.home.CategoryHeader
import com.doxsy.app.ui.home.EmptyList
import com.doxsy.app.ui.home.FileMenuHost
import com.doxsy.app.ui.home.groupByFolder
import com.doxsy.app.ui.home.rememberFileMenuState
import com.doxsy.app.ui.home.withFolders
import androidx.compose.foundation.layout.Box
import com.doxsy.app.util.FileUtils

/** Search tab: finds files by name among recent and starred documents. */
@Composable
fun SearchScreen(prefs: Prefs, onOpen: (DocEntry) -> Unit) {
    val ctx = LocalContext.current
    val recents by prefs.recents.state.collectAsState()
    val favourites by prefs.favourites.state.collectAsState()
    val device by DeviceFiles.files.collectAsState()
    var query by rememberSaveable { mutableStateOf("") }
    val q = query.trim()

    val results = remember(q, recents, favourites, device) {
        if (q.isEmpty()) emptyList()
        else (recents + favourites + device).distinctBy { it.uri }.filter { it.name.contains(q, ignoreCase = true) }
    }

    val categories = remember(results, device) { groupByFolder(withFolders(results, device)) }
    val fileMenu = rememberFileMenuState()

    Box(Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            placeholder = { Text("Search files on your phone") },
            leadingIcon = { Icon(Icons.Rounded.Search, null) },
            trailingIcon = {
                if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Rounded.Close, "Clear") }
            },
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
        )
        when {
            q.isEmpty() -> EmptyList(
                Icons.Rounded.Search,
                "Search your files",
                "Type a file name to find it among your PDFs and documents.",
            )
            results.isEmpty() -> EmptyList(
                Icons.Rounded.Search,
                "No results",
                "Nothing matches \"$q\".",
            )
            else -> LazyColumn {
                categories.forEach { cat ->
                    item(key = "h_" + cat.title) { CategoryHeader(cat.title) }
                    items(cat.files, key = { cat.title + it.uri }) { e ->
                        DocListRow(
                            entry = e,
                            selecting = false,
                            selected = false,
                            onClick = { onOpen(e) },
                            onLongClick = { fileMenu.show(e) },
                            menu = emptyList(),
                            onMore = { fileMenu.show(e) },
                        )
                    }
                }
            }
        }
    }
    FileMenuHost(fileMenu, prefs, onOpen = onOpen)
    }
}
