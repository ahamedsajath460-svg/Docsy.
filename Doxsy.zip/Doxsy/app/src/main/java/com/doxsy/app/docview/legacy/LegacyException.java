package com.doxsy.app.docview.legacy;

/** Raised by the legacy (binary Office) readers. {@link #passwordProtected} is true for encrypted files. */
public final class LegacyException extends Exception {
    public final boolean passwordProtected;

    public LegacyException(String message) {
        this(message, false, null);
    }

    public LegacyException(String message, boolean passwordProtected, Throwable cause) {
        super(message, cause);
        this.passwordProtected = passwordProtected;
    }
}
