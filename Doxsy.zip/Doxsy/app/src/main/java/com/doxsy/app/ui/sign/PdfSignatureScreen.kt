package com.doxsy.app.ui.sign

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.provider.DocumentsContract
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Create
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.RotateLeft
import androidx.compose.material.icons.rounded.RotateRight
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.key
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.doxsy.app.data.Prefs
import com.doxsy.app.pdf.OpenResult
import com.doxsy.app.pdf.PdfSession
import com.doxsy.app.sign.PdfSigner
import com.doxsy.app.sign.SavedSignature
import com.doxsy.app.sign.SignatureStore
import com.doxsy.app.ui.EmptyState
import com.doxsy.app.ui.SkeletonBox
import com.doxsy.app.util.AppFiles
import com.doxsy.app.util.FileUtils
import com.doxsy.app.util.OutputStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import kotlin.math.max
import kotlin.math.roundToInt

private sealed interface LoadState {
    data object Loading : LoadState
    data object Ready : LoadState
    data class Failed(val message: String) : LoadState
}

/** A signature placed on a page. Coordinates are fractions of the displayed page (top-left origin). */
private data class Placed(
    val id: Long,
    val sig: SavedSignature,
    val page: Int,
    val cx: Float,
    val cy: Float,
    val w: Float,
    val rot: Float,
)

private const val NOTICE_SHORT =
    "These are ordinary signature IMAGES inserted into the PDF. They are not cryptographic digital " +
        "signatures: there is no certificate and no tamper detection."

/**
 * PDF Signature module. [initialUri] = null shows the landing page (open a PDF, manage saved
 * signatures); otherwise the placement editor opens directly.
 */
@Composable
fun PdfSignatureScreen(
    prefs: Prefs,
    initialUri: Uri?,
    onBack: () -> Unit,
    onOpenPdf: (Uri) -> Unit,
) {
    val ctx = LocalContext.current
    var pdf by remember { mutableStateOf(initialUri) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            pdf = uri
        }
    }
    val chosen = pdf
    if (chosen == null) {
        BackHandler { onBack() }
        LandingPane(onBack = onBack, onPick = { picker.launch(arrayOf("application/pdf")) })
    } else {
        SignEditor(
            uri = chosen,
            onClose = { if (initialUri != null) onBack() else pdf = null },
            onOpenPdf = onOpenPdf,
        )
    }
}

@Composable
private fun TopRow(title: String, onBack: () -> Unit, subtitle: String? = null, actions: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") }
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (subtitle != null) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        actions()
    }
}

// ---------------------------------------------------------------- Landing

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LandingPane(onBack: () -> Unit, onPick: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val store = remember { SignatureStore(ctx) }
    var sigs by remember { mutableStateOf(store.list()) }
    var showPad by remember { mutableStateOf(false) }
    var showExplainer by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<SavedSignature?>(null) }
    var deleteTarget by remember { mutableStateOf<SavedSignature?>(null) }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding(),
    ) {
        TopRow("PDF Signature", onBack) {
            IconButton(onClick = { showExplainer = true }) { Icon(Icons.Rounded.Info, "Image signature vs digital signature") }
        }
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item { NoticeCard(onLearnMore = { showExplainer = true }) }
            item {
                Button(onClick = onPick, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.PictureAsPdf, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Open a PDF to sign")
                }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("My signatures", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    OutlinedButton(onClick = { showPad = true }) {
                        Icon(Icons.Rounded.Create, null)
                        Spacer(Modifier.width(6.dp))
                        Text("New")
                    }
                }
            }
            if (sigs.isEmpty()) {
                item {
                    EmptyState(
                        Icons.Rounded.Create,
                        "No saved signatures",
                        "Draw your signature once and reuse it on any PDF.",
                    )
                }
            } else {
                items(sigs, key = { it.id }) { sig ->
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    ) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            SignatureThumb(store, sig, Modifier.size(width = 104.dp, height = 60.dp))
                            Spacer(Modifier.width(12.dp))
                            Text(sig.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            IconButton(onClick = { renameTarget = sig }) { Icon(Icons.Rounded.Edit, "Rename signature") }
                            IconButton(onClick = { deleteTarget = sig }) { Icon(Icons.Rounded.Delete, "Delete signature") }
                        }
                    }
                }
            }
        }
    }

    if (showPad) {
        SignaturePadDialog(
            onDismiss = { showPad = false },
            onSave = { name, bmp ->
                showPad = false
                scope.launch {
                    val r = withContext(Dispatchers.IO) { runCatching { store.save(name, bmp) } }
                    if (r.isFailure) FileUtils.toast(ctx, "Could not save the signature.")
                    sigs = store.list()
                }
            },
        )
    }
    if (showExplainer) ExplainerSheet(onDismiss = { showExplainer = false })
    renameTarget?.let { t ->
        var text by remember(t.id) { mutableStateOf(t.name) }
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("Rename signature") },
            text = { OutlinedTextField(value = text, onValueChange = { text = it.take(40) }, singleLine = true) },
            confirmButton = {
                TextButton(
                    onClick = {
                        store.rename(t.id, text)
                        sigs = store.list()
                        renameTarget = null
                    },
                    enabled = text.isNotBlank(),
                ) { Text("Rename") }
            },
            dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("Cancel") } },
        )
    }
    deleteTarget?.let { t ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete ${t.name}?") },
            text = { Text("The saved signature image is removed from Doxsy. PDFs you already signed are not affected.") },
            confirmButton = {
                TextButton(onClick = {
                    store.delete(t.id)
                    sigs = store.list()
                    deleteTarget = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun NoticeCard(onLearnMore: () -> Unit) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Info, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Text("Image signature, not a digital signature", style = MaterialTheme.typography.titleSmall)
            }
            Spacer(Modifier.height(6.dp))
            Text(NOTICE_SHORT, style = MaterialTheme.typography.bodyMedium)
            TextButton(onClick = onLearnMore) { Text("Learn more") }
        }
    }
}

@Composable
private fun SignatureThumb(store: SignatureStore, sig: SavedSignature, modifier: Modifier = Modifier) {
    val bmp by produceState<Bitmap?>(null, sig.id) {
        value = withContext(Dispatchers.IO) { store.load(sig) }
    }
    Box(
        modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color.White)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(10.dp))
            .padding(4.dp),
        contentAlignment = Alignment.Center,
    ) {
        val b = bmp
        if (b != null) {
            Image(b.asImageBitmap(), sig.name, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ExplainerSheet(onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("Digital signature vs image signature", style = MaterialTheme.typography.titleLarge)
            Text("Image signature (what Doxsy does)", style = MaterialTheme.typography.titleSmall)
            Text(
                "Your handwritten signature is placed on the page as a picture and saved inside the PDF. " +
                    "It looks like a signature and is accepted for many everyday forms, but anyone with the file " +
                    "could copy it, and nothing in the PDF proves who added it or whether the document was " +
                    "changed afterwards.",
                style = MaterialTheme.typography.bodyMedium,
            )
            Text("Cryptographic digital signature (not offered)", style = MaterialTheme.typography.titleSmall)
            Text(
                "A digital signature uses a certificate and a private key to seal the document. PDF readers " +
                    "can then show who signed and warn if the file changed. Doxsy does NOT create these. If you " +
                    "need one (contracts, legal or regulated documents), use a dedicated signing service or " +
                    "desktop software.",
                style = MaterialTheme.typography.bodyMedium,
            )
            Text(
                "Your original PDF is never modified: signing always produces a new file.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Button(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("Got it") }
        }
    }
}

// ---------------------------------------------------------------- Editor

private fun ensurePdfName(n: String): String {
    val t = AppFiles.safeName(n)
    return if (t.endsWith(".pdf", ignoreCase = true)) t else "$t.pdf"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SignEditor(uri: Uri, onClose: () -> Unit, onOpenPdf: (Uri) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val store = remember { SignatureStore(ctx) }
    val displayName = remember(uri) { FileUtils.displayName(ctx, uri) }

    var load by remember(uri) { mutableStateOf<LoadState>(LoadState.Loading) }
    var session by remember(uri) { mutableStateOf<PdfSession?>(null) }
    val placements = remember(uri) { mutableStateListOf<Placed>() }
    var selected by remember(uri) { mutableStateOf<Long?>(null) }
    val sigBitmaps = remember { mutableStateMapOf<String, ImageBitmap>() }
    var sigs by remember { mutableStateOf(store.list()) }

    var showAdd by remember { mutableStateOf(false) }
    var showPad by remember { mutableStateOf(false) }
    var showSave by remember { mutableStateOf(false) }
    var showDiscard by remember { mutableStateOf(false) }
    var showExplainer by remember { mutableStateOf(false) }
    var showFirstUse by remember { mutableStateOf(!store.infoSeen) }
    var busy by remember { mutableStateOf(false) }
    var savedUri by remember(uri) { mutableStateOf<Uri?>(null) }
    var savedWhere by remember(uri) { mutableStateOf("") }
    var fileName by remember(uri) {
        mutableStateOf(ensurePdfName(displayName.removeSuffix(".pdf").removeSuffix(".PDF") + "-signed.pdf"))
    }

    LaunchedEffect(uri) {
        load = LoadState.Loading
        when (val r = PdfSession.open(ctx, uri)) {
            is OpenResult.Success -> {
                session = r.session
                r.session.loadPageSizes()
                load = LoadState.Ready
            }
            is OpenResult.PasswordRequired, is OpenResult.WrongPassword ->
                load = LoadState.Failed("This PDF is password-protected. Remove the password in Tools first, then sign it.")
            is OpenResult.Failure -> load = LoadState.Failed(r.message)
        }
    }
    DisposableEffect(uri) {
        onDispose { session?.close() }
    }

    fun update(id: Long, f: (Placed) -> Placed) {
        val i = placements.indexOfFirst { it.id == id }
        if (i >= 0) placements[i] = f(placements[i])
    }

    fun requestClose() {
        if (placements.isEmpty()) onClose() else showDiscard = true
    }
    BackHandler { requestClose() }

    val listState = rememberLazyListState()
    val visiblePage by remember { derivedStateOf { listState.firstVisibleItemIndex } }
    val pageCount = session?.pageCount ?: 0

    fun addPlacement(sig: SavedSignature) {
        scope.launch {
            if (sig.id !in sigBitmaps) {
                val bmp = withContext(Dispatchers.IO) { store.load(sig) }
                if (bmp == null) {
                    FileUtils.toast(ctx, "That signature image is missing.")
                    return@launch
                }
                sigBitmaps[sig.id] = bmp.asImageBitmap()
            }
            val id = System.nanoTime()
            val page = visiblePage.coerceIn(0, max(0, pageCount - 1))
            placements.add(Placed(id, sig, page, 0.5f, 0.72f, 0.32f, 0f))
            selected = id
        }
    }

    fun buildItems(): List<PdfSigner.Item> = placements.map {
        PdfSigner.Item(store.file(it.sig), it.sig.aspect, it.page, it.cx, it.cy, it.w, it.rot)
    }

    fun saveToDoxsy(thenShare: Boolean) {
        if (busy) return
        scope.launch {
            busy = true
            val items = buildItems()
            val name = ensurePdfName(fileName)
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    OutputStore.write(ctx, name, "application/pdf") { os -> PdfSigner.export(ctx, uri, items, os) }
                }
            }
            busy = false
            result.onSuccess {
                savedUri = it
                savedWhere = OutputStore.label(ctx)
                if (thenShare) FileUtils.share(ctx, it, "application/pdf")
            }.onFailure { FileUtils.toast(ctx, PdfSigner.describe(it)) }
        }
    }

    val saveAs = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { target ->
        if (target != null) {
            scope.launch {
                busy = true
                val items = buildItems()
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        val os = ctx.contentResolver.openOutputStream(target, "w")
                            ?: throw IOException("Could not write to that location.")
                        os.use { PdfSigner.export(ctx, uri, items, it) }
                    }
                }
                busy = false
                result.onSuccess {
                    savedUri = target
                    savedWhere = "the location you chose"
                }.onFailure {
                    runCatching { DocumentsContract.deleteDocument(ctx.contentResolver, target) }
                    FileUtils.toast(ctx, PdfSigner.describe(it))
                }
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding(),
    ) {
        TopRow(
            title = displayName,
            onBack = { requestClose() },
            subtitle = if (pageCount > 0) "Page ${visiblePage.coerceIn(0, pageCount - 1) + 1} of $pageCount" else null,
        ) {
            IconButton(onClick = { showExplainer = true }) { Icon(Icons.Rounded.Info, "Image signature vs digital signature") }
            IconButton(onClick = { showSave = true }, enabled = placements.isNotEmpty()) {
                Icon(Icons.Rounded.Save, "Save signed PDF")
            }
        }

        val state = load
        val sess = session
        when {
            state is LoadState.Failed -> Column(
                Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                EmptyState(Icons.Rounded.PictureAsPdf, "Cannot open this PDF", state.message, actionLabel = "Back", onAction = onClose)
            }
            state is LoadState.Loading || sess == null -> Column(Modifier.weight(1f).padding(16.dp)) {
                SkeletonBox(Modifier.fillMaxWidth().height(420.dp), 16)
            }
            else -> {
                if (placements.isEmpty()) {
                    Text(
                        "Tap \"Add signature\", then drag it where it belongs. Pinch to resize, twist with two fingers to rotate.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                    )
                }
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentPadding = PaddingValues(vertical = 8.dp),
                ) {
                    items(sess.pageCount, key = { it }) { p ->
                        PageWithSignatures(
                            session = sess,
                            page = p,
                            total = sess.pageCount,
                            placed = placements.filter { it.page == p },
                            bitmaps = sigBitmaps,
                            selected = selected,
                            onSelect = { selected = it },
                            onChange = { id, f -> update(id, f) },
                        )
                    }
                }
            }
        }

        // ---- Bottom toolbar
        Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 3.dp) {
            Column(
                Modifier
                    .navigationBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                val sel = placements.firstOrNull { it.id == selected }
                if (sel != null) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        IconButton(onClick = { update(sel.id) { it.copy(rot = it.rot - 15f) } }) {
                            Icon(Icons.Rounded.RotateLeft, "Rotate left")
                        }
                        IconButton(onClick = { update(sel.id) { it.copy(rot = it.rot + 15f) } }) {
                            Icon(Icons.Rounded.RotateRight, "Rotate right")
                        }
                        IconButton(onClick = { update(sel.id) { it.copy(w = (it.w * 0.9f).coerceIn(MIN_W, MAX_W)) } }) {
                            Icon(Icons.Rounded.Remove, "Make smaller")
                        }
                        IconButton(onClick = { update(sel.id) { it.copy(w = (it.w * 1.1f).coerceIn(MIN_W, MAX_W)) } }) {
                            Icon(Icons.Rounded.Add, "Make larger")
                        }
                        IconButton(onClick = {
                            placements.removeAll { it.id == sel.id }
                            selected = null
                        }) { Icon(Icons.Rounded.Delete, "Delete signature", tint = MaterialTheme.colorScheme.error) }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { sigs = store.list(); showAdd = true },
                        enabled = load is LoadState.Ready,
                        modifier = Modifier.weight(1f),
                    ) {
                        Icon(Icons.Rounded.Create, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Add signature")
                    }
                    OutlinedButton(onClick = { showSave = true }, enabled = placements.isNotEmpty()) {
                        Icon(Icons.Rounded.Save, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Save")
                    }
                }
            }
        }
    }

    // ---- Sheets and dialogs
    if (showAdd) {
        ModalBottomSheet(
            onDismissRequest = { showAdd = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        ) {
            Column(
                Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 24.dp)
                    .navigationBarsPadding(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text("Choose a signature", style = MaterialTheme.typography.titleLarge)
                Button(
                    onClick = {
                        showAdd = false
                        showPad = true
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Icon(Icons.Rounded.Create, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Draw a new signature")
                }
                if (sigs.isEmpty()) {
                    Text(
                        "No saved signatures yet. A new one is saved automatically so you can reuse it.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                sigs.forEach { sig ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .clickable {
                                showAdd = false
                                addPlacement(sig)
                            }
                            .padding(6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        SignatureThumb(store, sig, Modifier.size(width = 104.dp, height = 60.dp))
                        Spacer(Modifier.width(12.dp))
                        Text(sig.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }

    if (showPad) {
        SignaturePadDialog(
            onDismiss = { showPad = false },
            onSave = { name, bmp ->
                showPad = false
                scope.launch {
                    val r = withContext(Dispatchers.IO) { runCatching { store.save(name, bmp) } }
                    val saved = r.getOrNull()
                    if (saved == null) {
                        FileUtils.toast(ctx, "Could not save the signature.")
                    } else {
                        sigs = store.list()
                        addPlacement(saved)
                    }
                }
            },
        )
    }

    if (showSave) {
        ModalBottomSheet(
            onDismissRequest = { if (!busy) showSave = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        ) {
            Column(
                Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 24.dp)
                    .navigationBarsPadding(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text("Save signed PDF", style = MaterialTheme.typography.titleLarge)
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Image signature, not a digital signature", style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(4.dp))
                        Text(NOTICE_SHORT, style = MaterialTheme.typography.bodySmall)
                        TextButton(onClick = { showExplainer = true }) { Text("Learn more") }
                    }
                }
                Text(
                    "${placements.size} signature(s) will be embedded in a NEW file. Your original PDF is not changed.",
                    style = MaterialTheme.typography.bodyMedium,
                )
                OutlinedTextField(
                    value = fileName,
                    onValueChange = { fileName = it },
                    label = { Text("File name") },
                    singleLine = true,
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth(),
                )
                if (busy) {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                    Text("Embedding signatures...", style = MaterialTheme.typography.bodySmall)
                }
                Button(
                    onClick = { saveToDoxsy(false) },
                    enabled = !busy && fileName.isNotBlank(),
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Save signed PDF") }
                OutlinedButton(
                    onClick = { saveAs.launch(ensurePdfName(fileName)) },
                    enabled = !busy && fileName.isNotBlank(),
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Save as new document...") }
                OutlinedButton(
                    onClick = {
                        val s = savedUri
                        if (s != null) FileUtils.share(ctx, s, "application/pdf") else saveToDoxsy(true)
                    },
                    enabled = !busy && fileName.isNotBlank(),
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Share signed PDF") }
                val done = savedUri
                if (done != null) {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text("Saved to $savedWhere", style = MaterialTheme.typography.titleSmall, textAlign = TextAlign.Start)
                            Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = {
                                    showSave = false
                                    onOpenPdf(done)
                                }) { Text("Reopen signed PDF") }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showExplainer) ExplainerSheet(onDismiss = { showExplainer = false })

    if (showFirstUse) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Image signature, not a digital signature") },
            text = { Text(NOTICE_SHORT + "\n\nYour original PDF is never changed; a new signed copy is saved.") },
            confirmButton = {
                TextButton(onClick = {
                    store.infoSeen = true
                    showFirstUse = false
                }) { Text("I understand") }
            },
            dismissButton = {
                TextButton(onClick = { showExplainer = true }) { Text("Learn more") }
            },
        )
    }

    if (showDiscard) {
        AlertDialog(
            onDismissRequest = { showDiscard = false },
            title = { Text("Leave without saving?") },
            text = { Text("Your placed signatures have not been saved to a PDF yet.") },
            confirmButton = {
                TextButton(onClick = {
                    showDiscard = false
                    onClose()
                }) { Text("Leave") }
            },
            dismissButton = { TextButton(onClick = { showDiscard = false }) { Text("Stay") } },
        )
    }
}

private const val MIN_W = 0.06f
private const val MAX_W = 0.95f

@Composable
private fun PageWithSignatures(
    session: PdfSession,
    page: Int,
    total: Int,
    placed: List<Placed>,
    bitmaps: Map<String, ImageBitmap>,
    selected: Long?,
    onSelect: (Long?) -> Unit,
    onChange: (Long, (Placed) -> Placed) -> Unit,
) {
    val density = LocalDensity.current
    BoxWithConstraints(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
    ) {
        val pageW = maxWidth
        val pageH = pageW * session.aspect(page, 0)
        val pxW = with(density) { pageW.toPx() }
        val pxH = with(density) { pageH.toPx() }
        var bmp by remember(page) { mutableStateOf<Bitmap?>(null) }
        LaunchedEffect(page, pxW) {
            bmp = session.renderAsync(page, pxW.roundToInt().coerceAtLeast(64), 0)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier
                    .size(pageW, pageH)
                    .background(Color.White)
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    .pointerInput(Unit) { detectTapGestures(onTap = { onSelect(null) }) },
            ) {
                val b = bmp
                if (b != null) {
                    val img = remember(b) { b.asImageBitmap() }
                    Image(img, "Page ${page + 1}", Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
                } else {
                    SkeletonBox(Modifier.fillMaxSize(), 0)
                }
                placed.forEach { p ->
                    key(p.id) {
                        SignatureOverlay(
                            p = p,
                            image = bitmaps[p.sig.id],
                            pageW = pxW,
                            pageH = pxH,
                            isSelected = p.id == selected,
                            onSelect = { onSelect(p.id) },
                            onChange = { f -> onChange(p.id, f) },
                        )
                    }
                }
            }
            Text(
                "${page + 1} / $total",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp),
            )
        }
    }
}

@Composable
private fun SignatureOverlay(
    p: Placed,
    image: ImageBitmap?,
    pageW: Float,
    pageH: Float,
    isSelected: Boolean,
    onSelect: () -> Unit,
    onChange: ((Placed) -> Placed) -> Unit,
) {
    val density = LocalDensity.current
    val pw by rememberUpdatedState(pageW)
    val ph by rememberUpdatedState(pageH)
    val select by rememberUpdatedState(onSelect)
    val change by rememberUpdatedState(onChange)
    val accent = MaterialTheme.colorScheme.primary

    val wPx = p.w * pageW
    val hPx = wPx / p.sig.aspect
    val left = p.cx * pageW - wPx / 2f
    val top = p.cy * pageH - hPx / 2f

    Box(
        Modifier
            .offset { IntOffset(left.roundToInt(), top.roundToInt()) }
            .size(with(density) { wPx.toDp() }, with(density) { hPx.toDp() })
            .pointerInput(Unit) {
                detectTapGestures(onTap = { select() })
            }
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, rotation ->
                    select()
                    change { q ->
                        q.copy(
                            cx = (q.cx + pan.x / pw).coerceIn(0f, 1f),
                            cy = (q.cy + pan.y / ph).coerceIn(0f, 1f),
                            w = (q.w * zoom).coerceIn(MIN_W, MAX_W),
                            rot = q.rot + rotation,
                        )
                    }
                }
            }
            .graphicsLayer { rotationZ = p.rot },
    ) {
        if (image != null) {
            Image(image, "Signature ${p.sig.name}", Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
        }
        if (isSelected) {
            Box(
                Modifier
                    .fillMaxSize()
                    .border(1.5.dp, accent, RoundedCornerShape(4.dp)),
            )
            Box(
                Modifier
                    .align(Alignment.BottomEnd)
                    .size(26.dp)
                    .clip(CircleShape)
                    .background(accent)
                    .border(2.dp, Color.White, CircleShape)
                    .semantics { contentDescription = "Resize signature" }
                    .pointerInput(Unit) {
                        detectDragGestures { c, drag ->
                            c.consume()
                            change { q -> q.copy(w = (q.w + 2f * drag.x / pw).coerceIn(MIN_W, MAX_W)) }
                        }
                    },
            )
        }
    }
}
