package com.doxsy.app.edit

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.provider.DocumentsContract
import com.doxsy.app.annot.TextChar
import com.doxsy.app.pdf.PdfEngine
import com.doxsy.app.pdf.PdfTools
import com.doxsy.app.pdf.ToolResult
import com.doxsy.app.util.FileUtils
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.util.UUID
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

enum class EKind { TEXT, COVER, IMAGE }

/**
 * One edit on a page. Geometry is normalised to the page as DISPLAYED: x, w are fractions of the page
 * width, y, h fractions of the page height (origin top-left). [size] is the text size as a fraction of
 * the page width.
 *
 *  - TEXT  : [x],[y] = top-left, [text]. [cover] (optional) is a box that hides the ORIGINAL text.
 *  - COVER : a filled box (whiteout / blackout) = [x],[y],[w],[h], colour [color].
 *  - IMAGE : a picture = [x],[y],[w],[h]; the bitmap is kept outside, keyed by [id].
 */
data class EditItem(
    val id: String = UUID.randomUUID().toString(),
    val kind: EKind,
    val page: Int,
    val x: Float,
    val y: Float,
    val w: Float = 0f,
    val h: Float = 0f,
    val text: String = "",
    val size: Float = 0.03f,
    val color: Int = Color.BLACK,
    val bold: Boolean = false,
    val font: Int = 0,
    val cover: RectF? = null,
    val coverColor: Int = Color.WHITE,
)

/** The box (normalised) this item paints over the page, if any. */
fun coverRectOf(item: EditItem): RectF? = when (item.kind) {
    EKind.TEXT -> item.cover
    EKind.COVER -> RectF(item.x, item.y, item.x + item.w, item.y + item.h)
    EKind.IMAGE -> null
}

/** Draws edits. The SAME code paints the on-screen preview and the exported PDF, so what you see is what you get. */
object EditPainter {
    fun typefaceFor(font: Int, bold: Boolean): Typeface {
        val family = when (font) {
            1 -> Typeface.SERIF
            2 -> Typeface.MONOSPACE
            else -> Typeface.SANS_SERIF
        }
        return Typeface.create(family, if (bold) Typeface.BOLD else Typeface.NORMAL)
    }

    private fun paintFor(item: EditItem, pageW: Float): Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = item.size * pageW
        color = item.color
        typeface = typefaceFor(item.font, item.bold)
    }

    /** Bounds in pixels of a page that is [pageW] x [pageH] px. */
    fun bounds(item: EditItem, pageW: Float, pageH: Float): RectF = when (item.kind) {
        EKind.TEXT -> {
            val p = paintFor(item, pageW)
            val fm = p.fontMetrics
            val lh = fm.descent - fm.ascent
            val lines = item.text.split('\n')
            val w = max(lines.maxOf { p.measureText(it) }, item.size * pageW * 0.6f)
            val left = item.x * pageW
            val top = item.y * pageH
            RectF(left, top, left + w, top + lh * lines.size)
        }
        else -> RectF(item.x * pageW, item.y * pageH, (item.x + item.w) * pageW, (item.y + item.h) * pageH)
    }

    /** Text size (fraction of page width) that makes [text] about [targetWidthFrac] wide. */
    fun fitSize(text: String, font: Int, bold: Boolean, targetWidthFrac: Float): Float {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.typeface = typefaceFor(font, bold)
        p.textSize = 100f
        val em = text.split('\n').maxOf { p.measureText(it) } / 100f
        if (em <= 0f) return 0.03f
        return (targetWidthFrac / em).coerceIn(0.008f, 0.2f)
    }

    /** Height of one text line as a fraction of the page width. */
    fun lineHeightFrac(size: Float, font: Int, bold: Boolean): Float {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.typeface = typefaceFor(font, bold)
        p.textSize = 1000f
        val fm = p.fontMetrics
        return (fm.descent - fm.ascent) / 1000f * size
    }

    fun draw(canvas: Canvas, pageW: Float, pageH: Float, items: List<EditItem>, images: Map<String, Bitmap>) {
        val fill = Paint()
        // 1. boxes that hide original content
        for (item in items) {
            val r = coverRectOf(item) ?: continue
            fill.color = if (item.kind == EKind.COVER) item.color else item.coverColor
            canvas.drawRect(r.left * pageW, r.top * pageH, r.right * pageW, r.bottom * pageH, fill)
        }
        // 2. pictures
        val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        for (item in items) {
            if (item.kind != EKind.IMAGE) continue
            val bmp = images[item.id] ?: continue
            canvas.drawBitmap(bmp, null, bounds(item, pageW, pageH), bmpPaint)
        }
        // 3. text
        for (item in items) {
            if (item.kind != EKind.TEXT || item.text.isEmpty()) continue
            val p = paintFor(item, pageW)
            val fm = p.fontMetrics
            val lh = fm.descent - fm.ascent
            val left = item.x * pageW
            val top = item.y * pageH
            item.text.split('\n').forEachIndexed { i, line ->
                canvas.drawText(line, left, top - fm.ascent + i * lh, p)
            }
        }
    }

    private fun lum(c: Int): Float = 0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)

    /** Guesses (text colour, background colour) of the page area [r] (normalised) from a rendered page. */
    fun sampleColors(bmp: Bitmap, r: RectF): Pair<Int, Int> {
        val bw = bmp.width
        val bh = bmp.height
        fun px(u: Float, v: Float): Int {
            val x = (u * bw).toInt().coerceIn(0, bw - 1)
            val y = (v * bh).toInt().coerceIn(0, bh - 1)
            return bmp.getPixel(x, y) or (0xFF shl 24)
        }
        val cx = r.centerX()
        val cy = r.centerY()
        val samples = listOf(
            px(r.left - 0.012f, cy), px(r.right + 0.012f, cy),
            px(cx, r.top - 0.006f), px(cx, r.bottom + 0.006f),
        ).sortedBy { lum(it) }
        val bg = samples[samples.size / 2]
        val bgL = lum(bg)
        var best = bg
        var bestDiff = 0f
        val x0 = (r.left * bw).toInt().coerceIn(0, bw - 1)
        val x1 = (r.right * bw).toInt().coerceIn(0, bw - 1)
        val y0 = (r.top * bh).toInt().coerceIn(0, bh - 1)
        val y1 = (r.bottom * bh).toInt().coerceIn(0, bh - 1)
        for (y in y0..y1) for (x in x0..x1) {
            val c = bmp.getPixel(x, y)
            val d = abs(lum(c) - bgL)
            if (d > bestDiff) {
                bestDiff = d
                best = c
            }
        }
        val text = if (bestDiff < 60f) (if (bgL > 128f) Color.BLACK else Color.WHITE) else (best or (0xFF shl 24))
        return Pair(text, bg)
    }
}

class Segment(val text: String, val rect: RectF)

/**
 * The run of text under the tap point (u, v): the characters on the same line that are close together
 * (a table column or a sentence), so one tap edits one "box" of text rather than a whole row.
 */
fun findSegment(chars: List<TextChar>, u: Float, v: Float, aspect: Float): Segment? {
    var best = -1
    var bestD = Float.MAX_VALUE
    for (i in chars.indices) {
        val r = chars[i].rect
        if (r.width() <= 0f) continue
        val dx = max(max(r.left - u, u - r.right), 0f)
        val dy = max(max(r.top - v, v - r.bottom), 0f) * aspect
        val d = hypot(dx, dy)
        if (d < bestD) {
            bestD = d
            best = i
        }
    }
    if (best < 0) return null
    val bc = chars[best]
    if (bestD > max(bc.rect.height() * aspect, 0.008f) * 0.6f) return null
    val line = bc.lineIndex

    val segs = ArrayList<ArrayList<Int>>()
    var cur = ArrayList<Int>()
    var last: TextChar? = null
    for (i in chars.indices) {
        val c = chars[i]
        if (c.lineIndex != line) continue
        if (c.rect.width() <= 0f) {
            if (cur.isNotEmpty()) cur.add(i)
            continue
        }
        val l = last
        if (l != null) {
            val gap = c.rect.left - l.rect.right
            val hgt = max(c.rect.height() * aspect, 0.008f)
            if (gap > hgt || gap < -hgt * 3f) {
                segs.add(cur)
                cur = ArrayList()
            }
        }
        cur.add(i)
        last = c
    }
    if (cur.isNotEmpty()) segs.add(cur)
    val mine = segs.firstOrNull { best in it } ?: return null

    val sb = StringBuilder()
    val rect = RectF()
    var first = true
    for (i in mine) {
        val c = chars[i]
        sb.append(c.ch)
        if (c.rect.width() > 0f) {
            if (first) {
                rect.set(c.rect)
                first = false
            } else {
                rect.union(c.rect)
            }
        }
    }
    val text = sb.toString().replace(Regex("\\s+"), " ").trim()
    if (text.isEmpty() || first) return null
    return Segment(text, rect)
}

object PdfEditExporter {
    /** Draws one page of [file] (as displayed, with its rotation) into [bmp]. */
    private fun renderOriginal(file: File, index: Int, bmp: Bitmap) {
        val pfd = android.os.ParcelFileDescriptor.open(file, android.os.ParcelFileDescriptor.MODE_READ_ONLY)
        try {
            val renderer = android.graphics.pdf.PdfRenderer(pfd)
            try {
                val p = renderer.openPage(index)
                try {
                    p.render(bmp, null, null, android.graphics.pdf.PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                } finally {
                    p.close()
                }
            } finally {
                renderer.close()
            }
        } finally {
            runCatching { pfd.close() }
        }
    }

    /**
     * Writes a NEW PDF = the original pages with the edits painted on top. The original is not changed.
     * With [permanent], every page that has a whiteout / blackout / replaced text is turned into a picture, so the
     * text that was hidden is really gone from the file (it can no longer be selected or copied from that page).
     */
    suspend fun export(
        ctx: Context,
        input: Uri,
        items: List<EditItem>,
        images: Map<String, Bitmap>,
        out: Uri,
        permanent: Boolean = false,
    ): ToolResult =
        withContext(Dispatchers.IO) {
            PdfEngine.init(ctx)
            val cr = ctx.contentResolver
            try {
                val tmp = File(ctx.cacheDir, "doxsy_tmp_edit_${System.nanoTime()}.pdf")
                try {
                    cr.openInputStream(input)?.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                        ?: throw IOException("Could not open the PDF.")
                    PDDocument.load(tmp).use { doc ->
                        val byPage = items.groupBy { it.page }
                        for (pageIdx in byPage.keys.sorted()) {
                            if (pageIdx < 0 || pageIdx >= doc.numberOfPages) continue
                            val page = doc.getPage(pageIdx)
                            val box = page.cropBox ?: page.mediaBox
                            val rot = ((page.rotation % 360) + 360) % 360
                            val dispW = if (rot == 90 || rot == 270) box.height else box.width
                            val dispH = if (rot == 90 || rot == 270) box.width else box.height
                            val scale = (2000f / dispW).coerceIn(1.5f, 4f)
                            val pxW = (dispW * scale).toInt().coerceAtLeast(16)
                            val pxH = (dispH * scale).toInt().coerceAtLeast(16)
                            val pageItems = byPage.getValue(pageIdx)
                            val flatten = permanent && pageItems.any { it.kind == EKind.COVER || (it.kind == EKind.TEXT && it.cover != null) }
                            var bmp = Bitmap.createBitmap(pxW, pxH, Bitmap.Config.ARGB_8888)
                            if (flatten) {
                                bmp.eraseColor(Color.WHITE)
                                renderOriginal(tmp, pageIdx, bmp)
                            }
                            EditPainter.draw(Canvas(bmp), pxW.toFloat(), pxH.toFloat(), byPage.getValue(pageIdx), images)
                            if (rot != 0) {
                                val m = Matrix()
                                m.postRotate(-rot.toFloat())
                                val turned = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                                bmp.recycle()
                                bmp = turned
                            }
                            if (flatten) {
                                val img = com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory.createFromImage(doc, bmp, 0.9f)
                                page.resources = com.tom_roush.pdfbox.pdmodel.PDResources()
                                page.annotations = emptyList()
                                PDPageContentStream(doc, page, PDPageContentStream.AppendMode.OVERWRITE, true, true).use { cs ->
                                    cs.drawImage(img, box.lowerLeftX, box.lowerLeftY, box.width, box.height)
                                }
                            } else {
                                val img = LosslessFactory.createFromImage(doc, bmp)
                                PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                                    cs.drawImage(img, box.lowerLeftX, box.lowerLeftY, box.width, box.height)
                                }
                            }
                            bmp.recycle()
                        }
                        val os = cr.openOutputStream(out, "wt") ?: throw IOException("Could not write the output file.")
                        os.use { doc.save(it) }
                    }
                } finally {
                    tmp.delete()
                }
                ToolResult.Done("Edited PDF saved (${FileUtils.formatSize(PdfTools.querySize(ctx, out))}).")
            } catch (e: CancellationException) {
                runCatching { DocumentsContract.deleteDocument(cr, out) }
                throw e
            } catch (e: Throwable) {
                runCatching { DocumentsContract.deleteDocument(cr, out) }
                ToolResult.Failed(
                    when (e) {
                        is InvalidPasswordException -> "This PDF is password-protected. Remove the password first, then edit it."
                        is OutOfMemoryError -> "Not enough memory. Try editing fewer pages at a time."
                        else -> "Could not save the edited PDF: ${e.message ?: e.javaClass.simpleName}"
                    },
                )
            }
        }
}
