package com.doxsy.app.ai

import com.doxsy.app.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.UnknownHostException

/**
 * Where the AI requests go. Today the app talks to Groq / OpenRouter directly with keys that are built
 * into the APK. To move to your own backend later, replace [providers] with ONE entry that points to the
 * backend URL (same OpenAI-style request) and remove the keys from the build; nothing else changes.
 *
 * [vision]: the model can look at pictures. [files]: the provider reads a PDF file itself (OpenRouter).
 * [docChars]: how much document text one request may carry for this provider.
 */
object AiConfig {
    class Provider(
        val name: String,
        val url: String,
        val key: String,
        val model: String,
        val groq: Boolean,
        val vision: Boolean = false,
        val files: Boolean = false,
        val docChars: Int = 14_000,
        val reasoning: String? = null,
        val maxTokens: Int = 3_000,
    )

    // Groq's Llama 3.x models were shut down on 16 Aug 2026; gpt-oss is the replacement for text,
    // qwen/qwen3.8-27b is Groq's picture-capable model.
    val providers: List<Provider>
        get() = buildList {
            val groq = BuildConfig.GROQ_API_KEY
            val router = BuildConfig.OPENROUTER_API_KEY
            val groqUrl = "https://api.groq.com/openai/v1/chat/completions"
            val routerUrl = "https://openrouter.ai/api/v1/chat/completions"
            if (groq.isNotBlank()) {
                add(Provider("Groq", groqUrl, groq, "openai/gpt-oss-120b", true, reasoning = "low"))
                add(Provider("Groq", groqUrl, groq, "openai/gpt-oss-20b", true, reasoning = "low"))
                add(Provider("Groq", groqUrl, groq, "qwen/qwen3.8-27b", true, vision = true, maxTokens = 4_000))
            }
            if (router.isNotBlank()) {
                add(Provider("OpenRouter", routerUrl, router, "openai/gpt-6.2-astra", false, vision = true, files = true, docChars = 60_000))
                add(Provider("OpenRouter", routerUrl, router, "openrouter/free", false, vision = true, files = true, docChars = 40_000))
            }
        }

    const val MAX_HISTORY = 12
}

class AiMessage(val role: String, val content: String)

class AiException(message: String) : IOException(message)

/**
 * One answer. [thinking] is the model's own reasoning text when the provider returns it ("" otherwise),
 * [seconds] how long the whole request took, [model] which model answered.
 */
class AiReply(val text: String, val thinking: String, val seconds: Int, val model: String)

object AiClient {
    private class Request(val messages: JSONArray, val parsePdf: Boolean)

    private class AiHttpException(val code: Int, message: String, val optionsSent: Boolean = false) : IOException(message)

    /** What one call returned, before the timing is added. */
    private class Raw(val text: String, val thinking: String)

    /**
     * Sends the chat. [att] is the file the user attached: it goes to the AI as the file itself where the
     * model can read it (PDF, pictures) or as its complete text, cut to the relevant parts when it is long.
     * Tries each suitable provider in turn. [cfg] says when the model should think and how deeply; the model's
     * reasoning comes back in [AiReply.thinking].
     */
    suspend fun chat(history: List<AiMessage>, att: AiAttachment?, cfg: ThinkConfig = ThinkConfig()): AiReply = withContext(Dispatchers.IO) {
        val all = AiConfig.providers
        if (all.isEmpty()) throw AiException("AI is not set up in this build (no API key).")
        val providers = ordered(all, att)
        if (providers.isEmpty()) {
            throw AiException("This file needs an AI model that can see pictures, and none is set up in this build.")
        }

        val recent = history.takeLast(AiConfig.MAX_HISTORY)
        val older = history.dropLast(AiConfig.MAX_HISTORY)
        // The last questions decide which parts of a long file are sent, so a short follow-up still works.
        val query = recent.filter { it.role == "user" }.takeLast(2).joinToString(" ") { it.content }
        val latest = recent.lastOrNull { it.role == "user" }?.content.orEmpty()
        val think = AiThinking.wanted(cfg, latest, att != null)

        var lastError = "AI is not available right now."
        var busy = false
        for (p in providers) {
            try {
                val started = System.currentTimeMillis()
                val raw = callAdaptive(p, build(p, recent, older, att, query, latest, think), think, cfg.depth)
                val secs = ((System.currentTimeMillis() - started) / 1000).toInt().coerceAtLeast(1)
                return@withContext AiReply(raw.text, raw.thinking, secs, p.model.substringAfterLast('/'))
            } catch (e: UnknownHostException) {
                throw AiException("No internet connection.")
            } catch (e: AiHttpException) {
                if (e.code == 429) busy = true
                lastError = e.message.orEmpty()
            } catch (e: IOException) {
                lastError = e.message ?: "Network error."
            }
        }
        throw AiException(if (busy) "AI is busy right now. Please try again in a minute." else lastError)
    }

    /** Providers that can use this file; for a PDF the ones that read PDF files themselves come first. */
    private fun ordered(all: List<AiConfig.Provider>, att: AiAttachment?): List<AiConfig.Provider> {
        if (att == null) return all
        val usable = all.filter { p ->
            (att.pdf != null && p.files) || att.hasText || (att.images.isNotEmpty() && p.vision)
        }
        return if (att.pdf != null) usable.sortedByDescending { it.files } else usable
    }

    private fun build(
        p: AiConfig.Provider,
        history: List<AiMessage>,
        older: List<AiMessage>,
        att: AiAttachment?,
        query: String,
        latest: String,
        think: Boolean,
    ): Request {
        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", AiPrompt.system(latest, think)))
        AiPrompt.earlier(older).takeIf { it.isNotBlank() }?.let {
            messages.put(JSONObject().put("role", "system").put("content", it))
        }

        // Extra parts (the PDF file, pictures) that travel with the user's last message.
        val extra = JSONArray()
        var parsePdf = false

        if (att != null) {
            val useFile = att.pdf != null && p.files
            val useImages = !useFile && att.images.isNotEmpty() && p.vision
            val shown = if (useFile || !att.hasText) "" else AiContext.select(att.text, query, p.docChars)

            val sys = StringBuilder()
            when {
                useFile -> sys.append("The user attached the PDF file \"${att.name}\" (it is sent with the user's message).")
                useImages && !att.hasText -> sys.append(
                    "The user attached \"${att.name}\" as picture(s) (sent with the user's message). " +
                        "Look at them carefully and read any text in them.",
                )
                else -> sys.append("The user attached the file \"${att.name}\".")
            }
            sys.append(" Answer from it when the question is about it; if the answer is not in it, say so.")
            if (shown.isNotBlank()) {
                if (shown.length < att.text.length) {
                    sys.append(
                        " The file is long, so only its most relevant parts are shown, marked like [… part 3 of 20 …]. " +
                            "If the answer may be in a part you cannot see, say so.",
                    )
                }
                sys.append("\n\nFile text:\n\n").append(shown)
            }
            messages.put(JSONObject().put("role", "system").put("content", sys.toString()))

            if (useFile) {
                val fileName = if (att.name.endsWith(".pdf", ignoreCase = true)) att.name else att.name + ".pdf"
                extra.put(
                    JSONObject().put("type", "file").put(
                        "file",
                        JSONObject().put("filename", fileName).put("file_data", att.pdf),
                    ),
                )
                parsePdf = true
            }
            if (useImages) {
                for (url in att.images) {
                    extra.put(
                        JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", url)),
                    )
                }
            }
        }

        val lastUser = history.indexOfLast { it.role == "user" }
        history.forEachIndexed { i, m ->
            val o = JSONObject().put("role", m.role)
            if (i == lastUser && extra.length() > 0) {
                val parts = JSONArray().put(JSONObject().put("type", "text").put("text", m.content))
                for (k in 0 until extra.length()) parts.put(extra.get(k))
                o.put("content", parts)
            } else {
                o.put("content", m.content)
            }
            messages.put(o)
        }
        return Request(messages, parsePdf)
    }

    /**
     * Calls one provider. If it refuses a thinking option, that is remembered for this model and the same request
     * is sent once more without any, so thinking can never break the chat.
     */
    private fun callAdaptive(p: AiConfig.Provider, req: Request, think: Boolean, depth: ThinkDepth): Raw {
        try {
            return call(p, req, think, depth)
        } catch (e: AiHttpException) {
            if (e.optionsSent && AiThinking.isOptionError(e.code, e.message.orEmpty())) {
                AiThinking.markRefused(p)
                return call(p, req, think, depth)
            }
            throw e
        }
    }

    private fun call(p: AiConfig.Provider, req: Request, think: Boolean, depth: ThinkDepth): Raw {
        val body = JSONObject()
            .put("model", p.model)
            .put("messages", req.messages)
            .put("temperature", 0.4)
            .put("max_tokens", p.maxTokens)
        val optionsSent = AiThinking.apply(body, p, think, depth)
        if (req.parsePdf) {
            // The free text parser: a PDF that has text needs no paid OCR.
            body.put(
                "plugins",
                JSONArray().put(JSONObject().put("id", "file-parser").put("pdf", JSONObject().put("engine", "cloudflare-ai"))),
            )
        }

        val c = URL(p.url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15_000
            c.readTimeout = 120_000
            c.doOutput = true
            c.setRequestProperty("Authorization", "Bearer ${p.key}")
            c.setRequestProperty("Content-Type", "application/json")
            if (!p.groq) {
                c.setRequestProperty("HTTP-Referer", "https://doxsy.app")
                c.setRequestProperty("X-Title", "Doxsy")
            }
            val bytes = body.toString().toByteArray()
            c.setFixedLengthStreamingMode(bytes.size)
            c.outputStream.use { it.write(bytes) }

            val code = c.responseCode
            if (code !in 200..299) {
                val err = runCatching { c.errorStream?.bufferedReader()?.readText().orEmpty() }.getOrDefault("")
                val detail = runCatching { JSONObject(err).optJSONObject("error")?.optString("message") }.getOrNull()
                    ?.takeIf { it.isNotBlank() } ?: err.take(120)
                throw AiHttpException(code, "${p.name}: HTTP $code ${detail.take(140)}", optionsSent)
            }
            val json = JSONObject(c.inputStream.bufferedReader().readText())
            val message = json.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")
            val text = AiThinking.answerOf(message)
            if (text.isBlank()) throw AiHttpException(0, "${p.name}: empty answer")
            return Raw(text, AiThinking.reasoningOf(message))
        } finally {
            c.disconnect()
        }
    }
}
