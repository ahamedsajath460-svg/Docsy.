package com.doxsy.app.ai

import com.doxsy.app.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.UnknownHostException

/**
 * Where the AI requests go. Today the app talks to Groq / OpenRouter directly with keys that are built
 * into the APK. To move to your own backend later, replace [providers] with ONE entry that points to the
 * backend URL (same OpenAI-style request) and remove the keys from the build; nothing else changes.
 */
object AiConfig {
    class Provider(val name: String, val url: String, val key: String, val model: String, val groq: Boolean)

    // Groq's Llama 3.x models were shut down on 16 Aug 2026; gpt-oss is the replacement.
    val providers: List<Provider>
        get() = buildList {
            val groq = BuildConfig.GROQ_API_KEY
            val router = BuildConfig.OPENROUTER_API_KEY
            if (groq.isNotBlank()) {
                add(Provider("Groq", "https://api.groq.com/openai/v1/chat/completions", groq, "openai/gpt-oss-120b", true))
                add(Provider("Groq", "https://api.groq.com/openai/v1/chat/completions", groq, "openai/gpt-oss-20b", true))
            }
            if (router.isNotBlank()) {
                add(Provider("OpenRouter", "https://openrouter.ai/api/v1/chat/completions", router, "openai/gpt-6.2-astra", false))
                add(Provider("OpenRouter", "https://openrouter.ai/api/v1/chat/completions", router, "openrouter/free", false))
            }
        }

    const val MAX_DOC_CHARS = 14_000
    const val MAX_HISTORY = 12
}

class AiMessage(val role: String, val content: String)

class AiException(message: String) : IOException(message)

object AiClient {
    private const val SYSTEM = "You are Doxsy AI, the assistant inside the Doxsy PDF and documents app. " +
        "Be clear, accurate and concise. Reply in the language the user writes in " +
        "(if they write Tamil in English letters, reply the same way). Use short paragraphs or bullet points."

    /** Sends the chat. [docText] is the attached document's text (already shortened). Tries each provider in turn. */
    suspend fun chat(history: List<AiMessage>, docName: String?, docText: String?): String = withContext(Dispatchers.IO) {
        val providers = AiConfig.providers
        if (providers.isEmpty()) throw AiException("AI is not set up in this build (no API key).")

        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", SYSTEM))
        if (!docText.isNullOrBlank()) {
            messages.put(
                JSONObject().put("role", "system").put(
                    "content",
                    "The user attached the document \"${docName.orEmpty()}\". Answer from it when the question is about it. " +
                        "Document text:\n\n$docText",
                ),
            )
        }
        history.takeLast(AiConfig.MAX_HISTORY).forEach {
            messages.put(JSONObject().put("role", it.role).put("content", it.content))
        }

        var lastError = "AI is not available right now."
        var busy = false
        for (p in providers) {
            try {
                return@withContext call(p, messages)
            } catch (e: UnknownHostException) {
                throw AiException("No internet connection.")
            } catch (e: AiHttpException) {
                if (e.code == 429) busy = true
                lastError = e.message.orEmpty()
            } catch (e: IOException) {
                lastError = e.message ?: "Network error."
            }
        }
        throw AiException(if (busy) "AI is busy right now. Please try again in a minute." else lastError)
    }

    private class AiHttpException(val code: Int, message: String) : IOException(message)

    private fun call(p: AiConfig.Provider, messages: JSONArray): String {
        val body = JSONObject()
            .put("model", p.model)
            .put("messages", messages)
            .put("temperature", 0.4)
            .put("max_tokens", 2000)
        if (p.groq) body.put("reasoning_effort", "low")

        val c = URL(p.url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15_000
            c.readTimeout = 90_000
            c.doOutput = true
            c.setRequestProperty("Authorization", "Bearer ${p.key}")
            c.setRequestProperty("Content-Type", "application/json")
            if (!p.groq) {
                c.setRequestProperty("HTTP-Referer", "https://doxsy.app")
                c.setRequestProperty("X-Title", "Doxsy")
            }
            val bytes = body.toString().toByteArray()
            c.setFixedLengthStreamingMode(bytes.size)
            c.outputStream.use { it.write(bytes) }

            val code = c.responseCode
            if (code !in 200..299) {
                val err = runCatching { c.errorStream?.bufferedReader()?.readText().orEmpty() }.getOrDefault("")
                val detail = runCatching { JSONObject(err).optJSONObject("error")?.optString("message") }.getOrNull()
                    ?.takeIf { it.isNotBlank() } ?: err.take(120)
                throw AiHttpException(code, "${p.name}: HTTP $code ${detail.take(140)}")
            }
            val json = JSONObject(c.inputStream.bufferedReader().readText())
            val text = json.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")
                ?.optString("content").orEmpty().trim()
            if (text.isBlank()) throw AiHttpException(0, "${p.name}: empty answer")
            return text
        } finally {
            c.disconnect()
        }
    }
}
