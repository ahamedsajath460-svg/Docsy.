package com.doxsy.app.ai

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AiThinkingTest {
    private fun groq(model: String) = AiConfig.Provider("Groq", "u", "k", model, true, reasoning = "low", maxTokens = 3_000)
    private fun router(model: String) = AiConfig.Provider("OpenRouter", "u", "k", model, false)

    @Test fun greetingsAreChitChat() {
        for (t in listOf("hi", "Hello!", "thanks", "vanakkam", "eppadi irukka", "நன்றி", "வணக்கம்", "ok cool", "good morning")) {
            assertTrue("chit: $t", AiThinking.isChit(t))
        }
    }

    @Test fun realQuestionsAreNotChitChat() {
        for (t in listOf("summarize this document", "what is 12 + 15 * 3", "eppadi pdf compress panrathu", "Explain how PDF works")) {
            assertFalse("not chit: $t", AiThinking.isChit(t))
        }
    }

    @Test fun hardQuestionsNeedThinking() {
        assertTrue(AiThinking.needsThinking("Solve 3x + 5 = 20"))
        assertTrue(AiThinking.needsThinking("compare the two contracts"))
        assertTrue(AiThinking.needsThinking("12 + 15 * 3"))
        assertTrue(AiThinking.needsThinking("இந்த kanakku sari-ya?"))
        assertTrue(AiThinking.needsThinking("a".repeat(701)))
        assertFalse(AiThinking.needsThinking("Write a short email asking for a meeting"))
        assertFalse(AiThinking.needsThinking("நன்றி"))
    }

    @Test fun wantedFollowsTheSettings() {
        val auto = ThinkConfig(always = false, auto = true)
        assertTrue(AiThinking.wanted(auto, "Solve 3x + 5 = 20", false))
        assertFalse(AiThinking.wanted(auto, "Write a short email", false))
        assertFalse(AiThinking.wanted(ThinkConfig(auto = false), "Solve 3x + 5 = 20", false))
        assertTrue(AiThinking.wanted(ThinkConfig(always = true), "Write a short email", false))
        // small talk stays fast even with "Think deeper", unless a file is attached
        assertFalse(AiThinking.wanted(ThinkConfig(always = true), "hi", false))
        assertTrue(AiThinking.wanted(ThinkConfig(always = true), "hi", true))
    }

    @Test fun groqGptOssUsesEffortAndIncludeReasoning() {
        val b = JSONObject().put("max_tokens", 3_000)
        assertTrue(AiThinking.apply(b, groq("openai/gpt-oss-120b"), true, ThinkDepth.HIGH))
        assertEquals("high", b.getString("reasoning_effort"))
        assertTrue(b.getBoolean("include_reasoning"))
        assertFalse(b.has("reasoning_format"))
        assertEquals(3_000 + ThinkDepth.HIGH.extraTokens, b.getInt("max_tokens"))
    }

    @Test fun groqGptOssQuickStaysLow() {
        val b = JSONObject().put("max_tokens", 3_000)
        AiThinking.apply(b, groq("openai/gpt-oss-20b"), false, ThinkDepth.HIGH)
        assertEquals("low", b.getString("reasoning_effort"))
        assertFalse(b.getBoolean("include_reasoning"))
        assertEquals(3_000, b.getInt("max_tokens"))
    }

    @Test fun groqQwenUsesParsedFormat() {
        val on = JSONObject()
        AiThinking.apply(on, groq("qwen/qwen3.8-27b"), true, ThinkDepth.MEDIUM)
        assertEquals("parsed", on.getString("reasoning_format"))
        assertEquals("medium", on.getString("reasoning_effort"))
        val off = JSONObject()
        AiThinking.apply(off, groq("qwen/qwen3.8-27b"), false, ThinkDepth.MEDIUM)
        assertEquals("none", off.getString("reasoning_effort"))
    }

    @Test fun openRouterOnlyWhenThinking() {
        val on = JSONObject()
        assertTrue(AiThinking.apply(on, router("openrouter/free"), true, ThinkDepth.LOW))
        assertEquals("low", on.getJSONObject("reasoning").getString("effort"))
        assertFalse(AiThinking.apply(JSONObject(), router("openrouter/free"), false, ThinkDepth.LOW))
    }

    @Test fun refusedModelIsRememberedAndSentPlain() {
        val p = groq("openai/gpt-oss-test-refused")
        assertTrue(AiThinking.isOptionError(400, "Groq: HTTP 400 reasoning_effort is not supported"))
        assertFalse(AiThinking.isOptionError(400, "file too large"))
        assertFalse(AiThinking.isOptionError(401, "invalid effort key"))
        AiThinking.markRefused(p)
        val b = JSONObject()
        assertFalse(AiThinking.apply(b, p, true, ThinkDepth.MEDIUM))
        assertFalse(b.has("reasoning_effort"))
    }

    @Test fun reasoningAndAnswerAreSeparated() {
        val parsed = JSONObject().put("content", "Answer").put("reasoning", "because")
        assertEquals("because", AiThinking.reasoningOf(parsed))
        assertEquals("Answer", AiThinking.answerOf(parsed))
        val raw = JSONObject().put("content", "<think>step 1</think>\nFinal")
        assertEquals("step 1", AiThinking.reasoningOf(raw))
        assertEquals("Final", AiThinking.answerOf(raw))
        val cut = JSONObject().put("content", "<think>never finished")
        assertEquals("", AiThinking.answerOf(cut))
        val nullReasoning = JSONObject().put("content", "ok").put("reasoning", JSONObject.NULL)
        assertEquals("", AiThinking.reasoningOf(nullReasoning))
    }

    @Test fun promptHasLanguageRuleAndMemory() {
        assertTrue(AiPrompt.languageRule("வணக்கம் நண்பா").contains("Tamil script"))
        assertTrue(AiPrompt.languageRule("eppadi irukku").contains("Tamil typed in English letters"))
        assertTrue(AiPrompt.system("hi", true).contains("Reasoning mode"))
        assertFalse(AiPrompt.system("hi", false).contains("Reasoning mode"))
        assertEquals("", AiPrompt.earlier(emptyList()))
        val m = AiPrompt.earlier(listOf(AiMessage("user", "What is the deadline?"), AiMessage("assistant", "March 3.")))
        assertTrue(m.contains("- User: What is the deadline?") && m.contains("- AI: March 3."))
    }
}
