# Doxsy AI: chat intelligence + thinking (ported from Zen AI)

## What is new
- **Thinking** (same three controls as Zen AI), lightbulb in the chat top bar:
  *Think deeper* (think for every message), *Auto-think* (default ON: only hard questions such as maths, logic,
  compare / verify / calculate, long questions), *Thinking depth* Low / Medium / High (default Medium). Saved on the phone.
- Greetings and small talk (English, Tamil, Tamil typed in English letters) never think, so they stay fast.
- The model's reasoning is shown in a collapsible "Reasoning · answered in N s" block above the answer
  (only when the provider returns it).
- **Smarter prompt** (`AiPrompt.kt`): current date/time, Zen's language rule (Tamil script / Sinhala script / same style as the user),
  accuracy rules (no invented facts, check calculations, answer from the file and say so when it is not there),
  Markdown limited to what the chat can draw, and a reasoning line when thinking is on.
- **Conversation memory**: only the last 12 messages go in full; older ones are no longer dropped silently, a short digest of them is sent.
- **Provider-correct thinking** (`AiThinking.kt`), verified against Groq's reasoning docs:
  Groq gpt-oss: `reasoning_effort` + `include_reasoning` (no `reasoning_format`, it is not supported there);
  Groq Qwen3.8: `reasoning_format: parsed` + `reasoning_effort` (`none` for quick questions);
  OpenRouter: `reasoning {effort}` + `include_reasoning`.
  If a provider rejects a thinking option (HTTP 400/422 that mentions it) the request is repeated once without it and the model is
  remembered as "no thinking" until the app is closed. Other errors are not retried this way.

## Files
New: `ai/AiThinking.kt`, `ai/AiPrompt.kt`, `app/src/test/.../AiThinkingTest.kt`.
Changed: `ai/AiClient.kt` (`chat()` now returns `AiReply`, takes a `ThinkConfig`), `ui/ai/AiChatScreen.kt`, `app/build.gradle.kts` (JUnit + org.json for tests only).

## Not checked
Not compiled and not run on a device: the authoring environment had no Kotlin compiler / Android SDK / network.
The detection regexes were checked against the test sentences in Node. Run `./gradlew testDebugUnitTest` then `./gradlew assembleDebug`.
Thinking text only appears for models that return it; its time label is the whole request time (the app does not stream).
